package cnk.air_commercialscalculationengine.suppliertransactionalrules;

public class SegmentFeesCommercialCalculation {


	   static final long serialVersionUID = 1L;

	   private java.lang.String selectedRow;
	   private java.lang.String baseSelectedRow;	 

   private cnk.air_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake bri;	   

	   public SegmentFeesCommercialCalculation()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }

	   public java.lang.String getBaseSelectedRow()
	   {
	      return this.baseSelectedRow;
	   }

	   public void setBaseSelectedRow(java.lang.String baseSelectedRow)
	   {
	      this.baseSelectedRow = baseSelectedRow;
	   }	

   public cnk.air_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake getBri()
   {
      return this.bri;
   }

   public void setBri(
         cnk.air_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake bri)
   {
      this.bri = bri;
   }

   public SegmentFeesCommercialCalculation(
         java.lang.String selectedRow,
         java.lang.String baseSelectedRow,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake bri)
   {
      this.selectedRow = selectedRow;
      this.baseSelectedRow = baseSelectedRow;
      this.bri = bri;
   } 	   
	   
}
