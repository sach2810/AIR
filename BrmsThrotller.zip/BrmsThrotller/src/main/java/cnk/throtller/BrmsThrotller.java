package cnk.throtller;

import java.io.InputStream;
import java.util.TreeMap;

import org.json.JSONObject;
import cnk.configuration.Configuration;
import cnk.configuration.StoreBRMSresponse;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONTokener;
/*import java.io.File;
import org.apache.commons.io.FileUtils;*/

@Path("/cce")
public class BrmsThrotller {

	@Path("{productName}")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response createRule(InputStream ip,@PathParam("productName") String productName){
		JSONTokener jt = new JSONTokener(ip);
		JSONObject data = new JSONObject(jt);
		try {
			JSONObject output = Configuration.split(data,productName);
			StoreBRMSresponse.error=false;
			StoreBRMSresponse.errorMessage = new JSONObject();
			StoreBRMSresponse.mBRMSTree = new TreeMap<Integer, JSONObject>();
			return Response.status(200).entity(output.toString()).build();
		}
		catch(Exception e){
			StoreBRMSresponse.error=false;
			StoreBRMSresponse.errorMessage = new JSONObject();
			StoreBRMSresponse.mBRMSTree = new TreeMap<Integer, JSONObject>();
			e.printStackTrace();
		}
		return Response.status(500).entity("{ \"Status\": \"Failure\" }").build();
	}

	/*public static void main(String[] args){
		try {
			long start  =System.currentTimeMillis();
			String content = FileUtils.readFileToString(new File("D:\\AVAMAR BACKUP\\Milan Tank\\Desktop\\cce_acco_clientTrans_1Hotel_500Rooms_RQ.json"), "utf-8");
			JSONObject data = new JSONObject(content);
			Configuration.split(data,"accommodation");
			System.out.println(System.currentTimeMillis()-start);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/


}
