package cnk.products;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.configuration.Constants;
import cnk.configuration.HitBRMS;
import cnk.configuration.StoreBRMSresponse;
import cnk.configuration.ThreadPoolConfig;
import cnk.maven.MavenInvoker;

public class Air implements Constants {

	public static JSONObject splitAir(JSONObject template) throws JSONException, Exception{
		JSONObject clientTransactionalRules = template.getJSONArray(COMMANDS).getJSONObject(0).getJSONObject(INSERT).getJSONObject(OBJECT).getJSONObject(AIR_JSON_OBJECTNAME);
		JSONObject businessRuleIntake = clientTransactionalRules.getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		JSONObject briClone = new JSONObject(new JSONTokener(businessRuleIntake.toString()));
		briClone.remove(JOURNEY_DETAILS);
		clientTransactionalRules.put(BUSINESS_RULE_INTAKE, new JSONArray().put(briClone));

		int configuredRoomsCount = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(AIR_CONFIG_COUNT));
		JSONArray passengers = new JSONArray();
		JSONArray journey = new JSONArray();
		int counter=0, hotelIndex=-1;
		JSONArray temp = new JSONArray();
		Map<Integer, Integer> sequenceMAp = new HashMap<Integer, Integer>();

		JSONArray journeyDetails = businessRuleIntake.getJSONArray(JOURNEY_DETAILS);
		for(int i=0;i<journeyDetails.length();){
			hotelIndex++;
			JSONObject hotelObject = journeyDetails.getJSONObject(i);
			JSONArray passengerDetails = hotelObject.getJSONArray(PAX_DETAILS);
			if(passengerDetails.length()<=configuredRoomsCount){
				counter+= passengerDetails.length();
				if(counter>=configuredRoomsCount){
					counter=0;
					briClone.put(JOURNEY_DETAILS, journey);
					clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
					sequenceMAp.put(temp.length(), hotelIndex);
					temp.put(new JSONObject(new JSONTokener(template.toString())));
					journey=new JSONArray();
				}else{
					journey.put(hotelObject);
					journeyDetails.remove(0);
				}
			}else{
				for(int j=0;j<passengerDetails.length();){
					++counter;
					if(counter<=configuredRoomsCount){
						passengers.put(passengerDetails.getJSONObject(j));
						passengerDetails.remove(0);
					}else{
						counter=0;
						JSONObject journeyDetailsTemp = new JSONObject(new JSONTokener(hotelObject.toString()));
						journeyDetailsTemp.remove(PAX_DETAILS);
						journeyDetailsTemp.put(PAX_DETAILS, passengers);
						journey.put(journeyDetailsTemp);
						briClone.put(JOURNEY_DETAILS, journey);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), hotelIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						journey=new JSONArray();
						passengers=new JSONArray();
					}
				}
				if(counter!=0 && passengers.length()>0){
					JSONObject journeyDetailsTemp = new JSONObject(new JSONTokener(hotelObject.toString()));
					journeyDetailsTemp.remove(PAX_DETAILS);
					journeyDetailsTemp.put(PAX_DETAILS, passengers);
					journey.put(journeyDetailsTemp);
					//if(passengers.length()>=configuredRoomsCount){
						briClone.put(JOURNEY_DETAILS, journey);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), hotelIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						journey=new JSONArray();
						journeyDetails.remove(i);
					//}
				}
			}
		}
		if(journey.length()>0){
			briClone.put(JOURNEY_DETAILS, journey);
			clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
			sequenceMAp.put(temp.length(), hotelIndex);
			temp.put(new JSONObject(new JSONTokener(template.toString())));
		}
		
		ThreadPoolConfig.loadConfig();
		//Thread splitter
		StoreBRMSresponse searchListener = new StoreBRMSresponse(temp.length());
		for(int k=0;k<temp.length();k++) {
			HitBRMS hit = new HitBRMS(temp.getJSONObject(k),searchListener);
			ThreadPoolConfig.execute(hit);
		}

		synchronized(searchListener) {
			searchListener.wait(10*1000);
		}
		
		return StoreBRMSresponse.getCombinedResponse(sequenceMAp,JOURNEY_DETAILS,PAX_DETAILS,AIR_JSON_OBJECTNAME);
	}
}
