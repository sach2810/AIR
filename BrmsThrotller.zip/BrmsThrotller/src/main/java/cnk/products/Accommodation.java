package cnk.products;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.configuration.Constants;
import cnk.configuration.HitBRMS;
import cnk.configuration.StoreBRMSresponse;
import cnk.configuration.ThreadPoolConfig;
import cnk.maven.MavenInvoker;

public class Accommodation implements Constants {

	public static JSONObject splitAccommodation(JSONObject template) throws JSONException, Exception{
		JSONObject clientTransactionalRules = template.getJSONArray(COMMANDS).getJSONObject(0).getJSONObject(INSERT).getJSONObject(OBJECT).getJSONObject(ACCO_JSON_OBJECTNAME);
		JSONObject businessRuleIntake = clientTransactionalRules.getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		JSONObject briClone = new JSONObject(new JSONTokener(businessRuleIntake.toString()));
		briClone.remove(HOTEL_DETAILS);
		clientTransactionalRules.put(BUSINESS_RULE_INTAKE, new JSONArray().put(briClone));

		int configuredRoomsCount = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(ACCO_CONFIG_COUNT));
		JSONArray rooms = new JSONArray();
		JSONArray hotels = new JSONArray();
		int counter=0, hotelIndex=-1;
		JSONArray temp = new JSONArray();
		Map<Integer, Integer> sequenceMAp = new HashMap<Integer, Integer>();

		JSONArray hotelDetails = businessRuleIntake.getJSONArray(HOTEL_DETAILS);
		for(int i=0;i<hotelDetails.length();){
			hotelIndex++;
			JSONObject hotelObject = hotelDetails.getJSONObject(i);
			JSONArray roomDetails = hotelObject.getJSONArray(ROOM_DETAILS);
			if(roomDetails.length()<=configuredRoomsCount){
				counter+= roomDetails.length();
				if(counter>=configuredRoomsCount){
					counter=0;
					briClone.put(HOTEL_DETAILS, hotels);
					clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
					sequenceMAp.put(temp.length(), hotelIndex);
					temp.put(new JSONObject(new JSONTokener(template.toString())));
					hotels=new JSONArray();
				}else{
					hotels.put(hotelObject);
					hotelDetails.remove(0);
				}
			}else{
				for(int j=0;j<roomDetails.length();){
					++counter;
					if(counter<=configuredRoomsCount){
						rooms.put(roomDetails.getJSONObject(j));
						roomDetails.remove(0);
					}else{
						counter=0;
						JSONObject hotelDetailsTemp = new JSONObject(new JSONTokener(hotelObject.toString()));
						hotelDetailsTemp.remove(ROOM_DETAILS);
						hotelDetailsTemp.put(ROOM_DETAILS, rooms);
						hotels.put(hotelDetailsTemp);
						briClone.put(HOTEL_DETAILS, hotels);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), hotelIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						hotels=new JSONArray();
						rooms=new JSONArray();
					}
				}
				if(counter!=0 && rooms.length()>0){
					JSONObject hotelDetailsTemp = new JSONObject(new JSONTokener(hotelObject.toString()));
					hotelDetailsTemp.remove(ROOM_DETAILS);
					hotelDetailsTemp.put(ROOM_DETAILS, rooms);
					hotels.put(hotelDetailsTemp);
					//if(rooms.length()>=configuredRoomsCount){
						briClone.put(HOTEL_DETAILS, hotels);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), hotelIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						hotels=new JSONArray();
						hotelDetails.remove(i);
					//}
				}
			}
		}
		if(hotels.length()>0){
			briClone.put(HOTEL_DETAILS, hotels);
			clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
			sequenceMAp.put(temp.length(), hotelIndex);
			temp.put(new JSONObject(new JSONTokener(template.toString())));
		}
		
		ThreadPoolConfig.loadConfig();
		//Thread splitter
		StoreBRMSresponse searchListener = new StoreBRMSresponse(temp.length());
		for(int k=0;k<temp.length();k++) {
			HitBRMS hit = new HitBRMS(temp.getJSONObject(k),searchListener);
			ThreadPoolConfig.execute(hit);
		}

		synchronized(searchListener) {
			searchListener.wait(10*1000);
		}
		
		return StoreBRMSresponse.getCombinedResponse(sequenceMAp,HOTEL_DETAILS,ROOM_DETAILS,ACCO_JSON_OBJECTNAME);
	}
}
