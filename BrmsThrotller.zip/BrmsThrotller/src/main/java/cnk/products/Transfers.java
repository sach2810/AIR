package cnk.products;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.configuration.Constants;
import cnk.configuration.HitBRMS;
import cnk.configuration.StoreBRMSresponse;
import cnk.configuration.ThreadPoolConfig;
import cnk.maven.MavenInvoker;

public class Transfers implements Constants {

	public static JSONObject splitTransfers(JSONObject template) throws JSONException, Exception{
		JSONObject clientTransactionalRules = template.getJSONArray(COMMANDS).getJSONObject(0).getJSONObject(INSERT).getJSONObject(OBJECT).getJSONObject(TRANSFERS_JSON_OBJECTNAME);
		JSONObject businessRuleIntake = clientTransactionalRules.getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		JSONObject briClone = new JSONObject(new JSONTokener(businessRuleIntake.toString()));
		briClone.remove(TRANSFERS_DETAILS);
		clientTransactionalRules.put(BUSINESS_RULE_INTAKE, new JSONArray().put(briClone));

		int configuredRoomsCount = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(TRANSFERS_CONFIG_COUNT));
		JSONArray passengers = new JSONArray();
		JSONArray transfers = new JSONArray();
		int counter=0, transferIndex=-1;
		JSONArray temp = new JSONArray();
		Map<Integer, Integer> sequenceMAp = new HashMap<Integer, Integer>();

		JSONArray transferDetails = businessRuleIntake.getJSONArray(TRANSFERS_DETAILS);
		for(int i=0;i<transferDetails.length();){
			transferIndex++;
			JSONObject transferObject = transferDetails.getJSONObject(i);
			JSONArray passengerDetails = transferObject.getJSONArray(PAX_DETAILS);
			if(passengerDetails.length()<=configuredRoomsCount){
				counter+= passengerDetails.length();
				if(counter>=configuredRoomsCount){
					counter=0;
					briClone.put(TRANSFERS_DETAILS, transfers);
					clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
					sequenceMAp.put(temp.length(), transferIndex);
					temp.put(new JSONObject(new JSONTokener(template.toString())));
					transfers=new JSONArray();
				}else{
					transfers.put(transferObject);
					transferDetails.remove(0);
				}
			}else{
				for(int j=0;j<passengerDetails.length();){
					++counter;
					if(counter<=configuredRoomsCount){
						passengers.put(passengerDetails.getJSONObject(j));
						passengerDetails.remove(0);
					}else{
						counter=0;
						JSONObject transferDetailsTemp = new JSONObject(new JSONTokener(transferObject.toString()));
						transferDetailsTemp.remove(PAX_DETAILS);
						transferDetailsTemp.put(PAX_DETAILS, passengers);
						transfers.put(transferDetailsTemp);
						briClone.put(TRANSFERS_DETAILS, transfers);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), transferIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						transfers=new JSONArray();
						passengers=new JSONArray();
					}
				}
				if(counter!=0 && passengers.length()>0){
					JSONObject transferDetailsTemp = new JSONObject(new JSONTokener(transferObject.toString()));
					transferDetailsTemp.remove(PAX_DETAILS);
					transferDetailsTemp.put(PAX_DETAILS, passengers);
					transfers.put(transferDetailsTemp);
					//if(passengers.length()>=configuredRoomsCount){
						briClone.put(TRANSFERS_DETAILS, transfers);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), transferIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						transfers=new JSONArray();
						transferDetails.remove(i);
					//}
				}
			}
		}
		if(transfers.length()>0){
			briClone.put(TRANSFERS_DETAILS, transfers);
			clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
			sequenceMAp.put(temp.length(), transferIndex);
			temp.put(new JSONObject(new JSONTokener(template.toString())));
		}
		
		ThreadPoolConfig.loadConfig();
		//Thread splitter
		StoreBRMSresponse searchListener = new StoreBRMSresponse(temp.length());
		for(int k=0;k<temp.length();k++) {
			HitBRMS hit = new HitBRMS(temp.getJSONObject(k),searchListener);
			ThreadPoolConfig.execute(hit);
		}

		synchronized(searchListener) {
			searchListener.wait(10*1000);
		}
		
		return StoreBRMSresponse.getCombinedResponse(sequenceMAp,TRANSFERS_DETAILS,PAX_DETAILS,TRANSFERS_JSON_OBJECTNAME);
	}
}
