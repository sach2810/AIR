package cnk.products;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.configuration.Constants;
import cnk.configuration.HitBRMS;
import cnk.configuration.StoreBRMSresponse;
import cnk.configuration.ThreadPoolConfig;
import cnk.maven.MavenInvoker;

public class Bus implements Constants {

	public static JSONObject splitBus(JSONObject template) throws JSONException, Exception{
		JSONObject clientTransactionalRules = template.getJSONArray(COMMANDS).getJSONObject(0).getJSONObject(INSERT).getJSONObject(OBJECT).getJSONObject(BUS_JSON_OBJECTNAME);
		JSONObject businessRuleIntake = clientTransactionalRules.getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		JSONObject briClone = new JSONObject(new JSONTokener(businessRuleIntake.toString()));
		briClone.remove(BUS_SERVICE_DETAILS);
		clientTransactionalRules.put(BUSINESS_RULE_INTAKE, new JSONArray().put(briClone));

		int configuredRoomsCount = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(BUS_CONFIG_COUNT));
		JSONArray passengers = new JSONArray();
		JSONArray busServices = new JSONArray();
		int counter=0, busServiceIndex=-1;
		JSONArray temp = new JSONArray();
		Map<Integer, Integer> sequenceMAp = new HashMap<Integer, Integer>();

		JSONArray busServiceDetails = businessRuleIntake.getJSONArray(BUS_SERVICE_DETAILS);
		for(int i=0;i<busServiceDetails.length();){
			busServiceIndex++;
			JSONObject busServiceObject = busServiceDetails.getJSONObject(i);
			JSONArray passengerDetails = busServiceObject.getJSONArray(PAX_DETAILS);
			if(passengerDetails.length()<=configuredRoomsCount){
				counter+= passengerDetails.length();
				if(counter>=configuredRoomsCount){
					counter=0;
					briClone.put(BUS_SERVICE_DETAILS, busServices);
					clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
					sequenceMAp.put(temp.length(), busServiceIndex);
					temp.put(new JSONObject(new JSONTokener(template.toString())));
					busServices=new JSONArray();
				}else{
					busServices.put(busServiceObject);
					busServiceDetails.remove(0);
				}
			}else{
				for(int j=0;j<passengerDetails.length();){
					++counter;
					if(counter<=configuredRoomsCount){
						passengers.put(passengerDetails.getJSONObject(j));
						passengerDetails.remove(0);
					}else{
						counter=0;
						JSONObject busServiceDetailsTemp = new JSONObject(new JSONTokener(busServiceObject.toString()));
						busServiceDetailsTemp.remove(PAX_DETAILS);
						busServiceDetailsTemp.put(PAX_DETAILS, passengers);
						busServices.put(busServiceDetailsTemp);
						briClone.put(BUS_SERVICE_DETAILS, busServices);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), busServiceIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						busServices=new JSONArray();
						passengers=new JSONArray();
					}
				}
				if(counter!=0 && passengers.length()>0){
					JSONObject busServiceDetailsTemp = new JSONObject(new JSONTokener(busServiceObject.toString()));
					busServiceDetailsTemp.remove(PAX_DETAILS);
					busServiceDetailsTemp.put(PAX_DETAILS, passengers);
					busServices.put(busServiceDetailsTemp);
					//if(passengers.length()>=configuredRoomsCount){
						briClone.put(BUS_SERVICE_DETAILS, busServices);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), busServiceIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						busServices=new JSONArray();
						busServiceDetails.remove(i);
					//}
				}
			}
		}
		if(busServices.length()>0){
			briClone.put(BUS_SERVICE_DETAILS, busServices);
			clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
			sequenceMAp.put(temp.length(), busServiceIndex);
			temp.put(new JSONObject(new JSONTokener(template.toString())));
		}
		
		ThreadPoolConfig.loadConfig();
		//Thread splitter
		StoreBRMSresponse searchListener = new StoreBRMSresponse(temp.length());
		for(int k=0;k<temp.length();k++) {
			HitBRMS hit = new HitBRMS(temp.getJSONObject(k),searchListener);
			ThreadPoolConfig.execute(hit);
		}

		synchronized(searchListener) {
			searchListener.wait(10*1000);
		}
		
		return StoreBRMSresponse.getCombinedResponse(sequenceMAp,BUS_SERVICE_DETAILS,PAX_DETAILS,BUS_JSON_OBJECTNAME);
	}
}
