package cnk.products;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.configuration.Constants;
import cnk.configuration.HitBRMS;
import cnk.configuration.StoreBRMSresponse;
import cnk.configuration.ThreadPoolConfig;
import cnk.maven.MavenInvoker;

public class Activities implements Constants  {

	public static JSONObject splitActivities(JSONObject template) throws JSONException, Exception{
		JSONObject clientTransactionalRules = template.getJSONArray(COMMANDS).getJSONObject(0).getJSONObject(INSERT).getJSONObject(OBJECT).getJSONObject(ACTIVITIES_JSON_OBJECTNAME);
		JSONObject businessRuleIntake = clientTransactionalRules.getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		JSONObject briClone = new JSONObject(new JSONTokener(businessRuleIntake.toString()));
		briClone.remove(ACTIVITY_DETAILS);
		clientTransactionalRules.put(BUSINESS_RULE_INTAKE, new JSONArray().put(briClone));

		int configuredRoomsCount = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(ACTIVITIES_CONFIG_COUNT));
		JSONArray pricings = new JSONArray();
		JSONArray activitys = new JSONArray();
		int counter=0, activityIndex=-1;
		JSONArray temp = new JSONArray();
		Map<Integer, Integer> sequenceMAp = new HashMap<Integer, Integer>();

		JSONArray activityDetails = businessRuleIntake.getJSONArray(ACTIVITY_DETAILS);
		for(int i=0;i<activityDetails.length();){
			activityIndex++;
			JSONObject activityObject = activityDetails.getJSONObject(i);
			JSONArray pricingDetails = activityObject.getJSONArray(PRICING_DETAILS);
			if(pricingDetails.length()<=configuredRoomsCount){
				counter+= pricingDetails.length();
				if(counter>=configuredRoomsCount){
					counter=0;
					briClone.put(ACTIVITY_DETAILS, activitys);
					clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
					sequenceMAp.put(temp.length(), activityIndex);
					temp.put(new JSONObject(new JSONTokener(template.toString())));
					activitys=new JSONArray();
				}else{
					activitys.put(activityObject);
					activityDetails.remove(0);
				}
			}else{
				for(int j=0;j<pricingDetails.length();){
					++counter;
					if(counter<=configuredRoomsCount){
						pricings.put(pricingDetails.getJSONObject(j));
						pricingDetails.remove(0);
					}else{
						counter=0;
						JSONObject activityDetailsTemp = new JSONObject(new JSONTokener(activityObject.toString()));
						activityDetailsTemp.remove(PRICING_DETAILS);
						activityDetailsTemp.put(PRICING_DETAILS, pricings);
						activitys.put(activityDetailsTemp);
						briClone.put(ACTIVITY_DETAILS, activitys);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), activityIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						activitys=new JSONArray();
						pricings=new JSONArray();
					}
				}
				if(counter!=0 && pricings.length()>0){
					JSONObject activityDetailsTemp = new JSONObject(new JSONTokener(activityObject.toString()));
					activityDetailsTemp.remove(PRICING_DETAILS);
					activityDetailsTemp.put(PRICING_DETAILS, pricings);
					activitys.put(activityDetailsTemp);
					//if(pricings.length()>=configuredRoomsCount){
						briClone.put(ACTIVITY_DETAILS, activitys);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), activityIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						activitys=new JSONArray();
						activityDetails.remove(i);
					//}
				}
			}
		}
		if(activitys.length()>0){
			briClone.put(ACTIVITY_DETAILS, activitys);
			clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
			sequenceMAp.put(temp.length(), activityIndex);
			temp.put(new JSONObject(new JSONTokener(template.toString())));
		}
		
		ThreadPoolConfig.loadConfig();
		//Thread splitter
		StoreBRMSresponse searchListener = new StoreBRMSresponse(temp.length());
		for(int k=0;k<temp.length();k++) {
			HitBRMS hit = new HitBRMS(temp.getJSONObject(k),searchListener);
			ThreadPoolConfig.execute(hit);
		}

		synchronized(searchListener) {
			searchListener.wait(10*1000);
		}
		
		return StoreBRMSresponse.getCombinedResponse(sequenceMAp,ACTIVITY_DETAILS,PRICING_DETAILS,ACTIVITIES_JSON_OBJECTNAME);
	}
}
