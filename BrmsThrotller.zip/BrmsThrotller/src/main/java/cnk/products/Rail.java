package cnk.products;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.configuration.Constants;
import cnk.configuration.HitBRMS;
import cnk.configuration.StoreBRMSresponse;
import cnk.configuration.ThreadPoolConfig;
import cnk.maven.MavenInvoker;

public class Rail implements Constants {

	public static JSONObject splitRail(JSONObject template) throws JSONException, Exception{
		JSONObject clientTransactionalRules = template.getJSONArray(COMMANDS).getJSONObject(0).getJSONObject(INSERT).getJSONObject(OBJECT).getJSONObject(RAIL_JSON_OBJECTNAME);
		JSONObject businessRuleIntake = clientTransactionalRules.getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		JSONObject briClone = new JSONObject(new JSONTokener(businessRuleIntake.toString()));
		briClone.remove(TRAIN_DETAILS);
		clientTransactionalRules.put(BUSINESS_RULE_INTAKE, new JSONArray().put(briClone));

		int configuredRoomsCount = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(RAIL_CONFIG_COUNT));
		JSONArray passengers = new JSONArray();
		JSONArray trains = new JSONArray();
		int counter=0, trainIndex=-1;
		JSONArray temp = new JSONArray();
		Map<Integer, Integer> sequenceMAp = new HashMap<Integer, Integer>();

		JSONArray trainDetails = businessRuleIntake.getJSONArray(TRAIN_DETAILS);
		for(int i=0;i<trainDetails.length();){
			trainIndex++;
			JSONObject trainObject = trainDetails.getJSONObject(i);
			JSONArray passengerDetails = trainObject.getJSONArray(PAX_DETAILS);
			if(passengerDetails.length()<=configuredRoomsCount){
				counter+= passengerDetails.length();
				if(counter>=configuredRoomsCount){
					counter=0;
					briClone.put(TRAIN_DETAILS, trains);
					clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
					sequenceMAp.put(temp.length(), trainIndex);
					temp.put(new JSONObject(new JSONTokener(template.toString())));
					trains=new JSONArray();
				}else{
					trains.put(trainObject);
					trainDetails.remove(0);
				}
			}else{
				for(int j=0;j<passengerDetails.length();){
					++counter;
					if(counter<=configuredRoomsCount){
						passengers.put(passengerDetails.getJSONObject(j));
						passengerDetails.remove(0);
					}else{
						counter=0;
						JSONObject trainDetailsTemp = new JSONObject(new JSONTokener(trainObject.toString()));
						trainDetailsTemp.remove(PAX_DETAILS);
						trainDetailsTemp.put(PAX_DETAILS, passengers);
						trains.put(trainDetailsTemp);
						briClone.put(TRAIN_DETAILS, trains);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), trainIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						trains=new JSONArray();
						passengers=new JSONArray();
					}
				}
				if(counter!=0 && passengers.length()>0){
					JSONObject trainDetailsTemp = new JSONObject(new JSONTokener(trainObject.toString()));
					trainDetailsTemp.remove(PAX_DETAILS);
					trainDetailsTemp.put(PAX_DETAILS, passengers);
					trains.put(trainDetailsTemp);
					//if(passengers.length()>=configuredRoomsCount){
						briClone.put(TRAIN_DETAILS, trains);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), trainIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						trains=new JSONArray();
						trainDetails.remove(i);
					//}
				}
			}
		}
		if(trains.length()>0){
			briClone.put(TRAIN_DETAILS, trains);
			clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
			sequenceMAp.put(temp.length(), trainIndex);
			temp.put(new JSONObject(new JSONTokener(template.toString())));
		}
		
		ThreadPoolConfig.loadConfig();
		//Thread splitter
		StoreBRMSresponse searchListener = new StoreBRMSresponse(temp.length());
		for(int k=0;k<temp.length();k++) {
			HitBRMS hit = new HitBRMS(temp.getJSONObject(k),searchListener);
			ThreadPoolConfig.execute(hit);
		}

		synchronized(searchListener) {
			searchListener.wait(10*1000);
		}
		
		return StoreBRMSresponse.getCombinedResponse(sequenceMAp,TRAIN_DETAILS,PAX_DETAILS,RAIL_JSON_OBJECTNAME);
	}
}
