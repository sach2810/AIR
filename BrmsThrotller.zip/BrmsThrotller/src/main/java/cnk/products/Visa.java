package cnk.products;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.configuration.Constants;
import cnk.configuration.HitBRMS;
import cnk.configuration.StoreBRMSresponse;
import cnk.configuration.ThreadPoolConfig;
import cnk.maven.MavenInvoker;

public class Visa implements Constants {

	public static JSONObject splitVisa(JSONObject template) throws JSONException, Exception{
		JSONObject clientTransactionalRules = template.getJSONArray(COMMANDS).getJSONObject(0).getJSONObject(INSERT).getJSONObject(OBJECT).getJSONObject(VISA_JSON_OBJECTNAME);
		JSONObject businessRuleIntake = clientTransactionalRules.getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		JSONObject briClone = new JSONObject(new JSONTokener(businessRuleIntake.toString()));
		briClone.remove(PAX_DETAILS);
		clientTransactionalRules.put(BUSINESS_RULE_INTAKE, new JSONArray().put(briClone));

		int configuredRoomsCount = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(VISA_CONFIG_COUNT));
		JSONArray visas = new JSONArray();
		JSONArray passengers = new JSONArray();
		int counter=0, passengerIndex=-1;
		JSONArray temp = new JSONArray();
		Map<Integer, Integer> sequenceMAp = new HashMap<Integer, Integer>();

		JSONArray passengerDetails = businessRuleIntake.getJSONArray(PAX_DETAILS);
		for(int i=0;i<passengerDetails.length();){
			passengerIndex++;
			JSONObject passengerObject = passengerDetails.getJSONObject(i);
			JSONArray visaDetails = passengerObject.getJSONArray(VISA_DETAILS);
			if(visaDetails.length()<=configuredRoomsCount){
				counter+= visaDetails.length();
				if(counter>=configuredRoomsCount){
					counter=0;
					briClone.put(PAX_DETAILS, passengers);
					clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
					sequenceMAp.put(temp.length(), passengerIndex);
					temp.put(new JSONObject(new JSONTokener(template.toString())));
					passengers=new JSONArray();
				}else{
					passengers.put(passengerObject);
					passengerDetails.remove(0);
				}
			}else{
				for(int j=0;j<visaDetails.length();){
					++counter;
					if(counter<=configuredRoomsCount){
						visas.put(visaDetails.getJSONObject(j));
						visaDetails.remove(0);
					}else{
						counter=0;
						JSONObject passengerDetailsTemp = new JSONObject(new JSONTokener(passengerObject.toString()));
						passengerDetailsTemp.remove(VISA_DETAILS);
						passengerDetailsTemp.put(VISA_DETAILS, visas);
						passengers.put(passengerDetailsTemp);
						briClone.put(PAX_DETAILS, passengers);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), passengerIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						passengers=new JSONArray();
						visas=new JSONArray();
					}
				}
				if(counter!=0 && visas.length()>0){
					JSONObject passengerDetailsTemp = new JSONObject(new JSONTokener(passengerObject.toString()));
					passengerDetailsTemp.remove(VISA_DETAILS);
					passengerDetailsTemp.put(VISA_DETAILS, visas);
					passengers.put(passengerDetailsTemp);
					//if(visas.length()>=configuredRoomsCount){
						briClone.put(PAX_DETAILS, passengers);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), passengerIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						passengers=new JSONArray();
						passengerDetails.remove(i);
					//}
				}
			}
		}
		if(passengers.length()>0){
			briClone.put(PAX_DETAILS, passengers);
			clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
			sequenceMAp.put(temp.length(), passengerIndex);
			temp.put(new JSONObject(new JSONTokener(template.toString())));
		}
		
		ThreadPoolConfig.loadConfig();
		//Thread splitter
		StoreBRMSresponse searchListener = new StoreBRMSresponse(temp.length());
		for(int k=0;k<temp.length();k++) {
			HitBRMS hit = new HitBRMS(temp.getJSONObject(k),searchListener);
			ThreadPoolConfig.execute(hit);
		}

		synchronized(searchListener) {
			searchListener.wait(10*1000);
		}
		
		return StoreBRMSresponse.getCombinedResponse(sequenceMAp,PAX_DETAILS,VISA_DETAILS,VISA_JSON_OBJECTNAME);
	}
}
