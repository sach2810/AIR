package cnk.products;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.configuration.Constants;
import cnk.configuration.HitBRMS;
import cnk.configuration.StoreBRMSresponse;
import cnk.configuration.ThreadPoolConfig;
import cnk.maven.MavenInvoker;

public class CarRentals implements Constants {

	public static JSONObject splitCarRentals(JSONObject template) throws JSONException, Exception{
		JSONObject clientTransactionalRules = template.getJSONArray(COMMANDS).getJSONObject(0).getJSONObject(INSERT).getJSONObject(OBJECT).getJSONObject(CARRENTALS_JSON_OBJECTNAME);
		JSONObject businessRuleIntake = clientTransactionalRules.getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		JSONObject briClone = new JSONObject(new JSONTokener(businessRuleIntake.toString()));
		briClone.remove(VEHICLE_DETAILS);
		clientTransactionalRules.put(BUSINESS_RULE_INTAKE, new JSONArray().put(briClone));

		int configuredRoomsCount = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(CARRENTALS_CONFIG_COUNT));
		JSONArray passengers = new JSONArray();
		JSONArray vehicles = new JSONArray();
		int counter=0, vehicleIndex=-1;
		JSONArray temp = new JSONArray();
		Map<Integer, Integer> sequenceMAp = new HashMap<Integer, Integer>();

		JSONArray vehicleDetails = businessRuleIntake.getJSONArray(VEHICLE_DETAILS);
		for(int i=0;i<vehicleDetails.length();){
			vehicleIndex++;
			JSONObject vehicleObject = vehicleDetails.getJSONObject(i);
			JSONArray passengerDetails = vehicleObject.getJSONArray(PAX_DETAILS);
			if(passengerDetails.length()<=configuredRoomsCount){
				counter+= passengerDetails.length();
				if(counter>=configuredRoomsCount){
					counter=0;
					briClone.put(VEHICLE_DETAILS, vehicles);
					clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
					sequenceMAp.put(temp.length(), vehicleIndex);
					temp.put(new JSONObject(new JSONTokener(template.toString())));
					vehicles=new JSONArray();
				}else{
					vehicles.put(vehicleObject);
					vehicleDetails.remove(0);
				}
			}else{
				for(int j=0;j<passengerDetails.length();){
					++counter;
					if(counter<=configuredRoomsCount){
						passengers.put(passengerDetails.getJSONObject(j));
						passengerDetails.remove(0);
					}else{
						counter=0;
						JSONObject vehicleDetailsTemp = new JSONObject(new JSONTokener(vehicleObject.toString()));
						vehicleDetailsTemp.remove(PAX_DETAILS);
						vehicleDetailsTemp.put(PAX_DETAILS, passengers);
						vehicles.put(vehicleDetailsTemp);
						briClone.put(VEHICLE_DETAILS, vehicles);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), vehicleIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						vehicles=new JSONArray();
						passengers=new JSONArray();
					}
				}
				if(counter!=0 && passengers.length()>0){
					JSONObject vehicleDetailsTemp = new JSONObject(new JSONTokener(vehicleObject.toString()));
					vehicleDetailsTemp.remove(PAX_DETAILS);
					vehicleDetailsTemp.put(PAX_DETAILS, passengers);
					vehicles.put(vehicleDetailsTemp);
					//if(passengers.length()>=configuredRoomsCount){
						briClone.put(VEHICLE_DETAILS, vehicles);
						clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
						sequenceMAp.put(temp.length(), vehicleIndex);
						temp.put(new JSONObject(new JSONTokener(template.toString())));
						vehicles=new JSONArray();
						vehicleDetails.remove(i);
					//}
				}
			}
		}
		if(vehicles.length()>0){
			briClone.put(VEHICLE_DETAILS, vehicles);
			clientTransactionalRules.put(SEQUENCE_NUMBER, temp.length());
			sequenceMAp.put(temp.length(), vehicleIndex);
			temp.put(new JSONObject(new JSONTokener(template.toString())));
		}
		
		ThreadPoolConfig.loadConfig();
		//Thread splitter
		StoreBRMSresponse searchListener = new StoreBRMSresponse(temp.length());
		for(int k=0;k<temp.length();k++) {
			HitBRMS hit = new HitBRMS(temp.getJSONObject(k),searchListener);
			ThreadPoolConfig.execute(hit);
		}

		synchronized(searchListener) {
			searchListener.wait(10*1000);
		}
		
		return StoreBRMSresponse.getCombinedResponse(sequenceMAp,VEHICLE_DETAILS,PAX_DETAILS,CARRENTALS_JSON_OBJECTNAME);
	}
}
