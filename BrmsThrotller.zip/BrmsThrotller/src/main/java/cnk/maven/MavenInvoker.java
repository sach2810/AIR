package cnk.maven;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class MavenInvoker {
	
	private final Properties properties;
	private static MavenInvoker instance;
	
	public Properties getProperties() {
		return properties;
	}
    
    private MavenInvoker() throws IOException{
    	this.properties = new Properties();
    	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		try(InputStream in = classLoader.getResourceAsStream("configuration.properties")){
			properties.load(in);
		}
    }
    
    public static MavenInvoker getInstance() throws IOException {
		if (instance == null) {
			synchronized (MavenInvoker.class) {
				if (instance == null) {
					instance = new MavenInvoker();
				}
			}
		}
		return instance;
	}
}
