package cnk.configuration;

public interface Constants {

	public static final String JOURNEY_DETAILS="journeyDetails";
	public static final String PAX_DETAILS="passengerDetails";
	public static final String HOTEL_DETAILS="hotelDetails";
	public static final String ROOM_DETAILS="roomDetails";
	public static final String ACTIVITY_DETAILS="activityDetails";
	public static final String PRICING_DETAILS="pricingDetails";
	public static final String BUS_SERVICE_DETAILS="busServiceDetails";
	public static final String VEHICLE_DETAILS="vehicleDetails";
	public static final String PACKAGE_DETAILS="packageDetails";
	public static final String INSURANCE_DETAILS="insuranceDetails";
	public static final String TRAIN_DETAILS="trainDetails";
	public static final String TRANSFERS_DETAILS="transfersDetails";
	public static final String VISA_DETAILS="visaDetails";
	public static final String BUSINESS_RULE_INTAKE="businessRuleIntake";
	public static final String SEQUENCE_NUMBER="sequenceNumber";
	
	public static final String PRODUCTNAME_ACCOMMODATION="accommodation";
	public static final String PRODUCTNAME_AIR="air";
	public static final String PRODUCTNAME_ACTIVITIES="activities";
	public static final String PRODUCTNAME_HOLIDAYS="holidays";
	public static final String PRODUCTNAME_CARRENTALS="carrentals";
	public static final String PRODUCTNAME_BUS="bus";
	public static final String PRODUCTNAME_RAIL="rail";
	public static final String PRODUCTNAME_TRANSFERS="transfers";
	public static final String PRODUCTNAME_CRUISE="cruise";
	public static final String PRODUCTNAME_VISA="visa";
	public static final String PRODUCTNAME_INSURANCE="insurance";
	
	public static final String ACCO_JSON_OBJECTNAME="cnk.acco_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String AIR_JSON_OBJECTNAME="cnk.air_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String ACTIVITIES_JSON_OBJECTNAME="cnk.activities_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String HOLIDAYS_JSON_OBJECTNAME="cnk.holidays_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String CARRENTALS_JSON_OBJECTNAME="cnk.carrentals_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String BUS_JSON_OBJECTNAME="cnk.bus_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String RAIL_JSON_OBJECTNAME="cnk.rail_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String TRANSFERS_JSON_OBJECTNAME="cnk.transfers_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String CRUISE_JSON_OBJECTNAME="cnk.cruise_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String VISA_JSON_OBJECTNAME="cnk.visa_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String INSURANCE_JSON_OBJECTNAME="cnk.insurance_commercialscalculationengine.clienttransactionalrules.Root";
	public static final String ACCO_CONFIG_COUNT="acco_configurationCount";
	public static final String AIR_CONFIG_COUNT="air_configurationCount";
	public static final String ACTIVITIES_CONFIG_COUNT="activities_configurationCount";
	public static final String HOLIDAYS_CONFIG_COUNT="holidays_configurationCount";
	public static final String CARRENTALS_CONFIG_COUNT="carrentals_configurationCount";
	public static final String BUS_CONFIG_COUNT="bus_configurationCount";
	public static final String RAIL_CONFIG_COUNT="rail_configurationCount";
	public static final String TRANSFERS_CONFIG_COUNT="transfers_configurationCount";
	public static final String CRUISE_CONFIG_COUNT="cruise_configurationCount";
	public static final String INSURANCE_CONFIG_COUNT="insurance_configurationCount";
	public static final String VISA_CONFIG_COUNT="visa_configurationCount";
	
	public static final String ACCO_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/acco-cce-client-transactional";
	public static final String AIR_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/air-cce-client-transactional";
	public static final String ACTIVITIES_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/activities-cce-client-transactional";
	public static final String HOLIDAYS_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/holidays-cce-client-transactional";
	public static final String CARRENTALS_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/carrentals-cce-client-transactional";
	public static final String BUS_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/bus-cce-client-transactional";
	public static final String RAIL_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/rail-cce-client-transactional";
	public static final String TRANSFERS_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/transfers-cce-client-transactional";
	public static final String CRUISE_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/cruise-cce-client-transactional";
	public static final String VISA_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/visa-cce-client-transactional";
	public static final String INSURANCE_URL="http://localhost:8080/kie-server/services/rest/server/containers/instances/insurance-cce-client-transactional";
	public static final String PORT="localhost:8080";
	public static final String RQ_METHOD="POST";
	
	public static final String COMMANDS="commands";
	public static final String INSERT="insert";
	public static final String OBJECT="object";
	public static final String RESULT="result";
	public static final String EXE_RESULTS="execution-results";
	public static final String RESULTS="results";
	public static final String VALUE="value";
	
	public static final String PROP_THREAD_POOL_CORE_SIZE="THREAD_POOL_CORE_SIZE";
	public static final String PROP_THREAD_POOL_MAX_SIZE="THREAD_POOL_MAX_SIZE";
	public static final String PROP_THREAD_POOL_KEEP_ALIVE_SECONDS="THREAD_POOL_KEEP_ALIVE_SECONDS";
	public static final String PROP_THREAD_POOL_QUEUE_SIZE="THREAD_POOL_QUEUE_SIZE";
}
