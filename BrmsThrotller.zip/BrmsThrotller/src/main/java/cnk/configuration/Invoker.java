package cnk.configuration;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Invoker implements Constants {
	
	public static String method;
	private static String mUserID;
	private transient static String mPassword;
	private transient static String mHttpBasicAuth;

	public static JSONObject invokeBrmsServcie(String request, String productName) throws Exception{
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = "kieserver";
		mPassword = "kieserver1!";
		mHttpBasicAuth = "Basic ".concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(productName){
		case PRODUCTNAME_ACCOMMODATION:{
			URL = ACCO_URL;
			break;
		}
		case PRODUCTNAME_AIR:{
			URL = AIR_URL;
			break;
		}
		}
		if(URL!=null){
			return consumeJSONService(PORT,new URL(URL),mHttpHeaders,request);
		}
		return new JSONObject();
	}
	
	private static JSONObject consumeJSONService(String tgtSysId, URL tgtSysURL, Map<String, String> httpHdrs, String reqJsonStr) throws Exception {
		HttpURLConnection svcConn = null;
		try{
			svcConn = (HttpURLConnection) tgtSysURL.openConnection();
			/*if (logger.isTraceEnabled()) {
				logger.trace(String.format("%s JSON Request = %s", tgtSysId, reqJsonStr));
			}*/
			InputStream httpResStream = consumeService(tgtSysId, svcConn, httpHdrs, reqJsonStr.getBytes());
			if(httpResStream != null)
				return new JSONObject(new JSONTokener(httpResStream));
		}
		catch(Exception x){
			System.out.println(x);
			//logger.warn(String.format("%s JSON Service <%s> Consume Error", tgtSysId, tgtSysURL), x);
		}
		finally{
			if(svcConn != null)
				svcConn.disconnect();
		}
		return null;
	}
	
	private static InputStream consumeService(String tgtSysId, HttpURLConnection svcConn, Map<String, String> httpHdrs, byte[] payload) throws Exception {
		svcConn.setDoOutput(true);
		svcConn.setRequestMethod(RQ_METHOD);

		Set<Entry<String,String>> httpHeaders = httpHdrs.entrySet();
		if (httpHeaders != null && httpHeaders.size() > 0) {
			Iterator<Entry<String,String>> httpHeadersIter = httpHeaders.iterator();
			while (httpHeadersIter.hasNext()) {
				Entry<String,String> httpHeader = httpHeadersIter.next();
				svcConn.setRequestProperty(httpHeader.getKey(), httpHeader.getValue());
			}
		}
		//logger.trace(String.format("Sending request to %s",tgtSysId));
		OutputStream httpOut = svcConn.getOutputStream();
		httpOut.write(payload);
		httpOut.flush();
		httpOut.close();

		int resCode = svcConn.getResponseCode();
		//logger.debug(String.format("Receiving response from %s with HTTP response status: %s", tgtSysId, resCode));
		if (resCode == HttpURLConnection.HTTP_OK) {
			return svcConn.getInputStream();
		}
		return null;
	}
}
