package cnk.configuration;

import org.json.JSONObject;

public class HitBRMS implements Runnable{
	private JSONObject mreq;
	private StoreBRMSresponse mStoreBRMSListener;

	public HitBRMS(JSONObject req,StoreBRMSresponse sBr){
		mreq=req;	
		mStoreBRMSListener=sBr;
	}

	@Override
	public void run() {
		try {
			mStoreBRMSListener.storeResponse(Invoker.invokeBrmsServcie(mreq.toString(), Configuration.productname),Configuration.objectName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
