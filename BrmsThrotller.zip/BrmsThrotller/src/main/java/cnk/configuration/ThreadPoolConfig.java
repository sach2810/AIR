package cnk.configuration;

import java.io.IOException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import cnk.maven.MavenInvoker;

public class ThreadPoolConfig implements Constants {

	private static ThreadPoolExecutor mThreadPool;

	public static void loadConfig() throws NumberFormatException, IOException {
		int THREAD_POOL_CORE_SIZE = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(PROP_THREAD_POOL_CORE_SIZE));
		int THREAD_POOL_MAX_SIZE = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(PROP_THREAD_POOL_MAX_SIZE));
		int THREAD_POOL_KEEP_ALIVE_SECONDS = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(PROP_THREAD_POOL_KEEP_ALIVE_SECONDS));
		int THREAD_POOL_QUEUE_SIZE = Integer.parseInt(MavenInvoker.getInstance().getProperties().getProperty(PROP_THREAD_POOL_QUEUE_SIZE));

		mThreadPool = new ThreadPoolExecutor(THREAD_POOL_CORE_SIZE, THREAD_POOL_MAX_SIZE, THREAD_POOL_KEEP_ALIVE_SECONDS, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(THREAD_POOL_QUEUE_SIZE));
	}
	
	public static void execute(HitBRMS template) {
		mThreadPool.execute(template);
	}
}
