package cnk.configuration;

import org.json.JSONObject;
import cnk.products.Accommodation;
import cnk.products.Activities;
import cnk.products.Air;
import cnk.products.Bus;
import cnk.products.CarRentals;
import cnk.products.Cruise;
import cnk.products.Holidays;
import cnk.products.Insurance;
import cnk.products.Rail;
import cnk.products.Transfers;
import cnk.products.Visa;

public class Configuration implements Constants{
	public static String productname,objectName;

	public static JSONObject split(JSONObject template, String productName) throws Exception{
		productname = productName;
		JSONObject resJson = new JSONObject();
		switch(productName){
		case PRODUCTNAME_ACCOMMODATION:{
			objectName = ACCO_JSON_OBJECTNAME;
			resJson = Accommodation.splitAccommodation(template);
			break;
		}
		case PRODUCTNAME_AIR:{
			objectName = AIR_JSON_OBJECTNAME;
			resJson = Air.splitAir(template);
			break;
		}
		case PRODUCTNAME_ACTIVITIES:{
			objectName = ACTIVITIES_JSON_OBJECTNAME;
			resJson = Activities.splitActivities(template);
			break;
		}
		case PRODUCTNAME_HOLIDAYS:{
			objectName = HOLIDAYS_JSON_OBJECTNAME;
			resJson = Holidays.splitHolidays(template);
			break;
		}
		case PRODUCTNAME_CARRENTALS:{
			objectName = CARRENTALS_JSON_OBJECTNAME;
			resJson = CarRentals.splitCarRentals(template);
			break;
		}
		case PRODUCTNAME_BUS:{
			objectName = BUS_JSON_OBJECTNAME;
			resJson = Bus.splitBus(template);
			break;
		}
		case PRODUCTNAME_RAIL:{
			objectName = RAIL_JSON_OBJECTNAME;
			resJson = Rail.splitRail(template);
			break;
		}
		case PRODUCTNAME_CRUISE:{
			objectName = CRUISE_JSON_OBJECTNAME;
			resJson = Cruise.splitCruise(template);
			break;
		}
		case PRODUCTNAME_TRANSFERS:{
			objectName = TRANSFERS_JSON_OBJECTNAME;
			resJson = Transfers.splitTransfers(template);
			break;
		}
		case PRODUCTNAME_VISA:{
			objectName = VISA_JSON_OBJECTNAME;
			resJson = Visa.splitVisa(template);
			break;
		}
		case PRODUCTNAME_INSURANCE:{
			objectName = INSURANCE_JSON_OBJECTNAME;
			resJson = Insurance.splitInsurance(template);
			break;
		}
		}
		return resJson;
	}
}
