package cnk.configuration;

/*import java.util.ArrayList;
import java.util.Collections;
import java.util.List;*/
import java.util.Map;
import java.util.TreeMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class StoreBRMSresponse implements Constants {
	//private List<JSONObject> mBRMSRes;
	public static TreeMap<Integer, JSONObject> mBRMSTree = new TreeMap<Integer, JSONObject>();
	private int mReqCount;
	public static boolean error=false;
	public static JSONObject errorMessage = new JSONObject();

	//Total no of req to be hit is sent as arg
	public StoreBRMSresponse(int reqCount) {
		//mBRMSRes = Collections.synchronizedList(new ArrayList<JSONObject>());
		mReqCount=reqCount;
	}

	/*void storeResponse(JSONObject resp) {
		mBRMSRes.add(resp);
		if (mBRMSRes.size() == mReqCount) {
			// 
			//System.out.println("Response: "+mBRMSRes);
			synchronized(this) {
				notify();
			}
		}
	}*/

	//using treeMap
	void storeResponse(JSONObject resp, String objectName) {
		try{
			int sequence = resp.getJSONObject(RESULT).getJSONObject(EXE_RESULTS).getJSONArray(RESULTS).getJSONObject(0).getJSONObject(VALUE).getJSONObject(objectName).getInt(SEQUENCE_NUMBER);
			mBRMSTree.put(sequence,resp);
			if (mBRMSTree.size() == mReqCount) {
				synchronized(this) {
					notifyAll();
				}
			}
		}catch(Exception e){
			error=true;
			errorMessage=resp;
		}
	}


	public static JSONObject getCombinedResponse(Map<Integer, Integer> sequenceMAp, String outerArrayName, String innerArrayName, String objectName) throws JSONException, Exception{
		if(!error){
			JSONObject templateClone= new JSONObject(new JSONTokener(mBRMSTree.get(0).toString()));
			getBri(templateClone,objectName).remove(outerArrayName);
			int var=-1;
			for(int i=0;i<mBRMSTree.size();i++){
				if(sequenceMAp.get(i)!=null){
					if(i==0){
						var = sequenceMAp.get(i);
						getBri(templateClone,objectName).put(outerArrayName, getBri(mBRMSTree.get(i),objectName).getJSONArray(outerArrayName));
					}else if(var==sequenceMAp.get(i)){
						//rooms of same hotels
						JSONArray hotels = getBri(mBRMSTree.get(i),objectName).getJSONArray(outerArrayName);
						for(int h=0;h<hotels.length();h++){
							JSONObject hotelObject = hotels.getJSONObject(h);
							JSONArray rooms = hotelObject.getJSONArray(innerArrayName);
							for(int r=0;r<rooms.length();r++){
								JSONObject roomObject = rooms.getJSONObject(r);
								getBri(templateClone,objectName).getJSONArray(outerArrayName).getJSONObject(getBri(templateClone,objectName).getJSONArray(outerArrayName).length()-1).append(innerArrayName, roomObject);
							}
						}
					}else{
						//new hotel to append
						var = sequenceMAp.get(i);
						JSONArray hotels = getBri(mBRMSTree.get(i),objectName).getJSONArray(outerArrayName);
						for(int h=0;h<hotels.length();h++){
							JSONObject hotelObject = hotels.getJSONObject(h);
							getBri(templateClone,objectName).append(outerArrayName, hotelObject);
						}
					}
				}
			}
			return templateClone;
		}else return errorMessage;
	}


	static JSONObject getBri(JSONObject mrBRMSTree, String objectName) throws Exception{
		try {
			return mrBRMSTree.getJSONObject(RESULT).getJSONObject(EXE_RESULTS).getJSONArray(RESULTS).getJSONObject(0).getJSONObject(VALUE).getJSONObject(objectName).getJSONArray(BUSINESS_RULE_INTAKE).getJSONObject(0);
		} catch(Exception e) {
			e.printStackTrace();
		}
		throw new Exception();
	}
}