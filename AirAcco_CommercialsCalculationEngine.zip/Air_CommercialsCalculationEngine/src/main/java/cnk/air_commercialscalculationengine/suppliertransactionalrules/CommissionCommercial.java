package cnk.air_commercialscalculationengine.suppliertransactionalrules;

public class CommissionCommercial {
	
	private java.lang.String selectedRow;

	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead;

	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding;
	   
	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb;
	   
	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive;

	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees;

	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge;
	   
	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees;

	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees;
	   
	   private cnk.air_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake bri;

	   public CommissionCommercial()
	   {
	   }

	   public java.lang.String getSelectedRow()
	   {
	      return this.selectedRow;
	   }

	   public void setSelectedRow(java.lang.String selectedRow)
	   {
	      this.selectedRow = selectedRow;
	   }

	   public cnk.air_commercialscalculationengine.suppliertransactionalrules.CommercialHead getCommercialHead()
	   {
	      return this.commercialHead;
	   }

	   public void setCommercialHead(
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
	   {
	      this.commercialHead = commercialHead;
	   }

	   public cnk.air_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial getOverriding()
	   {
	      return this.overriding;
	   }

	   public void setOverriding(
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding)
	   {
	      this.overriding = overriding;
	   }
	   
	   public cnk.air_commercialscalculationengine.suppliertransactionalrules.PLBCommercial getPlb()
	   {
	      return this.plb;
	   }

	   public void setPlb(
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb)
	   {
	      this.plb = plb;
	   }
	  
	   public cnk.air_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial getSectorWiseIncentive()
	   {
	      return this.sectorWiseIncentive;
	   }

	   public void setSectorWiseIncentive(
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive)
	   {
	      this.sectorWiseIncentive = sectorWiseIncentive;
	   }

	   public cnk.air_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial getSegmentFees()
	   {
	      return this.segmentFees;
	   }

	   public void setSegmentFees(
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees)
	   {
	      this.segmentFees = segmentFees;
	   }
	   
	   public cnk.air_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial getIssuanceFees()
	   {
	      return this.issuanceFees;
	   }

	   public void setIssuanceFees(
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees)
	   {
	      this.issuanceFees = issuanceFees;
	   }

	   public cnk.air_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial getServiceCharge()
	   {
	      return this.serviceCharge;
	   }

	   public void setServiceCharge(
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge)
	   {
	      this.serviceCharge = serviceCharge;
	   }


	   public cnk.air_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial getManagementFees()
	   {
	      return this.managementFees;
	   }

	   public void setManagementFees(
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees)
	   {
	      this.managementFees = managementFees;
	   }
	   
   public cnk.air_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake getBri()
   {
      return this.bri;
   }

   public void setBri(
         cnk.air_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake bri)
   {
      this.bri = bri;
   }

   public CommissionCommercial(
         java.lang.String selectedRow,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.SectorWiseIncentiveCommercial sectorWiseIncentive,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.IssuanceFeesCommercial issuanceFees,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees,
         cnk.air_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake bri)
   {
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
      this.overriding = overriding;
      this.plb = plb;
      this.sectorWiseIncentive = sectorWiseIncentive;
      this.segmentFees = segmentFees;
      this.serviceCharge = serviceCharge;
      this.issuanceFees = issuanceFees;
      this.managementFees = managementFees;
      this.bri = bri;
   }	   
	   
	   
	     public CommissionCommercial(
	         java.lang.String selectedRow,
	         cnk.air_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead )
	   {
	      this.selectedRow = selectedRow;
	      this.commercialHead = commercialHead;
	     }		 



}
