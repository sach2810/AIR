package cnk.acco_commercialscalculationengine.suppliersettlementrules;

import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class BusinessRuleIntake implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String selectedRow;
   private java.lang.String ruleFlowName;
   private cnk.acco_commercialscalculationengine.suppliersettlementrules.CommonElements commonElements;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.IncentiveOnTopUp incentiveOnTopUp;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.PenaltyFee penaltyFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.MaintenanceFee maintenanceFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.IntegrationFee integrationFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.LicenceFee licenceFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.WebServiceFee webServiceFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.LoyaltyBonus loyaltyBonus;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.PreferenceBenefit preferenceBenefit;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.RetainerFee retainerFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.ListingFee listingFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.SignUpFee signUpFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.ContentAccessFee contentAccessFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.TrainingFee trainingFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.SignUpBonus signUpBonus;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.RemittanceFee remittanceFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.LookToBook lookToBook;

   private java.util.List<cnk.acco_commercialscalculationengine.suppliersettlementrules.SlabDetails> slabDetails;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.TerminationFee terminationFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.MSFFee msfFee;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.FreeOfCosts freeOfCosts;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.AdvancedDefinition advancedDefinition;

   public void modifyIncentiveOnTopUp(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getIncentiveOnTopUp() != null)
      {

         this.getIncentiveOnTopUp().setCommercialType(commercialType);
         this.getIncentiveOnTopUp().setContractType(contractType);
         this.getIncentiveOnTopUp().setIsApplicable(isApplicable);
      }
   }

   public void modifyPenaltyFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getPenaltyFee() != null)
      {

         this.getPenaltyFee().setCommercialType(commercialType);
         this.getPenaltyFee().setContractType(contractType);
         this.getPenaltyFee().setIsApplicable(isApplicable);
      }
   }

   public void modifyTerminationFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getTerminationFee() != null)
      {

         this.getTerminationFee().setCommercialType(commercialType);
         this.getTerminationFee().setContractType(contractType);
         this.getTerminationFee().setIsApplicable(isApplicable);
      }
   }

   public void modifyMaintenanceFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getMaintenanceFee() != null)
      {

         this.getMaintenanceFee().getOtherFees().setCommercialType(commercialType);
         this.getMaintenanceFee().getOtherFees().setContractType(contractType);
         this.getMaintenanceFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyIntegrationFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getIntegrationFee() != null)
      {

         this.getIntegrationFee().getOtherFees().setCommercialType(commercialType);
         this.getIntegrationFee().getOtherFees().setContractType(contractType);
         this.getIntegrationFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyLicenceFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getLicenceFee() != null)
      {

         this.getLicenceFee().getOtherFees().setCommercialType(commercialType);
         this.getLicenceFee().getOtherFees().setContractType(contractType);
         this.getLicenceFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyWebServiceFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getWebServiceFee() != null)
      {

         this.getWebServiceFee().getOtherFees().setCommercialType(commercialType);
         this.getWebServiceFee().getOtherFees().setContractType(contractType);
         this.getWebServiceFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyLoyaltyBonus(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getLoyaltyBonus() != null)
      {

         this.getLoyaltyBonus().getOtherFees().setCommercialType(commercialType);
         this.getLoyaltyBonus().getOtherFees().setContractType(contractType);
         this.getLoyaltyBonus().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyPreferenceBenefit(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getPreferenceBenefit() != null)
      {

         this.getPreferenceBenefit().getOtherFees().setCommercialType(commercialType);
         this.getPreferenceBenefit().getOtherFees().setContractType(contractType);
         this.getPreferenceBenefit().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyRetainerFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getRetainerFee() != null)
      {

         this.getRetainerFee().getOtherFees().setCommercialType(commercialType);
         this.getRetainerFee().getOtherFees().setContractType(contractType);
         this.getRetainerFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyListingFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getListingFee() != null)
      {

         this.getListingFee().getOtherFees().setCommercialType(commercialType);
         this.getListingFee().getOtherFees().setContractType(contractType);
         this.getListingFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifySignUpFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getSignUpFee() != null)
      {

         this.getSignUpFee().getOtherFees().setCommercialType(commercialType);
         this.getSignUpFee().getOtherFees().setContractType(contractType);
         this.getSignUpFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyContentAccessFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getContentAccessFee() != null)
      {

         this.getContentAccessFee().getOtherFees().setCommercialType(commercialType);
         this.getContentAccessFee().getOtherFees().setContractType(contractType);
         this.getContentAccessFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifyTrainingFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getTrainingFee() != null)
      {

         this.getTrainingFee().getOtherFees().setCommercialType(commercialType);
         this.getTrainingFee().getOtherFees().setContractType(contractType);
         this.getTrainingFee().getOtherFees().setIsApplicable(isApplicable);
      }
   }

   public void modifySignUpBonus(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getSignUpBonus() != null)
      {

         this.getSignUpBonus().setCommercialType(commercialType);
         this.getSignUpBonus().setContractType(contractType);
         this.getSignUpBonus().setIsApplicable(isApplicable);
      }
   }

   public void modifyRemittanceFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getRemittanceFee() != null)
      {

         this.getRemittanceFee().setCommercialType(commercialType);
         this.getRemittanceFee().setContractType(contractType);
         this.getRemittanceFee().setIsApplicable(isApplicable);
      }
   }

   public void modifyLookToBook(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getLookToBook() != null)
      {

         this.getLookToBook().setCommercialType(commercialType);
         this.getLookToBook().setContractType(contractType);
         this.getLookToBook().setIsApplicable(isApplicable);
      }
   }

   public void modifyMsfFee(String commercialType, String contractType, boolean isApplicable)
   {

      if (this.getMsfFee() != null)
      {

         this.getMsfFee().setCommercialType(commercialType);
         this.getMsfFee().setContractType(contractType);
         this.getMsfFee().setIsApplicable(isApplicable);
      }
   }

   public void modifyFreeOfCosts(String commercialType, String contractType, boolean isApplicable, boolean plbApplicable)
   {

      if (this.getFreeOfCosts() != null)
      {

         this.getFreeOfCosts().setCommercialType(commercialType);
         this.getFreeOfCosts().setContractType(contractType);
         this.getFreeOfCosts().setIsApplicable(isApplicable);
         this.getFreeOfCosts().setPLBApplicable(plbApplicable);
      }
   }

   public void calculateMaintenanceFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getMaintenanceFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getMaintenanceFee().getOtherFees().setCommercialAmount(this.getMaintenanceFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateIntegrationFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getIntegrationFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getIntegrationFee().getOtherFees().setCommercialAmount(this.getIntegrationFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateLicenceFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getLicenceFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getLicenceFee().getOtherFees().setCommercialAmount(this.getLicenceFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateWebServiceFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getWebServiceFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getWebServiceFee().getOtherFees().setCommercialAmount(this.getWebServiceFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateLoyaltyBonus(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getLoyaltyBonus().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getLoyaltyBonus().getOtherFees().setCommercialAmount(this.getLoyaltyBonus().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculatePreferenceBenefit(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getPreferenceBenefit().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getPreferenceBenefit().getOtherFees().setCommercialAmount(this.getPreferenceBenefit().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateRetainerFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getRetainerFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getRetainerFee().getOtherFees().setCommercialAmount(this.getRetainerFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateListingFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getListingFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getListingFee().getOtherFees().setCommercialAmount(this.getListingFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateSignUpFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getSignUpFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getSignUpFee().getOtherFees().setCommercialAmount(this.getSignUpFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateContentAccessFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getContentAccessFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getContentAccessFee().getOtherFees().setCommercialAmount(this.getContentAccessFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateTrainingFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getTrainingFee().getOtherFees().getFeeDetails())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getTrainingFee().getOtherFees().setCommercialAmount(this.getTrainingFee().getOtherFees().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public void calculateTerminationFee(List<String> commercialNamesList, List<String> commercialPercentagesList)
   {

      for (int i = 0; i < commercialNamesList.size(); i++)
      {

         for (FeeDetails feeDetails : this.getTerminationFee().getReturnableCommercialHead())
         {

            if (commercialNamesList.get(i).equals(feeDetails.getCommercialName()))
            {

               this.getTerminationFee().setCommercialAmount(this.getTerminationFee().getCommercialAmount() + (feeDetails.getCommercialAmount() * Double.valueOf(commercialPercentagesList.get(i)) / 100));
               break;
            }
         }
      }
   }

   public boolean CheckRange(String configuredInput, double checkingValue)
   {

      String[] configuredInputList = configuredInput.split(";");
      if (configuredInputList[0].equals("LESSTHANEQUALTO"))
      {

         return LESSTHANEQUALTO(Double.parseDouble(configuredInputList[1]), checkingValue);
      }
      else if (configuredInputList[0].equals("GREATERTHANEQUALTO"))
      {

         return GREATERTHANEQUALTO(Double.parseDouble(configuredInputList[1]), checkingValue);
      }
      else if (configuredInputList[0].equals("BETWEEN"))
      {

         return BETWEEN(Double.parseDouble(configuredInputList[1]), Double.parseDouble(configuredInputList[2]), checkingValue);
      }
      else if (configuredInputList[0].equals("EQUALTO"))
      {

         return EQUAL(Double.parseDouble(configuredInputList[1]), checkingValue);
      }
      else if (configuredInputList[0].equals("IN"))
      {

         return IN(configuredInputList[1], checkingValue);
      }

      return false;

   }

   public boolean LESSTHANEQUALTO(double configuredInput, double checkingValue)
   {

      if (checkingValue <= configuredInput)
         return true;

      return false;
   }

   public boolean GREATERTHANEQUALTO(double configuredInput, double checkingValue)
   {

      if (checkingValue >= configuredInput)
         return true;

      return false;
   }

   public boolean BETWEEN(double lowerLimit, double upperLimit, double checkingValue)
   {

      if (GREATERTHANEQUALTO(lowerLimit, checkingValue) && LESSTHANEQUALTO(upperLimit, checkingValue))
         return true;

      return false;
   }

   public boolean EQUAL(double configuredInput, double checkingValue)
   {

      if (checkingValue == configuredInput)
         return true;

      return false;
   }

   public boolean IN(String configuredInput, double checkingValue)
   {

      String[] configuredInputList = configuredInput.split("/");
      for (String tempConfiguredInput : configuredInputList)
      {

         if (EQUAL(Double.parseDouble(tempConfiguredInput), checkingValue))
            return true;
      }

      return false;
   }

   public static boolean checkDayOfWeek(String day, Date d)
   {
      DateFormat formatter = new SimpleDateFormat("EEE");
      return Arrays.asList(day.toUpperCase().split(";")).contains(formatter.format(d).toUpperCase());
   }

   public static boolean checkDayOfWeekInMonth(String day, Date d)
   {

      Calendar tempCal = Calendar.getInstance();
      tempCal.setTime(d);
      return Arrays.asList(day.split(";")).contains(String.valueOf(tempCal.get(Calendar.DAY_OF_WEEK_IN_MONTH)));
   }

   public static boolean checkDayInMonth(String day, Date d)
   {

      DateFormat formatter = new SimpleDateFormat("d");
      return Arrays.asList(day.split(";")).contains(formatter.format(d));
   }

   public static boolean checkMonth(String day, Date d)
   {

      DateFormat formatter = new SimpleDateFormat("M");
      return Arrays.asList(day.split(";")).contains(formatter.format(d));
   }

   public static boolean checkHours(int day, Date d)
   {

      DateFormat formatter = new SimpleDateFormat("HH");
      return day == Integer.parseInt((formatter.format(d)));
   }

   public static boolean checkMinutes(int day, Date d)
   {

      DateFormat formatter = new SimpleDateFormat("mm");
      return day == Integer.parseInt((formatter.format(d)));
   }

   public static boolean checkDate(String configuredInput, Date conditionValue)
   {

      try
      {
         String[] configuredInputList = configuredInput.split(";");
         DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

         if (configuredInputList[0].equals("LESSTHANEQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return (date.after(conditionValue) || date.equals(conditionValue));

         }
         else if (configuredInputList[0].equals("GREATERTHANEQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return (date.before(conditionValue) || date.equals(conditionValue));

         }
         else if (configuredInputList[0].equals("BETWEEN"))
         {

            Date lowerLimit = format.parse(configuredInputList[1]);
            Date upperLimit = format.parse(configuredInputList[2]);
            return ((lowerLimit.before(conditionValue) || lowerLimit.equals(conditionValue)) && (upperLimit.after(conditionValue) || upperLimit.equals(conditionValue)));

         }
         else if (configuredInputList[0].equals("EQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return date.equals(conditionValue);

         }
         else if (configuredInputList[0].equals("IN"))
         {

            String date = format.format(conditionValue);
            return Arrays.asList(configuredInputList[1].split("/")).contains(date);
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }

      return false;
   }

   public BusinessRuleIntake()
   {
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public java.lang.String getRuleFlowName()
   {
      return this.ruleFlowName;
   }

   public void setRuleFlowName(java.lang.String ruleFlowName)
   {
      this.ruleFlowName = ruleFlowName;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.CommonElements getCommonElements()
   {
      return this.commonElements;
   }

   public void setCommonElements(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.CommonElements commonElements)
   {
      this.commonElements = commonElements;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.IncentiveOnTopUp getIncentiveOnTopUp()
   {
      return this.incentiveOnTopUp;
   }

   public void setIncentiveOnTopUp(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.IncentiveOnTopUp incentiveOnTopUp)
   {
      this.incentiveOnTopUp = incentiveOnTopUp;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.PenaltyFee getPenaltyFee()
   {
      return this.penaltyFee;
   }

   public void setPenaltyFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.PenaltyFee penaltyFee)
   {
      this.penaltyFee = penaltyFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.MaintenanceFee getMaintenanceFee()
   {
      return this.maintenanceFee;
   }

   public void setMaintenanceFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.MaintenanceFee maintenanceFee)
   {
      this.maintenanceFee = maintenanceFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.IntegrationFee getIntegrationFee()
   {
      return this.integrationFee;
   }

   public void setIntegrationFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.IntegrationFee integrationFee)
   {
      this.integrationFee = integrationFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.LicenceFee getLicenceFee()
   {
      return this.licenceFee;
   }

   public void setLicenceFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.LicenceFee licenceFee)
   {
      this.licenceFee = licenceFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.WebServiceFee getWebServiceFee()
   {
      return this.webServiceFee;
   }

   public void setWebServiceFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.WebServiceFee webServiceFee)
   {
      this.webServiceFee = webServiceFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.LoyaltyBonus getLoyaltyBonus()
   {
      return this.loyaltyBonus;
   }

   public void setLoyaltyBonus(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.LoyaltyBonus loyaltyBonus)
   {
      this.loyaltyBonus = loyaltyBonus;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.PreferenceBenefit getPreferenceBenefit()
   {
      return this.preferenceBenefit;
   }

   public void setPreferenceBenefit(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.PreferenceBenefit preferenceBenefit)
   {
      this.preferenceBenefit = preferenceBenefit;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.RetainerFee getRetainerFee()
   {
      return this.retainerFee;
   }

   public void setRetainerFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.RetainerFee retainerFee)
   {
      this.retainerFee = retainerFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.ListingFee getListingFee()
   {
      return this.listingFee;
   }

   public void setListingFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.ListingFee listingFee)
   {
      this.listingFee = listingFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.SignUpFee getSignUpFee()
   {
      return this.signUpFee;
   }

   public void setSignUpFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.SignUpFee signUpFee)
   {
      this.signUpFee = signUpFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.ContentAccessFee getContentAccessFee()
   {
      return this.contentAccessFee;
   }

   public void setContentAccessFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.ContentAccessFee contentAccessFee)
   {
      this.contentAccessFee = contentAccessFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.TrainingFee getTrainingFee()
   {
      return this.trainingFee;
   }

   public void setTrainingFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.TrainingFee trainingFee)
   {
      this.trainingFee = trainingFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.SignUpBonus getSignUpBonus()
   {
      return this.signUpBonus;
   }

   public void setSignUpBonus(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.SignUpBonus signUpBonus)
   {
      this.signUpBonus = signUpBonus;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.RemittanceFee getRemittanceFee()
   {
      return this.remittanceFee;
   }

   public void setRemittanceFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.RemittanceFee remittanceFee)
   {
      this.remittanceFee = remittanceFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.LookToBook getLookToBook()
   {
      return this.lookToBook;
   }

   public void setLookToBook(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.LookToBook lookToBook)
   {
      this.lookToBook = lookToBook;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.suppliersettlementrules.SlabDetails> getSlabDetails()
   {
      return this.slabDetails;
   }

   public void setSlabDetails(
         java.util.List<cnk.acco_commercialscalculationengine.suppliersettlementrules.SlabDetails> slabDetails)
   {
      this.slabDetails = slabDetails;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.TerminationFee getTerminationFee()
   {
      return this.terminationFee;
   }

   public void setTerminationFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.TerminationFee terminationFee)
   {
      this.terminationFee = terminationFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.MSFFee getMsfFee()
   {
      return this.msfFee;
   }

   public void setMsfFee(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.MSFFee msfFee)
   {
      this.msfFee = msfFee;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.FreeOfCosts getFreeOfCosts()
   {
      return this.freeOfCosts;
   }

   public void setFreeOfCosts(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.FreeOfCosts freeOfCosts)
   {
      this.freeOfCosts = freeOfCosts;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.AdvancedDefinition getAdvancedDefinition()
   {
      return this.advancedDefinition;
   }

   public void setAdvancedDefinition(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.AdvancedDefinition advancedDefinition)
   {
      this.advancedDefinition = advancedDefinition;
   }

   public BusinessRuleIntake(
         java.lang.String selectedRow,
         java.lang.String ruleFlowName,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.CommonElements commonElements,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.IncentiveOnTopUp incentiveOnTopUp,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.PenaltyFee penaltyFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.MaintenanceFee maintenanceFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.IntegrationFee integrationFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.LicenceFee licenceFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.WebServiceFee webServiceFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.LoyaltyBonus loyaltyBonus,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.PreferenceBenefit preferenceBenefit,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.RetainerFee retainerFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.ListingFee listingFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.SignUpFee signUpFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.ContentAccessFee contentAccessFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.TrainingFee trainingFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.SignUpBonus signUpBonus,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.RemittanceFee remittanceFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.LookToBook lookToBook,
         java.util.List<cnk.acco_commercialscalculationengine.suppliersettlementrules.SlabDetails> slabDetails,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.TerminationFee terminationFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.MSFFee msfFee,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.FreeOfCosts freeOfCosts,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.AdvancedDefinition advancedDefinition)
   {
      this.selectedRow = selectedRow;
      this.ruleFlowName = ruleFlowName;
      this.commonElements = commonElements;
      this.incentiveOnTopUp = incentiveOnTopUp;
      this.penaltyFee = penaltyFee;
      this.maintenanceFee = maintenanceFee;
      this.integrationFee = integrationFee;
      this.licenceFee = licenceFee;
      this.webServiceFee = webServiceFee;
      this.loyaltyBonus = loyaltyBonus;
      this.preferenceBenefit = preferenceBenefit;
      this.retainerFee = retainerFee;
      this.listingFee = listingFee;
      this.signUpFee = signUpFee;
      this.contentAccessFee = contentAccessFee;
      this.trainingFee = trainingFee;
      this.signUpBonus = signUpBonus;
      this.remittanceFee = remittanceFee;
      this.lookToBook = lookToBook;
      this.slabDetails = slabDetails;
      this.terminationFee = terminationFee;
      this.msfFee = msfFee;
      this.freeOfCosts = freeOfCosts;
      this.advancedDefinition = advancedDefinition;
   }

}