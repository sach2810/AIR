package cnk.acco_commercialscalculationengine.suppliertransactionalrules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@org.codehaus.jackson.map.annotate.JsonSerialize(include = org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion.NON_NULL)
public class BusinessRuleIntake implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead> commercialHead;
   private java.lang.String selectedRow;
   private java.lang.String ruleFlowName;
   private java.util.List<java.lang.String> commercialStatus;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommonElements commonElements;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.AdvancedDefinition advancedDefinition;
   private java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.SlabDetails> slabDetails;
   private java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.HotelDetails> hotelDetails;

   public void appendCommercialHead(cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      if (this.getCommercialHead() == null)
      {

         this.setCommercialHead(new ArrayList<CommercialHead>());

      }

      this.getCommercialHead().add(commercialHead);

   }

   public static boolean checkDate(String configuredValue, Date inputValue)
   {
      try
      {
         String[] configuredValueList = configuredValue.split(";");
         DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
         if (configuredValueList[0].equals("LESSTHANEQUALTO"))
         {
            Date date = format.parse(configuredValueList[1]);
            return (date.after(inputValue) || date.equals(inputValue));
         }
         else if (configuredValueList[0].equals("GREATERTHANEQUALTO"))
         {
            Date date = format.parse(configuredValueList[1]);
            return (date.before(inputValue) || date.equals(inputValue));
         }
         else if (configuredValueList[0].equals("BETWEEN"))
         {
            Date LowerLimit = format.parse(configuredValueList[1]);
            Date UpperLimit = format.parse(configuredValueList[2]);
            return ((LowerLimit.before(inputValue) || LowerLimit.equals(inputValue)) && (UpperLimit.after(inputValue) || UpperLimit.equals(inputValue)));
         }
         else if (configuredValueList[0].equals("EQUALTO"))
         {
            Date date = format.parse(configuredValueList[1]);
            return (date.equals(inputValue));
         }
         else if (configuredValueList[0].equals("IN"))
         {
            String date = format.format(inputValue);
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      return false;
   }

   public BusinessRuleIntake()
   {
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.AdvancedDefinition getAdvancedDefinition()
   {
      return this.advancedDefinition;
   }

   public void setAdvancedDefinition(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.AdvancedDefinition advancedDefinition)
   {
      this.advancedDefinition = advancedDefinition;
   }

   public java.lang.String getRuleFlowName()
   {
      return this.ruleFlowName;
   }

   public void setRuleFlowName(java.lang.String ruleFlowName)
   {
      this.ruleFlowName = ruleFlowName;
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommonElements getCommonElements()
   {
      return this.commonElements;
   }

   public void setCommonElements(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommonElements commonElements)
   {
      this.commonElements = commonElements;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead> getCommercialHead()
   {
      return this.commercialHead;
   }

   public void setCommercialHead(
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead> commercialHead)
   {
      this.commercialHead = commercialHead;
   }

   public java.util.List<java.lang.String> getCommercialStatus()
   {
      return this.commercialStatus;
   }

   public void setCommercialStatus(
         java.util.List<java.lang.String> commercialStatus)
   {
      this.commercialStatus = commercialStatus;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.SlabDetails> getSlabDetails()
   {
      return this.slabDetails;
   }

   public void setSlabDetails(
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.SlabDetails> slabDetails)
   {
      this.slabDetails = slabDetails;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.HotelDetails> getHotelDetails()
   {
      return this.hotelDetails;
   }

   public void setHotelDetails(
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.HotelDetails> hotelDetails)
   {
      this.hotelDetails = hotelDetails;
   }

   public BusinessRuleIntake(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.AdvancedDefinition advancedDefinition,
         java.lang.String ruleFlowName,
         java.lang.String selectedRow,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommonElements commonElements,
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead> commercialHead,
         java.util.List<java.lang.String> commercialStatus,
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.SlabDetails> slabDetails,
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.HotelDetails> hotelDetails)
   {
      this.advancedDefinition = advancedDefinition;
      this.ruleFlowName = ruleFlowName;
      this.selectedRow = selectedRow;
      this.commonElements = commonElements;
      this.commercialHead = commercialHead;
      this.commercialStatus = commercialStatus;
      this.slabDetails = slabDetails;
      this.hotelDetails = hotelDetails;
   }

}