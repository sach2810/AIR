package cnk.acco_commercialscalculationengine.suppliertransactionalrules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class RoomDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String roomCategory;
   private java.lang.String roomType;
   private java.lang.String rateType;
   private java.lang.String rateCode;
   private java.lang.String passengerType;
   private java.lang.String bookingId;
   private java.util.List<java.lang.String> ineligibleCommercials;
   private int bookingEngineKey;
   private java.util.List<java.lang.String> commercialsApplied;
   private double totalFare;
   private double totalReceivables;
   private double totalPayables;
   private java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialDetails> commercialDetails;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.FareBreakUp fareBreakUp;

   public java.util.List<java.lang.String> getIneligibleCommercials(){
      return this.ineligibleCommercials;
   }

   public void setIneligibleCommercials(java.util.List<java.lang.String> ineligibleCommercials){
      this.ineligibleCommercials = ineligibleCommercials;
   }
   
   public java.lang.String getBookingId()
   {
      return this.bookingId;
   }

   public void setBookingId(java.lang.String bookingId)
   {
      this.bookingId = bookingId;
   }
   
   public static boolean checkPassengerType(String configuredInput, String inputValue)
   {
      if (configuredInput.length() == 0)
         return true;
      if (inputValue == null && configuredInput.length() > 0)
         return false;
      String[] configuredInputList = configuredInput.split(";");
      String[] inputValueList = inputValue.split(";");

      for (int i = 0; i < inputValueList.length; i++)
      {
         for (int j = 0; j < configuredInputList.length; j++)
         {
            if (inputValueList[i].contains(configuredInputList[j]))
            {
               return true;
            }
         }
      }
      return false;
   }

   public static boolean checkValueExists(String configuredInput, String inputValue)
   {
      if (configuredInput.length() == 0)
         return true;
      String[] configuredInputList = configuredInput.split(";");
      String[] inputValueList = inputValue.split(";");

      for (int i = 0; i < inputValueList.length; i++)
      {
         for (int j = 0; j < configuredInputList.length; j++)
         {
            if (inputValueList[i].contains(configuredInputList[j]))
            {
               return true;
            }
         }
      }
      return false;
   }

   public void NonNettOffCommercialCalculation(String CommercialName, String CommercialType, double PercentageValue, double AmountValue, String FareComponent, String Currency, String TaxComponent, String MDMRuleId)
   {

      if (CommercialType == "Receivable")
         ReceivableNonNettOffCommercialCalculation(CommercialName, PercentageValue, AmountValue, FareComponent, Currency, TaxComponent,MDMRuleId);
      else
         PayableNonNettOffCommercialCalculation(CommercialName, PercentageValue, AmountValue, FareComponent, Currency, TaxComponent,MDMRuleId);
   }

   public void ReceivableNonNettOffCommercialCalculation(String CommercialName, double PercentageValue, double AmountValue, String FareComponent, String Currency, String TaxComponent, String MDMRuleId)
   {

      CommercialDetails commDetails = new CommercialDetails();
      FareBreakUp commDetailsFareBreakUp = null;

      if (this.getCommercialDetails() == null)
      {
         this.setCommercialDetails(new ArrayList<CommercialDetails>());
      }

      if (this.getFareBreakUp() != null)
      {
         commDetailsFareBreakUp = new FareBreakUp();
         commDetailsFareBreakUp.setBaseFare(this.getFareBreakUp().getBaseFare());
      }
      commDetails.setCommercialInitialAmount(0);
	  commDetails.setMDMRuleId(MDMRuleId);
      double commAmount = 0;
      if (PercentageValue > 0 || TaxComponent!=null)
      {

         commAmount = ReceivableFareBreakUpCalculation(commDetails, commDetailsFareBreakUp, FareComponent, TaxComponent, PercentageValue);
         commDetails.setCommercialCalculationPercentage(PercentageValue);
      }
      if (AmountValue > 0)
      {

         if (commDetails.getCommercialFareComponent() == null && FareComponent != null)
            commDetails.setCommercialFareComponent(FareComponent);

         if (commDetailsFareBreakUp != null)
         {

            if (commDetails.getCommercialInitialAmount() == 0)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - AmountValue);
               CreateReceivableCommercialTaxBreakUp(this.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, 0);
               commDetails.setCommercialInitialAmount(this.getFareBreakUp().getBaseFare());
            }

            else
            {

               //  if (FareComponent == "Basic" || FareComponent == "Total")
               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - AmountValue);

               /*  else
                 {

                    List<String> tempTaxList = Arrays.asList(TaxComponent.split(";"));

                    for (TaxDetails taxDetails : commDetailsFareBreakUp.getTaxDetails())
                    {
                       for (String tempTaxName : tempTaxList)
                       {
                          if (tempTaxName.equals(taxDetails.getTaxName()))
                             taxDetails.setTaxValue(taxDetails.getTaxValue() - AmountValue);
                          //break;
                       }
                    }
                 }*/
            }

         }

         else
         {

            if (commDetails.getCommercialInitialAmount() == 0)
               commDetails.setCommercialInitialAmount(this.getTotalFare());
         }

         commAmount = commAmount + AmountValue;
         commDetails.setCommercialCurrency(Currency);
         commDetails.setCommercialCalculationAmount(AmountValue);
      }

      commDetails.setCommercialAmount(commAmount);
      commDetails.setCommercialName(CommercialName);
      commDetails.setCommercialTotalAmount(this.getTotalFare() - commAmount);
      commDetails.setFareBreakUp(commDetailsFareBreakUp);
      this.getCommercialDetails().add(commDetails);

      this.setTotalReceivables(this.getTotalReceivables() + commAmount);
   }

   public double ReceivableFareBreakUpCalculation(CommercialDetails commDetails, FareBreakUp commDetailsFareBreakUp, String fareName, String taxName, double percentageValue)
   {

      if (taxName == null)
      {

         commDetails.setCommercialFareComponent(fareName);
         if (fareName == "Total")
         {

            if (this.getFareBreakUp() != null)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - (commDetailsFareBreakUp.getBaseFare() * (percentageValue / 100)));
               CreateReceivableCommercialTaxBreakUp(this.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, percentageValue);

            }
            commDetails.setCommercialInitialAmount(this.getTotalFare());
            return this.getTotalFare() * (percentageValue / 100);

         }
         else if (fareName == "Basic")
         {

            if (this.getFareBreakUp().getTaxDetails() != null)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - (commDetailsFareBreakUp.getBaseFare() * (percentageValue / 100)));

               CreateReceivableCommercialTaxBreakUp(this.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, 0);
            }
            commDetails.setCommercialInitialAmount(this.getFareBreakUp().getBaseFare());
            return this.getFareBreakUp().getBaseFare() * (percentageValue / 100);
         }
      }

      else
      {

         double commercialAmount = 0;
		 double commercialTaxAmount = 0;
		 double taxAmount = 0;
         if (fareName == "Basic")
         {

            commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - (commDetailsFareBreakUp.getBaseFare() * percentageValue / 100));
            commercialAmount = this.getFareBreakUp().getBaseFare();
            commDetails.setCommercialFareComponent(fareName);

         }

         if (this.getFareBreakUp().getTaxDetails() != null)
         {

            List<String> tempTaxDetails = Arrays.asList(taxName.split("\\|"));
            commDetailsFareBreakUp.setTaxDetails(new ArrayList<TaxDetails>());

            for (TaxDetails taxes : this.getFareBreakUp().getTaxDetails())
            {

               TaxDetails commercialTax = new TaxDetails();
               commercialTax.setTaxName(taxes.getTaxName());
               commercialTax.setTaxValue(taxes.getTaxValue());

               for (String tempTaxName : tempTaxDetails)
               {
                  String[] configuredtax = tempTaxName.split(";");
                  if (configuredtax[0].equals(taxes.getTaxName()))
				 {
					 taxAmount = taxAmount + taxes.getTaxValue();
                     //commercialAmount = commercialAmount + taxes.getTaxValue();
                     commercialTaxAmount = commercialTaxAmount + (taxes.getTaxValue() * Double.parseDouble(configuredtax[1]) / 100);
                     commercialTax.setTaxValue(taxes.getTaxValue() - (taxes.getTaxValue() * Double.parseDouble(configuredtax[1]) / 100));

                     if (commDetails.getCommercialFareComponent() == null)
                        commDetails.setCommercialFareComponent(tempTaxName);
                     else
                        commDetails.setCommercialFareComponent(commDetails.getCommercialFareComponent() + "," + tempTaxName);
                  }
                  //break;
               }
               commDetailsFareBreakUp.getTaxDetails().add(commercialTax);
            }
         }

         commDetails.setCommercialInitialAmount(commercialAmount+taxAmount);
         return ((commercialAmount * (percentageValue / 100)) + commercialTaxAmount);
      }

      return 0;
   }

   public void CreateReceivableCommercialTaxBreakUp(List<TaxDetails> taxDetails, FareBreakUp commDetailsFareBreakUp, double taxPercentageValue)
   {

      commDetailsFareBreakUp.setTaxDetails(new ArrayList<TaxDetails>());

      for (TaxDetails taxes : taxDetails)
      {

         TaxDetails commercialTax = new TaxDetails();
         if (taxPercentageValue == 0)
         {

            commercialTax.setTaxValue(taxes.getTaxValue());
            commercialTax.setTaxName(taxes.getTaxName());
         }
         else
         {

            commercialTax.setTaxValue(taxes.getTaxValue() - (taxes.getTaxValue() * (taxPercentageValue / 100)));
            commercialTax.setTaxName(taxes.getTaxName());
         }

         commDetailsFareBreakUp.getTaxDetails().add(commercialTax);

      }
   }

   public void PayableNonNettOffCommercialCalculation(String CommercialName, double PercentageValue, double AmountValue, String FareComponent, String Currency, String TaxComponent, String MDMRuleId)
   {

      CommercialDetails commDetails = new CommercialDetails();
      FareBreakUp commDetailsFareBreakUp = null;

      if (this.getCommercialDetails() == null)
      {
         this.setCommercialDetails(new ArrayList<CommercialDetails>());
      }

      if (this.getFareBreakUp() != null)
      {
         commDetailsFareBreakUp = new FareBreakUp();
         commDetailsFareBreakUp.setBaseFare(this.getFareBreakUp().getBaseFare());
      }
      commDetails.setCommercialInitialAmount(0);
	  commDetails.setMDMRuleId(MDMRuleId);
      double commAmount = 0;
      if (PercentageValue > 0 || TaxComponent!=null)
      {

         commAmount = PayableFareBreakUpCalculation(commDetails, commDetailsFareBreakUp, FareComponent, TaxComponent, PercentageValue);
         commDetails.setCommercialCalculationPercentage(PercentageValue);
      }
      if (AmountValue > 0)
      {

         if (commDetails.getCommercialFareComponent() == null && FareComponent != null)
            commDetails.setCommercialFareComponent(FareComponent);

         if (commDetailsFareBreakUp != null)
         {

            if (commDetails.getCommercialInitialAmount() == 0)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() + AmountValue);
               CreatePayableCommercialTaxBreakUp(this.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, 0);
               commDetails.setCommercialInitialAmount(this.getFareBreakUp().getBaseFare());
            }

            else
            {

               // if (FareComponent == "Basic" || FareComponent == "Total")
               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() + AmountValue);

               /* else
                {

                   List<String> tempTaxList = Arrays.asList(TaxComponent.split(";"));
                   for (TaxDetails taxDetails : commDetailsFareBreakUp.getTaxDetails())
                   {
                      for (String tempTaxName : tempTaxList)
                      {
                         if (tempTaxName.equals(taxDetails.getTaxName()))
                            taxDetails.setTaxValue(taxDetails.getTaxValue() + AmountValue);
                         //break;
                      }
                   }
                }*/
            }

         }

         else
         {

            if (commDetails.getCommercialInitialAmount() == 0)
               commDetails.setCommercialInitialAmount(this.getTotalFare());
         }

         commAmount = commAmount + AmountValue;
         commDetails.setCommercialCurrency(Currency);
         commDetails.setCommercialCalculationAmount(AmountValue);
      }

      commDetails.setCommercialAmount(commAmount);
      commDetails.setCommercialName(CommercialName);
      commDetails.setCommercialTotalAmount(this.getTotalFare() + commAmount);
      commDetails.setFareBreakUp(commDetailsFareBreakUp);
      this.getCommercialDetails().add(commDetails);

      this.setTotalPayables(this.getTotalPayables() + commAmount);
   }

   public double PayableFareBreakUpCalculation(CommercialDetails commDetails, FareBreakUp commDetailsFareBreakUp, String fareName, String taxName, double percentageValue)
   {

      if (taxName == null)
      {

         commDetails.setCommercialFareComponent(fareName);
         if (fareName == "Total")
         {

            if (this.getFareBreakUp() != null)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() + (commDetailsFareBreakUp.getBaseFare() * (percentageValue / 100)));
               CreatePayableCommercialTaxBreakUp(this.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, percentageValue);

            }
            commDetails.setCommercialInitialAmount(this.getTotalFare());
            return this.getTotalFare() * (percentageValue / 100);

         }
         else if (fareName == "Basic")
         {

            if (this.getFareBreakUp().getTaxDetails() != null)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() + (commDetailsFareBreakUp.getBaseFare() * (percentageValue / 100)));
               CreatePayableCommercialTaxBreakUp(this.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, 0);
            }
            commDetails.setCommercialInitialAmount(this.getFareBreakUp().getBaseFare());
            return this.getFareBreakUp().getBaseFare() * (percentageValue / 100);
         }
      }

      else
      {

         double commercialAmount = 0;
		 double commercialTaxAmount = 0;
		 double taxAmount = 0;
         if (fareName == "Basic")
         {

            commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() + (commDetailsFareBreakUp.getBaseFare() * percentageValue / 100));
            commercialAmount = this.getFareBreakUp().getBaseFare();
            commDetails.setCommercialFareComponent(fareName);
         }

         if (this.getFareBreakUp().getTaxDetails() != null)
         {

            List<String> tempTaxDetails = Arrays.asList(taxName.split("\\|"));
            commDetailsFareBreakUp.setTaxDetails(new ArrayList<TaxDetails>());

            for (TaxDetails taxes : this.getFareBreakUp().getTaxDetails())
            {

               TaxDetails commercialTax = new TaxDetails();
               commercialTax.setTaxName(taxes.getTaxName());
               commercialTax.setTaxValue(taxes.getTaxValue());

               for (String tempTaxName : tempTaxDetails)
               {

                  String[] configuredtax = tempTaxName.split(";");
                  if (configuredtax[0].equals(taxes.getTaxName()))
                 {

                     //commercialAmount = commercialAmount + taxes.getTaxValue();
					 taxAmount = taxAmount + taxes.getTaxValue();
                     commercialTaxAmount = commercialTaxAmount + (taxes.getTaxValue() * Double.parseDouble(configuredtax[1]) / 100);
                     commercialTax.setTaxValue(taxes.getTaxValue() + (taxes.getTaxValue() * Double.parseDouble(configuredtax[1]) / 100));

                     if (commDetails.getCommercialFareComponent() == null)
                        commDetails.setCommercialFareComponent(tempTaxName);
                     else
                        commDetails.setCommercialFareComponent(commDetails.getCommercialFareComponent() + "," + tempTaxName);
                  }
                  //break;
               }
               commDetailsFareBreakUp.getTaxDetails().add(commercialTax);
            }
         }

         commDetails.setCommercialInitialAmount(commercialAmount+taxAmount);
         return ((commercialAmount * (percentageValue / 100)) + commercialTaxAmount);
      }

      return 0;
   }

   public void CreatePayableCommercialTaxBreakUp(List<TaxDetails> taxDetails, FareBreakUp commDetailsFareBreakUp, double taxPercentageValue)
   {

      commDetailsFareBreakUp.setTaxDetails(new ArrayList<TaxDetails>());
      for (TaxDetails taxes : taxDetails)
      {

         TaxDetails commercialTax = new TaxDetails();
         if (taxPercentageValue == 0)
         {

            commercialTax.setTaxValue(taxes.getTaxValue());
            commercialTax.setTaxName(taxes.getTaxName());
         }
         else
         {

            commercialTax.setTaxValue(taxes.getTaxValue() + (taxes.getTaxValue() * (taxPercentageValue / 100)));
            commercialTax.setTaxName(taxes.getTaxName());
         }

         commDetailsFareBreakUp.getTaxDetails().add(commercialTax);

      }
   }

   public void AllCommercialCalculation(String nettOffCommercialHeadName, String CommercialName, String CommercialType, double PercentageValue, double AmountValue, String FareComponent, String Currency, String TaxComponent, String MDMRuleId)
   {

      if (nettOffCommercialHeadName == null)
         NonNettOffCommercialCalculation(CommercialName, CommercialType, PercentageValue, AmountValue, FareComponent, Currency, TaxComponent,MDMRuleId);

      else
      {
         CommercialDetails netOffCommDetails = null;
         for (CommercialDetails itrCommDet : this.getCommercialDetails())
         {
            if (itrCommDet.getCommercialName().equals(nettOffCommercialHeadName))
            {

               netOffCommDetails = itrCommDet;
               break;
            }
         }
         NettOffCommercialCalculation(netOffCommDetails, CommercialName, PercentageValue, AmountValue, FareComponent, Currency, TaxComponent,MDMRuleId);

      }

   }

   public void NettOffCommercialCalculation(CommercialDetails nettOffCommDetails, String CommercialName, double PercentageValue, double AmountValue, String FareComponent, String Currency, String TaxComponent, String MDMRuleId)
   {

      CommercialDetails commDetails = new CommercialDetails();
      FareBreakUp commDetailsFareBreakUp = null;

      if (nettOffCommDetails.getFareBreakUp() != null)
      {
         commDetailsFareBreakUp = new FareBreakUp();
         commDetailsFareBreakUp.setBaseFare(nettOffCommDetails.getFareBreakUp().getBaseFare());
      }
      commDetails.setCommercialInitialAmount(0);
	  commDetails.setMDMRuleId(MDMRuleId);
      double commAmount = 0;
      if (PercentageValue > 0 || TaxComponent!=null)
      {

         commAmount = NettOffFareBreakUpCalculation(nettOffCommDetails, commDetails, commDetailsFareBreakUp, FareComponent, TaxComponent, PercentageValue);
         commDetails.setCommercialCalculationPercentage(PercentageValue);
      }
      if (AmountValue > 0)
      {

         if (commDetails.getCommercialFareComponent() == null && FareComponent != null)
            commDetails.setCommercialFareComponent(FareComponent);

         if (commDetailsFareBreakUp != null)
         {

            if (commDetails.getCommercialInitialAmount() == 0)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - AmountValue);
               CreateReceivableCommercialTaxBreakUp(nettOffCommDetails.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, 0);
               commDetails.setCommercialInitialAmount(nettOffCommDetails.getFareBreakUp().getBaseFare());
            }

            else
            {

               // if (FareComponent == "Basic" || FareComponent == "Total")
               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - AmountValue);

               /* else
                {

                   List<String> tempTaxList = Arrays.asList(TaxComponent.split(";"));
                   for (TaxDetails taxDetails : commDetailsFareBreakUp.getTaxDetails())
                   {
                      for (String tempTaxName : tempTaxList)
                      {
                         if (tempTaxName.equals(taxDetails.getTaxName()))
                            taxDetails.setTaxValue(taxDetails.getTaxValue() - AmountValue);
                         //break;
                      }
                   }
                }*/
            }

         }

         else
         {

            if (commDetails.getCommercialInitialAmount() == 0)
               commDetails.setCommercialInitialAmount(nettOffCommDetails.getCommercialTotalAmount());
         }

         commAmount = commAmount + AmountValue;
         commDetails.setCommercialCurrency(Currency);
         commDetails.setCommercialCalculationAmount(AmountValue);
      }

      commDetails.setCommercialAmount(commAmount);
      commDetails.setCommercialName(CommercialName);
      commDetails.setCommercialTotalAmount(nettOffCommDetails.getCommercialTotalAmount() - commAmount);
      commDetails.setFareBreakUp(commDetailsFareBreakUp);
      this.getCommercialDetails().add(commDetails);

      this.setTotalReceivables(this.getTotalReceivables() + commAmount);

   }

   public double NettOffFareBreakUpCalculation(CommercialDetails nettOffCommDetails, CommercialDetails commDetails, FareBreakUp commDetailsFareBreakUp, String fareName, String taxName, double percentageValue)
   {

      if (taxName == null)
      {

         commDetails.setCommercialFareComponent(fareName);
         if (fareName == "Total")
         {

            if (nettOffCommDetails.getFareBreakUp() != null)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - (commDetailsFareBreakUp.getBaseFare() * (percentageValue / 100)));
               CreateReceivableCommercialTaxBreakUp(nettOffCommDetails.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, percentageValue);

            }
            commDetails.setCommercialInitialAmount(nettOffCommDetails.getCommercialTotalAmount());
            return nettOffCommDetails.getCommercialTotalAmount() * (percentageValue / 100);

         }
         else if (fareName == "Basic")
         {

            if (nettOffCommDetails.getFareBreakUp().getTaxDetails() != null)
            {

               commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - (commDetailsFareBreakUp.getBaseFare() * (percentageValue / 100)));
               CreateReceivableCommercialTaxBreakUp(nettOffCommDetails.getFareBreakUp().getTaxDetails(), commDetailsFareBreakUp, 0);
            }
            commDetails.setCommercialInitialAmount(nettOffCommDetails.getFareBreakUp().getBaseFare());
            return nettOffCommDetails.getFareBreakUp().getBaseFare() * (percentageValue / 100);
         }
      }

      else
      {

         double commercialAmount = 0;
		 double commercialTaxAmount = 0;
		 double taxAmount = 0;
         if (fareName == "Basic")
         {

            commDetailsFareBreakUp.setBaseFare(commDetailsFareBreakUp.getBaseFare() - (commDetailsFareBreakUp.getBaseFare() * percentageValue / 100));
            commercialAmount = nettOffCommDetails.getFareBreakUp().getBaseFare();
            commDetails.setCommercialFareComponent(fareName);
         }

         if (nettOffCommDetails.getFareBreakUp().getTaxDetails() != null)
         {

            List<String> tempTaxDetails = Arrays.asList(taxName.split("\\|"));
            commDetailsFareBreakUp.setTaxDetails(new ArrayList<TaxDetails>());

            for (TaxDetails taxes : nettOffCommDetails.getFareBreakUp().getTaxDetails())
            {

               TaxDetails commercialTax = new TaxDetails();
               commercialTax.setTaxName(taxes.getTaxName());
               commercialTax.setTaxValue(taxes.getTaxValue());

               for (String tempTaxName : tempTaxDetails)
               {

                  String[] configuredtax = tempTaxName.split(";");
                  if (configuredtax[0].equals(taxes.getTaxName()))
                  {
					  taxAmount = taxAmount + taxes.getTaxValue();
                     //commercialAmount = commercialAmount + taxes.getTaxValue();
                     commercialTaxAmount = commercialTaxAmount + (taxes.getTaxValue() * Double.parseDouble(configuredtax[1]) / 100);                     
                     commercialTax.setTaxValue(taxes.getTaxValue() - (taxes.getTaxValue() * Double.parseDouble(configuredtax[1]) / 100));

                     if (commDetails.getCommercialFareComponent() == null)
                        commDetails.setCommercialFareComponent(tempTaxName);
                     else
                        commDetails.setCommercialFareComponent(commDetails.getCommercialFareComponent() + "," + tempTaxName);
                  }
                  //break;
               }
               commDetailsFareBreakUp.getTaxDetails().add(commercialTax);
            }
         }

         commDetails.setCommercialInitialAmount(commercialAmount+taxAmount);
         return ((commercialAmount * (percentageValue / 100)) + commercialTaxAmount);
      }

      return 0;
   }

   public RoomDetails()
   {
   }

   public java.lang.String getRoomType()
   {
      return this.roomType;
   }

   public void setRoomType(java.lang.String roomType)
   {
      this.roomType = roomType;
   }

   public java.util.List<java.lang.String> getCommercialsApplied()
   {
      return this.commercialsApplied;
   }

   public void setCommercialsApplied(
         java.util.List<java.lang.String> commercialsApplied)
   {
      this.commercialsApplied = commercialsApplied;
   }

   public double getTotalFare()
   {
      return this.totalFare;
   }

   public void setTotalFare(double totalFare)
   {
      this.totalFare = totalFare;
   }

   public double getTotalReceivables()
   {
      return this.totalReceivables;
   }

   public void setTotalReceivables(double totalReceivables)
   {
      this.totalReceivables = totalReceivables;
   }

   public double getTotalPayables()
   {
      return this.totalPayables;
   }

   public void setTotalPayables(double totalPayables)
   {
      this.totalPayables = totalPayables;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialDetails> getCommercialDetails()
   {
      return this.commercialDetails;
   }

   public void setCommercialDetails(
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialDetails> commercialDetails)
   {
      this.commercialDetails = commercialDetails;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.FareBreakUp getFareBreakUp()
   {
      return this.fareBreakUp;
   }

   public void setFareBreakUp(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.FareBreakUp fareBreakUp)
   {
      this.fareBreakUp = fareBreakUp;
   }

   public java.lang.String getRoomCategory()
   {
      return this.roomCategory;
   }

   public void setRoomCategory(java.lang.String roomCategory)
   {
      this.roomCategory = roomCategory;
   }

   public java.lang.String getPassengerType()
   {
      return this.passengerType;
   }

   public void setPassengerType(java.lang.String passengerType)
   {
      this.passengerType = passengerType;
   }

   public java.lang.String getRateType()
   {
      return this.rateType;
   }

   public void setRateType(java.lang.String rateType)
   {
      this.rateType = rateType;
   }

   public java.lang.String getRateCode()
   {
      return this.rateCode;
   }

   public void setRateCode(java.lang.String rateCode)
   {
      this.rateCode = rateCode;
   }

   public int getBookingEngineKey()
   {
      return this.bookingEngineKey;
   }

   public void setBookingEngineKey(int bookingEngineKey)
   {
      this.bookingEngineKey = bookingEngineKey;
   }

   public RoomDetails(
         java.lang.String roomType,
         java.util.List<java.lang.String> commercialsApplied,
         double totalFare,
         double totalReceivables,
         double totalPayables,
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialDetails> commercialDetails,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.FareBreakUp fareBreakUp,
         java.lang.String roomCategory, java.lang.String passengerType,
         java.lang.String rateType, java.lang.String rateCode,
         int bookingEngineKey,java.util.List<java.lang.String> ineligibleCommercials,java.lang.String bookingId)
   {
      this.roomType = roomType;
      this.commercialsApplied = commercialsApplied;
      this.totalFare = totalFare;
      this.totalReceivables = totalReceivables;
      this.totalPayables = totalPayables;
      this.commercialDetails = commercialDetails;
      this.fareBreakUp = fareBreakUp;
      this.roomCategory = roomCategory;
      this.passengerType = passengerType;
      this.rateType = rateType;
      this.rateCode = rateCode;
      this.bookingEngineKey = bookingEngineKey;
      this.bookingId = bookingId;
	  this.ineligibleCommercials = ineligibleCommercials;
   }

}