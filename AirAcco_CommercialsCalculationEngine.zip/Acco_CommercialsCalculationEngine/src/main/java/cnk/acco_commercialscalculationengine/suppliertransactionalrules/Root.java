package cnk.acco_commercialscalculationengine.suppliertransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class Root implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.Header header;
   private java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake> businessRuleIntake;

   private boolean transactional;

   public Root()
   {
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.Header getHeader()
   {
      return this.header;
   }

   public void setHeader(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.Header header)
   {
      this.header = header;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake> getBusinessRuleIntake()
   {
      return this.businessRuleIntake;
   }

   public void setBusinessRuleIntake(
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake> businessRuleIntake)
   {
      this.businessRuleIntake = businessRuleIntake;
   }

   public boolean isTransactional()
   {
      return this.transactional;
   }

   public void setTransactional(boolean transactional)
   {
      this.transactional = transactional;
   }

   public Root(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.Header header,
         java.util.List<cnk.acco_commercialscalculationengine.suppliertransactionalrules.BusinessRuleIntake> businessRuleIntake,
         boolean transactional)
   {
      this.header = header;
      this.businessRuleIntake = businessRuleIntake;
      this.transactional = transactional;
   }

}