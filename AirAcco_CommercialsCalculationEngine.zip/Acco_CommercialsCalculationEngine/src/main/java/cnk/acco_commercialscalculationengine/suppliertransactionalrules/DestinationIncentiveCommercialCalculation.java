package cnk.acco_commercialscalculationengine.suppliertransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class DestinationIncentiveCommercialCalculation
{

   static final long serialVersionUID = 1L;

   private java.lang.String selectedRow;

   private java.lang.String baseSelectedRow;

   public DestinationIncentiveCommercialCalculation()
   {
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public java.lang.String getBaseSelectedRow()
   {
      return this.baseSelectedRow;
   }

   public void setBaseSelectedRow(java.lang.String baseSelectedRow)
   {
      this.baseSelectedRow = baseSelectedRow;
   }

   public DestinationIncentiveCommercialCalculation(
         java.lang.String selectedRow, java.lang.String baseSelectedRow)
   {
      this.selectedRow = selectedRow;
      this.baseSelectedRow = baseSelectedRow;
   }
}
