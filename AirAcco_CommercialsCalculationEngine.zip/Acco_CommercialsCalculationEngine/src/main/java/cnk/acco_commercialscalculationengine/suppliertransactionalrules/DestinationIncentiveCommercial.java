package cnk.acco_commercialscalculationengine.suppliertransactionalrules;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class DestinationIncentiveCommercial implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String selectedRow;
   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead;

   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding;

   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb;

   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees;

   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge;

   private cnk.acco_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees;

   private boolean advancedDefinitionCompleted;

   public DestinationIncentiveCommercial()
   {
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead getCommercialHead()
   {
      return this.commercialHead;
   }

   public void setCommercialHead(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      this.commercialHead = commercialHead;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial getOverriding()
   {
      return this.overriding;
   }

   public void setOverriding(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding)
   {
      this.overriding = overriding;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.PLBCommercial getPlb()
   {
      return this.plb;
   }

   public void setPlb(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb)
   {
      this.plb = plb;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial getSegmentFees()
   {
      return this.segmentFees;
   }

   public void setSegmentFees(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees)
   {
      this.segmentFees = segmentFees;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial getServiceCharge()
   {
      return this.serviceCharge;
   }

   public void setServiceCharge(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge)
   {
      this.serviceCharge = serviceCharge;
   }

   public cnk.acco_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial getManagementFees()
   {
      return this.managementFees;
   }

   public void setManagementFees(
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees)
   {
      this.managementFees = managementFees;
   }

   public DestinationIncentiveCommercial(
         java.lang.String selectedRow,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead)
   {
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
   }

   public boolean isAdvancedDefinitionCompleted()
   {
      return this.advancedDefinitionCompleted;
   }

   public void setAdvancedDefinitionCompleted(boolean advancedDefinitionCompleted)
   {
      this.advancedDefinitionCompleted = advancedDefinitionCompleted;
   }

   public DestinationIncentiveCommercial(
         java.lang.String selectedRow,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.CommercialHead commercialHead,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.OverridingCommercial overriding,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.PLBCommercial plb,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.SegmentFeesCommercial segmentFees,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.ServiceChargeCommercial serviceCharge,
         cnk.acco_commercialscalculationengine.suppliertransactionalrules.ManagementFeesCommercial managementFees,
         boolean advancedDefinitionCompleted)
   {
      this.selectedRow = selectedRow;
      this.commercialHead = commercialHead;
      this.overriding = overriding;
      this.plb = plb;
      this.segmentFees = segmentFees;
      this.serviceCharge = serviceCharge;
      this.managementFees = managementFees;
      this.advancedDefinitionCompleted = advancedDefinitionCompleted;
   }

}