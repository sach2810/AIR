package cnk.acco_commercialscalculationengine.clientsettlementrules;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class AdvancedDefinition implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private boolean isAdvanceDefinition;
   private java.util.Date salesDate;
   private java.util.Date travelCheckInDate;
   private java.util.Date travelCheckOutDate;
   private java.lang.String roomCategory;
   private java.lang.String roomType;
   private java.lang.String bookingType;
   private java.lang.String credentialsName;
   private java.lang.String passengerType;
   private java.lang.String travelType;
   private java.lang.String travelProductName;
   private java.lang.String nationality;
   private java.lang.String continent;
   private java.lang.String country;
   private java.lang.String state;
   private java.lang.String city;
   private java.lang.String connectivitySupplier;
   private java.lang.String connectivitySupplierType;

   public AdvancedDefinition()
   {
   }

   public boolean isIsAdvanceDefinition()
   {
      return this.isAdvanceDefinition;
   }

   public void setIsAdvanceDefinition(boolean isAdvanceDefinition)
   {
      this.isAdvanceDefinition = isAdvanceDefinition;
   }

   public java.util.Date getSalesDate()
   {
      return this.salesDate;
   }

   public void setSalesDate(java.util.Date salesDate)
   {
      this.salesDate = salesDate;
   }

   public java.util.Date getTravelCheckInDate()
   {
      return this.travelCheckInDate;
   }

   public void setTravelCheckInDate(java.util.Date travelCheckInDate)
   {
      this.travelCheckInDate = travelCheckInDate;
   }

   public java.util.Date getTravelCheckOutDate()
   {
      return this.travelCheckOutDate;
   }

   public void setTravelCheckOutDate(java.util.Date travelCheckOutDate)
   {
      this.travelCheckOutDate = travelCheckOutDate;
   }

   public java.lang.String getRoomCategory()
   {
      return this.roomCategory;
   }

   public void setRoomCategory(java.lang.String roomCategory)
   {
      this.roomCategory = roomCategory;
   }

   public java.lang.String getRoomType()
   {
      return this.roomType;
   }

   public void setRoomType(java.lang.String roomType)
   {
      this.roomType = roomType;
   }

   public java.lang.String getBookingType()
   {
      return this.bookingType;
   }

   public void setBookingType(java.lang.String bookingType)
   {
      this.bookingType = bookingType;
   }

   public java.lang.String getCredentialsName()
   {
      return this.credentialsName;
   }

   public void setCredentialsName(java.lang.String credentialsName)
   {
      this.credentialsName = credentialsName;
   }

   public java.lang.String getPassengerType()
   {
      return this.passengerType;
   }

   public void setPassengerType(java.lang.String passengerType)
   {
      this.passengerType = passengerType;
   }

   public java.lang.String getTravelType()
   {
      return this.travelType;
   }

   public void setTravelType(java.lang.String travelType)
   {
      this.travelType = travelType;
   }

   public java.lang.String getTravelProductName()
   {
      return this.travelProductName;
   }

   public void setTravelProductName(java.lang.String travelProductName)
   {
      this.travelProductName = travelProductName;
   }

   public java.lang.String getNationality()
   {
      return this.nationality;
   }

   public void setNationality(java.lang.String nationality)
   {
      this.nationality = nationality;
   }

   public java.lang.String getContinent()
   {
      return this.continent;
   }

   public void setContinent(java.lang.String continent)
   {
      this.continent = continent;
   }

   public java.lang.String getCountry()
   {
      return this.country;
   }

   public void setCountry(java.lang.String country)
   {
      this.country = country;
   }

   public java.lang.String getState()
   {
      return this.state;
   }

   public void setState(java.lang.String state)
   {
      this.state = state;
   }

   public java.lang.String getCity()
   {
      return this.city;
   }

   public void setCity(java.lang.String city)
   {
      this.city = city;
   }

   public java.lang.String getConnectivitySupplier()
   {
      return this.connectivitySupplier;
   }

   public void setConnectivitySupplier(java.lang.String connectivitySupplier)
   {
      this.connectivitySupplier = connectivitySupplier;
   }

   public java.lang.String getConnectivitySupplierType()
   {
      return this.connectivitySupplierType;
   }

   public void setConnectivitySupplierType(
         java.lang.String connectivitySupplierType)
   {
      this.connectivitySupplierType = connectivitySupplierType;
   }

   public AdvancedDefinition(boolean isAdvanceDefinition,
         java.util.Date salesDate, java.util.Date travelCheckInDate,
         java.util.Date travelCheckOutDate, java.lang.String roomCategory,
         java.lang.String roomType, java.lang.String bookingType,
         java.lang.String credentialsName, java.lang.String passengerType,
         java.lang.String travelType, java.lang.String travelProductName,
         java.lang.String nationality, java.lang.String continent,
         java.lang.String country, java.lang.String state,
         java.lang.String city, java.lang.String connectivitySupplier,
         java.lang.String connectivitySupplierType)
   {
      this.isAdvanceDefinition = isAdvanceDefinition;
      this.salesDate = salesDate;
      this.travelCheckInDate = travelCheckInDate;
      this.travelCheckOutDate = travelCheckOutDate;
      this.roomCategory = roomCategory;
      this.roomType = roomType;
      this.bookingType = bookingType;
      this.credentialsName = credentialsName;
      this.passengerType = passengerType;
      this.travelType = travelType;
      this.travelProductName = travelProductName;
      this.nationality = nationality;
      this.continent = continent;
      this.country = country;
      this.state = state;
      this.city = city;
      this.connectivitySupplier = connectivitySupplier;
      this.connectivitySupplierType = connectivitySupplierType;
   }

}