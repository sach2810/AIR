package cnk.acco_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class WebServiceFee implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees;

   public WebServiceFee()
   {
   }

   public cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees getOtherFees()
   {
      return this.otherFees;
   }

   public void setOtherFees(
         cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

   public WebServiceFee(
         cnk.acco_commercialscalculationengine.clientsettlementrules.OtherFees otherFees)
   {
      this.otherFees = otherFees;
   }

}