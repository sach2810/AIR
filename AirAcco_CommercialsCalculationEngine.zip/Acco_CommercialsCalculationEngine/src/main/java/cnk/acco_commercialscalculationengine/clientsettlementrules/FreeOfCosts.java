package cnk.acco_commercialscalculationengine.clientsettlementrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class FreeOfCosts implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String contractType;
   private boolean PLBApplicable;
   private java.lang.String commercialType;
   private boolean isApplicable;
   private java.util.List<cnk.acco_commercialscalculationengine.suppliersettlementrules.SlabDetails> slabDetails;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCRooms focRooms;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCUpgrades focUpgrades;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCUtilisation focUtilisation;

   private cnk.acco_commercialscalculationengine.suppliersettlementrules.RoomDetails rooms;

   public FreeOfCosts()
   {
   }

   public java.lang.String getContractType()
   {
      return this.contractType;
   }

   public void setContractType(java.lang.String contractType)
   {
      this.contractType = contractType;
   }

   public boolean isPLBApplicable()
   {
      return this.PLBApplicable;
   }

   public void setPLBApplicable(boolean PLBApplicable)
   {
      this.PLBApplicable = PLBApplicable;
   }

   public java.lang.String getCommercialType()
   {
      return this.commercialType;
   }

   public void setCommercialType(java.lang.String commercialType)
   {
      this.commercialType = commercialType;
   }

   public boolean isIsApplicable()
   {
      return this.isApplicable;
   }

   public void setIsApplicable(boolean isApplicable)
   {
      this.isApplicable = isApplicable;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.suppliersettlementrules.SlabDetails> getSlabDetails()
   {
      return this.slabDetails;
   }

   public void setSlabDetails(
         java.util.List<cnk.acco_commercialscalculationengine.suppliersettlementrules.SlabDetails> slabDetails)
   {
      this.slabDetails = slabDetails;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCRooms getFocRooms()
   {
      return this.focRooms;
   }

   public void setFocRooms(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCRooms focRooms)
   {
      this.focRooms = focRooms;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCUpgrades getFocUpgrades()
   {
      return this.focUpgrades;
   }

   public void setFocUpgrades(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCUpgrades focUpgrades)
   {
      this.focUpgrades = focUpgrades;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCUtilisation getFocUtilisation()
   {
      return this.focUtilisation;
   }

   public void setFocUtilisation(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCUtilisation focUtilisation)
   {
      this.focUtilisation = focUtilisation;
   }

   public cnk.acco_commercialscalculationengine.suppliersettlementrules.RoomDetails getRooms()
   {
      return this.rooms;
   }

   public void setRooms(
         cnk.acco_commercialscalculationengine.suppliersettlementrules.RoomDetails rooms)
   {
      this.rooms = rooms;
   }

   public FreeOfCosts(
         java.lang.String contractType,
         boolean PLBApplicable,
         java.lang.String commercialType,
         boolean isApplicable,
         java.util.List<cnk.acco_commercialscalculationengine.suppliersettlementrules.SlabDetails> slabDetails,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCRooms focRooms,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCUpgrades focUpgrades,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.FOCUtilisation focUtilisation,
         cnk.acco_commercialscalculationengine.suppliersettlementrules.RoomDetails rooms)
   {
      this.contractType = contractType;
      this.PLBApplicable = PLBApplicable;
      this.commercialType = commercialType;
      this.isApplicable = isApplicable;
      this.slabDetails = slabDetails;
      this.focRooms = focRooms;
      this.focUpgrades = focUpgrades;
      this.focUtilisation = focUtilisation;
      this.rooms = rooms;
   }

}