package cnk.acco_commercialscalculationengine.clientsettlementrules;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class IncentiveOnTopUp implements java.io.Serializable
{
    
    public static boolean checkDayOfWeek(String day, Date d) {
		DateFormat formatter = new SimpleDateFormat("EEEE");
		return Arrays.asList(day.toUpperCase().split(";")).contains(formatter.format(d).toUpperCase());
	}
	
	
	public static boolean checkDayOfWeekInMonth(String day, Date d) {
		
		Calendar tempCal = Calendar.getInstance();
		tempCal.setTime(d);
		return Arrays.asList(day.split(";")).contains(String.valueOf(tempCal.get(Calendar.DAY_OF_WEEK_IN_MONTH)));
	}
	
	public static boolean checkDayInMonth(String day, Date d) {
		
		DateFormat formatter = new SimpleDateFormat("d");
		return Arrays.asList(day.split(";")).contains(formatter.format(d));
	}	
	
	public static boolean checkMonth(String day, Date d) {
		
		DateFormat formatter = new SimpleDateFormat("M");
		return Arrays.asList(day.split(";")).contains(formatter.format(d));
	}
	
	public static boolean checkHours(int day, Date d) {
		
		DateFormat formatter = new SimpleDateFormat("HH");
		return day == Integer.parseInt((formatter.format(d)));
	}	
	
	public static boolean checkMinutes(int day, Date d) {
		
		DateFormat formatter = new SimpleDateFormat("mm");
		return day == Integer.parseInt((formatter.format(d)));
	}	

   static final long serialVersionUID = 1L;

   private java.lang.String contractType;
   private java.lang.String modeofPayment;
   private java.lang.String bankName;
   private java.lang.String incentiveCurrency;
   private double incentiveAmount;
   private double incentivePercentage;
   private java.util.Date topUpDateTime;
   private java.lang.String incentiveRateType;
   private java.lang.String incentiveRateCode;
   private double commercialAmount;
   private java.lang.String commercialType;
   private boolean isApplicable;

   public IncentiveOnTopUp()
   {
   }

   public java.lang.String getContractType()
   {
      return this.contractType;
   }

   public void setContractType(java.lang.String contractType)
   {
      this.contractType = contractType;
   }

   public java.lang.String getModeofPayment()
   {
      return this.modeofPayment;
   }

   public void setModeofPayment(java.lang.String modeofPayment)
   {
      this.modeofPayment = modeofPayment;
   }

   public java.lang.String getBankName()
   {
      return this.bankName;
   }

   public void setBankName(java.lang.String bankName)
   {
      this.bankName = bankName;
   }

   public java.lang.String getIncentiveCurrency()
   {
      return this.incentiveCurrency;
   }

   public void setIncentiveCurrency(java.lang.String incentiveCurrency)
   {
      this.incentiveCurrency = incentiveCurrency;
   }

   public double getIncentiveAmount()
   {
      return this.incentiveAmount;
   }

   public void setIncentiveAmount(double incentiveAmount)
   {
      this.incentiveAmount = incentiveAmount;
   }

   public double getIncentivePercentage()
   {
      return this.incentivePercentage;
   }

   public void setIncentivePercentage(double incentivePercentage)
   {
      this.incentivePercentage = incentivePercentage;
   }

   public java.util.Date getTopUpDateTime()
   {
      return this.topUpDateTime;
   }

   public void setTopUpDateTime(java.util.Date topUpDateTime)
   {
      this.topUpDateTime = topUpDateTime;
   }

   public java.lang.String getIncentiveRateType()
   {
      return this.incentiveRateType;
   }

   public void setIncentiveRateType(java.lang.String incentiveRateType)
   {
      this.incentiveRateType = incentiveRateType;
   }

   public java.lang.String getIncentiveRateCode()
   {
      return this.incentiveRateCode;
   }

   public void setIncentiveRateCode(java.lang.String incentiveRateCode)
   {
      this.incentiveRateCode = incentiveRateCode;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

   public java.lang.String getCommercialType()
   {
      return this.commercialType;
   }

   public void setCommercialType(java.lang.String commercialType)
   {
      this.commercialType = commercialType;
   }

   public boolean isIsApplicable()
   {
      return this.isApplicable;
   }

   public void setIsApplicable(boolean isApplicable)
   {
      this.isApplicable = isApplicable;
   }

   public IncentiveOnTopUp(java.lang.String contractType,
         java.lang.String modeofPayment, java.lang.String bankName,
         java.lang.String incentiveCurrency, double incentiveAmount,
         double incentivePercentage, java.util.Date topUpDateTime,
         java.lang.String incentiveRateType,
         java.lang.String incentiveRateCode, double commercialAmount,
         java.lang.String commercialType, boolean isApplicable)
   {
      this.contractType = contractType;
      this.modeofPayment = modeofPayment;
      this.bankName = bankName;
      this.incentiveCurrency = incentiveCurrency;
      this.incentiveAmount = incentiveAmount;
      this.incentivePercentage = incentivePercentage;
      this.topUpDateTime = topUpDateTime;
      this.incentiveRateType = incentiveRateType;
      this.incentiveRateCode = incentiveRateCode;
      this.commercialAmount = commercialAmount;
      this.commercialType = commercialType;
      this.isApplicable = isApplicable;
   }

}