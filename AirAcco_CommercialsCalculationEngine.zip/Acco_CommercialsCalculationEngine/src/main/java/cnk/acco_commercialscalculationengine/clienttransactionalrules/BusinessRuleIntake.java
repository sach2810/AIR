package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@org.codehaus.jackson.map.annotate.JsonSerialize(include = org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion.NON_NULL)
public class BusinessRuleIntake implements java.io.Serializable
{

   static final long serialVersionUID = 1L;
   private java.util.List<java.lang.String> commercialStatus;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements;
   private java.lang.String selectedRow;
   private java.lang.String ruleFlowName;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> hotelDetails;
   private boolean tempStatus;

   /*public void getMarkUpParentName(EntityDetails entityDetails,MarkUp markUp)
   {
        if(entityDetails.getEntityStatus()==null){
                entityDetails.setEntityStatus(new ArrayList<String>());}       
       if(entityDetails.getParentEntityName()==null){
    	   	this.getEntityDetails().get(this.getEntityDetails().indexOf(entityDetails)).getEntityStatus().add("DefinitionMarkUpCompleted");    	   
           	//entityDetails.getEntityStatus().add("DefinitionMarkUpCompleted");
           	return;
       }
      for(EntityDetails ed : this.getEntityDetails()){
   	   System.out.println("Inside for");
   		if(ed.getEntityName().equals(entityDetails.getParentEntityName())){
   			System.out.println("Inside first if");
   			if(ed.getEntityStatus().contains("DefinitionMarkUpCompleted")){
   				System.out.println("Inside second if");
   				markUp.setMarkUpParentName(ed.getEntityName());
   				entityDetails.getEntityStatus().add("DefinitionMarkUpCompleted");
   			}	
   			else
   				getMarkUpParentName(ed,markUp);
   		}
   	}
   }*/

   /*@Override
    public String toString() {
    return "BusinessRuleIntake [commercialStatus=" + commercialStatus + ", advancedDefinition=" + advancedDefinition
    + ", commonElements=" + commonElements + ", selectedRow=" + selectedRow + ", ruleFlowName=" + ruleFlowName
    + ", entityDetails=" + entityDetails + ", slabDetails=" + slabDetails + ", hotelDetails=" + hotelDetails
    + ", tempStatus=" + tempStatus + "]";
    }*/

   private java.lang.String parentId;
   private java.lang.String briId;

   public static boolean checkDate(String configuredInput, Date conditionValue)
   {

      try
      {
         String[] configuredInputList = configuredInput.split(";");
         DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

         if (configuredInputList[0].equals("LESSTHANEQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return (date.after(conditionValue) || date.equals(conditionValue));

         }
         else if (configuredInputList[0].equals("GREATERTHANEQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return (date.before(conditionValue) || date.equals(conditionValue));

         }
         else if (configuredInputList[0].equals("BETWEEN"))
         {

            Date lowerLimit = format.parse(configuredInputList[1]);
            Date upperLimit = format.parse(configuredInputList[2]);
            return ((lowerLimit.before(conditionValue) || lowerLimit.equals(conditionValue)) && (upperLimit.after(conditionValue) || upperLimit.equals(conditionValue)));

         }
         else if (configuredInputList[0].equals("EQUALTO"))
         {

            Date date = format.parse(configuredInputList[1]);
            return date.equals(conditionValue);

         }
         else if (configuredInputList[0].equals("IN"))
         {

            String date = format.format(conditionValue);
            return Arrays.asList(configuredInputList[1].split("/")).contains(date);
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }

      return false;
   }

   public BusinessRuleIntake()
   {
   }

   public cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition getAdvancedDefinition()
   {
      return this.advancedDefinition;
   }

   public void setAdvancedDefinition(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition)
   {
      this.advancedDefinition = advancedDefinition;
   }

   public java.util.List<java.lang.String> getCommercialStatus()
   {
      return this.commercialStatus;
   }

   public void setCommercialStatus(
         java.util.List<java.lang.String> commercialStatus)
   {
      this.commercialStatus = commercialStatus;
   }

   public java.lang.String getRuleFlowName()
   {
      return this.ruleFlowName;
   }

   public void setRuleFlowName(java.lang.String ruleFlowName)
   {
      this.ruleFlowName = ruleFlowName;
   }

   public java.lang.String getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.lang.String selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements getCommonElements()
   {
      return this.commonElements;
   }

   public void setCommonElements(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements)
   {
      this.commonElements = commonElements;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> getEntityDetails()
   {
      return this.entityDetails;
   }

   public void setEntityDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails)
   {
      this.entityDetails = entityDetails;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> getSlabDetails()
   {
      return this.slabDetails;
   }

   public void setSlabDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails)
   {
      this.slabDetails = slabDetails;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> getHotelDetails()
   {
      return this.hotelDetails;
   }

   public void setHotelDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> hotelDetails)
   {
      this.hotelDetails = hotelDetails;
   }

   public boolean isTempStatus()
   {
      return this.tempStatus;
   }

   public void setTempStatus(boolean tempStatus)
   {
      this.tempStatus = tempStatus;
   }

   public BusinessRuleIntake(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition,
         java.util.List<java.lang.String> commercialStatus,
         java.lang.String ruleFlowName,
         java.lang.String selectedRow,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> hotelDetails,
         boolean tempStatus)
   {
      this.advancedDefinition = advancedDefinition;
      this.commercialStatus = commercialStatus;
      this.ruleFlowName = ruleFlowName;
      this.selectedRow = selectedRow;
      this.commonElements = commonElements;
      this.entityDetails = entityDetails;
      this.slabDetails = slabDetails;
      this.hotelDetails = hotelDetails;
      this.tempStatus = tempStatus;
   }

   public java.lang.String getParentId()
   {
      return this.parentId;
   }

   public void setParentId(java.lang.String parentId)
   {
      this.parentId = parentId;
   }

   public java.lang.String getBriId()
   {
      return this.briId;
   }

   public void setBriId(java.lang.String briId)
   {
      this.briId = briId;
   }

   public BusinessRuleIntake(
         java.util.List<java.lang.String> commercialStatus,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.AdvancedDefinition advancedDefinition,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.CommonElements commonElements,
         java.lang.String selectedRow,
         java.lang.String ruleFlowName,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityDetails> entityDetails,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.SlabDetails> slabDetails,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.HotelDetails> hotelDetails,
         boolean tempStatus, java.lang.String parentId, java.lang.String briId)
   {
      this.commercialStatus = commercialStatus;
      this.advancedDefinition = advancedDefinition;
      this.commonElements = commonElements;
      this.selectedRow = selectedRow;
      this.ruleFlowName = ruleFlowName;
      this.entityDetails = entityDetails;
      this.slabDetails = slabDetails;
      this.hotelDetails = hotelDetails;
      this.tempStatus = tempStatus;
      this.parentId = parentId;
      this.briId = briId;
   }

}