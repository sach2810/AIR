package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import java.util.ArrayList;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@org.codehaus.jackson.map.annotate.JsonSerialize(include = org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion.NON_NULL)
public class EntityDetails implements java.io.Serializable
{

   /*  @Override
   public String toString() {
   	return "EntityDetails [entityType=" + entityType + ", entityName=" + entityName + ", entityMarket="
   			+ entityMarket + ", parentEntityName=" + parentEntityName + ", selectedRow=" + selectedRow
   			+ ", childEntityName=" + childEntityName + ", commercialsApplied=" + commercialsApplied
   			+ ", entityStatus=" + entityStatus + ", commercialHead=" + commercialHead + ", standardSelectedRow="
   			+ standardSelectedRow + ", markUpSelectedRow=" + markUpSelectedRow + ", overridingSelectedRow="
   			+ overridingSelectedRow + ", plbSelectedRow=" + plbSelectedRow + ", serviceChargeSelectedRow="
   			+ serviceChargeSelectedRow + ", sectorWiseIncentiveSelectedRow=" + sectorWiseIncentiveSelectedRow
   			+ ", managementFeeSelectedRow=" + managementFeeSelectedRow + ", discountSelectedRow="
   			+ discountSelectedRow + ", destinationIncentiveSelectedRow=" + destinationIncentiveSelectedRow
   			+ ", segmentFeesSelectedRow=" + segmentFeesSelectedRow + "]";
   }*/

   static final long serialVersionUID = 1L;
   private java.lang.String entityType;
   private java.lang.String entityName;
   private java.lang.String entityMarket;
   private java.lang.String parentEntityName;
   private boolean byProduct;
   private java.util.List<java.lang.String> commercialsApplied;
   private java.util.List<java.lang.String> entityStatus;
   private boolean ruleExists;
   private boolean isMarkUpByProduct;
   private boolean isStandardByProduct;
   private java.lang.String focus;
   private java.util.List<java.lang.String> selectedRow;
   private java.lang.String childEntityName;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialHead> commercialHead;
   private java.lang.String standardSelectedRow;
   private java.lang.String markUpSelectedRow;
   private java.lang.String overridingSelectedRow;
   private java.lang.String plbSelectedRow;
   private java.lang.String serviceChargeSelectedRow;
   private java.lang.String sectorWiseIncentiveSelectedRow;
   private java.lang.String managementFeeSelectedRow;
   private java.lang.String discountSelectedRow;
   private java.lang.String destinationIncentiveSelectedRow;
   private java.lang.String segmentFeesSelectedRow;
   private java.lang.String parentId;
   private java.lang.String entityDetailsId;

   /*public void appendCommercials(String CommercialHeadName, String CommercialType, String CommercialProperty, boolean isCommisionable)
   {
      //this.setSelectedRow(this.getCommonElements().getSupplier()+"_"+this.getCommonElements().getSupplierMarket());
      CommercialHead commercialHead = new CommercialHead(CommercialHeadName, CommercialType, null, null, CommercialProperty, isCommisionable);
      if (this.getCommercialHead() == null)
         this.setCommercialHead(new ArrayList<CommercialHead>());
      this.getCommercialHead().add(commercialHead);
   }*/
   
   public void appendCommercials(CommercialHead commercialHead)
   {
      //this.setSelectedRow(this.getCommonElements().getSupplier()+"_"+this.getCommonElements().getSupplierMarket());
      if (this.getCommercialHead() == null)
         this.setCommercialHead(new ArrayList<CommercialHead>());
      this.getCommercialHead().add(commercialHead);
   }   

   public EntityDetails()
   {
   }
   
   public boolean isByProduct()
   {
      return this.byProduct;
   }

   public void setByProduct(boolean byProduct)
   {
      this.byProduct = byProduct;
   }

   public java.lang.String getFocus()
   {
      return this.focus;
   }

   public void setFocus(java.lang.String focus)
   {
      this.focus = focus;
   }
   
   public boolean isIsMarkUpByProduct()
   {
      return this.isMarkUpByProduct;
   }

   public void setIsMarkUpByProduct(boolean isMarkUpByProduct)
   {
      this.isMarkUpByProduct = isMarkUpByProduct;
   }
   
   public boolean isIsStandardByProduct()
   {
      return this.isStandardByProduct;
   }

   public void setIsStandardByProduct(boolean isStandardByProduct)
   {
      this.isStandardByProduct = isStandardByProduct;
   }
   
   public boolean isRuleExists()
   {
      return this.ruleExists;
   }

   public void setRuleExists(boolean ruleExists)
   {
      this.ruleExists = ruleExists;
   }

   public java.lang.String getEntityType()
   {
      return this.entityType;
   }

   public void setEntityType(java.lang.String entityType)
   {
      this.entityType = entityType;
   }

   public java.lang.String getEntityName()
   {
      return this.entityName;
   }

   public void setEntityName(java.lang.String entityName)
   {
      this.entityName = entityName;
   }

   public java.lang.String getEntityMarket()
   {
      return this.entityMarket;
   }

   public void setEntityMarket(java.lang.String entityMarket)
   {
      this.entityMarket = entityMarket;
   }

   public java.lang.String getParentEntityName()
   {
      return this.parentEntityName;
   }

   public void setParentEntityName(java.lang.String parentEntityName)
   {
      this.parentEntityName = parentEntityName;
   }

   public java.util.List<java.lang.String> getSelectedRow()
   {
      return this.selectedRow;
   }

   public void setSelectedRow(java.util.List<java.lang.String> selectedRow)
   {
      this.selectedRow = selectedRow;
   }

   public java.lang.String getChildEntityName()
   {
      return this.childEntityName;
   }

   public void setChildEntityName(java.lang.String childEntityName)
   {
      this.childEntityName = childEntityName;
   }

   public java.util.List<java.lang.String> getCommercialsApplied()
   {
      return this.commercialsApplied;
   }

   public void setCommercialsApplied(
         java.util.List<java.lang.String> commercialsApplied)
   {
      this.commercialsApplied = commercialsApplied;
   }

   public java.util.List<java.lang.String> getEntityStatus()
   {
      return this.entityStatus;
   }

   public void setEntityStatus(java.util.List<java.lang.String> entityStatus)
   {
      this.entityStatus = entityStatus;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialHead> getCommercialHead()
   {
      return this.commercialHead;
   }

   public void setCommercialHead(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialHead> commercialHead)
   {
      this.commercialHead = commercialHead;
   }

   public java.lang.String getStandardSelectedRow()
   {
      return this.standardSelectedRow;
   }

   public void setStandardSelectedRow(java.lang.String standardSelectedRow)
   {
      this.standardSelectedRow = standardSelectedRow;
   }

   public java.lang.String getMarkUpSelectedRow()
   {
      return this.markUpSelectedRow;
   }

   public void setMarkUpSelectedRow(java.lang.String markUpSelectedRow)
   {
      this.markUpSelectedRow = markUpSelectedRow;
   }

   public java.lang.String getOverridingSelectedRow()
   {
      return this.overridingSelectedRow;
   }

   public void setOverridingSelectedRow(java.lang.String overridingSelectedRow)
   {
      this.overridingSelectedRow = overridingSelectedRow;
   }

   public java.lang.String getPlbSelectedRow()
   {
      return this.plbSelectedRow;
   }

   public void setPlbSelectedRow(java.lang.String plbSelectedRow)
   {
      this.plbSelectedRow = plbSelectedRow;
   }

   public java.lang.String getServiceChargeSelectedRow()
   {
      return this.serviceChargeSelectedRow;
   }

   public void setServiceChargeSelectedRow(
         java.lang.String serviceChargeSelectedRow)
   {
      this.serviceChargeSelectedRow = serviceChargeSelectedRow;
   }

   public java.lang.String getSectorWiseIncentiveSelectedRow()
   {
      return this.sectorWiseIncentiveSelectedRow;
   }

   public void setSectorWiseIncentiveSelectedRow(
         java.lang.String sectorWiseIncentiveSelectedRow)
   {
      this.sectorWiseIncentiveSelectedRow = sectorWiseIncentiveSelectedRow;
   }

   public java.lang.String getManagementFeeSelectedRow()
   {
      return this.managementFeeSelectedRow;
   }

   public void setManagementFeeSelectedRow(
         java.lang.String managementFeeSelectedRow)
   {
      this.managementFeeSelectedRow = managementFeeSelectedRow;
   }

   public java.lang.String getDiscountSelectedRow()
   {
      return this.discountSelectedRow;
   }

   public void setDiscountSelectedRow(java.lang.String discountSelectedRow)
   {
      this.discountSelectedRow = discountSelectedRow;
   }

   public java.lang.String getDestinationIncentiveSelectedRow()
   {
      return this.destinationIncentiveSelectedRow;
   }

   public void setDestinationIncentiveSelectedRow(
         java.lang.String destinationIncentiveSelectedRow)
   {
      this.destinationIncentiveSelectedRow = destinationIncentiveSelectedRow;
   }

   public java.lang.String getSegmentFeesSelectedRow()
   {
      return this.segmentFeesSelectedRow;
   }

   public void setSegmentFeesSelectedRow(java.lang.String segmentFeesSelectedRow)
   {
      this.segmentFeesSelectedRow = segmentFeesSelectedRow;
   }

   public java.lang.String getParentId()
   {
      return this.parentId;
   }

   public void setParentId(java.lang.String parentId)
   {
      this.parentId = parentId;
   }

   public java.lang.String getEntityDetailsId()
   {
      return this.entityDetailsId;
   }

   public void setEntityDetailsId(java.lang.String entityDetailsId)
   {
      this.entityDetailsId = entityDetailsId;
   }

   public EntityDetails(
         java.lang.String entityType,
         java.lang.String entityName,
         java.lang.String entityMarket,
         java.lang.String parentEntityName,
         java.util.List<java.lang.String> selectedRow,
         java.lang.String childEntityName,
         java.util.List<java.lang.String> commercialsApplied,
         java.util.List<java.lang.String> entityStatus,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialHead> commercialHead,
         java.lang.String standardSelectedRow,
         java.lang.String markUpSelectedRow,
         java.lang.String overridingSelectedRow,
         java.lang.String plbSelectedRow,
         java.lang.String serviceChargeSelectedRow,
         java.lang.String sectorWiseIncentiveSelectedRow,
         java.lang.String managementFeeSelectedRow,
         java.lang.String discountSelectedRow,
         java.lang.String destinationIncentiveSelectedRow,
         java.lang.String segmentFeesSelectedRow, java.lang.String parentId,
         java.lang.String focus,
         java.lang.String entityDetailsId,
		 boolean byProduct,
		 boolean ruleExists,
		 boolean isMarkUpByProduct,
		 boolean isStandardByProduct)
   {
      this.entityType = entityType;
      this.entityName = entityName;
      this.entityMarket = entityMarket;
      this.parentEntityName = parentEntityName;
      this.selectedRow = selectedRow;
      this.childEntityName = childEntityName;
      this.commercialsApplied = commercialsApplied;
      this.entityStatus = entityStatus;
      this.commercialHead = commercialHead;
      this.standardSelectedRow = standardSelectedRow;
      this.markUpSelectedRow = markUpSelectedRow;
      this.overridingSelectedRow = overridingSelectedRow;
      this.plbSelectedRow = plbSelectedRow;
      this.serviceChargeSelectedRow = serviceChargeSelectedRow;
      this.sectorWiseIncentiveSelectedRow = sectorWiseIncentiveSelectedRow;
      this.managementFeeSelectedRow = managementFeeSelectedRow;
      this.discountSelectedRow = discountSelectedRow;
      this.destinationIncentiveSelectedRow = destinationIncentiveSelectedRow;
      this.segmentFeesSelectedRow = segmentFeesSelectedRow;
      this.parentId = parentId;
      this.focus = focus;
      this.entityDetailsId = entityDetailsId;
	  this.byProduct = byProduct;
	  this.ruleExists = ruleExists;
	  this.isMarkUpByProduct = isMarkUpByProduct;
	  this.isStandardByProduct = isStandardByProduct;
   }

}