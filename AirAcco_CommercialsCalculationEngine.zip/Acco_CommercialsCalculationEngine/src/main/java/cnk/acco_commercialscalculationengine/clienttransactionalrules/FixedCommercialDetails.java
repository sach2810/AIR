package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include=Inclusion.NON_NULL)
public class FixedCommercialDetails implements java.io.Serializable
{
	
/*   @Override
	public String toString() {
		return "FixedCommercialDetails [commercialName=" + commercialName + ", calculationPercentage="
				+ calculationPercentage + ", calculationAmount=" + calculationAmount + ", commercialAmount="
				+ commercialAmount + ", MDMRuleId=" + MDMRuleId + "]";
	}*/

static final long serialVersionUID = 1L;

   private java.lang.String commercialName;
   private double calculationPercentage;
   private double calculationAmount;
   private double commercialAmount;
   private String MDMRuleId;

   public java.lang.String getMDMRuleId()
   {
      return this.MDMRuleId;
   }

   public void setMDMRuleId(java.lang.String MDMRuleId)
   {
      this.MDMRuleId = MDMRuleId;
   }

   public FixedCommercialDetails()
   {
   }

   public java.lang.String getCommercialName()
   {
      return this.commercialName;
   }

   public void setCommercialName(java.lang.String commercialName)
   {
      this.commercialName = commercialName;
   }

   public double getCalculationPercentage()
   {
      return this.calculationPercentage;
   }

   public void setCalculationPercentage(double calculationPercentage)
   {
      this.calculationPercentage = calculationPercentage;
   }

   public double getCalculationAmount()
   {
      return this.calculationAmount;
   }

   public void setCalculationAmount(double calculationAmount)
   {
      this.calculationAmount = calculationAmount;
   }

   public double getCommercialAmount()
   {
      return this.commercialAmount;
   }

   public void setCommercialAmount(double commercialAmount)
   {
      this.commercialAmount = commercialAmount;
   }

      public FixedCommercialDetails(java.lang.String commercialName,
         double calculationPercentage,
         double calculationAmount, double commercialAmount, java.lang.String MDMRuleId
         )
   {
      this.commercialName = commercialName;
      this.calculationPercentage = calculationPercentage;
      this.calculationAmount = calculationAmount;
      this.commercialAmount = commercialAmount;
      this.MDMRuleId = MDMRuleId;
      
   }

}