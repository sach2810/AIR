package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@org.codehaus.jackson.map.annotate.JsonSerialize(include = org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion.NON_NULL)
public class RoomDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.util.List<java.lang.String> commercialsApplied;
   private java.lang.String roomType;
   private java.lang.String roomCategory;
   private java.lang.String passengerType;
   private java.lang.String starCategory;
   private java.lang.String mealPlan;
   private java.lang.Integer passengerCount;
   private java.lang.Integer noOfNights;
   private java.lang.String rateType;
   private java.lang.String rateCode;
   private int bookingEngineKey;
   private double totalReceivables;
   private double totalPayables;
   private double totalFare;
   private double totalFareTemp;
   private java.lang.String bookingId;
   private java.util.List<java.lang.String> ineligibleCommercials;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUpTemp;
   private boolean isAdvanced;
   private cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials;

   private java.lang.String parentId;

   private java.lang.String roomDetailsId;

   public java.util.List<java.lang.String> getIneligibleCommercials()
   {
      return this.ineligibleCommercials;
   }

   /* @Override
   public String toString() {
   return "RoomDetails [commercialsApplied=" + commercialsApplied + ", roomType=" + roomType + ", roomCategory="
   		+ roomCategory + ", passengerType=" + passengerType + ", starCategory=" + starCategory + ", mealPlan="
   		+ mealPlan + ", passengerCount=" + passengerCount + ", noOfNights=" + noOfNights + ", rateType=" + rateType
   		+ ", rateCode=" + rateCode + ", bookingEngineKey=" + bookingEngineKey + ", totalReceivables="
   		+ totalReceivables + ", totalPayables=" + totalPayables + ", totalFare=" + totalFare + ", totalFareTemp="
   		+ totalFareTemp + ", bookingId=" + bookingId + ", ineligibleCommercials=" + ineligibleCommercials
   		+ ", fareBreakUpTemp=" + fareBreakUpTemp + ", isAdvanced=" + isAdvanced + ", fareBreakUp=" + fareBreakUp
   		+ ", commercialDetails=" + commercialDetails + ", entityCommercials=" + entityCommercials + "]";
   }*/

   public void setIneligibleCommercials(java.util.List<java.lang.String> ineligibleCommercials)
   {
      this.ineligibleCommercials = ineligibleCommercials;
   }

   public java.lang.String getBookingId()
   {
      return this.bookingId;
   }

   public void setBookingId(java.lang.String bookingId)
   {
      this.bookingId = bookingId;
   }

   public void ClientCommercialCalculation(String CommercialName, String CommercialType, String CommercialProperty, double RetentionPercentage, double RetentionAmountPercentage, double AdditionalPercentage, double AdditionalAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetl, String MDMRuleID, boolean isCommissionable)
   {
      if (roomDetl.getIneligibleCommercials() == null || !(roomDetl.getIneligibleCommercials().contains(CommercialName)))
      {
         if (CommercialProperty.equals("Retention"))
            CalculateRetentionCommercial(CommercialName, CommercialType, RetentionPercentage, RetentionAmountPercentage, entyDtls, roomDetl, MDMRuleID, isCommissionable);
         else if (CommercialProperty.equals("Additional"))
            CalculateAdditionalCommercial(CommercialName, CommercialType, AdditionalPercentage, AdditionalAmount, FareComponent, TaxComponent, Currency, entyDtls, roomDetl, MDMRuleID, isCommissionable);
         else CalculateFixedCommercial(CommercialName, CommercialType, RetentionPercentage, RetentionAmountPercentage, entyDtls, roomDetl, MDMRuleID, isCommissionable);
      }
   }

   public void CalculateRetentionCommercial(String CommercialName, String CommercialType, double RetentionPercentage, double RetentionAmountPercentage, EntityDetails entyDtls, RoomDetails roomDetl, String MDMRuleID, boolean isCommissionable)
   {
      RetentionCommercialDetails retComDtls = new RetentionCommercialDetails();
      double tempAmount = 0;
      if (entyDtls.getParentEntityName() == null)
      {
         for (CommercialDetails commdetails : roomDetl.getCommercialDetails())
         {
            if (CommercialName.equals(commdetails.getCommercialName()))
            {
               retComDtls.setRemainingAmount(commdetails.getCommercialCalculationAmount());
               retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount());
               if (RetentionAmountPercentage != 0)
               {
                  tempAmount = commdetails.getCommercialCalculationAmount() * (RetentionAmountPercentage / 100);
                  retComDtls.setRetentionAmountPercentage(RetentionAmountPercentage);
                  if (CommercialType.equals("Receivable"))
                     retComDtls.setRemainingAmount(tempAmount);
                  else
                     retComDtls.setRemainingAmount(commdetails.getCommercialCalculationAmount() - tempAmount);
               }
               if (RetentionPercentage != 0)
               {
                  double percentageAmount = 0;
                  if (commdetails.getCommercialCalculationAmount() != 0)
                  {
                     percentageAmount = (commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount()) * (RetentionPercentage / 100);
                     if (CommercialType.equals("Receivable"))
                        retComDtls.setRemainingPercentageAmount(percentageAmount);
                     else
                        retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - commdetails.getCommercialCalculationAmount() - percentageAmount);
                     tempAmount = tempAmount + percentageAmount;
                  }
                  else
                  {
                     percentageAmount = commdetails.getCommercialAmount() * (RetentionPercentage / 100);
                     if (CommercialType.equals("Receivable"))
                        retComDtls.setRemainingPercentageAmount(percentageAmount);
                     else
                        retComDtls.setRemainingPercentageAmount(commdetails.getCommercialAmount() - percentageAmount);
                     tempAmount = tempAmount + percentageAmount;
                  }
                  retComDtls.setRetentionPercentage(RetentionPercentage);
               }
               retComDtls.setCommercialAmount(tempAmount);
               retComDtls.setCommercialName(CommercialName);
            }

         }
      }
      else
      {
         for (EntityCommercials parentEntity : roomDetl.getEntityCommercials())
         {
            if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName()))
            {
               for (RetentionCommercialDetails retcommdetails : parentEntity.getRetentionCommercialDetails())
               {
                  if (CommercialName.equals(retcommdetails.getCommercialName()))
                  {
                     retComDtls.setRemainingAmount(retcommdetails.getRemainingAmount());
                     retComDtls.setRemainingPercentageAmount(retcommdetails.getRemainingPercentageAmount());
                     if (RetentionAmountPercentage != 0)
                     {
                        tempAmount = retcommdetails.getRemainingAmount() * (RetentionAmountPercentage / 100);
                        retComDtls.setRetentionAmountPercentage(RetentionAmountPercentage);
                        retComDtls.setRemainingAmount(retcommdetails.getRemainingAmount() - tempAmount);
                     }
                     if (RetentionPercentage != 0)
                     {
                        double percentageAmount = 0;
                        percentageAmount = retcommdetails.getRemainingPercentageAmount() * (RetentionPercentage / 100);
                        tempAmount = tempAmount + percentageAmount;
                        retComDtls.setRetentionPercentage(RetentionPercentage);
                        retComDtls.setRemainingPercentageAmount(retcommdetails.getRemainingPercentageAmount() - percentageAmount);
                     }
                     retComDtls.setCommercialAmount(tempAmount);
                     retComDtls.setCommercialName(CommercialName);
                  }
               }
            }
         }
      }
      if (CommercialName.equals("Standard") && isCommissionable == false)
      {
         if (retComDtls.getCommercialAmount() > 0)
         {
            boolean isCompleted = false;
            if (CommercialType.equals("Receivable"))
            {
               if (this.getEntityCommercials() != null)
               {
                  for (EntityCommercials entityCommercials : this.getEntityCommercials())
                  {
                     if (entityCommercials.getMarkUpCommercialDetails() != null && entityCommercials.getEntityName().equals(entyDtls.getEntityName()))
                     {
                        entityCommercials.getMarkUpCommercialDetails().setTotalFare(entityCommercials.getMarkUpCommercialDetails().getTotalFare() + retComDtls.getCommercialAmount());
                        if (entityCommercials.getMarkUpCommercialDetails().getFareBreakUp() != null)
                           entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().setBaseFare(entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().getBaseFare() + retComDtls.getCommercialAmount());
                        isCompleted = true;
                        totalFareTemp = totalFareTemp + retComDtls.getCommercialAmount();
                        break;
                     }
                  }
               }
               if (isCompleted == false)
               {
                  totalFareTemp = totalFareTemp + retComDtls.getCommercialAmount();
                  if (fareBreakUpTemp != null)
                  {
                     FareBreakUp fb = new FareBreakUp(fareBreakUpTemp.getBaseFare() + retComDtls.getCommercialAmount(), fareBreakUpTemp.getTaxDetails());
                     fareBreakUpTemp = fb;
                  }
               }
            }
            else
            {
               if (this.getEntityCommercials() != null)
               {
                  for (EntityCommercials entityCommercials : this.getEntityCommercials())
                  {
                     if (entityCommercials.getMarkUpCommercialDetails() != null && entityCommercials.getEntityName().equals(entyDtls.getEntityName()))
                     {
                        entityCommercials.getMarkUpCommercialDetails().setTotalFare(entityCommercials.getMarkUpCommercialDetails().getTotalFare() - retComDtls.getCommercialAmount());
                        if (entityCommercials.getMarkUpCommercialDetails().getFareBreakUp() != null)
                           entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().setBaseFare(entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().getBaseFare() - retComDtls.getCommercialAmount());
                        isCompleted = true;
                        totalFareTemp = totalFareTemp - retComDtls.getCommercialAmount();
                        break;
                     }
                  }
               }
               if (isCompleted == false)
               {
                  totalFareTemp = totalFareTemp - retComDtls.getCommercialAmount();
                  if (fareBreakUpTemp != null)
                  {
                     FareBreakUp fb = new FareBreakUp(fareBreakUpTemp.getBaseFare() - retComDtls.getCommercialAmount(), fareBreakUpTemp.getTaxDetails());
                     fareBreakUpTemp = fb;
                  }
               }
            }
         }
      }

      if (roomDetl.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entyDtls.getEntityName());
         entityCommercials.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
         entityCommercials.getRetentionCommercialDetails().add(retComDtls);
         roomDetl.setEntityCommercials(new ArrayList<EntityCommercials>());
         roomDetl.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entityComm : roomDetl.getEntityCommercials())
         {
            if (entyDtls.getEntityName().equals(entityComm.getEntityName()))
            {
               if (entityComm.getRetentionCommercialDetails() == null)
                  entityComm.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
               entityComm.getRetentionCommercialDetails().add(retComDtls);
               isEntityPresent = true;
               break;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entyDtls.getEntityName());
            entityCommercials.setRetentionCommercialDetails(new ArrayList<RetentionCommercialDetails>());
            entityCommercials.getRetentionCommercialDetails().add(retComDtls);
            roomDetl.getEntityCommercials().add(entityCommercials);
         }

      }
      //entyDtls.getEntityStatus().add(CommercialName + "RetentionCompleted");
      retComDtls.setMDMRuleId(MDMRuleID);
   }

   public void CalculateFixedCommercial(String CommercialName, String CommercialType, double RetentionPercentage, double RetentionAmount, EntityDetails entyDtls, RoomDetails roomDetl, String MDMRuleID, boolean isCommissionable)
   {
      FixedCommercialDetails fixedCommercialDetails = new FixedCommercialDetails();
      fixedCommercialDetails.setCalculationPercentage(RetentionPercentage);
      fixedCommercialDetails.setCalculationAmount(RetentionAmount);
      fixedCommercialDetails.setCommercialAmount(RetentionAmount + ((RetentionPercentage / 100) * this.getTotalFare()));
      fixedCommercialDetails.setCommercialName(CommercialName);
	  
	  if (CommercialName.equals("Standard") && isCommissionable == false)
      {
         if (fixedCommercialDetails.getCommercialAmount() > 0)
         {
            boolean isCompleted = false;
            if (CommercialType.equals("Receivable"))
            {
               if (this.getEntityCommercials() != null)
               {
                  for (EntityCommercials entityCommercials : this.getEntityCommercials())
                  {
                     if (entityCommercials.getMarkUpCommercialDetails() != null && entityCommercials.getEntityName().equals(entyDtls.getEntityName()))
                     {
                        entityCommercials.getMarkUpCommercialDetails().setTotalFare(entityCommercials.getMarkUpCommercialDetails().getTotalFare() + fixedCommercialDetails.getCommercialAmount());
                        if (entityCommercials.getMarkUpCommercialDetails().getFareBreakUp() != null)
                           entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().setBaseFare(entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().getBaseFare() + fixedCommercialDetails.getCommercialAmount());
                        isCompleted = true;
                        totalFareTemp = totalFareTemp + fixedCommercialDetails.getCommercialAmount();
                        break;
                     }
                  }
               }
               if (isCompleted == false)
               {
                  totalFareTemp = totalFareTemp + fixedCommercialDetails.getCommercialAmount();
                  if (fareBreakUpTemp != null)
                  {
                     FareBreakUp fb = new FareBreakUp(fareBreakUpTemp.getBaseFare() + fixedCommercialDetails.getCommercialAmount(), fareBreakUpTemp.getTaxDetails());
                     fareBreakUpTemp = fb;
                  }
               }
            }
            else
            {
               if (this.getEntityCommercials() != null)
               {
                  for (EntityCommercials entityCommercials : this.getEntityCommercials())
                  {
                     if (entityCommercials.getMarkUpCommercialDetails() != null && entityCommercials.getEntityName().equals(entyDtls.getEntityName()))
                     {
                        entityCommercials.getMarkUpCommercialDetails().setTotalFare(entityCommercials.getMarkUpCommercialDetails().getTotalFare() - fixedCommercialDetails.getCommercialAmount());
                        if (entityCommercials.getMarkUpCommercialDetails().getFareBreakUp() != null)
                           entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().setBaseFare(entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().getBaseFare() - fixedCommercialDetails.getCommercialAmount());
                        isCompleted = true;
                        totalFareTemp = totalFareTemp - fixedCommercialDetails.getCommercialAmount();
                        break;
                     }
                  }
               }
               if (isCompleted == false)
               {
                  totalFareTemp = totalFareTemp - fixedCommercialDetails.getCommercialAmount();
                  if (fareBreakUpTemp != null)
                  {
                     FareBreakUp fb = new FareBreakUp(fareBreakUpTemp.getBaseFare() - fixedCommercialDetails.getCommercialAmount(), fareBreakUpTemp.getTaxDetails());
                     fareBreakUpTemp = fb;
                  }
               }
            }
         }
      }
      /* if (entyDtls.getParentEntityName() == null) {
           for (CommercialDetails commdetails: roomDetl.getCommercialDetails()) {
               if (CommercialName.equals(commdetails.getCommercialName())) {
                   fixedCommercialDetails.setRemainingAmount(RetentionAmount);
                   fixedCommercialDetails.setRemainingPercentageAmount(commdetails.getCommercialAmount() * RetentionPercentage / 100);
                   fixedCommercialDetails.setRetentionPercentage(RetentionPercentage);
                   fixedCommercialDetails.setRetentionAmountPercentage(RetentionAmount);
                   fixedCommercialDetails.setCommercialAmount(fixedCommercialDetails.getRemainingAmount() + fixedCommercialDetails.getRemainingPercentageAmount());
                   fixedCommercialDetails.setCommercialName(CommercialName);
               }

           }
       } else {
           for (EntityCommercials parentEntity: roomDetl.getEntityCommercials()) {
               if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName())) {
                   for (RetentionCommercialDetails retcommdetails: parentEntity.getRetentionCommercialDetails()) {
                       if (CommercialName.equals(retcommdetails.getCommercialName())) {
                           fixedCommercialDetails.setRemainingAmount(RetentionAmount);
                           fixedCommercialDetails.setRemainingPercentageAmount(retcommdetails.getCommercialAmount() * RetentionPercentage / 100);
                           fixedCommercialDetails.setRetentionPercentage(RetentionPercentage);
                           fixedCommercialDetails.setRetentionAmountPercentage(RetentionAmount);
                           fixedCommercialDetails.setCommercialAmount(fixedCommercialDetails.getRemainingAmount() + fixedCommercialDetails.getRemainingPercentageAmount());
                           fixedCommercialDetails.setCommercialName(CommercialName);
                       }
                   }
               }
           }
       }*/
      if (roomDetl.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entyDtls.getEntityName());
         entityCommercials.setFixedCommercialDetails(new ArrayList<FixedCommercialDetails>());
         entityCommercials.getFixedCommercialDetails().add(fixedCommercialDetails);
         roomDetl.setEntityCommercials(new ArrayList<EntityCommercials>());
         roomDetl.getEntityCommercials().add(entityCommercials);
      }else{
         boolean isEntityPresent = false;
         for (EntityCommercials entityComm : roomDetl.getEntityCommercials())
         {
            if (entyDtls.getEntityName().equals(entityComm.getEntityName()))
            {
               if (entityComm.getFixedCommercialDetails() == null)
                  entityComm.setFixedCommercialDetails(new ArrayList<FixedCommercialDetails>());
               entityComm.getFixedCommercialDetails().add(fixedCommercialDetails);
               isEntityPresent = true;
               break;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entyDtls.getEntityName());
            entityCommercials.setFixedCommercialDetails(new ArrayList<FixedCommercialDetails>());
            entityCommercials.getFixedCommercialDetails().add(fixedCommercialDetails);
            roomDetl.getEntityCommercials().add(entityCommercials);
         }

      }
      //entyDtls.getEntityStatus().add(CommercialName + "FixedCompleted");
	  fixedCommercialDetails.setMDMRuleId(MDMRuleID);
   }
   
   public void CalculateAdditionalCommercial(String CommercialName, String CommercialType, double AdditionalPercentage, double AdditionalAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetl, String MDMRuleID, boolean isCommissionable)
   {

      AdditionalCommercialDetails addComm = new AdditionalCommercialDetails();
      addComm.setCommercialName(CommercialName);
      addComm.setCommercialFareComponent(FareComponent);

      if (AdditionalPercentage > 0)
      {
         addComm.setCommercialCalculationPercentage(AdditionalPercentage);
         if (TaxComponent == null)
         {
            if (FareComponent.equals("Total"))
               addComm.setCommercialAmount(this.totalFareTemp * AdditionalPercentage / 100);
            else
               addComm.setCommercialAmount(this.fareBreakUpTemp.getBaseFare() * AdditionalPercentage / 100);
         }
         else
         {
            if (!(FareComponent == null))
            {
               if (FareComponent.equals("Basic"))
                  addComm.setCommercialAmount(this.fareBreakUpTemp.getBaseFare());
            }
            List<String> tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
            double commercialAmount = 0;
            for (TaxDetails taxes : this.fareBreakUpTemp.getTaxDetails())
            {
               for (String tempTaxName : tempTaxDetails)
               {
                  if (tempTaxName.equals(taxes.getTaxName()))
                  {
                     commercialAmount = commercialAmount + taxes.getTaxValue();
                     if (addComm.getCommercialFareComponent() == null)
                        addComm.setCommercialFareComponent(tempTaxName);
                     else
                        addComm.setCommercialFareComponent(addComm.getCommercialFareComponent() + "," + tempTaxName);
                  }
               }
            }
            addComm.setCommercialAmount((addComm.getCommercialAmount() + commercialAmount) * AdditionalPercentage / 100);
         }
      }
      if (AdditionalAmount > 0)
      {
         addComm.setCommercialAmount(addComm.getCommercialAmount() + AdditionalAmount);
         if (addComm.getCommercialCurrency() == null)
            addComm.setCommercialCurrency(Currency);
         addComm.setCommercialCalculationAmount(AdditionalAmount);
      }
      if (CommercialName.equals("Standard") && isCommissionable == false)
      {
         if (addComm.getCommercialAmount() > 0)
         {
            boolean isCompleted = false;
            if (CommercialType.equals("Receivable"))
            {
               if (this.getEntityCommercials() != null)
               {
                  for (EntityCommercials entityCommercials : this.getEntityCommercials())
                  {
                     if (entityCommercials.getMarkUpCommercialDetails() != null && entityCommercials.getEntityName().equals(entyDtls.getEntityName()))
                     {
                        entityCommercials.getMarkUpCommercialDetails().setTotalFare(entityCommercials.getMarkUpCommercialDetails().getTotalFare() + addComm.getCommercialAmount());
                        if (entityCommercials.getMarkUpCommercialDetails().getFareBreakUp() != null)
                           entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().setBaseFare(entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().getBaseFare() + addComm.getCommercialAmount());
                        isCompleted = true;
                        totalFareTemp = totalFareTemp + addComm.getCommercialAmount();
                        break;
                     }
                  }
               }
               if (isCompleted == false)
               {
                  totalFareTemp = totalFareTemp + addComm.getCommercialAmount();
                  if (fareBreakUpTemp != null)
                  {
                     FareBreakUp fb = new FareBreakUp(fareBreakUpTemp.getBaseFare() + addComm.getCommercialAmount(), fareBreakUpTemp.getTaxDetails());
                     fareBreakUpTemp = fb;
                  }
               }
            }
            else
            {
               if (this.getEntityCommercials() != null)
               {
                  for (EntityCommercials entityCommercials : this.getEntityCommercials())
                  {
                     if (entityCommercials.getMarkUpCommercialDetails() != null && entityCommercials.getEntityName().equals(entyDtls.getEntityName()))
                     {
                        entityCommercials.getMarkUpCommercialDetails().setTotalFare(entityCommercials.getMarkUpCommercialDetails().getTotalFare() - addComm.getCommercialAmount());
                        if (entityCommercials.getMarkUpCommercialDetails().getFareBreakUp() != null)
                           entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().setBaseFare(entityCommercials.getMarkUpCommercialDetails().getFareBreakUp().getBaseFare() - addComm.getCommercialAmount());
                        isCompleted = true;
                        totalFareTemp = totalFareTemp - addComm.getCommercialAmount();
                        break;
                     }
                  }
               }
               if (isCompleted == false)
               {
                  totalFareTemp = totalFareTemp - addComm.getCommercialAmount();
                  if (fareBreakUpTemp != null)
                  {
                     FareBreakUp fb = new FareBreakUp(fareBreakUpTemp.getBaseFare() - addComm.getCommercialAmount(), fareBreakUpTemp.getTaxDetails());
                     fareBreakUpTemp = fb;
                  }
               }

            }
         }
      }
      if (roomDetl.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entyDtls.getEntityName());
         roomDetl.setEntityCommercials(new ArrayList<EntityCommercials>());
         entityCommercials.setAdditionalCommercialDetails(new ArrayList<AdditionalCommercialDetails>());
         entityCommercials.getAdditionalCommercialDetails().add(addComm);
         roomDetl.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entityComm : roomDetl.getEntityCommercials())
         {
            if (entyDtls.getEntityName().equals(entityComm.getEntityName()))
            {
               if (entityComm.getAdditionalCommercialDetails() == null)
                  entityComm.setAdditionalCommercialDetails(new ArrayList<AdditionalCommercialDetails>());
               entityComm.getAdditionalCommercialDetails().add(addComm);
               isEntityPresent = true;
               break;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entyDtls.getEntityName());
            entityCommercials.setAdditionalCommercialDetails(new ArrayList<AdditionalCommercialDetails>());
            entityCommercials.getAdditionalCommercialDetails().add(addComm);
            roomDetl.getEntityCommercials().add(entityCommercials);
         }

      }
      //entyDtls.getEntityStatus().add(CommercialName + "AdditionalCompleted");
      addComm.setMDMRuleId(MDMRuleID);
   }

   public void CalculateMarkUpCommercial(double MarkUpPercentage, double MarkUpAmount, String FareComponent, String TaxComponent, String Currency, EntityDetails entyDtls, RoomDetails roomDetl, double MinSellingPrice, String MDMRuleID)
   {
      if (roomDetl.getIneligibleCommercials() == null || !(roomDetl.getIneligibleCommercials().contains("MarkUp")))
      {
         MarkUpCommercialDetails markComm = new MarkUpCommercialDetails();
         if (this.fareBreakUp == null)
            FareBreakUpNull(MarkUpPercentage, MarkUpAmount, totalFareTemp, entyDtls.getEntityName(), MinSellingPrice, markComm, Currency, MDMRuleID);
         else
            MarkUpCalculation(MarkUpPercentage, MarkUpAmount, FareComponent, TaxComponent, Currency, totalFareTemp, entyDtls.getEntityName(), MinSellingPrice, fareBreakUpTemp, markComm, MDMRuleID);
         /*if (entyDtls.getParentEntityName() == null) {

             if (roomDetl.getFareBreakUp() == null) {
                 FareBreakUpNull(MarkUpPercentage, MarkUpAmount, roomDetl.getTotalFare(), entyDtls.getEntityName(), MinSellingPrice, markComm);

             } else {
                 MarkUpCalculation(MarkUpPercentage, MarkUpAmount, FareComponent, TaxComponent, Currency, roomDetl.getTotalFare(), entyDtls.getEntityName(), MinSellingPrice, this.getFareBreakUp(), markComm);

             }
         } else {

            
         ArrayList <EntityCommercials> tempEntityCommercials=new ArrayList<EntityCommercials>(roomDetl.getEntityCommercials());
             for (EntityCommercials parentEntity: tempEntityCommercials) {
                 if (entyDtls.getParentEntityName().equals(parentEntity.getEntityName())) {

                     if (parentEntity.getMarkUpCommercialDetails().getFareBreakUp() == null) {
                         FareBreakUpNull(MarkUpPercentage, MarkUpAmount, parentEntity.getMarkUpCommercialDetails().getTotalFare(), entyDtls.getEntityName(), MinSellingPrice, markComm);
                     } else {
                         MarkUpCalculation(MarkUpPercentage, MarkUpAmount, FareComponent, TaxComponent, Currency, parentEntity.getMarkUpCommercialDetails().getTotalFare(), entyDtls.getEntityName(), MinSellingPrice, parentEntity.getMarkUpCommercialDetails().getFareBreakUp(), markComm);
                     }
                 }
             }*/
      }
   }

   public void MarkUpCalculation(double MarkUpPercentage, double MarkUpAmount, String FareComponent, String TaxComponent, String Currency, double totalFare, String entityName, double MinSellingPrice, FareBreakUp fareBreakUp, MarkUpCommercialDetails markComm, String MDMRuleID)
   {
      //System.out.println("Entity Name : "+entityName);
      if (fareBreakUp == null)
         setFareBreakUp(this.fareBreakUp);
      if (totalFare == 0)
         setTotalFare(this.totalFare);
      markComm.setFareBreakUp(new FareBreakUp());
      markComm.getFareBreakUp().setTaxDetails(new ArrayList<TaxDetails>());
      markComm.setCommercialAmount(0.0);
      if (MarkUpPercentage > 0)
      {
         markComm.setCommercialCalculationPercentage(MarkUpPercentage);
         if (TaxComponent == null)
         {
            //List <TaxDetails> taxDetails = new ArrayList<TaxDetails>(fareBreakUp.getTaxDetails());
            //markComm.getFareBreakUp().setTaxDetails(taxDetails);

            for (TaxDetails taxes : fareBreakUp.getTaxDetails())
            {
               TaxDetails td = new TaxDetails();
               td.setTaxName(taxes.getTaxName());
               td.setTaxValue(taxes.getTaxValue());
               markComm.getFareBreakUp().getTaxDetails().add(td);
            }

            if (FareComponent.equals("Total"))
            {
               double commercialAmt = totalFare * MarkUpPercentage / 100;
               markComm.setCommercialAmount(commercialAmt);
               markComm.setCommercialFareComponent(FareComponent);
               markComm.getFareBreakUp().setBaseFare(fareBreakUp.getBaseFare() + (fareBreakUp.getBaseFare() * MarkUpPercentage / 100));
               for (TaxDetails taxDetail : markComm.getFareBreakUp().getTaxDetails())
               {
                  taxDetail.setTaxValue(taxDetail.getTaxValue() + (taxDetail.getTaxValue() * MarkUpPercentage / 100));
               }

            }
            else
            {
               markComm.setCommercialAmount(fareBreakUp.getBaseFare() * MarkUpPercentage / 100);
               markComm.setCommercialFareComponent(FareComponent);
               //System.out.println("fareBreakUp.getBaseFare() "+fareBreakUp.getBaseFare());
               //System.out.println("markComm.getCommercialAmount() "+markComm.getCommercialAmount());
               markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + fareBreakUp.getBaseFare());
            }
         }
         else
         {
            markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + fareBreakUp.getBaseFare());
            if (!(FareComponent == null))
            {
               markComm.setCommercialAmount(fareBreakUp.getBaseFare() * MarkUpPercentage / 100);
               markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + fareBreakUp.getBaseFare());
               markComm.setCommercialFareComponent(FareComponent);
            }
            List<String> tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
            double commercialAmount = 0;
            for (TaxDetails taxes : fareBreakUp.getTaxDetails())
            {
               TaxDetails td = new TaxDetails();
               td.setTaxName(taxes.getTaxName());
               td.setTaxValue(taxes.getTaxValue());
               for (String tempTaxName : tempTaxDetails)
               {
                  if (tempTaxName.equals(taxes.getTaxName()))
                  {
                     double TaxComVal = (taxes.getTaxValue() * MarkUpPercentage / 100);
                     td.setTaxValue(taxes.getTaxValue() + TaxComVal);
                     commercialAmount = commercialAmount + TaxComVal;

                     if (markComm.getCommercialFareComponent() == null)
                        markComm.setCommercialFareComponent(tempTaxName);
                     else
                        markComm.setCommercialFareComponent(markComm.getCommercialFareComponent() + "," + tempTaxName);
                  }
               }
               markComm.getFareBreakUp().getTaxDetails().add(td);
            }
            markComm.setCommercialAmount((markComm.getCommercialAmount() + commercialAmount));

         }
      }
      if (MarkUpAmount > 0)
      {
         markComm.setCommercialAmount(markComm.getCommercialAmount() + MarkUpAmount);
         //System.out.println("Amount markComm.getCommercialAmount() "+markComm.getCommercialAmount());
         if (MarkUpPercentage == 0)
         {
            markComm.getFareBreakUp().setBaseFare(markComm.getCommercialAmount() + fareBreakUp.getBaseFare());
            for (TaxDetails taxes : fareBreakUp.getTaxDetails())
            {
               TaxDetails td = new TaxDetails();
               td.setTaxName(taxes.getTaxName());
               td.setTaxValue(taxes.getTaxValue());
               markComm.getFareBreakUp().getTaxDetails().add(td);

            }
         }
         else
         {
            //if (!(FareComponent == null))
            markComm.getFareBreakUp().setBaseFare(markComm.getFareBreakUp().getBaseFare() + MarkUpAmount);
            //System.out.println("Amount markComm.getFareBreakUp().getBaseFare() "+markComm.getFareBreakUp().getBaseFare());
            /*else {
                List < String > tempTaxDetails = Arrays.asList(TaxComponent.split(";"));
                for (TaxDetails taxes: markComm.getFareBreakUp().getTaxDetails()) {
                    for (String tempTaxName: tempTaxDetails) {
                        if (tempTaxName.equals(taxes.getTaxName())) {
                            taxes.setTaxValue(taxes.getTaxValue() + MarkUpAmount);
                        }
                    }
                }
            }*/
         }
      }
      markComm.setCommercialCurrency(Currency);
      markComm.setCommercialCalculationAmount(MarkUpAmount);
      markComm.setTotalFare(markComm.getCommercialAmount() + totalFare);

      if (this.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entityName);
         this.setEntityCommercials(new ArrayList<EntityCommercials>());
         entityCommercials.setMarkUpCommercialDetails(markComm);
         this.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entitycommercials : this.getEntityCommercials())
         {
            if (entitycommercials.getEntityName().equals(entityName))
            {
               entitycommercials.setMarkUpCommercialDetails(markComm);
               isEntityPresent = true;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entityName);
            entityCommercials.setMarkUpCommercialDetails(markComm);
            this.getEntityCommercials().add(entityCommercials);
         }
      }
      markComm.setCommercialName("MarkUp");
      if ((markComm.getCommercialAmount() + totalFare) < MinSellingPrice)
      {
         markComm.setTotalFare(MinSellingPrice);
         markComm.getFareBreakUp().setBaseFare(fareBreakUp.getBaseFare() + (MinSellingPrice - totalFare));
         markComm.setCommercialAmount(MinSellingPrice - totalFare);
         markComm.getFareBreakUp().getTaxDetails().removeAll(markComm.getFareBreakUp().getTaxDetails());
         markComm.getFareBreakUp().getTaxDetails().addAll(fareBreakUp.getTaxDetails());
      }
      if (MarkUpPercentage != 0 || MarkUpAmount != 0)
      {
         fareBreakUpTemp = markComm.getFareBreakUp();
         totalFareTemp = markComm.getTotalFare();
      }
      if (MarkUpPercentage == 0 && MarkUpAmount == 0)
      {
         markComm.setFareBreakUp(fareBreakUp);
      }
      markComm.setMDMRuleId(MDMRuleID);
   }

   public void FareBreakUpNull(double MarkUpPercentage, double MarkUpAmount, double totalFare, String entityName, double MinSellingPrice, MarkUpCommercialDetails markComm, String Currency, String MDMRuleID)
   {
      if (totalFare == 0)
         setTotalFare(this.totalFare);
      double markUpTotalFare = totalFare;
      if (MarkUpPercentage > 0)
      {
         markComm.setTotalFare(totalFare + (totalFare * MarkUpPercentage / 100));
         markUpTotalFare = markComm.getTotalFare();
         markComm.setCommercialCalculationPercentage(MarkUpPercentage);
		 markComm.setCommercialAmount(totalFare * MarkUpPercentage / 100);
		}
      if (MarkUpAmount > 0)
      {
		 markComm.setTotalFare(markUpTotalFare + MarkUpAmount);
         markComm.setCommercialCalculationAmount(MarkUpAmount);
         markComm.setCommercialAmount(markComm.getCommercialAmount() + MarkUpAmount);
	  }
      /*else
      {
         markComm.setTotalFare(totalFare + MarkUpAmount);
         markComm.setCommercialAmount(MarkUpAmount);
		 markComm.setCommercialCalculationAmount(MarkUpAmount);
      }*/

      markComm.setCommercialFareComponent("Total");
      markComm.setCommercialCurrency(Currency);

      if (this.getEntityCommercials() == null)
      {
         EntityCommercials entityCommercials = new EntityCommercials();
         entityCommercials.setEntityName(entityName);
         this.setEntityCommercials(new ArrayList<EntityCommercials>());
         entityCommercials.setMarkUpCommercialDetails(markComm);
         this.getEntityCommercials().add(entityCommercials);
      }
      else
      {
         boolean isEntityPresent = false;
         for (EntityCommercials entitycommercials : this.getEntityCommercials())
         {
            if (entitycommercials.getEntityName().equals(entityName))
            {
               entitycommercials.setMarkUpCommercialDetails(markComm);
               isEntityPresent = true;
            }
         }
         if (isEntityPresent == false)
         {
            EntityCommercials entityCommercials = new EntityCommercials();
            entityCommercials.setEntityName(entityName);
            entityCommercials.setMarkUpCommercialDetails(markComm);
            this.getEntityCommercials().add(entityCommercials);
         }
      }
      markComm.setCommercialName("MarkUp");
      if ((markComm.getCommercialAmount() + totalFare) < MinSellingPrice)
      {

         markComm.setTotalFare(MinSellingPrice);
         markComm.setCommercialAmount(MinSellingPrice - totalFare);
      }
      if (MarkUpPercentage != 0 || MarkUpAmount != 0)
      {
         totalFareTemp = markComm.getTotalFare();
      }
      markComm.setMDMRuleId(MDMRuleID);
   }

   public RoomDetails()
   {
   }

   public java.lang.String getRoomType()
   {
      return this.roomType;
   }

   public void setRoomType(java.lang.String roomType)
   {
      this.roomType = roomType;
   }

   public java.lang.String getRoomCategory()
   {
      return this.roomCategory;
   }

   public void setRoomCategory(java.lang.String roomCategory)
   {
      this.roomCategory = roomCategory;
   }

   public java.lang.String getPassengerType()
   {
      return this.passengerType;
   }

   public void setPassengerType(java.lang.String passengerType)
   {
      this.passengerType = passengerType;
   }

   public boolean isIsAdvanced()
   {
      return this.isAdvanced;
   }

   public void setIsAdvanced(boolean isAdvanced)
   {
      this.isAdvanced = isAdvanced;
   }

   public cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp getFareBreakUp()
   {
      return this.fareBreakUp;
   }

   public void setFareBreakUp(
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp)
   {
      this.fareBreakUp = fareBreakUp;
      fareBreakUpTemp = this.fareBreakUp;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> getCommercialDetails()
   {
      return this.commercialDetails;
   }

   public void setCommercialDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails)
   {
      this.commercialDetails = commercialDetails;
   }

   public double getTotalReceivables()
   {
      return this.totalReceivables;
   }

   public void setTotalReceivables(double totalReceivables)
   {
      this.totalReceivables = totalReceivables;
   }

   public double getTotalPayables()
   {
      return this.totalPayables;
   }

   public void setTotalPayables(double totalPayables)
   {
      this.totalPayables = totalPayables;
   }

   public double getTotalFare()
   {
      return this.totalFare;
   }

   public void setTotalFare(double totalFare)
   {
      this.totalFare = totalFare;
      totalFareTemp = this.totalFare;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> getEntityCommercials()
   {
      return this.entityCommercials;
   }

   public void setEntityCommercials(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials)
   {
      this.entityCommercials = entityCommercials;
   }

   public java.util.List<java.lang.String> getCommercialsApplied()
   {
      return this.commercialsApplied;
   }

   public void setCommercialsApplied(
         java.util.List<java.lang.String> commercialsApplied)
   {
      this.commercialsApplied = commercialsApplied;
   }

   public java.lang.String getStarCategory()
   {
      return this.starCategory;
   }

   public void setStarCategory(java.lang.String starCategory)
   {
      this.starCategory = starCategory;
   }

   public java.lang.String getMealPlan()
   {
      return this.mealPlan;
   }

   public void setMealPlan(java.lang.String mealPlan)
   {
      this.mealPlan = mealPlan;
   }

   public java.lang.Integer getPassengerCount()
   {
      return this.passengerCount;
   }

   public void setPassengerCount(java.lang.Integer passengerCount)
   {
      this.passengerCount = passengerCount;
   }

   public java.lang.Integer getNoOfNights()
   {
      return this.noOfNights;
   }

   public void setNoOfNights(java.lang.Integer noOfNights)
   {
      this.noOfNights = noOfNights;
   }

   public java.lang.String getRateType()
   {
      return this.rateType;
   }

   public void setRateType(java.lang.String rateType)
   {
      this.rateType = rateType;
   }

   public java.lang.String getRateCode()
   {
      return this.rateCode;
   }

   public void setRateCode(java.lang.String rateCode)
   {
      this.rateCode = rateCode;
   }

   public int getBookingEngineKey()
   {
      return this.bookingEngineKey;
   }

   public void setBookingEngineKey(int bookingEngineKey)
   {
      this.bookingEngineKey = bookingEngineKey;
   }

   public RoomDetails(
         java.lang.String roomType,
         java.lang.String roomCategory,
         java.lang.String passengerType,
         boolean isAdvanced,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails,
         double totalReceivables,
         double totalPayables,
         double totalFare,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials,
         java.util.List<java.lang.String> commercialsApplied,
         java.util.List<java.lang.String> ineligibleCommercials,
         double totalFareTemp,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUpTemp,
         java.lang.String starCategory, java.lang.String mealPlan,
         java.lang.Integer passengerCount, java.lang.Integer noOfNights,
         java.lang.String rateType, java.lang.String rateCode,
         int bookingEngineKey, java.lang.String bookingId)
   {
      this.roomType = roomType;
      this.roomCategory = roomCategory;
      this.passengerType = passengerType;
      this.isAdvanced = isAdvanced;
      this.fareBreakUp = fareBreakUp;
      this.commercialDetails = commercialDetails;
      this.totalReceivables = totalReceivables;
      this.totalPayables = totalPayables;
      this.totalFare = totalFare;
      this.entityCommercials = entityCommercials;
      this.commercialsApplied = commercialsApplied;
      this.ineligibleCommercials = ineligibleCommercials;
      this.totalFareTemp = totalFareTemp;
      this.fareBreakUpTemp = fareBreakUpTemp;
      this.starCategory = starCategory;
      this.mealPlan = mealPlan;
      this.passengerCount = passengerCount;
      this.noOfNights = noOfNights;
      this.rateType = rateType;
      this.rateCode = rateCode;
      this.bookingEngineKey = bookingEngineKey;
      this.bookingId = bookingId;
   }

   public java.lang.String getParentId()
   {
      return this.parentId;
   }

   public void setParentId(java.lang.String parentId)
   {
      this.parentId = parentId;
   }

   public java.lang.String getRoomDetailsId()
   {
      return this.roomDetailsId;
   }

   public void setRoomDetailsId(java.lang.String roomDetailsId)
   {
      this.roomDetailsId = roomDetailsId;
   }

   public RoomDetails(
         java.util.List<java.lang.String> commercialsApplied,
         java.lang.String roomType,
         java.lang.String roomCategory,
         java.lang.String passengerType,
         java.lang.String starCategory,
         java.lang.String mealPlan,
         java.lang.Integer passengerCount,
         java.lang.Integer noOfNights,
         java.lang.String rateType,
         java.lang.String rateCode,
         int bookingEngineKey,
         double totalReceivables,
         double totalPayables,
         double totalFare,
         double totalFareTemp,
         java.lang.String bookingId,
         java.util.List<java.lang.String> ineligibleCommercials,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUpTemp,
         boolean isAdvanced,
         cnk.acco_commercialscalculationengine.clienttransactionalrules.FareBreakUp fareBreakUp,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.CommercialDetails> commercialDetails,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.EntityCommercials> entityCommercials,
         java.lang.String parentId, java.lang.String roomDetailsId)
   {
      this.commercialsApplied = commercialsApplied;
      this.roomType = roomType;
      this.roomCategory = roomCategory;
      this.passengerType = passengerType;
      this.starCategory = starCategory;
      this.mealPlan = mealPlan;
      this.passengerCount = passengerCount;
      this.noOfNights = noOfNights;
      this.rateType = rateType;
      this.rateCode = rateCode;
      this.bookingEngineKey = bookingEngineKey;
      this.totalReceivables = totalReceivables;
      this.totalPayables = totalPayables;
      this.totalFare = totalFare;
      this.totalFareTemp = totalFareTemp;
      this.bookingId = bookingId;
      this.ineligibleCommercials = ineligibleCommercials;
      this.fareBreakUpTemp = fareBreakUpTemp;
      this.isAdvanced = isAdvanced;
      this.fareBreakUp = fareBreakUp;
      this.commercialDetails = commercialDetails;
      this.entityCommercials = entityCommercials;
      this.parentId = parentId;
      this.roomDetailsId = roomDetailsId;
   }

}