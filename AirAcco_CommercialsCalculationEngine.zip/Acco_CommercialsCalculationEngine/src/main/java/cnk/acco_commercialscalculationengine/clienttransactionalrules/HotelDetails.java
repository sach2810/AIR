package cnk.acco_commercialscalculationengine.clienttransactionalrules;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@org.codehaus.jackson.map.annotate.JsonSerialize(include = org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion.NON_NULL)
public class HotelDetails implements java.io.Serializable
{

   static final long serialVersionUID = 1L;

   private java.lang.String productChain;
   private java.lang.String productBrand;
   private java.lang.String productName;
   private java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.RoomDetails> roomDetails;

   private java.lang.String parentId;

   private java.lang.String hotelDetailsId;

   public HotelDetails()
   {
   }

   /* @Override
   public String toString() {
   return "HotelDetails [productChain=" + productChain + ", productBrand=" + productBrand + ", productName="
   		+ productName + ", roomDetails=" + roomDetails + "]";
   }*/

   public java.lang.String getProductChain()
   {
      return this.productChain;
   }

   public void setProductChain(java.lang.String productChain)
   {
      this.productChain = productChain;
   }

   public java.lang.String getProductBrand()
   {
      return this.productBrand;
   }

   public void setProductBrand(java.lang.String productBrand)
   {
      this.productBrand = productBrand;
   }

   public java.lang.String getProductName()
   {
      return this.productName;
   }

   public void setProductName(java.lang.String productName)
   {
      this.productName = productName;
   }

   public java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.RoomDetails> getRoomDetails()
   {
      return this.roomDetails;
   }

   public void setRoomDetails(
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.RoomDetails> roomDetails)
   {
      this.roomDetails = roomDetails;
   }

   public java.lang.String getParentId()
   {
      return this.parentId;
   }

   public void setParentId(java.lang.String parentId)
   {
      this.parentId = parentId;
   }

   public java.lang.String getHotelDetailsId()
   {
      return this.hotelDetailsId;
   }

   public void setHotelDetailsId(java.lang.String hotelDetailsId)
   {
      this.hotelDetailsId = hotelDetailsId;
   }

   public HotelDetails(
         java.lang.String productChain,
         java.lang.String productBrand,
         java.lang.String productName,
         java.util.List<cnk.acco_commercialscalculationengine.clienttransactionalrules.RoomDetails> roomDetails,
         java.lang.String parentId, java.lang.String hotelDetailsId)
   {
      this.productChain = productChain;
      this.productBrand = productBrand;
      this.productName = productName;
      this.roomDetails = roomDetails;
      this.parentId = parentId;
      this.hotelDetailsId = hotelDetailsId;
   }

}