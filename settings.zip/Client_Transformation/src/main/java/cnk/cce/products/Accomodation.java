package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.cce.configuration.CommonFunctions;
import cnk.cce.configuration.SettlementCommercials;

public class Accomodation {
	public static String serviceContractValidityTo,sectorContractValidityFrom,serviceContractValidityFrom,sectorContractValidityTo,segmentContractValidityTo,segmentContractValidityFrom,stdContractValidityFrom,stdContractValidityTo,overContractValidityFrom,overContractValidityTo,plbContractValidityFrom,plbContractValidityTo;
	public static String managementContractValidityFrom,managementContractValidityTo,discountContractValidityFrom,discountContractValidityTo,markupContractValidityFrom,markupContractValidityTo,destinationContractValidityFrom,destinationContractValidityTo,segmentLocalID;
	public static String destLocalID,stdAdvanceDefinitionId,overridingAdvanceDefinitionId,plbAdvanceDefinitionId,sectorWiseAdvanceDefinitionId,segmentAdvanceDefinitionId,serviceAdvanceDefinitionId,mngtAdvanceDefinitionId,discountAdvanceDefinitionId,destinationAdvanceDefinitionId;
	public static String stdLocalID,overridingLocalID,plbLocalID,sectorWiseLocalID,commissionLocalID,serviceLocalID,mngtLocalID,discountLocalID,markupLocalID,destinationLocalID,issuanceLocalID,commissionAdvanceDefinitionId,markupAdvanceDefinitionId,issuanceAdvanceDefinitionId;
	public static JSONArray plbapplicableOnArray,segmentapplicableOnArray,serviceapplicableOnArray;

	public static JSONObject appendAccoCommercialDetails(String advancedDT, String calculationDT, String commercialName, JSONObject mdmCommDefn,JSONObject mainJson, String productName, boolean advancedApplicable, String id) {
		JSONObject advanced = new JSONObject();
		JSONObject calculation = new JSONObject();
		advanced.put("type", "advanced");
		calculation.put("type", "calculation");
		advanced.put("selectedRow", id);
		advanced.put("contractValidity", getContractValidity(commercialName));
		setRuleID(commercialName,advanced,calculation,id);
		CommonFunctions.setCalculationParameters(commercialName,calculation,mainJson);
		JSONArray advancedArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		advancedArr.put(advanced);
		calcArr.put(calculation);
		mainJson.put(advancedDT, advancedArr);
		mainJson.put(calculationDT, calcArr);

		appendApplicableOnDetails(advancedArr,calcArr,commercialName,mdmCommDefn.getJSONArray("clientCommercialOtherHead"));
		
		if(advancedApplicable){
			JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray("advancedDefinitionData");
			switch(commercialName){
			case "Standard":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,stdAdvanceDefinitionId,id,commercialName);break;}
			case "Overriding":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,overridingAdvanceDefinitionId,id,commercialName);break;}
			case "PLB":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,plbAdvanceDefinitionId,id,commercialName);break;}
			case "SectorWiseIncentive":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,sectorWiseAdvanceDefinitionId,id,commercialName);break;}
			case "DestinationIncentive":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,destinationAdvanceDefinitionId,id,commercialName);break;}
			case "SegmentFee":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,segmentAdvanceDefinitionId,id,commercialName);break;}
			case "ServiceCharge":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,serviceAdvanceDefinitionId,id,commercialName);break;}
			case "ManagementFee":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,mngtAdvanceDefinitionId,id,commercialName);break;}
			case "Discount":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,discountAdvanceDefinitionId,id,commercialName);break;}
			case "MarkUp":{setAccoAdvDefn(advancedArr,calcArr,advancedDefinitionData,markupAdvanceDefinitionId,id,commercialName);break;}
			default:System.out.println("default of appendAccoCommercialDetails due to: "+commercialName);
			}
		}
		
		for(int i=0;i<calcArr.length();i++){
			JSONObject calculation1 = calcArr.getJSONObject(i);
			CommonFunctions.setMDMRuleID(commercialName,calculation1);
			String ruleId = calculation1.getString("mdmRuleID")+"|"+calculation1.getString("selectedRow");
			calculation1.put("mdmRuleID", ruleId);
		}
		return mainJson;
	}

	
	private static void setAccoAdvDefn(JSONArray advancedArr,JSONArray calcArr,JSONArray advancedDefinitionData,String advDefnID,String id,String commercialName) {
		for(int i=0;i<advancedDefinitionData.length();i++){
			if(advancedDefinitionData.getJSONObject(i).get("_id").equals(advDefnID)){
				if(!commercialName.equals("PLB")){
					JSONObject advanceDefinitionAccommodation = advancedDefinitionData.getJSONObject(i).getJSONObject("advanceDefinitionAccommodation");
					appendAccomodationAdvancedDefinition(advancedArr,calcArr,advanceDefinitionAccommodation,id);
				}else{
					JSONObject advanceDefinitionAccommodationPLB = advancedDefinitionData.getJSONObject(i).getJSONObject("advanceDefinitionAccommodationPLB");
					appendPLBAccomodationCommercialsDetails(advancedArr,calcArr,advanceDefinitionAccommodationPLB,id);
				}
			}
		}
	}


	private static void appendPLBAccomodationCommercialsDetails(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionAccommodationPLB, String id) {
		if(advanceDefinitionAccommodationPLB.has("validity")){
			JSONObject validity = advanceDefinitionAccommodationPLB.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "sale":{
				CommonFunctions.getPLBDates(advancedArr,calcArr,validity.getJSONArray("sale"),"sale");
				break;
			}
			case "travel":{
				CommonFunctions.getPLBDates(advancedArr,calcArr,validity.getJSONArray("travel"),"travel");
				break;
			}
			default:{
				JSONArray salePlusTravel = validity.getJSONArray("salePlusTravel");
				CommonFunctions.insertPLBSalePlusTravel(salePlusTravel,advancedArr,calcArr);
				break;
			}
			}
		}
		
		if(advanceDefinitionAccommodationPLB.has("nationality") && advanceDefinitionAccommodationPLB.length()>0)
			CommonFunctions.getTriggerPayoutArray(advancedArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray("nationality"),"clientNationality",true);

		/*if(advanceDefinitionAccommodationPLB.has("passenger") && advanceDefinitionAccommodationPLB.getJSONArray("passenger").length()>0)
			CommonFunctions.getTriggerPayoutArray(advancedArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray("passenger"),"passengerTypes",false);*/
		
		if(advanceDefinitionAccommodationPLB.has("credentials") && advanceDefinitionAccommodationPLB.getJSONArray("credentials").length()>0)
			CommonFunctions.getTriggerPayoutArray(advancedArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray("credentials"),"credentialId",true);
				
		if(advanceDefinitionAccommodationPLB.has("connectivity") && advanceDefinitionAccommodationPLB.getJSONObject("connectivity")!=null)
			CommonFunctions.getConnectivity(advancedArr,advanceDefinitionAccommodationPLB.getJSONObject("connectivity"));
			
		if(advanceDefinitionAccommodationPLB.has("others") && advanceDefinitionAccommodationPLB.getJSONObject("others")!=null){
			JSONObject others = advanceDefinitionAccommodationPLB.getJSONObject("others");
			if(others.has("bookingType"))
				if(others.getBoolean("isInclusion"))
					CommonFunctions.getBookingType(advancedArr,others.getJSONObject("bookingType"),true);
				else CommonFunctions.getBookingType(advancedArr,others.getJSONObject("bookingType"),false);
			
			if(others.has("roomTypes") && others.getJSONArray("roomTypes").length()>0){
				if(others.getBoolean("isInclusion"))
					CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr,calcArr,others.getJSONArray("roomTypes"),"roomTypes",true,false);
				else CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr,calcArr,others.getJSONArray("roomTypes"),"roomTypes",false,false);
			}
			
			if(others.has("roomCategories") && others.getJSONArray("roomCategories").length()>0){
				if(others.getBoolean("isInclusion"))
					CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr,calcArr,others.getJSONArray("roomCategories"),"roomCategory",true,false);
				else CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr,calcArr,others.getJSONArray("roomCategories"),"roomCategory",false,false);
			}
		}
		
		if(advanceDefinitionAccommodationPLB.has("travelDestination") && advanceDefinitionAccommodationPLB.getJSONObject("travelDestination")!=null){
			JSONObject travelDestination = advanceDefinitionAccommodationPLB.getJSONObject("travelDestination");
			if(travelDestination.getJSONArray("travel").length()>0){
				if(travelDestination.getBoolean("isInclusion"))
					CommonFunctions.getDestination(advancedArr,calcArr,travelDestination.getJSONArray("travel"),true,true);
				else CommonFunctions.getDestination(advancedArr,calcArr,travelDestination.getJSONArray("travel"),false,true);
			}
		}
		
	}


	private static void setRuleID(String commercialName, JSONObject advanced, JSONObject calculation, String id) {
		switch(commercialName){
		case "Standard":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+stdLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+stdLocalID);
			advanced.put("agendaGroup", id+"_Standard");
			calculation.put("agendaGroup", id+"_Standard");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+stdLocalID);
		}break;
		case "Overriding":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+overridingLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+overridingLocalID);
			advanced.put("agendaGroup", id+"_Overriding");
			calculation.put("agendaGroup", id+"_Overriding");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+overridingLocalID);
		}break;
		case "PLB":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+plbLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+plbLocalID);
			advanced.put("agendaGroup", id+"_PLB");
			calculation.put("agendaGroup", id+"_PLB");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+plbLocalID);
		}break;
		case "SectorWiseIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+sectorWiseLocalID);
			advanced.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
		}break;
		case "DestinationIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+destinationLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+destinationLocalID);
			advanced.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+destinationLocalID);
		}break;
		case "SegmentFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+segmentLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+segmentLocalID);
			advanced.put("agendaGroup", id+"_SegmentFee");
			calculation.put("agendaGroup", id+"_SegmentFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+segmentLocalID);
		}break;
		case "ServiceCharge":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+serviceLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+serviceLocalID);
			advanced.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+serviceLocalID);
		}break;
		case "ManagementFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+mngtLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+mngtLocalID);
			advanced.put("agendaGroup", id+"_ManagementFee");
			calculation.put("agendaGroup", id+"_ManagementFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+mngtLocalID);
		}break;
		case "Discount":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+discountLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+discountLocalID);
			advanced.put("agendaGroup", id+"_Discount");
			calculation.put("agendaGroup", id+"_Discount");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+discountLocalID);
		}break;
		case "MarkUp":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+markupLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+markupLocalID);
			advanced.put("agendaGroup", id+"_MarkUp");
			calculation.put("agendaGroup", id+"_MarkUp");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+markupLocalID);
		}break;
		case "Commission":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+commissionLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+commissionLocalID);
			advanced.put("agendaGroup", id+"_Commission");
			calculation.put("agendaGroup", id+"_Commission");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+commissionLocalID);
		}break;
		default:System.out.println("default of Accomodation.setRuleID due to: "+commercialName);
		}
	}


	public static JSONObject getContractValidity(String commercialName) {
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		switch(commercialName){
		case "Standard":{
			contractValidity.put("from", stdContractValidityFrom);
			contractValidity.put("to", stdContractValidityTo);
			break;
		}
		case "Overriding":{
			contractValidity.put("from", overContractValidityFrom);
			contractValidity.put("to", overContractValidityTo);
			break;
		}
		case "PLB":{
			contractValidity.put("from", plbContractValidityFrom);
			contractValidity.put("to", plbContractValidityTo);
			break;
		}
		case "SectorWiseIncentive":{
			contractValidity.put("from", sectorContractValidityFrom);
			contractValidity.put("to", sectorContractValidityTo);
			break;
		}
		case "DestinationIncentive":{
			contractValidity.put("from", destinationContractValidityFrom);
			contractValidity.put("to", destinationContractValidityTo);
			break;
		}
		case "SegmentFee":{
			contractValidity.put("from", segmentContractValidityFrom);
			contractValidity.put("to", segmentContractValidityTo);
			break;
		}
		case "ServiceCharge":{
			contractValidity.put("from", serviceContractValidityFrom);
			contractValidity.put("to", serviceContractValidityTo);
			break;
		}
		case "ManagementFee":{
			contractValidity.put("from", managementContractValidityFrom);
			contractValidity.put("to", managementContractValidityTo);
			break;
		}
		case "Discount":{
			contractValidity.put("from", discountContractValidityFrom);
			contractValidity.put("to", discountContractValidityTo);
			break;
		}
		case "MarkUp":{
			contractValidity.put("from", markupContractValidityFrom);
			contractValidity.put("to", markupContractValidityTo);
			break;
		}
		default:System.out.println("default of Accomodation.getContractValidity due to: "+commercialName);
		}
		return contractValidity;
	}


	public static void appendAccomodationAdvancedDefinition(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionAccommodation, String id) {
		int length = advancedArr.length();
		for(int i=0;i<length;i++){
			JSONObject advanced = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
			JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
			if(advanceDefinitionAccommodation.has("nationality")){
				JSONObject nationality = advanceDefinitionAccommodation.getJSONObject("nationality");
				if(!nationality.getJSONArray("clientNationality").getString(0).equalsIgnoreCase("All"))
					if(nationality.getBoolean("isInclusion"))
						advanced.put("clientNationality", nationality.get("clientNationality"));
					else advanced.put("clientNationality_exclusion", nationality.get("clientNationality"));
			}
			/*if(advanceDefinitionAccommodation.has("passengerTypes") && advanceDefinitionAccommodation.getJSONArray("passengerTypes").length()>0){
				if(!advanceDefinitionAccommodation.getJSONArray("passengerTypes").getString(0).equalsIgnoreCase("All"))
					calculation.put("passengerType", advanceDefinitionAccommodation.getJSONArray("passengerTypes"));
			}*/
			if(advanceDefinitionAccommodation.has("credentials") && advanceDefinitionAccommodation.getJSONArray("credentials").length()>0){
				if(!advanceDefinitionAccommodation.getJSONArray("credentials").getString(0).equalsIgnoreCase("All"))
					advanced.put("credentialsName", advanceDefinitionAccommodation.getJSONArray("credentials"));
			}
			if(advanceDefinitionAccommodation.has("connectivity") && advanceDefinitionAccommodation.getJSONObject("connectivity")!=null){
				JSONObject connectivity = advanceDefinitionAccommodation.getJSONObject("connectivity");
				if(!connectivity.getString("supplierType").equalsIgnoreCase("All"))
					advanced.put("connectivitySupplierType",connectivity.getString("supplierType"));
				if(!connectivity.getString("supplierId").equalsIgnoreCase("All"))
					advanced.put("connectivitySupplierName",connectivity.getString("supplierId"));
			}
			if(advanceDefinitionAccommodation.has("others") && advanceDefinitionAccommodation.getJSONObject("others")!=null){
				JSONObject others = advanceDefinitionAccommodation.getJSONObject("others");
				if(others.has("bookingType") && !others.getString("bookingType").equalsIgnoreCase("All"))
					advanced.put("bookingType",others.getString("bookingType"));
				if(others.has("roomTypes") && others.getJSONObject("roomTypes")!=null ){
					if(!others.getJSONObject("roomTypes").getJSONArray("roomTypes").getString(0).equalsIgnoreCase("All"))
						if(others.getJSONObject("roomTypes").getBoolean("isInclusion"))
							calculation.put("roomType", others.getJSONObject("roomTypes").get("roomTypes"));
						else calculation.put("roomType_exclusion", others.getJSONObject("roomTypes").get("roomTypes"));
				}
				if(others.has("roomCategories") && others.getJSONObject("roomCategories")!=null ){
					if(!others.getJSONObject("roomCategories").getJSONArray("roomCategories").getString(0).equalsIgnoreCase("All"))
						if(others.getJSONObject("roomCategories").getBoolean("isInclusion"))
							calculation.put("roomCategory", others.getJSONObject("roomCategories").get("roomCategories"));
						else calculation.put("roomCategory_exclusion", others.getJSONObject("roomCategories").get("roomCategories"));
				}
			}
			advancedArr.put(advanced);
			calcArr.put(calculation);
		}
		for(int i=0;i<length;i++){
			advancedArr.remove(0);
			calcArr.remove(0);
		}
		
		if(advanceDefinitionAccommodation.has("travelDestination")){
			JSONObject travelDestination = advanceDefinitionAccommodation.getJSONObject("travelDestination");
			if(travelDestination.has("destinations") && travelDestination.getJSONArray("destinations").length()>0){
				JSONArray destinations = travelDestination.getJSONArray("destinations");
				if(travelDestination.getBoolean("isInclusion"))
					CommonFunctions.getTravelDestination(advancedArr,calcArr,destinations,true,true);//isInclusion:true :: inAdvanced:true
				else CommonFunctions.getTravelDestination(advancedArr,calcArr,destinations,false,true);//isInclusion:false :: inAdvanced:true
			}
		}
		
		if(advanceDefinitionAccommodation.has("validity")){
			JSONObject validity = advanceDefinitionAccommodation.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "sale":{
				CommonFunctions.setDate(advancedArr, calcArr, validity.getJSONArray("sale"), "sale", true);
				break;
			}
			case "travel":{
				CommonFunctions.setDate(advancedArr, calcArr, validity.getJSONArray("travel"), "travel", true);
				break;
			}
			default:{
				JSONArray salePlusTravel = validity.getJSONArray("salePlusTravel");
				CommonFunctions.insertSalePlusTravel(advancedArr,calcArr,salePlusTravel);
				break;
			}
			}
		}
	}


	public static void appendAccomodationOtherFeesAdvDefn(JSONObject advanceDefinitionAccommodation, JSONArray otherFeeArr, JSONObject mdmCommDefn, JSONObject jsonObject, String id){
		for(int g=0;g<mdmCommDefn.getJSONArray("clientCommercialOtherHead").length();){
			JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray("clientCommercialOtherHead").getJSONObject(g);
			JSONObject otherFees = clientCommercialOtherHead.getJSONObject("commercialHeads").getJSONObject("otherFees");

			if(advanceDefinitionAccommodation.has("travelDestination")){
				JSONArray destinationArray = advanceDefinitionAccommodation.getJSONObject("travelDestination").getJSONArray("destinations");
				for(int i=0;i<destinationArray.length();i++){
					JSONObject otherFee = new JSONObject();
					JSONObject destinationObj = destinationArray.getJSONObject(i);
					otherFee.put("RuleID", "Acco");
					otherFee.put("RuleID", jsonObject.getString("_id")+destinationObj.getString("_id"));
					otherFee.put("selectedRow", id);
					otherFee.put("type", "otherFee");
					//JSONObject mdmOtherFees = mdmCommDefn.getJSONObject("otherFees").getJSONObject("otherFees");
					//otherFee.put("contractValidity", getContractValidity(jsonObject));
					//applyOn(mdmOtherFees,otherFee);
					SettlementCommercials.appliedOnOtherFees(otherFees,otherFee);
					try{
						JSONObject fixed = otherFees.getJSONObject("fixed");
						otherFee.put("commercialAmount", fixed.get("value").toString());
						otherFee.put("commercialCurrency", fixed.getString("currency"));
					}catch(Exception e){}
					if(advanceDefinitionAccommodation.getJSONObject("travelDestination").getBoolean("isInclusion")){
						if(destinationObj.has("continent") && !destinationObj.getString("continent").equalsIgnoreCase("All"))
							otherFee.put("tocontinent", destinationObj.getString("continent"));
						if(destinationObj.has("country") && !destinationObj.getString("country").equalsIgnoreCase("All"))
							otherFee.put("tocountry",destinationObj.getString("country"));
						if(destinationObj.has("state") && !destinationObj.getString("state").equalsIgnoreCase("All"))
							otherFee.put("tostate",destinationObj.getString("state"));
						if(destinationObj.has("city") && !destinationObj.getString("city").equalsIgnoreCase("All"))
							otherFee.put("tocity",destinationObj.getString("city"));
					}else{
						if(destinationObj.has("continent") && !destinationObj.getString("continent").equalsIgnoreCase("All"))
							otherFee.put("tocontinent_exclusion", destinationObj.getString("continent"));
						if(destinationObj.has("country") && !destinationObj.getString("country").equalsIgnoreCase("All"))
							otherFee.put("tocountry_exclusion",destinationObj.getString("country"));
						if(destinationObj.has("state") && !destinationObj.getString("state").equalsIgnoreCase("All"))
							otherFee.put("tostate_exclusion",destinationObj.getString("state"));
						if(destinationObj.has("city") && !destinationObj.getString("city").equalsIgnoreCase("All"))
							otherFee.put("tocity_exclusion",destinationObj.getString("city"));
					}
					setAccoAdvancedDefinition(advanceDefinitionAccommodation,otherFee);
					otherFeeArr.put(otherFee);
				}
				if(advanceDefinitionAccommodation.has("validity") && advanceDefinitionAccommodation.getJSONObject("validity")!=null && advanceDefinitionAccommodation.getJSONObject("validity").length()!=0 )
					switch(advanceDefinitionAccommodation.getJSONObject("validity").getString("validityType")){
					case "sale":{
						JSONArray sale = advanceDefinitionAccommodation.getJSONObject("validity").getJSONArray("sale");
						getTransportationSalesDate(sale,otherFeeArr);
						break;
					}
					case "travel":{
						JSONArray travel = advanceDefinitionAccommodation.getJSONObject("validity").getJSONArray("travel");
						getTransportationTravelDate(travel,otherFeeArr);
						break;
					}
					default:{
						JSONArray salePlusTravel = advanceDefinitionAccommodation.getJSONObject("validity").getJSONArray("salePlusTravel");
						int length = otherFeeArr.length();
						for(int i=0;i<length;i++){
							for(int x=0;x<salePlusTravel.length();x++){
								JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
								JSONObject salePlusTravelObj = salePlusTravel.getJSONObject(x);
								JSONArray saleArr = new JSONArray();
								JSONArray salesinclusionArr = new JSONArray();
								JSONArray salesexclusionArr = new JSONArray();
								JSONObject salesinclusionObject = new JSONObject();
								JSONObject salesexclusionObject = new JSONObject();
								JSONObject saleInclusionIndiObj = new JSONObject();
								JSONObject travelInclusionIndiObj = new JSONObject();
								JSONObject saleExclusionIndiObj = new JSONObject();
								JSONObject travelExclusionIndiObj = new JSONObject();
								JSONObject inclusionObject = new JSONObject();
								JSONObject exclusionObject = new JSONObject();
								JSONArray travelArr = new JSONArray();
								JSONArray travelinclusionArr = new JSONArray();
								JSONArray travelexclusionArr = new JSONArray();
								JSONObject saleObj = salePlusTravelObj.getJSONObject("sales");
								JSONObject travelObj = salePlusTravelObj.getJSONObject("travel");

								if(saleObj.has("saleFrom")){
									if(saleObj.has("saleTo")){
										saleInclusionIndiObj.put("operator", "BETWEEN");
										saleInclusionIndiObj.put("from", saleObj.get("saleFrom").toString().substring(0, 19));
										saleInclusionIndiObj.put("to", saleObj.get("saleTo").toString().substring(0, 19));
										salesinclusionArr.put(saleInclusionIndiObj);
									}else if(saleObj.has("saleFrom")){
										saleInclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
										saleInclusionIndiObj.put("from", saleObj.get("saleFrom").toString().substring(0, 19));
										salesinclusionArr.put(saleInclusionIndiObj);
									}
								}else if(saleObj.has("saleTo")){
									saleInclusionIndiObj.put("operator", "LESSTHANEQUALTO");
									saleInclusionIndiObj.put("to", saleObj.get("saleTo").toString().substring(0, 19));
									salesinclusionArr.put(saleInclusionIndiObj);

								}
								if(saleObj.has("blockOutFrom")){
									if(saleObj.has("blockOutTo")){
										saleExclusionIndiObj.put("operator", "BETWEEN");
										saleExclusionIndiObj.put("from", saleObj.get("blockOutFrom").toString().substring(0, 19));
										saleExclusionIndiObj.put("to", saleObj.get("blockOutTo").toString().substring(0, 19));
										salesexclusionArr.put(saleExclusionIndiObj);
									}else{
										saleExclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
										saleExclusionIndiObj.put("from", saleObj.get("blockOutFrom").toString().substring(0, 19));
										salesexclusionArr.put(saleExclusionIndiObj);
									}
								}else if(saleObj.has("blockOuto")){
									saleExclusionIndiObj.put("operator", "LESSTHANEQUALTO");
									saleExclusionIndiObj.put("to", saleObj.get("blockOutTo").toString().substring(0, 19));
									salesexclusionArr.put(saleExclusionIndiObj);

								}

								if(salesinclusionArr.length()>0){
									salesinclusionObject.put("inclusion",salesinclusionArr);
									saleArr.put(salesinclusionObject);
								}
								if(salesexclusionArr.length()>0){
									salesexclusionObject.put("exclusion",salesexclusionArr);
									saleArr.put(salesexclusionObject);
								}

								if(travelObj.has("travelFrom")){
									if(travelObj.has("travelTo")){
										travelInclusionIndiObj.put("operator", "BETWEEN");
										travelInclusionIndiObj.put("from", travelObj.get("travelFrom").toString().substring(0, 19));
										travelInclusionIndiObj.put("to", travelObj.get("travelTo").toString().substring(0, 19));
										travelinclusionArr.put(travelInclusionIndiObj);
									}else{
										travelInclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
										travelInclusionIndiObj.put("from", travelObj.get("travelFrom").toString().substring(0, 19));
										travelinclusionArr.put(travelInclusionIndiObj);
									}
								}else if(travelObj.has("travelTo")){
									travelInclusionIndiObj.put("operator", "LESSTHANEQUALTO");
									travelInclusionIndiObj.put("to", travelObj.get("travelTo").toString().substring(0, 19));
									travelinclusionArr.put(travelInclusionIndiObj);

								}
								if(travelObj.has("blockOutFrom")){
									if(travelObj.has("blockOutTo")){
										travelExclusionIndiObj.put("operator", "BETWEEN");
										travelExclusionIndiObj.put("from", travelObj.get("blockOutFrom").toString().substring(0, 19));
										travelExclusionIndiObj.put("to", travelObj.get("blockOutTo").toString().substring(0, 19));
										travelinclusionArr.put(travelExclusionIndiObj);
									}else{
										travelExclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
										travelExclusionIndiObj.put("from", travelObj.get("blockOutFrom").toString().substring(0, 19));
										travelinclusionArr.put(travelExclusionIndiObj);
									}
								}else if(travelObj.has("blockOuto")){
									travelExclusionIndiObj.put("operator", "LESSTHANEQUALTO");
									travelExclusionIndiObj.put("to", travelObj.get("blockOutTo").toString().substring(0, 19));
									travelinclusionArr.put(travelExclusionIndiObj);

								}

								if(travelinclusionArr.length()>0){
									inclusionObject.put("inclusion",travelinclusionArr);
									travelArr.put(inclusionObject);
								}
								if(travelexclusionArr.length()>0){
									exclusionObject.put("exclusion",travelexclusionArr);
									travelArr.put(exclusionObject);
								}

								SettlementCommercials.setSettlementRuleID(otherFee, salePlusTravelObj.getString("_id"));
								otherFee.put("sale", saleArr);
								otherFee.put("travel", travelArr);
								otherFeeArr.put(otherFee);
							}
						}
						for(int i=0;i<length;i++){
							otherFeeArr.remove(0);
						}
					}
					}
			}
			break;
		}
	}
	
	
	public static void getTransportationTravelDate(JSONArray travel, JSONArray otherFeeArr) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travel.length();j++){
				JSONObject inclusionIndiObjMDM =travel.getJSONObject(j);
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONArray inclusionArr = new JSONArray();
				JSONArray exclusionArr = new JSONArray();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray travelArr = new JSONArray();
				JSONObject inclusionIndiObj = new JSONObject();
				JSONObject exclusionIndiObj = new JSONObject();

				if(inclusionIndiObjMDM.has("travelFrom")){
					if(inclusionIndiObjMDM.has("travelTo")){
						inclusionIndiObj.put("operator", "BETWEEN");
						inclusionIndiObj.put("from", inclusionIndiObjMDM.get("travelFrom").toString().substring(0, 19));
						inclusionIndiObj.put("to", inclusionIndiObjMDM.get("travelTo").toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}else{
						inclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						inclusionIndiObj.put("value", inclusionIndiObjMDM.get("travelFrom").toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has("travelTo")){
					inclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					inclusionIndiObj.put("value", inclusionIndiObjMDM.get("travelTo").toString().substring(0, 19));
					inclusionArr.put(inclusionIndiObj);
				}

				if(inclusionIndiObjMDM.has("blockOutFrom")){
					if(inclusionIndiObjMDM.has("blockOutTo")){
						exclusionIndiObj.put("operator", "BETWEEN");
						exclusionIndiObj.put("from", inclusionIndiObjMDM.get("blockOutFrom").toString().substring(0, 19));
						exclusionIndiObj.put("to", inclusionIndiObjMDM.get("blockOutTo").toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}else{
						exclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						exclusionIndiObj.put("value", inclusionIndiObjMDM.get("blockOutFrom").toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has("blockOutTo")){
					exclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					exclusionIndiObj.put("value", inclusionIndiObjMDM.get("blockOutTo").toString().substring(0, 19));
					exclusionArr.put(exclusionIndiObj);
				}

				if(inclusionArr.length()>0){
					inclusionObject.put("inclusion",inclusionArr);
					travelArr.put(inclusionObject);
				}
				if(exclusionArr.length()>0){
					exclusionObject.put("exclusion",exclusionArr);
					travelArr.put(exclusionObject);
				}

				SettlementCommercials.setSettlementRuleID(otherFee,inclusionIndiObjMDM.getString("_id"));
				otherFee.put("travel", travelArr);
				otherFeeArr.put(otherFee);
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	public static void getTransportationSalesDate(JSONArray sale,JSONArray otherFeeArr){
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<sale.length();j++){
				JSONObject inclusionIndiObjMDM =sale.getJSONObject(j);
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONArray inclusionArr = new JSONArray();
				JSONArray exclusionArr = new JSONArray();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray saleArr = new JSONArray();
				JSONObject inclusionIndiObj = new JSONObject();
				JSONObject exclusionIndiObj = new JSONObject();
				if(inclusionIndiObjMDM.has("saleFrom")){
					if(inclusionIndiObjMDM.has("saleTo")){
						inclusionIndiObj.put("operator", "BETWEEN");
						inclusionIndiObj.put("from", inclusionIndiObjMDM.get("saleFrom").toString().substring(0, 19));
						inclusionIndiObj.put("to", inclusionIndiObjMDM.get("saleTo").toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}else{
						inclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						inclusionIndiObj.put("value", inclusionIndiObjMDM.get("saleFrom").toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has("saleTo")){
					inclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					inclusionIndiObj.put("value", inclusionIndiObjMDM.get("saleTo").toString().substring(0, 19));
					inclusionArr.put(inclusionIndiObj);
				}

				if(inclusionIndiObjMDM.has("blockOutFrom")){
					if(inclusionIndiObjMDM.has("blockOutTo")){
						exclusionIndiObj.put("operator", "BETWEEN");
						exclusionIndiObj.put("from", inclusionIndiObjMDM.get("blockOutFrom").toString().substring(0, 19));
						exclusionIndiObj.put("to", inclusionIndiObjMDM.get("blockOutTo").toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}else{
						exclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						exclusionIndiObj.put("value", inclusionIndiObjMDM.get("blockOutFrom").toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has("blockOutTo")){
					exclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					exclusionIndiObj.put("value", inclusionIndiObjMDM.get("blockOutTo").toString().substring(0, 19));
					exclusionArr.put(exclusionIndiObj);
				}

				if(inclusionArr.length()>0){
					inclusionObject.put("inclusion",inclusionArr);
					saleArr.put(inclusionObject);
				}
				if(exclusionArr.length()>0){
					exclusionObject.put("exclusion",exclusionArr);
					saleArr.put(exclusionObject);
				}

				SettlementCommercials.setSettlementRuleID(otherFee,inclusionIndiObjMDM.getString("_id"));
				otherFee.put("sale", saleArr);
				otherFeeArr.put(otherFee);
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	private static void setAccoAdvancedDefinition(JSONObject advanceDefinitionAccommodation, JSONObject otherFee) {
		if(advanceDefinitionAccommodation.has("nationality") && advanceDefinitionAccommodation.getJSONObject("nationality")!=null)
			if(advanceDefinitionAccommodation.getJSONObject("nationality").getBoolean("isInclusion"))
				otherFee.put("clientNationality", advanceDefinitionAccommodation.getJSONObject("nationality").get("clientNationality"));
			else otherFee.put("clientNationality_exclusion", advanceDefinitionAccommodation.getJSONObject("nationality").get("clientNationality"));
		if(advanceDefinitionAccommodation.has("passengerTypes"))
			if(advanceDefinitionAccommodation.getJSONArray("passengerTypes").length()>0)
				otherFee.put("passengerType", advanceDefinitionAccommodation.getJSONArray("passengerTypes"));
		if(advanceDefinitionAccommodation.has("credentials"))
			if(advanceDefinitionAccommodation.getJSONArray("credentials").length()>0)
				otherFee.put("credentialsName", advanceDefinitionAccommodation.getJSONArray("credentials"));
		if(advanceDefinitionAccommodation.has("connectivity") && advanceDefinitionAccommodation.getJSONObject("connectivity")!=null){
			otherFee.put("connectivitySupplierType",advanceDefinitionAccommodation.getJSONObject("connectivity").getString("supplierType"));
			otherFee.put("connectivitySupplierName",advanceDefinitionAccommodation.getJSONObject("connectivity").getString("supplierId"));
		}
		if(advanceDefinitionAccommodation.has("others") && advanceDefinitionAccommodation.getJSONObject("others")!=null){
			if(advanceDefinitionAccommodation.getJSONObject("others").has("bookingType"))
				otherFee.put("bookingType",advanceDefinitionAccommodation.getJSONObject("others").getString("bookingType"));
			if(advanceDefinitionAccommodation.getJSONObject("others").has("roomTypes") && advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomTypes")!=null ){
				if(advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomTypes").getBoolean("isInclusion"))
					otherFee.put("roomType", advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomTypes").get("roomTypes"));
				else otherFee.put("roomType_exclusion", advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomTypes").get("roomTypes"));
			}
			if(advanceDefinitionAccommodation.getJSONObject("others").has("roomCategories") && advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomCategories")!=null ){
				if(advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomCategories").getBoolean("isInclusion"))
					otherFee.put("roomCategory", advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomCategories").get("roomCategories"));
				else otherFee.put("roomCategory_exclusion", advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomCategories").get("roomCategories"));
			}
		}
	}
	
	
	private static void appendApplicableOnDetails(JSONArray advancedArr, JSONArray calculationArr, String commercialName, JSONArray clientCommercialOtherHead) {
		switch(commercialName){
		case "PLB":{
			if(plbapplicableOnArray!=null && plbapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<plbapplicableOnArray.length();i++){
					String applicableOnID = plbapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								JSONObject plb = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("plb");
								if(CommonFunctions.plbOH.equals("slab")){
									JSONObject slab = plb.getJSONObject("slab");
									if(slab.has("slabType"))
										calculation.put("slabType", slab.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+slab.get("fromValue")+";"+slab.get("toValue"));
								}else if(plb.has("retention")){
									JSONObject retention = plb.getJSONObject("retention");
									if(retention.has("slabType"))
										calculation.put("slabType", retention.getString("slabType"));
									String slabTypeValue="BETWEEN;";
									JSONArray currencyDetails = retention.getJSONObject("details").getJSONArray("currencyDetails");
									for(int k=0;k<currencyDetails.length();k++){
										JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
										slabTypeValue+=currencyDetailsObject.get("fromValue")+";"+currencyDetailsObject.get("toValue");
									}
									calculation.put("slabTypeValue", slabTypeValue);
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "SegmentFee":{
			if(segmentapplicableOnArray!=null && segmentapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<segmentapplicableOnArray.length();i++){
					String applicableOnID = segmentapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								if(clientCommercialOtherHeadObject.has("commercialHeads") && clientCommercialOtherHeadObject.getJSONObject("commercialHeads").has("segmentFees")){
									JSONObject segmentFees = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("segmentFees");
									calculation.put("slabType", segmentFees.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+segmentFees.getString("fromValue")+";"+segmentFees.getString("toValue"));
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "ServiceCharge":{
			if(serviceapplicableOnArray!=null && serviceapplicableOnArray.length()>0){
				for(int i=0;i<serviceapplicableOnArray.length();i++){
					String applicableOnID = serviceapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int k=0;k<advancedArr.length();k++){
								JSONObject advanced = advancedArr.getJSONObject(k);
								if(clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn").length()>0)
									advanced.put("applicableOn", clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn"));
							}
						}
					}
				}
			}break;
		}
		}
	}
	

}
