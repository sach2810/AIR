package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.cce.configuration.CommonFunctions;

public class Air {
	public static String commissionContractValidityFrom,commissionContractValidityTo,sectorContractValidityFrom,sectorContractValidityTo,issuanceContractValidityFrom,issuanceContractValidityTo,stdLocalID,overridingLocalID,plbLocalID,sectorWiseLocalID,commissionAdvanceDefinitionId,markupAdvanceDefinitionId,commissionLocalID,issuanceAdvanceDefinitionId;
	public static String serviceContractValidityTo,serviceContractValidityFrom,segmentContractValidityTo,segmentContractValidityFrom,stdContractValidityFrom,stdContractValidityTo,overContractValidityFrom,overContractValidityTo,plbContractValidityFrom,plbContractValidityTo,destinationContractValidityFrom,destinationContractValidityTo;
	public static String managementContractValidityFrom,managementContractValidityTo,discountContractValidityFrom,discountContractValidityTo,markupContractValidityFrom,markupContractValidityTo,segmentLocalID,serviceLocalID,mngtLocalID,discountLocalID,markupLocalID,destinationLocalID,issuanceLocalID,discountAdvanceDefinitionId,destinationAdvanceDefinitionId;
	public static String stdAdvanceDefinitionId,overridingAdvanceDefinitionId,plbAdvanceDefinitionId,sectorWiseAdvanceDefinitionId,segmentAdvanceDefinitionId,serviceAdvanceDefinitionId,mngtAdvanceDefinitionId;
	public static JSONArray plbapplicableOnArray,segmentapplicableOnArray,serviceapplicableOnArray;

	public static void appendAirCommercialDetails(String advancedDT, String calculationDT, String commercialName, JSONObject mdmCommDefn,JSONObject mainJson, boolean advancedApplicable, String id) {
		JSONObject advanced = new JSONObject();
		JSONObject calculation = new JSONObject();
		advanced.put("type", "advanced");
		calculation.put("type", "calculation");
		advanced.put("selectedRow", id);
		advanced.put("contractValidity", getContractValidity(commercialName));
		setMDMRuleID(commercialName,calculation);
		setRuleID(commercialName,advanced,calculation,id);
		CommonFunctions.setCalculationParameters(commercialName,calculation,mainJson);
		JSONArray advancedArr = new JSONArray();
		JSONArray calculationArr = new JSONArray();
		advancedArr.put(advanced);
		calculationArr.put(calculation);
		mainJson.put(advancedDT, advancedArr);
		mainJson.put(calculationDT, calculationArr);
		
		appendApplicableOnDetails(advancedArr,calculationArr,commercialName,mdmCommDefn.getJSONArray("clientCommercialOtherHead"));

		if(advancedApplicable && getAdvancedDefintionID(commercialName)!=null){
			JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray("advancedDefinitionData");
			for(int i=0;i<advancedDefinitionData.length();i++){
				if(getAdvancedDefintionID(commercialName).equals(advancedDefinitionData.getJSONObject(i).getString("_id"))){
					JSONObject advancedDefinitionObject = advancedDefinitionData.getJSONObject(i);
					JSONObject flights = advancedDefinitionObject.getJSONObject("advanceDefinitionAir");
					if(!commercialName.equals("PLB"))
						setAdvancedDefinition(advancedArr,calculationArr,flights,getAdvancedDefintionID(commercialName));
					else setPLBAdvancedDefinition(advancedArr,calculationArr,flights,getAdvancedDefintionID(commercialName));
				}
			}
		}
		
		for(int i=0;i<calculationArr.length();i++){
			JSONObject calculation1 = calculationArr.getJSONObject(i);
			setMDMRuleID(commercialName,calculation1);
			String ruleId = calculation1.getString("mdmRuleID")+"|"+calculation1.getString("selectedRow");
			calculation1.put("mdmRuleID", ruleId);
		}
	}
	
	public static void setMDMRuleID(String commercialName, JSONObject calculation) {
		switch(commercialName){
		case "Standard":{calculation.put("mdmRuleID", CommonFunctions.stdclientCommercialDataID);break;}
		case "Overriding":{calculation.put("mdmRuleID", CommonFunctions.overclientCommercialDataID);break;}
		case "PLB":{calculation.put("mdmRuleID", CommonFunctions.plbclientCommercialDataID);break;}
		case "SectorWiseIncentive":{calculation.put("mdmRuleID", CommonFunctions.sectorclientCommercialDataID);break;}
		case "ManagementFee":{calculation.put("mdmRuleID", CommonFunctions.mngtclientCommercialDataID);break;}
		case "SegmentFee":{calculation.put("mdmRuleID", CommonFunctions.segmentclientCommercialDataID);break;}
		case "ServiceCharge":{calculation.put("mdmRuleID", CommonFunctions.serviceclientCommercialDataID);break;}
		case "Discount":{calculation.put("mdmRuleID", CommonFunctions.discountclientCommercialDataID);break;}
		case "MarkUp":{calculation.put("mdmRuleID", CommonFunctions.markupclientCommercialDataID);break;}
		case "Commission":{calculation.put("mdmRuleID", CommonFunctions.commissionclientCommercialDataID);break;}
		case "DestinationIncentive":{calculation.put("mdmRuleID", CommonFunctions.destinationclientCommercialDataID);break;}
		case "IssuanceFee":{calculation.put("mdmRuleID", CommonFunctions.issuanceclientCommercialDataID);break;}
		default:System.out.println("default of setMDMRuleID due to CommercialName :"+commercialName);
		}
	}
	
	
	private static void setPLBAdvancedDefinition(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String advDefnID) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			if(advanceDefinitionAir.has("validity")){
				JSONObject validity = advanceDefinitionAir.getJSONObject("validity");
				switch(validity.getString("validityType")){
				case "ticketing":{
					CommonFunctions.getPLBDates(baseArr,calcArr,validity.getJSONArray("ticketing"),"ticketing");
					break;
				}
				case "travel":{
					CommonFunctions.getPLBDates(baseArr,calcArr,validity.getJSONArray("travel"),"travel");
					break;
				}
				default:{
					JSONArray ticketingPlusTravel = validity.getJSONArray("ticketingPlusTravel");
					CommonFunctions.insertPLBTicketingPlusTravel(ticketingPlusTravel,baseArr,calcArr);
					break;
				}
				}
			}

			if(advanceDefinitionAir.has("connectivity") && advanceDefinitionAir.getJSONObject("connectivity")!=null)
				CommonFunctions.getAirConnectivity(baseArr,advanceDefinitionAir.getJSONObject("connectivity"));

			if(advanceDefinitionAir.has("credentials") && advanceDefinitionAir.getJSONArray("credentials").length()>0)
				CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAir.getJSONArray("credentials"),"credentials",true);

			if(advanceDefinitionAir.has("others") && advanceDefinitionAir.getJSONObject("others")!=null){
				JSONObject others = advanceDefinitionAir.getJSONObject("others");
				if(others.has("bookingType"))
					CommonFunctions.getBookingType(baseArr,others,true);
			}

			if(advanceDefinitionAir.has("bookingClass") && advanceDefinitionAir.getJSONObject("bookingClass")!=null){
				JSONObject bookingClass = advanceDefinitionAir.getJSONObject("bookingClass");
				setBookingTypeTP(baseArr, calcArr, bookingClass);
			}

			if(advanceDefinitionAir.has("flightTimings"))
				getFlightTimingsNumbersTP(baseArr,calcArr,advanceDefinitionAir.getJSONObject("flightTimings"),"flightTimings","flightTimeFrom","flightTimeTo");

			if(advanceDefinitionAir.has("flightNumbers"))
				getFlightTimingsNumbersTP(baseArr,calcArr,advanceDefinitionAir.getJSONObject("flightNumbers"),"flightRange","flightRangeFrom","flightRangeTo");

			if(advanceDefinitionAir.has("passengerTypes") && advanceDefinitionAir.getJSONArray("passengerTypes").length()>0)
				CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAir.getJSONArray("passengerTypes"),"passengerTypes",false);

			if(advanceDefinitionAir.has("fareClass")){
				if(advanceDefinitionAir.getJSONObject("fareClass").has("fareBasis")){
					JSONObject fareBasis = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("fareBasis");
					JSONArray fare = fareBasis.getJSONArray("fare");
					if(fareBasis.getBoolean("isInclusion"))
						getFareBasisTP(baseArr,calcArr,fare,true);
					else getFareBasisTP(baseArr,calcArr,fare,false);
				}

				if(advanceDefinitionAir.getJSONObject("fareClass").has("dealCodes")){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes");
					if(dealCodes.getBoolean("isInclusion"))
						CommonFunctions.getTriggerPayoutArrayIncExc(baseArr, calcArr, dealCodes.getJSONArray("dealCodes"), "dealCode", true, false);
					else CommonFunctions.getTriggerPayoutArrayIncExc(baseArr, calcArr, dealCodes.getJSONArray("dealCodes"), "dealCode", false, false);
				}
			}

			if(advanceDefinitionAir.has("travelDestination")){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject("travelDestination");
				if(travelDestination.getBoolean("isInclusion")){
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray("triggerOrPayout"),travelDestination.getJSONArray("soldAndTicketingOptions"),"travelType",true);

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray("triggerOrPayout"),travelDestination.getJSONArray("journeyType"),"journeyType",true);

					getCodeSharedFlightIncludedTP(calcArr,travelDestination.getBoolean("codeshareFlightIncluded"),travelDestination.getJSONArray("triggerOrPayout"),true);
					getFlightTypeTP(calcArr,travelDestination.getBoolean("isDirectFlights"),travelDestination.getJSONArray("triggerOrPayout"),true);
					getFlightLineTypeTP(calcArr,travelDestination.getBoolean("isOnline"),travelDestination.getJSONArray("triggerOrPayout"),true);
					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray("productId").length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray("productId").getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						getTravelProductNameTP(calcArr,travelProductNameArr,travelDestination.getJSONArray("triggerOrPayout"),true);
				}else{
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray("triggerOrPayout"),travelDestination.getJSONArray("soldAndTicketingOptions"),"travelType",false);

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray("triggerOrPayout"),travelDestination.getJSONArray("journeyType"),"journeyType",false);

					getCodeSharedFlightIncludedTP(calcArr,travelDestination.getBoolean("codeshareFlightIncluded"),travelDestination.getJSONArray("triggerOrPayout"),false);
					getFlightTypeTP(calcArr,travelDestination.getBoolean("isDirectFlights"),travelDestination.getJSONArray("triggerOrPayout"),false);
					getFlightLineTypeTP(calcArr,travelDestination.getBoolean("isOnline"),travelDestination.getJSONArray("triggerOrPayout"),false);
					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray("productId").length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray("productId").getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						getTravelProductNameTP(calcArr,travelProductNameArr,travelDestination.getJSONArray("triggerOrPayout"),true);
				}
			}
		}
		int lengthCalc = calcArr.length();
		JSONObject travelDestination = advanceDefinitionAir.getJSONObject("travelDestination");
		JSONArray destinations = travelDestination.getJSONArray("destinations");
		for(int d=0;d<lengthCalc;d++){
			JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(d).toString()));
			JSONArray dest = new JSONArray();
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(travelDestination.getJSONArray("triggerOrPayout"));
			dest.put(triggerPayout);
			dest.put(setAirDestination("inclusion",advanceDefinitionAir.getJSONObject("travelDestination").getJSONArray("journeyType"),new JSONObject(),destinations));
			calculation.put("destination", dest);
			calcArr.put(calculation);
		}
		for(int d=0;d<lengthCalc;d++){
			calcArr.remove(0);
		}
	}
	
	
	private static void getTravelProductNameTP(JSONArray calcArr, JSONArray travelProductNameArr, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isInclusion)
				flightObject.put("travelproductName", travelProductNameArr);
			else flightObject.put("travelproductName_exclusion", travelProductNameArr);
			flightArr.put(flightObject);
			calculation.put("travelproductName", flightArr);
		}
	}
	
	
	private static void getFlightLineTypeTP(JSONArray calcArr, boolean isOnline, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isOnline){
				if(isInclusion)
					flightObject.put("flightLineType", "Online");
				else flightObject.put("flightLineType_exclusion", "Online");
			}else{
				if(isInclusion)
					flightObject.put("flightLineType", "Offline");
				else flightObject.put("flightLineType_exclusion", "Offline");
			}
			flightArr.put(flightObject);
			calculation.put("flightLineType", flightArr);
		}
	}


	private static void getFlightTypeTP(JSONArray calcArr, boolean isDirectFlight, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isDirectFlight){
				if(isInclusion)
					flightObject.put("flightType", "Direct");
				else flightObject.put("flightType_exclusion", "Direct");
			}else{
				if(isInclusion)
					flightObject.put("flightType", "Via");
				else flightObject.put("flightType_exclusion", "Via");
			}
			flightArr.put(flightObject);
			calculation.put("flightType", flightArr);
		}
	}


	private static void getCodeSharedFlightIncludedTP(JSONArray calcArr, boolean codeSharedFlightIncluded, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject code = new JSONObject();
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray codeArr = new JSONArray();
			codeArr.put(triggerPayout);
			if(isInclusion)
				code.put("codeSharedFlightIncluded", codeSharedFlightIncluded);
			else code.put("codeSharedFlightIncluded_exclusion", codeSharedFlightIncluded);
			codeArr.put(code);
			calculation.put("codeSharedFlightIncluded", codeArr);
		}
	}
	
	
	private static void getFareBasisTP(JSONArray baseArr, JSONArray calcArr, JSONArray fare, boolean isInclusion) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<fare.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject fareObject = fare.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(fareObject.getJSONArray("triggerOrPayout"));
				JSONArray fareArr = new JSONArray();
				JSONArray fareBasisArr = new JSONArray();
				fareArr.put(triggerPayout);
				fareBasisArr.put(fareObject.getString("condition"));
				fareBasisArr.put(fareObject.getString("value"));
				JSONObject FareObject = new JSONObject();
				if(isInclusion)
					FareObject.put("fareBasisValue", fareBasisArr);
				else FareObject.put("fareBasisValue_exclusion", fareBasisArr);
				fareArr.put(FareObject);
				calculation.put("fareBasisValue",fareArr);

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, fareObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	private static void getFlightTimingsNumbersTP(JSONArray baseArr, JSONArray calcArr, JSONObject flightTiming, String arrayName, String from, String to) {
		int length=baseArr.length();
		JSONArray flighTimeArr = flightTiming.getJSONArray(arrayName);
		for(int i=0;i<length;i++){
			for(int j=0;j<flighTimeArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject timeObject = flighTimeArr.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(timeObject.getJSONArray("triggerOrPayout"));
				JSONArray timeArr = new JSONArray();
				timeArr.put(triggerPayout);
				JSONObject timeObjectMain = new JSONObject();
				if(timeObject.has(from)){
					if(timeObject.has(to)){
						String time = "BETWEEN;"+timeObject.get(from)+";"+timeObject.get(to);
						if(flightTiming.getBoolean("isInclusion"))
							timeObjectMain.put(arrayName, time);
						else timeObjectMain.put(arrayName+"_exclusion", time);
					}else{
						String time = "GREATERTHANEQUALTO;"+timeObject.get(from);
						if(flightTiming.getBoolean("isInclusion"))
							timeObjectMain.put(arrayName, time);
						else timeObjectMain.put(arrayName+"_exclusion", time);
					}
				}else if(timeObject.has(to)){
					String time = "LESSTHANEQUALTO;"+timeObject.get(to);
					if(flightTiming.getBoolean("isInclusion"))
						timeObjectMain.put(arrayName, time);
					else timeObjectMain.put(arrayName+"_exclusion", time);
				}
				timeArr.put(timeObjectMain);
				calculation.put(arrayName, timeArr);
				CommonFunctions.setRuleID(baseArr,calcArr,base,calculation,timeObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	private static void setBookingTypeTP(JSONArray baseArr, JSONArray calcArr, JSONObject bookingClass) {
		int length = baseArr.length();
		JSONArray cabin = bookingClass.getJSONArray("cabin");
		for(int i=0;i<length;i++){
			for(int j=0;j<cabin.length();j++){
				JSONObject cabinObject = cabin.getJSONObject(j);
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(cabinObject.getJSONArray("triggerOrPayout"));
				JSONArray cabinArr = new JSONArray();
				JSONObject cabinJson= new JSONObject();
				cabinArr.put(triggerPayout);
				if(cabinObject.has("cabinClass") && !cabinObject.getString("cabinClass").equalsIgnoreCase("All")){
					if(bookingClass.getBoolean("isInclusion"))
						cabinJson.put("cabinClass", cabinObject.getString("cabinClass"));
					else cabinJson.put("cabinClass_exclusion", cabinObject.getString("cabinClass"));
				}
				if(cabinObject.has("rbd") && !cabinObject.getString("rbd").equalsIgnoreCase("All")){
					if(bookingClass.getBoolean("isInclusion"))
						cabinJson.put("RBD", cabinObject.getString("rbd"));
					else cabinJson.put("RBD_exclusion", cabinObject.getString("rbd"));
				}
				cabinArr.put(cabinJson);
				calculation.put("bookingClass", cabinArr);
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, cabinObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setAdvancedDefinition(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String advDefnID) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
			JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));

			if(advanceDefinitionAir.has("connectivity") && advanceDefinitionAir.getJSONObject("connectivity")!=null){
				JSONObject connectivity = advanceDefinitionAir.getJSONObject("connectivity");
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					base.put("connectivitySupplierType", connectivity.getString("supplierType"));
				if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All"))
					base.put("connectivitySupplier", connectivity.getString("supplierName"));
			}

			if(advanceDefinitionAir.has("credentials") && advanceDefinitionAir.getJSONArray("credentials").length()>0){
				JSONArray credentials = advanceDefinitionAir.getJSONArray("credentials");
				JSONArray crentialsArr = new JSONArray();
				for(int cr=0;cr<credentials.length();cr++){
					crentialsArr.put(credentials.getJSONObject(cr).getString("credentials"));
				}
				base.put("credentialsName", crentialsArr);
			}

			if(advanceDefinitionAir.has("others")){
				if(advanceDefinitionAir.getJSONObject("others")!=null)
					base.put("bookingType", advanceDefinitionAir.getJSONObject("others").getString("bookingType"));
			}

			getBookingClass(advanceDefinitionAir, calculation);

			if(advanceDefinitionAir.has("passengerTypes") && advanceDefinitionAir.getJSONArray("passengerTypes").length()>0){
				JSONArray passengerTypes  = advanceDefinitionAir.getJSONArray("passengerTypes");
				JSONArray paxType = new JSONArray();
				for(int pt=0;pt<passengerTypes.length();pt++){
					paxType.put(passengerTypes.getJSONObject(pt).getString("passengerTypes"));
				}
				calculation.put("passengerType", paxType);
			}

			if(advanceDefinitionAir.has("travelDestination")){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject("travelDestination");
				if(travelDestination.getBoolean("isInclusion")){
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						base.put("travelType", travelDestination.get("soldAndTicketingOptions"));

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						base.put("journeyType", travelDestination.get("journeyType"));

					calculation.put("codeShareFlightIncluded", travelDestination.getBoolean("codeshareFlightIncluded"));

					if(travelDestination.getBoolean("isDirectFlights"))
						calculation.put("flightType", "Direct");
					else calculation.put("flightType", "Via");

					if(travelDestination.getBoolean("isOnline"))
						calculation.put("flightLineType", "Online");
					else calculation.put("flightLineType", "Offline");

					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray("productId").length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray("productId").getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						calculation.put("travelProductName", travelProductNameArr);

					setAirDestination("inclusion",advanceDefinitionAir.getJSONObject("travelDestination").getJSONArray("journeyType"),calculation,destinations);
				}else{
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						base.put("travelType_exclusion", travelDestination.get("soldAndTicketingOptions"));

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						base.put("journeyType_exclusion", travelDestination.get("journeyType"));

					calculation.put("codeShareFlightIncluded_exclusion", travelDestination.getBoolean("codeshareFlightIncluded"));

					if(travelDestination.getBoolean("isDirectFlights"))
						calculation.put("flightType_exclusion", "Direct");
					else calculation.put("flightType_exclusion", "Via");

					if(travelDestination.getBoolean("isOnline"))
						calculation.put("flightLineType_exclusion", "Online");
					else calculation.put("flightLineType_exclusion", "Offline");

					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0)
								travelProductNameArr.put(destObj.get("productId"));
						}
					}
					if(travelProductNameArr.length()>0)
						calculation.put("travelProductName_exclusion", travelProductNameArr);

					setAirDestination("exclusion",advanceDefinitionAir.getJSONObject("travelDestination").getJSONArray("journeyType"),calculation,destinations);
				}
			}
			if(advanceDefinitionAir.has("fareClass")){
				if(advanceDefinitionAir.getJSONObject("fareClass").has("dealCodes") && advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes")!=null){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes");
					JSONArray dealCodesArr = dealCodes.getJSONArray("dealCodes");
					JSONArray dealcode= new JSONArray();
					for(int dc=0;dc<dealCodesArr.length();dc++){
						dealcode.put(dealCodesArr.getJSONObject(dc).getString("dealCode"));
					}
					if(dealCodes.getBoolean("isInclusion"))
						calculation.put("dealCode", dealcode);
					else calculation.put("dealCode_exclusion", dealcode);
				}
			}
			baseArr.put(base);
			calcArr.put(calculation);
		}
		for(int w=0;w<length;w++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
		setFareBasisValue(advanceDefinitionAir,calcArr,baseArr);
		CommonFunctions.setTravelTicketing(baseArr,calcArr,advanceDefinitionAir.getJSONObject("validity"));
		getFlightTimings(baseArr,calcArr,advanceDefinitionAir);
		getFlightNumbers(baseArr,calcArr,advanceDefinitionAir);
	}
	
	
	private static void setFareBasisValue(JSONObject advanceDefinitionAir, JSONArray calcArr, JSONArray baseArr) {
		if(advanceDefinitionAir.has("fareClass")){
			if(advanceDefinitionAir.getJSONObject("fareClass").has("fareBasis")){
				int length =calcArr.length();
				for(int i=0;i<length;i++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONArray fare = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("fareBasis").getJSONArray("fare");
					for(int f=0;f<fare.length();f++){
						JSONObject fareObject = fare.getJSONObject(f);
						JSONArray fareArr = new JSONArray();
						if(fareObject.has("condition"))
							fareArr.put(fareObject.getString("condition"));
						if(fareObject.has("value"))
							fareArr.put(fareObject.getString("value"));
						calculation.put("fareBasisValue", fareArr);

						CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, fareObject.getString("_id"));
					}
				}
				for(int i=0;i<length;i++){
					baseArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
	}

	private static void getFlightNumbers(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("flightNumbers")){
			JSONArray flightRange = advanceDefinitionAir.getJSONObject("flightNumbers").getJSONArray("flightRange");
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<flightRange.length();j++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject flightObject  = flightRange.getJSONObject(j);
					String numbers=null;
					if(flightObject.has("flightRangeFrom")){
						if(flightObject.has("flightRangeTo"))
							numbers="BETWEEN"+";"+flightObject.get("flightRangeFrom")+";"+flightObject.get("flightRangeTo");
						else numbers="GREATERTHANEQUALTO"+";"+flightObject.get("flightRangeFrom");
					}else if(flightObject.has("flightRangeTo"))
						numbers="LESSTHANEQUALTO"+";"+flightObject.get("flightRangeTo");

					if(advanceDefinitionAir.getJSONObject("flightNumbers").getBoolean("isInclusion"))
						calculation.put("flightNumber", numbers);
					else calculation.put("flightNumber_exclusion", numbers);

					CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, flightObject.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}
	
	
	private static void getFlightTimings(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("flightTimings")){
			JSONArray flightTimings = advanceDefinitionAir.getJSONObject("flightTimings").getJSONArray("flightTimings");
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				for(int m=0;m<flightTimings.length();m++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject flightTimingObj = flightTimings.getJSONObject(m);
					String timing = null;
					if(flightTimingObj.has("flightTimeFrom")){
						if(flightTimingObj.has("flightTimeTo")){
							timing="BETWEEN";
							timing+=";"+flightTimingObj.getString("flightTimeFrom")+";"+flightTimingObj.getString("flightTimeTo");
						}else{
							timing="GREATERTHANEQUALTO";
							timing+=";"+flightTimingObj.getString("flightTimeFrom");
						}
					}else if(flightTimingObj.has("flightTimeTo")){
						timing="LESSTHANEQUALTO";
						timing+=";"+flightTimingObj.getString("flightTimeTo");
					}
					if(advanceDefinitionAir.getJSONObject("flightTimings").getBoolean("isInclusion"))
						calculation.put("flightTiming", timing);
					else calculation.put("flightTiming_exclusion", timing);	
					
					CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, flightTimingObj.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}
	
	
	private static JSONObject setAirDestination(String incExc, JSONArray journeyType, JSONObject calculation, JSONArray destinations) {
		String continentMain=null,countryMain=null,cityMain=null,journeyTypeString=null;
		for(int i=0;i<journeyType.length();i++){
			if(i==0)
				journeyTypeString=journeyType.getString(i);
			else journeyTypeString+="&"+journeyType.getString(i);
		}
		for(int i=0;i<destinations.length();i++){
			JSONObject continent = destinations.getJSONObject(i).getJSONObject("continent");
			JSONObject country = destinations.getJSONObject(i).getJSONObject("country");
			JSONObject city = destinations.getJSONObject(i).getJSONObject("city");
			if(i==0){
				if(continent.has("via"))
					continentMain = continent.getString("from")+";"+continent.getString("via")+";"+continent.getString("to");
				else continentMain = continent.getString("from")+";"+null+";"+continent.getString("to");
				if(country.has("via"))
					countryMain = country.getString("from")+";"+country.getString("via")+";"+country.getString("to");
				else countryMain = country.getString("from")+";"+null+";"+country.getString("to");
				if(city.has("via"))
					cityMain = city.getString("from")+";"+city.getString("via")+";"+city.getString("to");
				else cityMain = city.getString("from")+";"+null+";"+city.getString("to");
			}
			else{
				if(continent.has("via"))
					continentMain+="/"+continent.getString("from")+";"+continent.getString("via")+";"+continent.getString("to");
				else continentMain+="/"+continent.getString("from")+";"+null+";"+continent.getString("to");
				if(country.has("via"))
					countryMain+="/"+country.getString("from")+";"+country.getString("via")+";"+country.getString("to");
				else countryMain+="/"+country.getString("from")+";"+null+";"+country.getString("to");
				if(city.has("via"))
					cityMain+="/"+city.getString("from")+";"+city.getString("via")+";"+city.getString("to");
				else cityMain+="/"+city.getString("from")+";"+null+";"+city.getString("to");
			}
		}
		if(incExc=="inclusion"){
			calculation.put("continent", journeyTypeString+";"+continentMain);
			calculation.put("country", journeyTypeString+";"+countryMain);
			calculation.put("city", journeyTypeString+";"+cityMain);
		}else{
			calculation.put("continent_exclusion", journeyTypeString+";"+continentMain);
			calculation.put("country_exclusion", journeyTypeString+";"+countryMain);
			calculation.put("city_exclusion", journeyTypeString+";"+cityMain);
		}
		return calculation;
	}
	
	
	public static void getBookingClass(JSONObject advanceDefinitionAir, JSONObject calculation) {
		if(advanceDefinitionAir.has("bookingClass")){
			JSONArray cabin = advanceDefinitionAir.getJSONObject("bookingClass").getJSONArray("cabin");
			JSONArray cabinArr =new JSONArray();
			JSONArray rbdArr =new JSONArray();
			for(int k=0;k<cabin.length();k++){
				JSONObject cabinObj = cabin.getJSONObject(k);
				if(cabinObj.has("cabinClass"))
					cabinArr.put(cabinObj.getString("cabinClass"));
				
				if(cabinObj.has("rbd"))
					rbdArr.put(cabinObj.getString("rbd"));
			}
			if(advanceDefinitionAir.getJSONObject("bookingClass").getBoolean("isInclusion")){
				if(cabinArr.length()>0)
					calculation.put("cabinClass", cabinArr);
				if(rbdArr.length()>0)
					calculation.put("RBD", rbdArr);
			}else{
				if(cabinArr.length()>0)
					calculation.put("cabinClass_exclusion", cabinArr);
				if(rbdArr.length()>0)
					calculation.put("RBD_exclusion", rbdArr);
			}
		}
	}


	private static String getAdvancedDefintionID(String commercialName) {
		switch(commercialName){
		case "Standard":return stdAdvanceDefinitionId;
		case "Overriding":return overridingAdvanceDefinitionId;
		case "PLB":return plbAdvanceDefinitionId;
		case "SectorWiseIncentive":return sectorWiseAdvanceDefinitionId;
		case "ManagementFee":return mngtAdvanceDefinitionId;
		case "SegmentFee":return segmentAdvanceDefinitionId;
		case "ServiceCharge":return serviceAdvanceDefinitionId;
		case "Discount":return discountAdvanceDefinitionId;
		case "MarkUp":return markupAdvanceDefinitionId;
		case "Commission":return commissionAdvanceDefinitionId;
		case "DestinationIncentive":return destinationAdvanceDefinitionId;
		case "IssuanceFee":return issuanceAdvanceDefinitionId;
		}
		return null;
	}


	private static JSONObject getContractValidity(String commercialName) {
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		switch(commercialName){
		case "Standard":{
			contractValidity.put("from", stdContractValidityFrom);
			contractValidity.put("to", stdContractValidityTo);
			break;
		}
		case "Overriding":{
			contractValidity.put("from", overContractValidityFrom);
			contractValidity.put("to", overContractValidityTo);
			break;
		}
		case "PLB":{
			contractValidity.put("from", plbContractValidityFrom);
			contractValidity.put("to", plbContractValidityTo);
			break;
		}
		case "SectorWiseIncentive":{
			contractValidity.put("from", sectorContractValidityFrom);
			contractValidity.put("to", sectorContractValidityTo);
			break;
		}
		case "ManagementFee":{
			contractValidity.put("from", managementContractValidityFrom);
			contractValidity.put("to", managementContractValidityTo);
			break;
		}
		case "SegmentFee":{
			contractValidity.put("from", segmentContractValidityFrom);
			contractValidity.put("to", segmentContractValidityTo);
			break;
		}
		case "ServiceCharge":{
			contractValidity.put("from", serviceContractValidityFrom);
			contractValidity.put("to", serviceContractValidityTo);
			break;
		}
		case "Discount":{
			contractValidity.put("from", discountContractValidityFrom);
			contractValidity.put("to", discountContractValidityTo);
			break;
		}
		case "MarkUp":{
			contractValidity.put("from", markupContractValidityFrom);
			contractValidity.put("to", markupContractValidityTo);
			break;
		}
		case "Commission":{
			contractValidity.put("from", commissionContractValidityFrom);
			contractValidity.put("to", commissionContractValidityTo);
			break;
		}
		case "DestinationIncentive":{
			contractValidity.put("from", destinationContractValidityFrom);
			contractValidity.put("to", destinationContractValidityTo);
			break;
		}
		case "IssuanceFee":{
			contractValidity.put("from", issuanceContractValidityFrom);
			contractValidity.put("to", issuanceContractValidityTo);
			break;
		}
		default:System.out.println("default of getContractValidity : Air.java");
		}
		return contractValidity;
	}
	
	
	public static void getOtherFeesAdvancedDefinition(JSONArray otherFeeArr, JSONObject advanceDefinitionAir, String commDefnID){
		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
			if(advanceDefinitionAir.has("connectivity") && advanceDefinitionAir.getJSONObject("connectivity")!=null){
				JSONObject connectivity = advanceDefinitionAir.getJSONObject("connectivity");
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierType", connectivity.getString("supplierType"));
				if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplier", connectivity.getString("supplierName"));
			}
			if(advanceDefinitionAir.has("credentials") && advanceDefinitionAir.getJSONArray("credentials").length()>0){
				JSONArray credentials = advanceDefinitionAir.getJSONArray("credentials");
				JSONArray crentialsArr = new JSONArray();
				for(int cr=0;cr<credentials.length();cr++){
					crentialsArr.put(credentials.getJSONObject(cr).getString("credentials"));
				}
				otherFee.put("credentialsName", crentialsArr);
			}
			if(advanceDefinitionAir.has("others")){
				if(advanceDefinitionAir.getJSONObject("others")!=null)
					otherFee.put("bookingType", advanceDefinitionAir.getJSONObject("others").getString("bookingType"));
			}
			getBookingClass(advanceDefinitionAir, otherFee);

			/*	if(advanceDefinitionAir.has("passengerTypes") && advanceDefinitionAir.getJSONArray("passengerTypes").length()>0){
				JSONArray passengerTypes  = advanceDefinitionAir.getJSONArray("passengerTypes");
				JSONArray paxType = new JSONArray();
				for(int pt=0;pt<passengerTypes.length();pt++){
					paxType.put(passengerTypes.getJSONObject(pt).getString("passengerTypes"));
				}
				otherFee.put("passengerType", paxType);
			}*/
			if(advanceDefinitionAir.has("travelDestination")){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject("travelDestination");
				if(travelDestination.getBoolean("isInclusion")){
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						otherFee.put("travelType", travelDestination.get("soldAndTicketingOptions"));

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						otherFee.put("journeyType", travelDestination.get("journeyType"));

					otherFee.put("codeShareFlightIncluded", travelDestination.getBoolean("codeshareFlightIncluded"));

					if(travelDestination.getBoolean("isDirectFlights"))
						otherFee.put("flightType", "Direct");
					else otherFee.put("flightType", "Via");

					if(travelDestination.getBoolean("isOnline"))
						otherFee.put("flightLineType", "Online");
					else otherFee.put("flightLineType", "Offline");

					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray("productId").length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray("productId").getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						otherFee.put("travelProductName", travelProductNameArr);
				}else{
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						otherFee.put("travelType_exclusion", travelDestination.get("soldAndTicketingOptions"));

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						otherFee.put("journeyType_exclusion", travelDestination.get("journeyType"));

					otherFee.put("codeShareFlightIncluded_exclusion", travelDestination.getBoolean("codeshareFlightIncluded"));

					if(travelDestination.getBoolean("isDirectFlights"))
						otherFee.put("flightType_exclusion", "Direct");
					else otherFee.put("flightType_exclusion", "Via");

					if(travelDestination.getBoolean("isOnline"))
						otherFee.put("flightLineType_exclusion", "Online");
					else otherFee.put("flightLineType_exclusion", "Offline");

					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0)
								travelProductNameArr.put(destObj.get("productId"));
						}
					}
					if(travelProductNameArr.length()>0)
						otherFee.put("travelProductName_exclusion", travelProductNameArr);
				}
			}
			if(advanceDefinitionAir.has("fareClass")){
				if(advanceDefinitionAir.getJSONObject("fareClass").has("dealCodes") && advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes")!=null){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes");
					JSONArray dealCodesArr = dealCodes.getJSONArray("dealCodes");
					JSONArray dealcode= new JSONArray();
					for(int dc=0;dc<dealCodesArr.length();dc++){
						dealcode.put(dealCodesArr.getJSONObject(dc).getString("dealCode"));
					}
					if(dealCodes.getBoolean("isInclusion"))
						otherFee.put("dealCode", dealcode);
					else otherFee.put("dealCode_exclusion", dealcode);
				}
			}
			otherFeeArr.put(otherFee);
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
		//setOtherFeesDestination
		setAirOtherFeesDestination(otherFeeArr,advanceDefinitionAir);
		//refFare
		//		private static void setAirOtherFeesDestination(JSONArray otherFeeArr, )
		CommonFunctions.setOtherFeeTicketing(otherFeeArr,advanceDefinitionAir.getJSONObject("validity"));
		getOtherFeesFareBasis(otherFeeArr,advanceDefinitionAir);
		//getOtherFeesFlightTiming(otherFeeArr,advanceDefinitionAir);
		//getOtherFeesFlightNumbers(otherFeeArr,advanceDefinitionAir);
	}

	
	private static void setAirOtherFeesDestination(JSONArray otherFeeArr, JSONObject advanceDefinitionAir){
		if(advanceDefinitionAir.getJSONObject("travelDestination").has("destinations")){
			JSONArray destinationArray = advanceDefinitionAir.getJSONObject("travelDestination").getJSONArray("destinations");
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<destinationArray.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject destinationObj = destinationArray.getJSONObject(j);
					if(advanceDefinitionAir.getJSONObject("travelDestination").getBoolean("isInclusion")){
						if(destinationObj.has("continent")){
							JSONObject continent = destinationArray.getJSONObject(j).getJSONObject("continent");
							if(continent.has("from") && !continent.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcontinent", continent.getString("from"));
							if(continent.has("via") && !continent.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacontinent", continent.getString("via"));
							if(continent.has("to") && !continent.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocontinent", continent.getString("to"));
						}
						if(destinationObj.has("country")){
							JSONObject country = destinationArray.getJSONObject(j).getJSONObject("country");
							if(country.has("from") && !country.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcountry", country.getString("from"));
							if(country.has("via") && !country.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacountry", country.getString("via"));
							if(country.has("to") && !country.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocountry", country.getString("to"));
						}
						if(destinationObj.has("city")){
							JSONObject city = destinationArray.getJSONObject(j).getJSONObject("city");
							if(city.has("from") && !city.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcity", city.getString("from"));
							if(city.has("via") && !city.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacity", city.getString("via"));
							if(city.has("to") && !city.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocity", city.getString("to"));
						}
					}else{
						if(destinationObj.has("continent")){
							JSONObject continent = destinationArray.getJSONObject(j).getJSONObject("continent");
							if(continent.has("from") && !continent.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcontinent_exclusion", continent.getString("from"));
							if(continent.has("via") && !continent.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacontinentexclusion", continent.getString("via"));
							if(continent.has("to") && !continent.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocontinentexclusion", continent.getString("to"));
						}
						if(destinationObj.has("country")){
							JSONObject country = destinationArray.getJSONObject(j).getJSONObject("country");
							if(country.has("from") && !country.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcountry_exclusion", country.getString("from"));
							if(country.has("via") && !country.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacountry_exclusion", country.getString("via"));
							if(country.has("to") && !country.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocountry_exclusion", country.getString("to"));
						}
						if(destinationObj.has("city")){
							JSONObject city = destinationArray.getJSONObject(j).getJSONObject("city");
							if(city.has("from") && !city.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcity_exclusion", city.getString("from"));
							if(city.has("via") && !city.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacity_exclusion", city.getString("via"));
							if(city.has("to") && !city.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocity_exclusion", city.getString("to"));
						}
					}
					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, destinationObj.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
			
		}
	}
	
	
	/*private static void getOtherFeesFlightNumbers(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("flightNumbers")){
			JSONArray flightRange = advanceDefinitionAir.getJSONObject("flightNumbers").getJSONArray("flightRange");
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<flightRange.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject range = flightRange.getJSONObject(j);
					String numbers=null;
					if(range.has("flightRangeFrom")){
						if(range.has("flightRangeTo"))
							numbers="BETWEEN"+";"+range.get("flightRangeFrom")+";"+range.get("flightRangeTo");
						else numbers="GREATERTHANEQUALTO"+";"+range.get("flightRangeFrom");
					}else if(range.has("flightRangeTo"))
						numbers="LESSTHANEQUALTO"+";"+range.get("flightRangeTo");
					
					if(advanceDefinitionAir.getJSONObject("flightNumbers").getBoolean("isInclusion"))
						otherFee.put("flightNumber", numbers);
					else otherFee.put("flightNumber_exclusion", numbers);
					
					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, range.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}
	

	private static void getOtherFeesFlightTiming(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("flightTimings")){
			JSONArray flightTimings = advanceDefinitionAir.getJSONObject("flightTimings").getJSONArray("flightTimings");
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int m=0;m<flightTimings.length();m++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject timingObject = flightTimings.getJSONObject(m);
					String timing=null;
					if(timingObject.has("flightTimeFrom")){
						if(timingObject.has("flightTimeTo"))
							timing="BETWEEN"+";"+timingObject.get("flightTimeFrom")+";"+timingObject.get("flightTimeTo");
						else timing="GREATERTHANEQUALTO"+";"+timingObject.get("flightTimeFrom");
					}else if(timingObject.has("flightTimeTo"))
						timing="LESSTHANEQUALTO"+";"+timingObject.get("flightTimeTo");
					
					if(advanceDefinitionAir.getJSONObject("flightTimings").getBoolean("isInclusion"))
						otherFee.put("flightTiming", timing);
					else otherFee.put("flightTiming_exclusion", timing);
					
					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, timingObject.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}*/


	private static void getOtherFeesFareBasis(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("fareClass")){
			if(advanceDefinitionAir.getJSONObject("fareClass").has("fareBasis")){
				JSONArray fare = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("fareBasis").getJSONArray("fare");
				int length = otherFeeArr.length();
				for(int i=0;i<length;i++){
					for(int f=0;f<fare.length();f++){
						JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
						JSONObject fareObject = fare.getJSONObject(f);
						JSONArray fareArr = new JSONArray();
						if(fareObject.has("condition"))
							fareArr.put(fareObject.getString("condition"));
						if(fareObject.has("value"))
							fareArr.put(fareObject.getString("value"));
						otherFee.put("fareBasisValue", fareArr);
						String otherFeeID = otherFee.getString("RuleID");
						otherFee.put("RuleID", otherFeeID+fareObject.getString("_id"));
						otherFeeArr.put(otherFee);
					}
				}
				for(int i=0;i<length;i++){
					otherFeeArr.remove(0);
				}
			}
		}
	}
	
	
	private static void setRuleID(String commercialName, JSONObject advanced, JSONObject calculation, String id) {
		switch(commercialName){
		case "Standard":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+stdLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+stdLocalID);
			advanced.put("agendaGroup", id+"_Standard");
			calculation.put("agendaGroup", id+"_Standard");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+stdLocalID);
		}break;
		case "Overriding":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+overridingLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+overridingLocalID);
			advanced.put("agendaGroup", id+"_Overriding");
			calculation.put("agendaGroup", id+"_Overriding");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+overridingLocalID);
		}break;
		case "PLB":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+plbLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+plbLocalID);
			advanced.put("agendaGroup", id+"_PLB");
			calculation.put("agendaGroup", id+"_PLB");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+plbLocalID);
		}break;
		case "SectorWiseIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+sectorWiseLocalID);
			advanced.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
		}break;
		case "DestinationIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+destinationLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+destinationLocalID);
			advanced.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+destinationLocalID);
		}break;
		case "SegmentFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+segmentLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+segmentLocalID);
			advanced.put("agendaGroup", id+"_SegmentFee");
			calculation.put("agendaGroup", id+"_SegmentFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+segmentLocalID);
		}break;
		case "ServiceCharge":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+serviceLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+serviceLocalID);
			advanced.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+serviceLocalID);
		}break;
		case "ManagementFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+mngtLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+mngtLocalID);
			advanced.put("agendaGroup", id+"_ManagementFee");
			calculation.put("agendaGroup", id+"_ManagementFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+mngtLocalID);
		}break;
		case "Discount":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+discountLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+discountLocalID);
			advanced.put("agendaGroup", id+"_Discount");
			calculation.put("agendaGroup", id+"_Discount");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+discountLocalID);
		}break;
		case "MarkUp":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+markupLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+markupLocalID);
			advanced.put("agendaGroup", id+"_MarkUp");
			calculation.put("agendaGroup", id+"_MarkUp");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+markupLocalID);
		}break;
		case "Commission":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+commissionLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+commissionLocalID);
			advanced.put("agendaGroup", id+"_Commission");
			calculation.put("agendaGroup", id+"_Commission");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+commissionLocalID);
		}break;
		default:System.out.println("default of Accomodation.setRuleID due to: "+commercialName);
		}
	}
	
	
	private static void appendApplicableOnDetails(JSONArray advancedArr, JSONArray calculationArr, String commercialName, JSONArray clientCommercialOtherHead) {
		switch(commercialName){
		case "PLB":{
			if(plbapplicableOnArray!=null && plbapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<plbapplicableOnArray.length();i++){
					String applicableOnID = plbapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								JSONObject plb = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("plb");
								if(CommonFunctions.plbOH.equals("slab")){
									JSONObject slab = plb.getJSONObject("slab");
									if(slab.has("slabType"))
										calculation.put("slabType", slab.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+slab.get("fromValue")+";"+slab.get("toValue"));
								}else if(plb.has("retention")){
									JSONObject retention = plb.getJSONObject("retention");
									if(retention.has("slabType"))
										calculation.put("slabType", retention.getString("slabType"));
									String slabTypeValue="BETWEEN;";
									JSONArray currencyDetails = retention.getJSONObject("details").getJSONArray("currencyDetails");
									for(int k=0;k<currencyDetails.length();k++){
										JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
										slabTypeValue+=currencyDetailsObject.get("fromValue")+";"+currencyDetailsObject.get("toValue");
									}
									calculation.put("slabTypeValue", slabTypeValue);
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "SegmentFee":{
			if(segmentapplicableOnArray!=null && segmentapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<segmentapplicableOnArray.length();i++){
					String applicableOnID = segmentapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								if(clientCommercialOtherHeadObject.has("commercialHeads") && clientCommercialOtherHeadObject.getJSONObject("commercialHeads").has("segmentFees")){
									JSONObject segmentFees = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("segmentFees");
									calculation.put("slabType", segmentFees.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+segmentFees.getString("fromValue")+";"+segmentFees.getString("toValue"));
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "ServiceCharge":{
			if(serviceapplicableOnArray!=null && serviceapplicableOnArray.length()>0){
				for(int i=0;i<serviceapplicableOnArray.length();i++){
					String applicableOnID = serviceapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							if(clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn").length()>0){
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn"));
								}
							}else{
								JSONArray app = new JSONArray();
								app.put("Book");
								app.put("Ammend");
								app.put("Cancel");
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", app);
								}
							}
						}
					}
				}
			}else{
				JSONArray app = new JSONArray();
				app.put("Book");
				app.put("Ammend");
				app.put("Cancel");
				for(int k=0;k<advancedArr.length();k++){
					JSONObject advanced = advancedArr.getJSONObject(k);
					advanced.put("applicableOn", app);
				}
			}break;
		}
		}
	}
}
