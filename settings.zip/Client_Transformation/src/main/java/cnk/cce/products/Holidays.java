package cnk.cce.products;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.cce.configuration.CommonFunctions;

public class Holidays {
	public static String sectorContractValidityFrom,sectorContractValidityTo,issuanceContractValidityFrom,issuanceContractValidityTo,managementContractValidityTo,discountContractValidityFrom,discountContractValidityTo,markupContractValidityFrom,markupContractValidityTo,destinationContractValidityTo,destination,country;
	public static String serviceContractValidityTo,serviceContractValidityFrom,segmentContractValidityTo,segmentContractValidityFrom,stdContractValidityFrom,stdContractValidityTo,overContractValidityFrom,overContractValidityTo,plbContractValidityFrom,plbContractValidityTo,destinationContractValidityFrom,flavourName;
	public static String managementContractValidityFrom,stdLocalID,overridingLocalID,plbLocalID,sectorWiseLocalID,segmentLocalID,serviceLocalID,mngtLocalID,discountLocalID,markupLocalID,destinationLocalID,issuanceLocalID,commissionLocalID,issuanceAdvanceDefinitionId,markupAdvanceDefinitionId,city,brochureName;
	public static String stdAdvanceDefinitionId,overridingAdvanceDefinitionId,plbAdvanceDefinitionId,sectorWiseAdvanceDefinitionId,segmentAdvanceDefinitionId,serviceAdvanceDefinitionId,mngtAdvanceDefinitionId,discountAdvanceDefinitionId,destinationAdvanceDefinitionId,brandName,productName,flavourType,productType;
	public static JSONArray plbapplicableOnArray,segmentapplicableOnArray,serviceapplicableOnArray;
	
	public static void appendHolidaysCommercialDetails(String advancedDT, String calculationDT, String commercialName, JSONObject mdmCommDefn,JSONObject mainJson, String productName, boolean advancedApplicable, String id, String productCategory, String productCategorySubType) {
		JSONObject advanced = new JSONObject();
		JSONObject calculation = new JSONObject();
		advanced.put("type", "advanced");
		calculation.put("type", "calculation");
		advanced.put("selectedRow", id);
		advanced.put("contractValidity", getContractValidity(commercialName));
		advanced.put("productCategory", productCategory);
		advanced.put("productCategorySubType", productCategorySubType);
		//CommonFunctions.setMDMRuleID(commercialName,calculation);
		setRuleID(commercialName,advanced,calculation,id);
		CommonFunctions.setCalculationParameters(commercialName,calculation,mainJson);
		setBudgetedMarginDetails(calculation);
		JSONArray advancedArr = new JSONArray();
		JSONArray calculationArr = new JSONArray();
		advancedArr.put(advanced);
		calculationArr.put(calculation);
		mainJson.put(advancedDT, advancedArr);
		mainJson.put(calculationDT, calculationArr);
		
		appendApplicableOnDetails(advancedArr,calculationArr,commercialName,mdmCommDefn.getJSONArray("clientCommercialOtherHead"));

		if(advancedApplicable && getAdvancedDefintionID(commercialName)!=null){
			JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray("advancedDefinitionData");
			for(int i=0;i<advancedDefinitionData.length();i++){
				if(getAdvancedDefintionID(commercialName).equals(advancedDefinitionData.getJSONObject(i).getString("_id"))){
					JSONObject advancedDefinitionObject = advancedDefinitionData.getJSONObject(i);
					JSONObject advanceDefinitionHolidays = advancedDefinitionObject.getJSONObject("advanceDefinitionHolidays");
						setHolidaysAdvancedDefinition(advancedArr,calculationArr,advanceDefinitionHolidays,getAdvancedDefintionID(commercialName),commercialName,mainJson,mdmCommDefn.getJSONArray("clientCommercialOtherHead"));
				}
			}
		}
	}


	private static void appendApplicableOnDetails(JSONArray advancedArr, JSONArray calculationArr, String commercialName, JSONArray clientCommercialOtherHead) {
		switch(commercialName){
		case "PLB":{
			if(plbapplicableOnArray!=null && plbapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<plbapplicableOnArray.length();i++){
					String applicableOnID = plbapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								JSONObject plb = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("plb");
								if(CommonFunctions.plbOH.equals("slab")){
									JSONObject slab = plb.getJSONObject("slab");
									if(slab.has("slabType"))
										calculation.put("slabType", slab.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+slab.get("fromValue")+";"+slab.get("toValue"));
								}else if(plb.has("retention")){
									JSONObject retention = plb.getJSONObject("retention");
									if(retention.has("slabType"))
										calculation.put("slabType", retention.getString("slabType"));
									String slabTypeValue="BETWEEN;";
									JSONArray currencyDetails = retention.getJSONObject("details").getJSONArray("currencyDetails");
									for(int k=0;k<currencyDetails.length();k++){
										JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
										slabTypeValue+=currencyDetailsObject.get("fromValue")+";"+currencyDetailsObject.get("toValue");
									}
									calculation.put("slabTypeValue", slabTypeValue);
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "SegmentFee":{
			if(segmentapplicableOnArray!=null && segmentapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<segmentapplicableOnArray.length();i++){
					String applicableOnID = segmentapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								if(clientCommercialOtherHeadObject.has("commercialHeads") && clientCommercialOtherHeadObject.getJSONObject("commercialHeads").has("segmentFees")){
									JSONObject segmentFees = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("segmentFees");
									calculation.put("slabType", segmentFees.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+segmentFees.getString("fromValue")+";"+segmentFees.getString("toValue"));
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "ServiceCharge":{
			if(serviceapplicableOnArray!=null && serviceapplicableOnArray.length()>0){
				for(int i=0;i<serviceapplicableOnArray.length();i++){
					String applicableOnID = serviceapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							if(clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn").length()>0){
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn"));
								}
							}else{
								JSONArray app = new JSONArray();
								app.put("Book");
								app.put("Ammend");
								app.put("Cancel");
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", app);
								}
							}
						}
					}
				}
			}else{
				JSONArray app = new JSONArray();
				app.put("Book");
				app.put("Ammend");
				app.put("Cancel");
				for(int k=0;k<advancedArr.length();k++){
					JSONObject advanced = advancedArr.getJSONObject(k);
					advanced.put("applicableOn", app);
				}
			}break;
		}
		}
	}
	
	
	public static void setHolidaysAdvancedDefinition(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionHolidays, String advDefnID, String commercialName, JSONObject mainJson, JSONArray clientCommercialOtherHead) {
		if(advanceDefinitionHolidays.has("applicableOn") && advanceDefinitionHolidays.getJSONArray("applicableOn").length()>0){
			setApplicableOnDTName(commercialName,calcArr,mainJson);
			setAdvancedDefinition(advanceDefinitionHolidays,baseArr,calcArr);
			setHolidaysApplicableOn(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray("applicableOn"),advanceDefinitionHolidays);
		}else{
			setAdvancedDefinition(advanceDefinitionHolidays,baseArr,calcArr);
			if(advanceDefinitionHolidays.has("passengerType") && advanceDefinitionHolidays.getJSONArray("passengerType").length()>0){
				JSONObject passengerType = advanceDefinitionHolidays.getJSONArray("passengerType").getJSONObject(0);
				if(passengerType.has("triggerOrPayout") && passengerType.getJSONArray("triggerOrPayout").length()>0)
					CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType", true, false);
				else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType", true, false);
			}
			
			if(advanceDefinitionHolidays.has("roomLevel")){
				JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
				if(roomLevel.has("roomCategories") && roomLevel.getJSONArray("roomCategories").length()>0){
					JSONObject roomCategories = roomLevel.getJSONArray("roomCategories").getJSONObject(0);
					if(roomCategories.has("triggerOrPayout") && roomCategories.getJSONArray("triggerOrPayout").length()>0)
						CommonFunctions.getArray(baseArr, calcArr, roomLevel.getJSONArray("roomCategories"), "roomCategories", true, false);
					else CommonFunctions.getArrayNonTP(baseArr, calcArr,roomLevel.getJSONArray("roomCategories"),"roomCategories",true,false);
				}
				
				if(roomLevel.has("roomTypes") && roomLevel.getJSONArray("roomTypes").length()>0){
					JSONObject roomTypes = roomLevel.getJSONArray("roomTypes").getJSONObject(0);
					if(roomTypes.has("triggerOrPayout") && roomTypes.getJSONArray("triggerOrPayout").length()>0)
						CommonFunctions.getArray(baseArr, calcArr, roomLevel.getJSONArray("roomTypes"), "roomTypes", true, false);
					else CommonFunctions.getArrayNonTP(baseArr, calcArr,roomLevel.getJSONArray("roomTypes"),"roomTypes",true,false);
				}
			}
		}
	}
	
	
	private static void setApplicableOnDTName(String commercialName, JSONArray calculationArr, JSONObject mainJson) {
		switch(commercialName){
		case "Standard":{
			mainJson.remove("StandardClientCommercialCalculationDT");
			mainJson.put("StandardApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		case "Overriding":{
			mainJson.remove("OverridingClientCommercialCalculationDT");
			mainJson.put("OverridingApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		case "PLB":{
			mainJson.remove("PLBClientCommercialCalculationDT");
			mainJson.put("PLBApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		case "SegmentFee":{
			mainJson.remove("SegmentFeeClientCommercialCalculationDT");
			mainJson.put("SegmentFeesApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		case "SectorWiseIncentive":{
			mainJson.remove("SectorWiseIncentiveClientCommercialCalculationDT");
			mainJson.put("SectorWiseIncentiveApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		case "DestinationIncentive":{
			mainJson.remove("DestinationIncentiveClientCommercialCalculationDT");
			mainJson.put("DestinationIncentiveApplicableOnCommercialCalculationDT", calculationArr);
			break;
		}
		case "ManagementFee":{
			mainJson.remove("ManagementFeeClientCommercialCalculationDT");
			mainJson.put("ManagementFeesApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		case "ServiceCharge":{
			mainJson.remove("ServiceChargeClientCommercialCalculationDT");
			mainJson.put("ServiceChargeApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		case "Discount":{
			mainJson.remove("DiscountClientCommercialCalculationDT");
			mainJson.put("DiscountApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		case "MarkUp":{
			mainJson.remove("MarkUpClientCommercialCalculationDT");
			mainJson.put("MarkUpApplicableOnClientCommercialCalculationDT", calculationArr);
			break;
		}
		default:System.out.println("default of setApplicableOnDTName due to commercialName: "+commercialName);
		}
	}
	

	private static void setAdvancedDefinition(JSONObject advanceDefinitionHolidays, JSONArray baseArr, JSONArray calcArr) {
		if(advanceDefinitionHolidays.has("validity")){
			JSONObject validity = advanceDefinitionHolidays.getJSONObject("validity");
			switch(validity.getString("saleOrTravel")){
			case "sales":{
				JSONObject sales = validity.getJSONArray("sales").getJSONObject(0);
				if(sales.has("triggerOrPayout") && sales.getJSONArray("triggerOrPayout").length()>0)
					CommonFunctions.getPLBDates(baseArr, calcArr, validity.getJSONArray("sales"), "sale", false);
				else CommonFunctions.setDate(baseArr, calcArr, validity.getJSONArray("sales"), "sale", false);
				break;
			}
			case "travel":{
				JSONObject travel = validity.getJSONArray("travel").getJSONObject(0);
				if(travel.has("triggerOrPayout") && travel.getJSONArray("triggerOrPayout").length()>0)
					CommonFunctions.getPLBDates(baseArr, calcArr, validity.getJSONArray("travel"), "travel", false);
				else CommonFunctions.setDate(baseArr, calcArr, validity.getJSONArray("travel"), "travel", false);
				break;
			}
			default:System.out.println("default of Holidays.setHolidaysAdvancedDefinition");
			}
		}

		if(advanceDefinitionHolidays.has("travelDestinations") && advanceDefinitionHolidays.getJSONArray("travelDestinations").length()>0){
			JSONObject travelDestinations = advanceDefinitionHolidays.getJSONArray("travelDestinations").getJSONObject(0);
			if(travelDestinations.has("triggerOrPayout") && travelDestinations.getJSONArray("triggerOrPayout").length()>0)
				setPLBHolidaysDestinations(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray("travelDestinations"));
			else setHolidaysDestinations(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray("travelDestinations"));
		}
		
		if(advanceDefinitionHolidays.has("credentials") && advanceDefinitionHolidays.getJSONArray("credentials").length()>0){
			JSONObject credentials = advanceDefinitionHolidays.getJSONArray("credentials").getJSONObject(0);
			if(credentials.has("triggerOrPayout") && credentials.getJSONArray("triggerOrPayout").length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("credentials"), "credentials", true, true);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("credentials"), "credentials", true, true);
		}
		
		if(advanceDefinitionHolidays.has("nationality") && advanceDefinitionHolidays.getJSONArray("nationality").length()>0){
			JSONObject nationality = advanceDefinitionHolidays.getJSONArray("nationality").getJSONObject(0);
			if(nationality.has("triggerOrPayout") && nationality.getJSONArray("triggerOrPayout").length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("nationality"), "clientNationality", true, true);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("nationality"), "clientNationality", true, true);
		}
		
		if(advanceDefinitionHolidays.has("tourTypes") && advanceDefinitionHolidays.getJSONArray("tourTypes").length()>0){
			JSONObject tourTypes = advanceDefinitionHolidays.getJSONArray("tourTypes").getJSONObject(0);
			if(tourTypes.has("triggerOrPayout") && tourTypes.getJSONArray("triggerOrPayout").length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("tourTypes"), "tourTypes", true, false);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("tourTypes"), "tourTypes", true, false);
		}
		
		if(advanceDefinitionHolidays.has("connectivity")){
			JSONObject connectivity = advanceDefinitionHolidays.getJSONObject("connectivity");
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				if(connectivity.has("triggerOrPayout") && connectivity.getJSONArray("triggerOrPayout").length()>0){
					CommonFunctions.getConnectivityTP(baseArr, connectivity);
					break;
				}
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					base.put("connectivitySupplierType",connectivity.getString("supplierType"));
				if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
					base.put("connectivitySupplierName",connectivity.getString("supplierId"));
			}
		}
		
		if(advanceDefinitionHolidays.has("roomLevel")){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
			if(roomLevel.has("bookingType")){
				JSONObject bookingType = roomLevel.getJSONObject("bookingType");
				if(bookingType.has("triggerOrPayout") && bookingType.getJSONArray("triggerOrPayout").length()>0){
					CommonFunctions.getBookingTypeTP(baseArr, calcArr,bookingType, true, false);
				}else{
					int length=calcArr.length();
					for(int i=0;i<length;i++){
						JSONObject calculation = calcArr.getJSONObject(i);
						calculation.put("bookingType", bookingType.getString("bookingType"));
					}
				}
			}	
		}
	}
	
	
	private static void setHolidaysApplicableOn(JSONArray baseArr, JSONArray calcArr, JSONArray applicableOnArr, JSONObject advanceDefinitionHolidays) {
		if(advanceDefinitionHolidays.has("passengerType") && advanceDefinitionHolidays.getJSONArray("passengerType").length()>0){
			JSONObject passengerType = advanceDefinitionHolidays.getJSONArray("passengerType").getJSONObject(0);
			if(passengerType.has("triggerOrPayout") && passengerType.getJSONArray("triggerOrPayout").length()>0)
				getArrayApplicableOn(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType");
			else getArrayNonTPApplicableOn(calcArr, advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType");
		}
		
		if(advanceDefinitionHolidays.has("roomLevel")){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
			if(roomLevel.has("roomCategories") && roomLevel.getJSONArray("roomCategories").length()>0){
				JSONObject roomCategories = roomLevel.getJSONArray("roomCategories").getJSONObject(0);
				if(roomCategories.has("triggerOrPayout") && roomCategories.getJSONArray("triggerOrPayout").length()>0)
					getArrayApplicableOn(baseArr, calcArr, roomLevel.getJSONArray("roomCategories"), "roomCategories");
				else getArrayNonTPApplicableOn(calcArr,roomLevel.getJSONArray("roomCategories"),"roomCategories");
			}
			
			if(roomLevel.has("roomTypes") && roomLevel.getJSONArray("roomTypes").length()>0){
				JSONObject roomTypes = roomLevel.getJSONArray("roomTypes").getJSONObject(0);
				if(roomTypes.has("triggerOrPayout") && roomTypes.getJSONArray("triggerOrPayout").length()>0)
					getArrayApplicableOn(baseArr, calcArr, roomLevel.getJSONArray("roomTypes"), "roomTypes");
				else getArrayNonTPApplicableOn(calcArr,roomLevel.getJSONArray("roomTypes"),"roomTypes");
			}
		}
		
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			calculation.put("productName_applicableOn", applicableOnArr);
		}
	}
	
	
	private static void getArrayApplicableOn(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name) {
		int length=calcArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<jsonArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject jsonObject = jsonArray.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(jsonObject.getJSONArray("triggerOrPayout"));
				JSONArray array = new JSONArray();
				array.put(triggerPayout);
				JSONObject object = new JSONObject();
				object.put(name+"_applicableOn", jsonObject.getString(name));
				array.put(object);
				calculation.put(name, array);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, jsonObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	private static void getArrayNonTPApplicableOn(JSONArray calcArr, JSONArray jsonArray, String name) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			calculation.put(name+"_applicableOn", array);
		}
	}
	
	
	public static void setHolidaysDestinations(JSONArray baseArr, JSONArray calcArr, JSONArray travelDestinationsArr) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				if(travelDestinations.has("destination") && !travelDestinations.getString("destination").equalsIgnoreCase("All"))
					calculation.put("toContinent", travelDestinations.getString("destination"));
				if(travelDestinations.has("country") && !travelDestinations.getString("country").equalsIgnoreCase("All"))
					calculation.put("toCountry", travelDestinations.getString("country"));
				if(travelDestinations.has("city") && !travelDestinations.getString("city").equalsIgnoreCase("All"))
					calculation.put("toCity", travelDestinations.getString("city"));
				if(travelDestinations.has("state") && !travelDestinations.getString("state").equalsIgnoreCase("All"))
					calculation.put("toState", travelDestinations.getString("state"));

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, travelDestinations.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	private static void setPLBHolidaysDestinations(JSONArray baseArr, JSONArray calcArr, JSONArray travelDestinationsArr) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(travelDestinations.getJSONArray("triggerOrPayout"));
				JSONArray destinatn = new JSONArray();
				JSONObject desti = new JSONObject();
				destinatn.put(triggerPayout);
				
				if(travelDestinations.has("destination") && !travelDestinations.getString("destination").equalsIgnoreCase("All"))
					desti.put("toContinent", travelDestinations.getString("destination"));
				if(travelDestinations.has("country") && !travelDestinations.getString("country").equalsIgnoreCase("All"))
					desti.put("toCountry", travelDestinations.getString("country"));
				if(travelDestinations.has("city") && !travelDestinations.getString("city").equalsIgnoreCase("All"))
					desti.put("toCity", travelDestinations.getString("city"));
				if(travelDestinations.has("state") && !travelDestinations.getString("state").equalsIgnoreCase("All"))
					desti.put("toState", travelDestinations.getString("state"));

				destinatn.put(desti);
				calculation.put("travelDestinations", destinatn);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, travelDestinations.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
		
	}
	
	
	private static String getAdvancedDefintionID(String commercialName) {
		switch(commercialName){
		case "Standard":return stdAdvanceDefinitionId;
		case "Overriding":return overridingAdvanceDefinitionId;
		case "PLB":return plbAdvanceDefinitionId;
		case "SectorWiseIncentive":return sectorWiseAdvanceDefinitionId;
		case "ManagementFee":return mngtAdvanceDefinitionId;
		case "SegmentFee":return segmentAdvanceDefinitionId;
		case "ServiceCharge":return serviceAdvanceDefinitionId;
		case "Discount":return discountAdvanceDefinitionId;
		case "MarkUp":return markupAdvanceDefinitionId;
		case "DestinationIncentive":return destinationAdvanceDefinitionId;
		case "IssuanceFee":return issuanceAdvanceDefinitionId;
		}
		return null;
	}
	
	
	private static JSONObject getContractValidity(String commercialName) {
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		switch(commercialName){
		case "Standard":{
			contractValidity.put("from", stdContractValidityFrom);
			contractValidity.put("to", stdContractValidityTo);
			break;
		}
		case "Overriding":{
			contractValidity.put("from", overContractValidityFrom);
			contractValidity.put("to", overContractValidityTo);
			break;
		}
		case "PLB":{
			contractValidity.put("from", plbContractValidityFrom);
			contractValidity.put("to", plbContractValidityTo);
			break;
		}
		case "SectorWiseIncentive":{
			contractValidity.put("from", sectorContractValidityFrom);
			contractValidity.put("to", sectorContractValidityTo);
			break;
		}
		case "ManagementFee":{
			contractValidity.put("from", managementContractValidityFrom);
			contractValidity.put("to", managementContractValidityTo);
			break;
		}
		case "SegmentFee":{
			contractValidity.put("from", segmentContractValidityFrom);
			contractValidity.put("to", segmentContractValidityTo);
			break;
		}
		case "ServiceCharge":{
			contractValidity.put("from", serviceContractValidityFrom);
			contractValidity.put("to", serviceContractValidityTo);
			break;
		}
		case "Discount":{
			contractValidity.put("from", discountContractValidityFrom);
			contractValidity.put("to", discountContractValidityTo);
			break;
		}
		case "MarkUp":{
			contractValidity.put("from", markupContractValidityFrom);
			contractValidity.put("to", markupContractValidityTo);
			break;
		}
		case "DestinationIncentive":{
			contractValidity.put("from", destinationContractValidityFrom);
			contractValidity.put("to", destinationContractValidityTo);
			break;
		}
		case "IssuanceFee":{
			contractValidity.put("from", issuanceContractValidityFrom);
			contractValidity.put("to", issuanceContractValidityTo);
			break;
		}
		default:System.out.println("default of getContractValidity : Air.java");
		}
		return contractValidity;
	}
	
	
	public static void setOtherFeesHolidaysAdvancedDefinition(JSONObject advanceDefinitionHolidays, JSONArray otherFeeArr){
		if(advanceDefinitionHolidays.has("validity")){
			JSONObject validity = advanceDefinitionHolidays.getJSONObject("validity");
			switch(validity.getString("saleOrTravel")){
			case "sales":{
				CommonFunctions.setOtherFeesDate(otherFeeArr,validity.getJSONArray("sales"),"sale");
				break;
			}
			case "travel":{
				CommonFunctions.setOtherFeesDate(otherFeeArr,validity.getJSONArray("travel"),"travel");
				break;
			}
			default:System.out.println("default of Holidays.setHolidaysAdvancedDefinition");
			}
		}

		if(advanceDefinitionHolidays.has("travelDestinations") && advanceDefinitionHolidays.getJSONArray("travelDestinations").length()>0)
			setOtherFeeHolidaysDestinations(otherFeeArr,advanceDefinitionHolidays.getJSONArray("travelDestinations"));

		if(advanceDefinitionHolidays.has("credentials") && advanceDefinitionHolidays.getJSONArray("credentials").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionHolidays.getJSONArray("credentials"), "credentials");

		if(advanceDefinitionHolidays.has("nationality") && advanceDefinitionHolidays.getJSONArray("nationality").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray("nationality"), "clientNationality");

		if(advanceDefinitionHolidays.has("tourTypes") && advanceDefinitionHolidays.getJSONArray("tourTypes").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray("tourTypes"), "tourTypes");

		if(advanceDefinitionHolidays.has("connectivity")){
			JSONObject connectivity = advanceDefinitionHolidays.getJSONObject("connectivity");
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierType",connectivity.getString("supplierType"));
				if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierName",connectivity.getString("supplierId"));
			}
		}

		if(advanceDefinitionHolidays.has("roomLevel")){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
			if(roomLevel.has("bookingType")){
				JSONObject bookingType = roomLevel.getJSONObject("bookingType");
				int length=otherFeeArr.length();
				for(int i=0;i<length;i++){
					JSONObject otherFee = otherFeeArr.getJSONObject(i);
					otherFee.put("bookingType", bookingType.getString("bookingType"));
				}
			}	
		}

		if(advanceDefinitionHolidays.has("passengerType") && advanceDefinitionHolidays.getJSONArray("passengerType").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType");

		if(advanceDefinitionHolidays.has("roomLevel")){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
			if(roomLevel.has("roomCategories") && roomLevel.getJSONArray("roomCategories").length()>0)
				CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,roomLevel.getJSONArray("roomCategories"),"roomCategories");

			if(roomLevel.has("roomTypes") && roomLevel.getJSONArray("roomTypes").length()>0)
				CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,roomLevel.getJSONArray("roomTypes"),"roomTypes");
		}
	}
	

	public static void setOtherFeeHolidaysDestinations(JSONArray otherFeeArr, JSONArray travelDestinationsArr) {
		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				if(travelDestinations.has("destination") && !travelDestinations.getString("destination").equalsIgnoreCase("All"))
					otherFee.put("continent", travelDestinations.getString("destination"));
				if(travelDestinations.has("country") && !travelDestinations.getString("country").equalsIgnoreCase("All"))
					otherFee.put("country", travelDestinations.getString("country"));
				if(travelDestinations.has("city") && !travelDestinations.getString("city").equalsIgnoreCase("All"))
					otherFee.put("city", travelDestinations.getString("city"));
				if(travelDestinations.has("state") && !travelDestinations.getString("state").equalsIgnoreCase("All"))
					otherFee.put("state", travelDestinations.getString("state"));

				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, travelDestinations.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);

		}
	}
	
	
	private static void setRuleID(String commercialName, JSONObject advanced, JSONObject calculation, String id) {
		switch(commercialName){
		case "Standard":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+stdLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+stdLocalID);
			advanced.put("agendaGroup", id+"_Standard");
			calculation.put("agendaGroup", id+"_Standard");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+stdLocalID);
		}break;
		case "Overriding":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+overridingLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+overridingLocalID);
			advanced.put("agendaGroup", id+"_Overriding");
			calculation.put("agendaGroup", id+"_Overriding");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+overridingLocalID);
		}break;
		case "PLB":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+plbLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+plbLocalID);
			advanced.put("agendaGroup", id+"_PLB");
			calculation.put("agendaGroup", id+"_PLB");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+plbLocalID);
		}break;
		case "SectorWiseIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+sectorWiseLocalID);
			advanced.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
		}break;
		case "DestinationIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+destinationLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+destinationLocalID);
			advanced.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+destinationLocalID);
		}break;
		case "SegmentFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+segmentLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+segmentLocalID);
			advanced.put("agendaGroup", id+"_SegmentFee");
			calculation.put("agendaGroup", id+"_SegmentFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+segmentLocalID);
		}break;
		case "ServiceCharge":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+serviceLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+serviceLocalID);
			advanced.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+serviceLocalID);
		}break;
		case "ManagementFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+mngtLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+mngtLocalID);
			advanced.put("agendaGroup", id+"_ManagementFee");
			calculation.put("agendaGroup", id+"_ManagementFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+mngtLocalID);
		}break;
		case "Discount":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+discountLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+discountLocalID);
			advanced.put("agendaGroup", id+"_Discount");
			calculation.put("agendaGroup", id+"_Discount");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+discountLocalID);
		}break;
		case "MarkUp":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+markupLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+markupLocalID);
			advanced.put("agendaGroup", id+"_MarkUp");
			calculation.put("agendaGroup", id+"_MarkUp");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+markupLocalID);
		}break;
		case "Commission":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+commissionLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+commissionLocalID);
			advanced.put("agendaGroup", id+"_Commission");
			calculation.put("agendaGroup", id+"_Commission");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+commissionLocalID);
		}break;
		default:System.out.println("default of Accomodation.setRuleID due to: "+commercialName);
		}
	}
	
	
	public static void setBudgetMarginDetails(JSONObject budgetMarginsObject){
		JSONObject holiday = budgetMarginsObject.getJSONObject("holiday");
		if(holiday.getBoolean("isDestinationLevel")){
			JSONObject destinationLevel = holiday.getJSONObject("destinationLevel");
			if(destinationLevel.has("destination") && !destinationLevel.getString("destination").equalsIgnoreCase("All"))
				destination = destinationLevel.getString("destination");
			if(destinationLevel.has("country") && !destinationLevel.getString("country").equalsIgnoreCase("All"))
				country = destinationLevel.getString("country");
			if(destinationLevel.has("city") && !destinationLevel.getString("city").equalsIgnoreCase("All"))
				city = destinationLevel.getString("city");
		}else{
			JSONObject productLevel = holiday.getJSONObject("productLevel");
			if(productLevel.has("brochureName") && !productLevel.getString("brochureName").equalsIgnoreCase("All"))
				brochureName = productLevel.getString("brochureName");
			if(productLevel.has("flavourName") && !productLevel.getString("flavourName").equalsIgnoreCase("All"))
				flavourName = productLevel.getString("flavourName");
			if(productLevel.has("productType") && !productLevel.getString("productType").equalsIgnoreCase("All"))
				productType = productLevel.getString("productType");
			if(productLevel.has("brandName") && !productLevel.getString("brandName").equalsIgnoreCase("All"))
				brandName = productLevel.getString("brandName");
			if(productLevel.has("productName") && !productLevel.getString("productName").equalsIgnoreCase("All"))
				productName = productLevel.getString("productName");
			if(productLevel.has("flavourType") && !productLevel.getString("flavourType").equalsIgnoreCase("All"))
				flavourType = productLevel.getString("flavourType");
		}
	}
	
	
	private static void setBudgetedMarginDetails(JSONObject calculation) {
		if(destination!=null)
			calculation.put("toContinent", destination);
		if(country!=null)
			calculation.put("toCountry", country);
		if(city!=null)
			calculation.put("toCity", city);
		if(flavourName!=null)
			calculation.put("productFlavorName", flavourName);
		if(productType!=null)
			calculation.put("productType", productType);
		if(brandName!=null)
			calculation.put("brandName", brandName);
		if(productName!=null)
			calculation.put("productName", productName);
		if(flavourType!=null)
			calculation.put("flavorType", flavourType);
	}
}
