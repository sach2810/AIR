package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.cce.configuration.CommonFunctions;

public class Cruise {
	public static String sectorContractValidityFrom,sectorContractValidityTo,issuanceContractValidityFrom,issuanceContractValidityTo,managementContractValidityTo,discountContractValidityFrom,discountContractValidityTo,markupContractValidityFrom,markupContractValidityTo,destinationContractValidityTo;
	public static String serviceContractValidityTo,serviceContractValidityFrom,segmentContractValidityTo,segmentContractValidityFrom,stdContractValidityFrom,stdContractValidityTo,overContractValidityFrom,overContractValidityTo,plbContractValidityFrom,plbContractValidityTo,destinationContractValidityFrom;
	public static String managementContractValidityFrom,stdLocalID,overridingLocalID,plbLocalID,sectorWiseLocalID,segmentLocalID,serviceLocalID,mngtLocalID,discountLocalID,markupLocalID,destinationLocalID,issuanceLocalID,commissionLocalID,markupAdvanceDefinitionId,issuanceAdvanceDefinitionId;
	public static String stdAdvanceDefinitionId,overridingAdvanceDefinitionId,plbAdvanceDefinitionId,sectorWiseAdvanceDefinitionId,segmentAdvanceDefinitionId,serviceAdvanceDefinitionId,mngtAdvanceDefinitionId,discountAdvanceDefinitionId,destinationAdvanceDefinitionId;
	public static JSONArray plbapplicableOnArray,segmentapplicableOnArray,serviceapplicableOnArray;
	
	public static JSONObject appendCruiseCommercialDetails(String advancedDT, String calculationDT, String commercialName, JSONObject mdmCommDefn,JSONObject mainJson, String productName, boolean advancedApplicable, String id) throws Exception {
		JSONObject advanced = new JSONObject();
		JSONObject calculation = new JSONObject();
		advanced.put("type", "advanced");
		calculation.put("type", "calculation");
		advanced.put("selectedRow", id);
		advanced.put("contractValidity", getContractValidity(commercialName));
		//CommonFunctions.setMDMRuleID(commercialName,calculation);
		setRuleID(commercialName,advanced,calculation,id);
		CommonFunctions.setCalculationParameters(commercialName,calculation,mainJson);
		JSONArray advancedArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		advancedArr.put(advanced);
		calcArr.put(calculation);
		mainJson.put(advancedDT, advancedArr);
		mainJson.put(calculationDT, calcArr);
		
		appendApplicableOnDetails(advancedArr,calcArr,commercialName,mdmCommDefn.getJSONArray("clientCommercialOtherHead"));
		
		//cruise details?
		
		JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray("advancedDefinitionData");
		if(advancedApplicable){
			switch(commercialName){
			case "Standard":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,stdAdvanceDefinitionId,commercialName);break;}
			case "Overriding":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,overridingAdvanceDefinitionId,commercialName);break;}
			case "PLB":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,plbAdvanceDefinitionId,commercialName);break;}
			case "SectorWiseIncentive":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,sectorWiseAdvanceDefinitionId,commercialName);break;}
			case "DestinationIncentive":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,destinationAdvanceDefinitionId,commercialName);break;}
			case "SegmentFee":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,segmentAdvanceDefinitionId,commercialName);break;}
			case "ServiceCharge":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,serviceAdvanceDefinitionId,commercialName);break;}
			case "ManagementFee":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,mngtAdvanceDefinitionId,commercialName);break;}
			case "IssuanceFee":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,issuanceAdvanceDefinitionId,commercialName);break;}
			case "Discount":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,discountAdvanceDefinitionId,commercialName);break;}
			case "MarkUp":{setCruiseAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,markupAdvanceDefinitionId,commercialName);break;}
			default:System.out.println("default of appendAccoCommercialDetails due to: "+commercialName);
			}
		}
		return mainJson;
	}
	
	
	public static void setCruiseAdvancedDefinition(JSONArray advancedArr, JSONArray calcArr, JSONArray advancedDefinitionData, String advDefnID, String commercialName) {
		for(int i=0;i<advancedDefinitionData.length();i++){
			if(advDefnID!=null){
				if(advancedDefinitionData.getJSONObject(i).get("_id").equals(advDefnID)){
					JSONObject advanceDefinitionTransportation = advancedDefinitionData.getJSONObject(i).getJSONObject("advanceDefinitionTransportation");
					CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation, advancedArr, calcArr);
					//Cruise Details Here
				}
			}
		}
	}
	
	
	private static void setRuleID(String commercialName, JSONObject advanced, JSONObject calculation, String id) {
		switch(commercialName){
		case "Standard":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+stdLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+stdLocalID);
			advanced.put("agendaGroup", id+"_Standard");
			calculation.put("agendaGroup", id+"_Standard");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+stdLocalID);
		}break;
		case "Overriding":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+overridingLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+overridingLocalID);
			advanced.put("agendaGroup", id+"_Overriding");
			calculation.put("agendaGroup", id+"_Overriding");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+overridingLocalID);
		}break;
		case "PLB":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+plbLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+plbLocalID);
			advanced.put("agendaGroup", id+"_PLB");
			calculation.put("agendaGroup", id+"_PLB");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+plbLocalID);
		}break;
		case "SectorWiseIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+sectorWiseLocalID);
			advanced.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
		}break;
		case "DestinationIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+destinationLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+destinationLocalID);
			advanced.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+destinationLocalID);
		}break;
		case "SegmentFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+segmentLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+segmentLocalID);
			advanced.put("agendaGroup", id+"_SegmentFee");
			calculation.put("agendaGroup", id+"_SegmentFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+segmentLocalID);
		}break;
		case "ServiceCharge":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+serviceLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+serviceLocalID);
			advanced.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+serviceLocalID);
		}break;
		case "ManagementFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+mngtLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+mngtLocalID);
			advanced.put("agendaGroup", id+"_ManagementFee");
			calculation.put("agendaGroup", id+"_ManagementFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+mngtLocalID);
		}break;
		case "Discount":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+discountLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+discountLocalID);
			advanced.put("agendaGroup", id+"_Discount");
			calculation.put("agendaGroup", id+"_Discount");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+discountLocalID);
		}break;
		case "MarkUp":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+markupLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+markupLocalID);
			advanced.put("agendaGroup", id+"_MarkUp");
			calculation.put("agendaGroup", id+"_MarkUp");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+markupLocalID);
		}break;
		case "Commission":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+commissionLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+commissionLocalID);
			advanced.put("agendaGroup", id+"_Commission");
			calculation.put("agendaGroup", id+"_Commission");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+commissionLocalID);
		}break;
		default:System.out.println("default of Accomodation.setRuleID due to: "+commercialName);
		}
	}
	
	
	private static JSONObject getContractValidity(String commercialName) {
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		switch(commercialName){
		case "Standard":{
			contractValidity.put("from", stdContractValidityFrom);
			contractValidity.put("to", stdContractValidityTo);
			break;
		}
		case "Overriding":{
			contractValidity.put("from", overContractValidityFrom);
			contractValidity.put("to", overContractValidityTo);
			break;
		}
		case "PLB":{
			contractValidity.put("from", plbContractValidityFrom);
			contractValidity.put("to", plbContractValidityTo);
			break;
		}
		case "SectorWiseIncentive":{
			contractValidity.put("from", sectorContractValidityFrom);
			contractValidity.put("to", sectorContractValidityTo);
			break;
		}
		case "DestinationIncentive":{
			contractValidity.put("from", destinationContractValidityFrom);
			contractValidity.put("to", destinationContractValidityTo);
			break;
		}
		case "SegmentFee":{
			contractValidity.put("from", segmentContractValidityFrom);
			contractValidity.put("to", segmentContractValidityTo);
			break;
		}
		case "ServiceCharge":{
			contractValidity.put("from", serviceContractValidityFrom);
			contractValidity.put("to", serviceContractValidityTo);
			break;
		}
		case "ManagementFee":{
			contractValidity.put("from", managementContractValidityFrom);
			contractValidity.put("to", managementContractValidityTo);
			break;
		}
		case "Discount":{
			contractValidity.put("from", discountContractValidityFrom);
			contractValidity.put("to", discountContractValidityTo);
			break;
		}
		case "IssuanceFee":{
			contractValidity.put("from", issuanceContractValidityFrom);
			contractValidity.put("to", issuanceContractValidityTo);
			break;
		}
		case "MarkUp":{
			contractValidity.put("from", markupContractValidityFrom);
			contractValidity.put("to", markupContractValidityTo);
			break;
		}
		default:System.out.println("default of Accomodation.getContractValidity due to: "+commercialName);
		}
		return contractValidity;
	}
	
	
	private static void appendApplicableOnDetails(JSONArray advancedArr, JSONArray calculationArr, String commercialName, JSONArray clientCommercialOtherHead) {
		switch(commercialName){
		case "PLB":{
			if(plbapplicableOnArray!=null && plbapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<plbapplicableOnArray.length();i++){
					String applicableOnID = plbapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								JSONObject plb = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("plb");
								if(CommonFunctions.plbOH.equals("slab")){
									JSONObject slab = plb.getJSONObject("slab");
									if(slab.has("slabType"))
										calculation.put("slabType", slab.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+slab.get("fromValue")+";"+slab.get("toValue"));
								}else if(plb.has("retention")){
									JSONObject retention = plb.getJSONObject("retention");
									if(retention.has("slabType"))
										calculation.put("slabType", retention.getString("slabType"));
									String slabTypeValue="BETWEEN;";
									JSONArray currencyDetails = retention.getJSONObject("details").getJSONArray("currencyDetails");
									for(int k=0;k<currencyDetails.length();k++){
										JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
										slabTypeValue+=currencyDetailsObject.get("fromValue")+";"+currencyDetailsObject.get("toValue");
									}
									calculation.put("slabTypeValue", slabTypeValue);
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "SegmentFee":{
			if(segmentapplicableOnArray!=null && segmentapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<segmentapplicableOnArray.length();i++){
					String applicableOnID = segmentapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								if(clientCommercialOtherHeadObject.has("commercialHeads") && clientCommercialOtherHeadObject.getJSONObject("commercialHeads").has("segmentFees")){
									JSONObject segmentFees = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("segmentFees");
									calculation.put("slabType", segmentFees.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+segmentFees.getString("fromValue")+";"+segmentFees.getString("toValue"));
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "ServiceCharge":{
			if(serviceapplicableOnArray!=null && serviceapplicableOnArray.length()>0){
				for(int i=0;i<serviceapplicableOnArray.length();i++){
					String applicableOnID = serviceapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							if(clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn").length()>0){
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn"));
								}
							}else{
								JSONArray app = new JSONArray();
								app.put("Book");
								app.put("Ammend");
								app.put("Cancel");
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", app);
								}
							}
						}
					}
				}
			}else{
				JSONArray app = new JSONArray();
				app.put("Book");
				app.put("Ammend");
				app.put("Cancel");
				for(int k=0;k<advancedArr.length();k++){
					JSONObject advanced = advancedArr.getJSONObject(k);
					advanced.put("applicableOn", app);
				}
			}break;
		}
		}
	}
}
