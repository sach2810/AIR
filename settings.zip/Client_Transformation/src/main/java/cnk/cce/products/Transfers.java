package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.cce.configuration.CommonFunctions;

public class Transfers {
	public static String commissionContractValidityFrom,commissionContractValidityTo,sectorContractValidityFrom,sectorContractValidityTo,issuanceContractValidityFrom,issuanceContractValidityTo,managementContractValidityTo,discountContractValidityFrom,discountContractValidityTo,markupContractValidityFrom,markupContractValidityTo;
	public static String serviceContractValidityTo,serviceContractValidityFrom,segmentContractValidityTo,segmentContractValidityFrom,stdContractValidityFrom,stdContractValidityTo,overContractValidityFrom,overContractValidityTo,plbContractValidityFrom,plbContractValidityTo,destinationContractValidityFrom,destinationContractValidityTo;
	public static String destLocalID,managementContractValidityFrom,stdLocalID,overridingLocalID,plbLocalID,sectorWiseLocalID,segmentLocalID,serviceLocalID,mngtLocalID,discountLocalID,markupLocalID,destinationLocalID,issuanceLocalID,commissionLocalID;
	public static String stdAdvanceDefinitionId,destAdvanceDefinitionId=null,overridingAdvanceDefinitionId,plbAdvanceDefinitionId,sectorWiseAdvanceDefinitionId,segmentAdvanceDefinitionId,serviceAdvanceDefinitionId,mngtAdvanceDefinitionId,discountAdvanceDefinitionId,destinationAdvanceDefinitionId,issuanceAdvanceDefinitionId,commissionAdvanceDefinitionId,markupAdvanceDefinitionId;
	public static JSONArray plbapplicableOnArray,segmentapplicableOnArray,serviceapplicableOnArray;
	
	public static JSONObject appendTransfersCommercialDetails(String advancedDT, String calculationDT, String commercialName, JSONObject mdmCommDefn,JSONObject mainJson, String productName, boolean advancedApplicable, String id) throws Exception {
		JSONObject advanced = new JSONObject();
		JSONObject calculation = new JSONObject();
		advanced.put("type", "advanced");
		calculation.put("type", "calculation");
		advanced.put("selectedRow", id);
		advanced.put("contractValidity", getContractValidity(commercialName));
		//CommonFunctions.setMDMRuleID(commercialName,calculation);
		setRuleID(commercialName,advanced,calculation,id);
		CommonFunctions.setCalculationParameters(commercialName,calculation,mainJson);
		JSONArray advancedArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		advancedArr.put(advanced);
		calcArr.put(calculation);
		mainJson.put(advancedDT, advancedArr);
		mainJson.put(calculationDT, calcArr);
		
		appendApplicableOnDetails(advancedArr,calcArr,commercialName,mdmCommDefn.getJSONArray("clientCommercialOtherHead"));
		
		JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray("advancedDefinitionData");
		if(advancedApplicable){
			switch(commercialName){
			case "Standard":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,stdAdvanceDefinitionId,commercialName);break;}
			case "Overriding":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,overridingAdvanceDefinitionId,commercialName);break;}
			case "PLB":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,plbAdvanceDefinitionId,commercialName);break;}
			case "SectorWiseIncentive":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,sectorWiseAdvanceDefinitionId,commercialName);break;}
			case "DestinationIncentive":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,destinationAdvanceDefinitionId,commercialName);break;}
			case "SegmentFee":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,segmentAdvanceDefinitionId,commercialName);break;}
			case "ServiceCharge":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,serviceAdvanceDefinitionId,commercialName);break;}
			case "ManagementFee":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,mngtAdvanceDefinitionId,commercialName);break;}
			case "Discount":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,discountAdvanceDefinitionId,commercialName);break;}
			case "MarkUp":{setTransfersAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,markupAdvanceDefinitionId,commercialName);break;}
			default:System.out.println("default of appendAccoCommercialDetails due to: "+commercialName);
			}
		}
		return mainJson;
	}
	
	
	private static void setTransfersAdvancedDefinition(JSONArray advancedArr, JSONArray calcArr, JSONArray advancedDefinitionData, String advDefnID, String commercialName) {
		for(int i=0;i<advancedDefinitionData.length();i++){
			if(advDefnID!=null){
				if(advancedDefinitionData.getJSONObject(i).get("_id").equals(advDefnID)){
					JSONObject advanceDefinitionTransportation = advancedDefinitionData.getJSONObject(i).getJSONObject("advanceDefinitionTransportation");
					appendTransportationAdvancedDefinition(advancedArr,calcArr,advanceDefinitionTransportation,advDefnID);
				}
			}
		}
	}
	
	
	public static void appendTransportationAdvancedDefinition(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionTransportation, String advDefnID) {
		for(int i=0;i<advancedArr.length();i++){
			JSONObject base = advancedArr.getJSONObject(i);
			JSONObject calculation = calcArr.getJSONObject(i);
			String baseID = base.getString("RuleID");
			String calcID = calculation.getString("RuleID");
			base.put("RuleID", baseID+advDefnID);
			base.put("entitySelectedRow", baseID+advDefnID);
			calculation.put("RuleID", calcID+advDefnID);
			calculation.put("selectedRow", baseID+advDefnID);
		}

		CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation, advancedArr, calcArr);
		appendVehicleDetails(advancedArr,calcArr,advanceDefinitionTransportation);

		for(int i=0;i<calcArr.length();i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			/*if(advanceDefinitionTransportation.has("rateTypeApplicableFor"))
				calculation.put("rateTypeApplicableFor", advanceDefinitionTransportation.getString("rateTypeApplicableFor"));
			if(advanceDefinitionTransportation.has("category"))
				calculation.put("rateTypeApplicableForCategory", advanceDefinitionTransportation.getString("category"));*/
			if(advanceDefinitionTransportation.getBoolean("isPrepaid"))
				calculation.put("modeOfPayment", "Prepaid");
			else calculation.put("modeOfPayment", "Postpaid");
		}
	}
	
	
	private static void appendVehicleDetails(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionTransportation) {
		if(advanceDefinitionTransportation.has("vehicleDetails")){
			JSONObject vehicleDetails = advanceDefinitionTransportation.getJSONObject("vehicleDetails");
			if(vehicleDetails.has("vehicles") && vehicleDetails.getJSONArray("vehicles").length()>0){
				JSONArray vehicles = vehicleDetails.getJSONArray("vehicles");
				int length= advancedArr.length();
				for(int i=0;i<length;i++){
					for(int j=0;j<vehicles.length();j++){
						JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
						JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
						JSONObject vehicle = vehicles.getJSONObject(j);
						if(vehicleDetails.getBoolean("isInclusion")){
							/*if(vehicle.has("sippOrACRISScode"))
								calculation.put("sippOrACRISScode", vehicle.getString("sippOrACRISScode"));*/
							if(vehicle.has("vehicleCategory"))
								calculation.put("vehicleCategory", vehicle.getString("vehicleCategory"));
							if(vehicle.has("vehicleName"))
								calculation.put("vehicleName", vehicle.getString("vehicleName"));
						}else{
							/*if(vehicle.has("sippOrACRISScode"))
								calculation.put("sippOrACRISScode_exclusion", vehicle.getString("sippOrACRISScode"));*/
							if(vehicle.has("vehicleCategory"))
								calculation.put("vehicleCategory_exclusion", vehicle.getString("vehicleCategory"));
							if(vehicle.has("vehicleName"))
								calculation.put("vehicleName_exclusion", vehicle.getString("vehicleName"));
						}
						CommonFunctions.setRuleID(advancedArr, calcArr, base, calculation, vehicle.getString("_id"));
					}
				}
				for(int i=0;i<length;i++){
					advancedArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
	}
	
	
	private static void setRuleID(String commercialName, JSONObject advanced, JSONObject calculation, String id) {
		switch(commercialName){
		case "Standard":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+stdLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+stdLocalID);
			advanced.put("agendaGroup", id+"_Standard");
			calculation.put("agendaGroup", id+"_Standard");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+stdLocalID);
		}break;
		case "Overriding":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+overridingLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+overridingLocalID);
			advanced.put("agendaGroup", id+"_Overriding");
			calculation.put("agendaGroup", id+"_Overriding");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+overridingLocalID);
		}break;
		case "PLB":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+plbLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+plbLocalID);
			advanced.put("agendaGroup", id+"_PLB");
			calculation.put("agendaGroup", id+"_PLB");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+plbLocalID);
		}break;
		case "SectorWiseIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+sectorWiseLocalID);
			advanced.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
		}break;
		case "DestinationIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+destinationLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+destinationLocalID);
			advanced.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+destinationLocalID);
		}break;
		case "SegmentFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+segmentLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+segmentLocalID);
			advanced.put("agendaGroup", id+"_SegmentFee");
			calculation.put("agendaGroup", id+"_SegmentFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+segmentLocalID);
		}break;
		case "ServiceCharge":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+serviceLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+serviceLocalID);
			advanced.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+serviceLocalID);
		}break;
		case "ManagementFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+mngtLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+mngtLocalID);
			advanced.put("agendaGroup", id+"_ManagementFee");
			calculation.put("agendaGroup", id+"_ManagementFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+mngtLocalID);
		}break;
		case "Discount":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+discountLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+discountLocalID);
			advanced.put("agendaGroup", id+"_Discount");
			calculation.put("agendaGroup", id+"_Discount");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+discountLocalID);
		}break;
		case "MarkUp":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+markupLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+markupLocalID);
			advanced.put("agendaGroup", id+"_MarkUp");
			calculation.put("agendaGroup", id+"_MarkUp");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+markupLocalID);
		}break;
		case "Commission":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+commissionLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+commissionLocalID);
			advanced.put("agendaGroup", id+"_Commission");
			calculation.put("agendaGroup", id+"_Commission");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+commissionLocalID);
		}break;
		default:System.out.println("default of Accomodation.setRuleID due to: "+commercialName);
		}
	}
	
	
	private static JSONObject getContractValidity(String commercialName) {
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		switch(commercialName){
		case "Standard":{
			contractValidity.put("from", stdContractValidityFrom);
			contractValidity.put("to", stdContractValidityTo);
			break;
		}
		case "Overriding":{
			contractValidity.put("from", overContractValidityFrom);
			contractValidity.put("to", overContractValidityTo);
			break;
		}
		case "PLB":{
			contractValidity.put("from", plbContractValidityFrom);
			contractValidity.put("to", plbContractValidityTo);
			break;
		}
		case "SectorWiseIncentive":{
			contractValidity.put("from", sectorContractValidityFrom);
			contractValidity.put("to", sectorContractValidityTo);
			break;
		}
		case "DestinationIncentive":{
			contractValidity.put("from", destinationContractValidityFrom);
			contractValidity.put("to", destinationContractValidityTo);
			break;
		}
		case "SegmentFee":{
			contractValidity.put("from", segmentContractValidityFrom);
			contractValidity.put("to", segmentContractValidityTo);
			break;
		}
		case "ServiceCharge":{
			contractValidity.put("from", serviceContractValidityFrom);
			contractValidity.put("to", serviceContractValidityTo);
			break;
		}
		case "ManagementFee":{
			contractValidity.put("from", managementContractValidityFrom);
			contractValidity.put("to", managementContractValidityTo);
			break;
		}
		case "Discount":{
			contractValidity.put("from", discountContractValidityFrom);
			contractValidity.put("to", discountContractValidityTo);
			break;
		}
		case "MarkUp":{
			contractValidity.put("from", markupContractValidityFrom);
			contractValidity.put("to", markupContractValidityTo);
			break;
		}
		default:System.out.println("default of Accomodation.getContractValidity due to: "+commercialName);
		}
		return contractValidity;
	}
	
	
	private static void appendApplicableOnDetails(JSONArray advancedArr, JSONArray calculationArr, String commercialName, JSONArray clientCommercialOtherHead) {
		switch(commercialName){
		case "PLB":{
			if(plbapplicableOnArray!=null && plbapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<plbapplicableOnArray.length();i++){
					String applicableOnID = plbapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								JSONObject plb = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("plb");
								if(CommonFunctions.plbOH.equals("slab")){
									JSONObject slab = plb.getJSONObject("slab");
									if(slab.has("slabType"))
										calculation.put("slabType", slab.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+slab.get("fromValue")+";"+slab.get("toValue"));
								}else if(plb.has("retention")){
									JSONObject retention = plb.getJSONObject("retention");
									if(retention.has("slabType"))
										calculation.put("slabType", retention.getString("slabType"));
									String slabTypeValue="BETWEEN;";
									JSONArray currencyDetails = retention.getJSONObject("details").getJSONArray("currencyDetails");
									for(int k=0;k<currencyDetails.length();k++){
										JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
										slabTypeValue+=currencyDetailsObject.get("fromValue")+";"+currencyDetailsObject.get("toValue");
									}
									calculation.put("slabTypeValue", slabTypeValue);
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "SegmentFee":{
			if(segmentapplicableOnArray!=null && segmentapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<segmentapplicableOnArray.length();i++){
					String applicableOnID = segmentapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								if(clientCommercialOtherHeadObject.has("commercialHeads") && clientCommercialOtherHeadObject.getJSONObject("commercialHeads").has("segmentFees")){
									JSONObject segmentFees = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("segmentFees");
									calculation.put("slabType", segmentFees.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+segmentFees.getString("fromValue")+";"+segmentFees.getString("toValue"));
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "ServiceCharge":{
			if(serviceapplicableOnArray!=null && serviceapplicableOnArray.length()>0){
				for(int i=0;i<serviceapplicableOnArray.length();i++){
					String applicableOnID = serviceapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							if(clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn").length()>0){
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn"));
								}
							}else{
								JSONArray app = new JSONArray();
								app.put("Book");
								app.put("Ammend");
								app.put("Cancel");
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", app);
								}
							}
						}
					}
				}
			}else{
				JSONArray app = new JSONArray();
				app.put("Book");
				app.put("Ammend");
				app.put("Cancel");
				for(int k=0;k<advancedArr.length();k++){
					JSONObject advanced = advancedArr.getJSONObject(k);
					advanced.put("applicableOn", app);
				}
			}break;
		}
		}
	}
}
