package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.cce.configuration.CommonFunctions;

public class Activities {
	public static String sectorContractValidityFrom,sectorContractValidityTo,issuanceContractValidityFrom,issuanceContractValidityTo,managementContractValidityTo,discountContractValidityFrom,discountContractValidityTo,markupContractValidityFrom,markupContractValidityTo,destinationContractValidityTo;
	public static String serviceContractValidityTo,serviceContractValidityFrom,segmentContractValidityTo,segmentContractValidityFrom,stdContractValidityFrom,stdContractValidityTo,overContractValidityFrom,overContractValidityTo,plbContractValidityFrom,plbContractValidityTo,destinationContractValidityFrom;
	public static String destLocalID,managementContractValidityFrom,stdLocalID,overridingLocalID,plbLocalID,sectorWiseLocalID,segmentLocalID,serviceLocalID,mngtLocalID,discountLocalID,markupLocalID,destinationLocalID,issuanceLocalID,issuanceAdvanceDefinitionId,commissionAdvanceDefinitionId,markupAdvanceDefinitionId;
	public static String stdAdvanceDefinitionId,destAdvanceDefinitionId,overridingAdvanceDefinitionId,plbAdvanceDefinitionId,sectorWiseAdvanceDefinitionId,segmentAdvanceDefinitionId,serviceAdvanceDefinitionId,mngtAdvanceDefinitionId,discountAdvanceDefinitionId,destinationAdvanceDefinitionId;
	public static JSONArray plbapplicableOnArray,segmentapplicableOnArray,serviceapplicableOnArray;

	public static JSONObject appendActivitiesCommercialDetails(String advancedDT, String calculationDT, String commercialName, JSONObject mdmCommDefn,JSONObject mainJson, String productName, boolean advancedApplicable, String id) throws Exception {
		JSONObject advanced = new JSONObject();
		JSONObject calculation = new JSONObject();
		advanced.put("type", "advanced");
		calculation.put("type", "calculation");
		advanced.put("selectedRow", id);
		advanced.put("contractValidity", getContractValidity(commercialName));
		//CommonFunctions.setMDMRuleID(commercialName,calculation);
		setRuleID(commercialName,advanced,calculation,id);
		CommonFunctions.setCalculationParameters(commercialName,calculation,mainJson);
		JSONArray advancedArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		advancedArr.put(advanced);
		calcArr.put(calculation);
		mainJson.put(advancedDT, advancedArr);
		mainJson.put(calculationDT, calcArr);
		
		appendApplicableOnDetails(advancedArr,calcArr,commercialName,mdmCommDefn.getJSONArray("clientCommercialOtherHead"));
		
		JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray("advancedDefinitionData");
		if(advancedApplicable){
			switch(commercialName){
			case "Standard":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,stdAdvanceDefinitionId,commercialName);break;}
			case "Overriding":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,overridingAdvanceDefinitionId,commercialName);break;}
			case "PLB":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,plbAdvanceDefinitionId,commercialName);break;}
			case "SectorWiseIncentive":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,sectorWiseAdvanceDefinitionId,commercialName);break;}
			case "DestinationIncentive":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,destinationAdvanceDefinitionId,commercialName);break;}
			case "SegmentFee":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,segmentAdvanceDefinitionId,commercialName);break;}
			case "ServiceCharge":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,serviceAdvanceDefinitionId,commercialName);break;}
			case "ManagementFee":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,mngtAdvanceDefinitionId,commercialName);break;}
			case "Discount":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,discountAdvanceDefinitionId,commercialName);break;}
			case "MarkUp":{setAdvancedDefinition(advancedArr,calcArr,advancedDefinitionData,markupAdvanceDefinitionId,commercialName);break;}
			default:System.out.println("default of appendCommercialDetails due to: "+commercialName);
			}
		}
		return mainJson;
	}
	
	
	public static void getOtherFeesAdvancedDefinition(JSONArray otherFeeArr, JSONObject advanceDefinition){
		if(advanceDefinition.has("connectivity") && advanceDefinition.getJSONObject("connectivity")!=null){
			JSONObject connectivity = advanceDefinition.getJSONObject("connectivity");
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierType", connectivity.getString("supplierType"));
				if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplier", connectivity.getString("supplierName"));
			}
		}
		
		if(advanceDefinition.has("credentials") && advanceDefinition.getJSONArray("credentials").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinition.getJSONArray("credentials"), "credentials");
		
		if(advanceDefinition.has("others")){
			JSONObject others = advanceDefinition.getJSONObject("others");

			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				otherFee.put("bookingType", others.getString("bookingType"));
			}
		}

		setOtherFeeValidity(otherFeeArr,advanceDefinition);
		CommonFunctions.setTransportationOtherFeesDestination(otherFeeArr, advanceDefinition);
	}
	
	
	private static void setOtherFeeValidity(JSONArray otherFeeArr, JSONObject advanceDefinition) {
		if (advanceDefinition.has("validity")) {
			JSONObject validity = advanceDefinition.getJSONObject("validity");
			if(validity.has("validityType"))
				switch (validity.getString("validityType")) {
				case "sale": {
					setSaleTravelDateOF(validity.getJSONArray("sale"),"sale", otherFeeArr);
					break;
				}
				case "travel": {
					setSaleTravelDateOF(validity.getJSONArray("travel"),"travel", otherFeeArr);
					break;
				}
				case "sale+travel": {
					int length = otherFeeArr.length();
					for (int i = 0; i < validity.getJSONArray("salePlusTravel").length(); i++) {
						for(int j = 0; j<length; j++){
							JSONObject otherFeeObj = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(j).toString()));								
							JSONObject object = validity.getJSONArray("salePlusTravel").getJSONObject(i);
							if(object.has("sales")){
								JSONArray incArr = new JSONArray();
								JSONArray excArr = new JSONArray();
								JSONObject incObj = new JSONObject();
								JSONObject excObj = new JSONObject();
								if (object.getJSONObject("sales").has("saleFrom")) {
									if (object.getJSONObject("sales").has("saleTo")) {
										incObj.put("operator", "BETWEEN");
										incObj.put("from", object.getJSONObject("sales").getString("saleFrom").substring(0, 19));
										incObj.put("to", object.getJSONObject("sales").getString("saleTo").substring(0, 19));
									} else {
										incObj.put("operator", "GREATERTHANEQUALTO");
										incObj.put("value", object.getJSONObject("sales").getString("saleFrom").substring(0, 19));
									}
								} else if (object.getJSONObject("sales").has("saleTo")) {
									incObj.put("operator", "LESSTHANEQUALTO");
									incObj.put("value", object.getJSONObject("sales").getString("saleTo").substring(0, 19));
								}
								if (object.getJSONObject("sales").has("blockOutFrom")) {
									if (object.getJSONObject("sales").has("blockOutTo")) {
										excObj.put("operator", "BETWEEN");
										excObj.put("from", object.getJSONObject("sales").getString("blockOutFrom").substring(0, 19));
										excObj.put("to", object.getJSONObject("sales").getString("blockOutTo").substring(0, 19));
									} else {
										excObj.put("operator", "GREATERTHANEQUALTO");
										excObj.put("value", object.getJSONObject("sales").getString("blockOutFrom").substring(0, 19));
									}
								} else {
									if (object.getJSONObject("sales").has("blockOutTo")) {
										excObj.put("operator", "LESSTHANEQUALTO");
										excObj.put("value", object.getJSONObject("sales").getString("blockOutTo").substring(0, 19));
									}
								}
								if (incObj.length()!=0) {
									incArr.put(incObj);
								}
								if (excObj.length()!=0) {
									excArr.put(excObj);
								}		
								JSONArray date = new JSONArray();
								if (incArr.length() > 0) {
									JSONObject inclusion = new JSONObject();
									inclusion.put("inclusion", incArr);
									date.put(inclusion);
								}
								if (excArr.length() > 0) {
									JSONObject exclusion = new JSONObject();
									exclusion.put("exclusion", excArr);
									date.put(exclusion);
								}
								otherFeeObj.put("sale", date);
							}
							if(object.has("travel")){
								JSONArray incArr = new JSONArray();
								JSONArray excArr = new JSONArray();
								JSONObject incObj = new JSONObject();
								JSONObject excObj = new JSONObject();
								if (object.getJSONObject("travel").has("travelFrom")) {
									if (object.getJSONObject("travel").has("travelTo")) {
										incObj.put("operator", "BETWEEN");
										incObj.put("from", object.getJSONObject("travel").getString("travelFrom").substring(0, 19));
										incObj.put("to", object.getJSONObject("travel").getString("travelTo").substring(0, 19));
									} else {
										incObj.put("operator", "GREATERTHANEQUALTO");
										incObj.put("value", object.getString("travelFrom").substring(0, 19));
									}
								} else if (object.getJSONObject("travel").has("travelTo")) {
									incObj.put("operator", "LESSTHANEQUALTO");
									incObj.put("value", object.getJSONObject("travel").getString("travelTo").substring(0, 19));
								}
								if (object.getJSONObject("travel").has("blockOutFrom")) {
									if (object.getJSONObject("travel").has("blockOutTo")) {
										excObj.put("operator", "BETWEEN");
										excObj.put("from", object.getJSONObject("travel").getString("blockOutFrom").substring(0, 19));
										excObj.put("to", object.getJSONObject("travel").getString("blockOutTo").substring(0, 19));
									} else {
										excObj.put("operator", "GREATERTHANEQUALTO");
										excObj.put("value", object.getJSONObject("travel").getString("blockOutFrom").substring(0, 19));
									}
								} else {
									if (object.getJSONObject("travel").has("blockOutTo")) {
										excObj.put("operator", "LESSTHANEQUALTO");
										excObj.put("value", object.getJSONObject("travel").getString("blockOutTo").substring(0, 19));
									}
								}
								if (incObj.length()!=0) {
									incArr.put(incObj);
								}
								if (excObj.length()!=0) {
									excArr.put(excObj);
								}		
								JSONArray date = new JSONArray();
								if (incArr.length() > 0) {
									JSONObject inclusion = new JSONObject();
									inclusion.put("inclusion", incArr);
									date.put(inclusion);
								}
								if (excArr.length() > 0) {
									JSONObject exclusion = new JSONObject();
									exclusion.put("exclusion", excArr);
									date.put(exclusion);
								}
								otherFeeObj.put("travel", date);
							}
							CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFeeObj, object.getString("_id"));
						}	
					}
					for(int i=0;i<length;i++){
						otherFeeArr.remove(0);
					}
					break;
				}
				}
		}	
	}
	
	
	private static void setSaleTravelDateOF(JSONArray array, String validityType, JSONArray otherFeeArr) {
		String from = validityType+"From";
		String to =  validityType+"To";
		int length = otherFeeArr.length();
		for(int  i= 0; i<length; i++){
			for (int j = 0; j < array.length(); j++) {
				JSONObject otherFeeObj = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject object = array.getJSONObject(j);
				JSONArray incArr = new JSONArray();
				JSONArray excArr = new JSONArray();
				JSONObject incObj = new JSONObject();
				JSONObject excObj = new JSONObject();
				if (object.has(from)) {
					if (object.has(to)) {
						incObj.put("operator", "BETWEEN");
						incObj.put("from", object.getString(from).substring(0, 19));
						incObj.put("to", object.getString(to).substring(0, 19));
					} else {
						incObj.put("operator", "GREATERTHANEQUALTO");
						incObj.put("value", object.getString(from).substring(0, 19));
					}
				} else if (object.has(to)) {
					incObj.put("operator", "LESSTHANEQUALTO");
					incObj.put("value", object.getString(to).substring(0, 19));
				}
				if (object.has("blockOutFrom")) {
					if (object.has("blockOutTo")) {
						excObj.put("operator", "BETWEEN");
						excObj.put("from", object.getString("blockOutFrom").substring(0, 19));
						excObj.put("to", object.getString("blockOutTo").substring(0, 19));
					} else {
						excObj.put("operator", "GREATERTHANEQUALTO");
						excObj.put("value", object.getString("blockOutFrom").substring(0, 19));
					}
				} else {
					if (object.has("blockOutTo")) {
						excObj.put("operator", "LESSTHANEQUALTO");
						excObj.put("value", object.getString("blockOutTo").substring(0, 19));
					}
				}
				if (incObj.length()!=0) {
					incArr.put(incObj);
				}
				if (excObj.length()!=0) {
					excArr.put(excObj);
				}		
				JSONArray date = new JSONArray();
				if (incArr.length() > 0) {
					JSONObject inclusion = new JSONObject();
					inclusion.put("inclusion", incArr);
					date.put(inclusion);
				}
				if (excArr.length() > 0) {
					JSONObject exclusion = new JSONObject();
					exclusion.put("exclusion", excArr);
					date.put(exclusion);
				}
				otherFeeObj.put(validityType, date);
				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFeeObj, object.getString("_id"));
			}	
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	private static void setRuleID(String commercialName, JSONObject advanced, JSONObject calculation, String id) {
		switch(commercialName){
		case "Standard":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+stdLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+stdLocalID);
			advanced.put("agendaGroup", id+"_Standard");
			calculation.put("agendaGroup", id+"_Standard");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+stdLocalID);
		}break;
		case "Overriding":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+overridingLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+overridingLocalID);
			advanced.put("agendaGroup", id+"_Overriding");
			calculation.put("agendaGroup", id+"_Overriding");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+overridingLocalID);
		}break;
		case "PLB":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+plbLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+plbLocalID);
			advanced.put("agendaGroup", id+"_PLB");
			calculation.put("agendaGroup", id+"_PLB");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+plbLocalID);
		}break;
		case "SectorWiseIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+sectorWiseLocalID);
			advanced.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("agendaGroup", id+"_SectorWiseIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+sectorWiseLocalID);
		}break;
		case "DestinationIncentive":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+destinationLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+destinationLocalID);
			advanced.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("agendaGroup", id+"_DestinationIncentive");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+destinationLocalID);
		}break;
		case "SegmentFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+segmentLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+segmentLocalID);
			advanced.put("agendaGroup", id+"_SegmentFee");
			calculation.put("agendaGroup", id+"_SegmentFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+segmentLocalID);
		}break;
		case "ServiceCharge":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+serviceLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+serviceLocalID);
			advanced.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("agendaGroup", id+"_ServiceCharge");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+serviceLocalID);
		}break;
		case "ManagementFee":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+mngtLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+mngtLocalID);
			advanced.put("agendaGroup", id+"_ManagementFee");
			calculation.put("agendaGroup", id+"_ManagementFee");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+mngtLocalID);
		}break;
		case "Discount":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+discountLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+discountLocalID);
			advanced.put("agendaGroup", id+"_Discount");
			calculation.put("agendaGroup", id+"_Discount");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+discountLocalID);
		}break;
		case "MarkUp":{
			advanced.put("RuleID", "Advanced_"+commercialName+"_"+markupLocalID);
			calculation.put("RuleID", "Calculation_"+commercialName+"_"+markupLocalID);
			advanced.put("agendaGroup", id+"_MarkUp");
			calculation.put("agendaGroup", id+"_MarkUp");
			calculation.put("selectedRow", "Advanced_"+commercialName+"_"+markupLocalID);
		}break;
		default:System.out.println("default of Accomodation.setRuleID due to: "+commercialName);
		}
	}

	
	private static void setAdvancedDefinition(JSONArray advancedArr, JSONArray calcArr, JSONArray advancedDefinitionData, String advDefnID, String commercialName) {
		for(int i=0;i<advancedDefinitionData.length();i++){
			if(advDefnID!=null && advancedDefinitionData.getJSONObject(i).get("_id").equals(advDefnID)){
				JSONObject advanceDefinitionActivities = advancedDefinitionData.getJSONObject(i).getJSONObject("advanceDefinitionActivities");
				appendAdvancedDefinition(advancedArr,calcArr,advanceDefinitionActivities,advDefnID);
			}
		}	
	}

	
	public static void appendAdvancedDefinition(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinition, String advDefnID) {
		for(int i=0;i<advancedArr.length();i++){
			JSONObject base = advancedArr.getJSONObject(i);
			JSONObject calculation = calcArr.getJSONObject(i);
			String baseID = base.getString("RuleID");
			String calcID = calculation.getString("RuleID");
			base.put("RuleID", baseID+advDefnID);
			calculation.put("RuleID", calcID+advDefnID);
			calculation.put("selectedRow", baseID+advDefnID);
		}	
		
		CommonFunctions.setTransportationAdvancedDefinition(advanceDefinition, advancedArr, calcArr);
	}
	
	
	public static JSONObject getContractValidity(String commercialName) {
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		switch(commercialName){
		case "Standard":{
			contractValidity.put("from", stdContractValidityFrom);
			contractValidity.put("to", stdContractValidityTo);
			break;
		}
		case "Overriding":{
			contractValidity.put("from", overContractValidityFrom);
			contractValidity.put("to", overContractValidityTo);
			break;
		}
		case "PLB":{
			contractValidity.put("from", plbContractValidityFrom);
			contractValidity.put("to", plbContractValidityTo);
			break;
		}
		case "SectorWiseIncentive":{
			contractValidity.put("from", sectorContractValidityFrom);
			contractValidity.put("to", sectorContractValidityTo);
			break;
		}
		case "DestinationIncentive":{
			contractValidity.put("from", destinationContractValidityFrom);
			contractValidity.put("to", destinationContractValidityTo);
			break;
		}
		case "SegmentFee":{
			contractValidity.put("from", segmentContractValidityFrom);
			contractValidity.put("to", segmentContractValidityTo);
			break;
		}
		case "ServiceCharge":{
			contractValidity.put("from", serviceContractValidityFrom);
			contractValidity.put("to", serviceContractValidityTo);
			break;
		}
		case "ManagementFee":{
			contractValidity.put("from", managementContractValidityFrom);
			contractValidity.put("to", managementContractValidityTo);
			break;
		}
		case "Discount":{
			contractValidity.put("from", discountContractValidityFrom);
			contractValidity.put("to", discountContractValidityTo);
			break;
		}
		case "MarkUp":{
			contractValidity.put("from", markupContractValidityFrom);
			contractValidity.put("to", markupContractValidityTo);
			break;
		}
		default:System.out.println("default of Accomodation.getContractValidity due to: "+commercialName);
		}
		return contractValidity;
	}

	
	private static void appendApplicableOnDetails(JSONArray advancedArr, JSONArray calculationArr, String commercialName, JSONArray clientCommercialOtherHead) {
		switch(commercialName){
		case "PLB":{
			if(plbapplicableOnArray!=null && plbapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<plbapplicableOnArray.length();i++){
					String applicableOnID = plbapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								JSONObject plb = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("plb");
								if(CommonFunctions.plbOH.equals("slab")){
									JSONObject slab = plb.getJSONObject("slab");
									if(slab.has("slabType"))
										calculation.put("slabType", slab.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+slab.get("fromValue")+";"+slab.get("toValue"));
								}else if(plb.has("retention")){
									JSONObject retention = plb.getJSONObject("retention");
									if(retention.has("slabType"))
										calculation.put("slabType", retention.getString("slabType"));
									String slabTypeValue="BETWEEN;";
									JSONArray currencyDetails = retention.getJSONObject("details").getJSONArray("currencyDetails");
									for(int k=0;k<currencyDetails.length();k++){
										JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
										slabTypeValue+=currencyDetailsObject.get("fromValue")+";"+currencyDetailsObject.get("toValue");
									}
									calculation.put("slabTypeValue", slabTypeValue);
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "SegmentFee":{
			if(segmentapplicableOnArray!=null && segmentapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<segmentapplicableOnArray.length();i++){
					String applicableOnID = segmentapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								if(clientCommercialOtherHeadObject.has("commercialHeads") && clientCommercialOtherHeadObject.getJSONObject("commercialHeads").has("segmentFees")){
									JSONObject segmentFees = clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONObject("segmentFees");
									calculation.put("slabType", segmentFees.getString("slabType"));
									calculation.put("slabTypeValue", "BETWEEN;"+segmentFees.getString("fromValue")+";"+segmentFees.getString("toValue"));
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, applicableOnID);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}break;
		}
		case "ServiceCharge":{
			if(serviceapplicableOnArray!=null && serviceapplicableOnArray.length()>0){
				for(int i=0;i<serviceapplicableOnArray.length();i++){
					String applicableOnID = serviceapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString("_id"))){
							if(clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn").length()>0){
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", clientCommercialOtherHeadObject.getJSONObject("commercialHeads").getJSONArray("serviceChargeApplicableOn"));
								}
							}else{
								JSONArray app = new JSONArray();
								app.put("Book");
								app.put("Ammend");
								app.put("Cancel");
								for(int k=0;k<advancedArr.length();k++){
									JSONObject advanced = advancedArr.getJSONObject(k);
									advanced.put("applicableOn", app);
								}
							}
						}
					}
				}
			}else{
				JSONArray app = new JSONArray();
				app.put("Book");
				app.put("Ammend");
				app.put("Cancel");
				for(int k=0;k<advancedArr.length();k++){
					JSONObject advanced = advancedArr.getJSONObject(k);
					advanced.put("applicableOn", app);
				}
			}break;
		}
		}
	}
}
