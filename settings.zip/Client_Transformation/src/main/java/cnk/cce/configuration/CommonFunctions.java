package cnk.cce.configuration;

import java.text.ParseException;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.products.Accomodation;
import cnk.cce.products.Activities;
import cnk.cce.products.Air;
import cnk.cce.products.Bus;
import cnk.cce.products.CarRentals;
import cnk.cce.products.Cruise;
import cnk.cce.products.Holidays;
import cnk.cce.products.Insurance;
import cnk.cce.products.Rail;
import cnk.cce.products.Transfers;
import cnk.cce.products.Visa;

public class CommonFunctions {
	public static int priority=0;
	public static String stdretentionPercentage,stdretentionAmount,stdAdditionalPercentage,stdAdditionalAmount,overretentionPercentage,overretentionAmount,overAdditionalPercentage,overAdditionalAmount,plbretentionPercentage,plbretentionAmount,plbAdditionalPercentage,plbAdditionalAmount,serviceretentionPercentage,serviceretentionAmount,serviceAdditionalPercentage,serviceAdditionalAmount,stdFareComponent,overFareComponent,plbFareComponent,serviceFareComponent;
	public static String sectorCurrency,segmentCurrency,mngtCurrency,discountCurrency,markUpCurrency,sectorFareComponent,discountFareComponent,markUpFareComponent,mngtFareComponent,segmentFareComponent,mngtretentionPercentage,mngtretentionAmount,discountretentionPercentage,discountretentionAmount,markUpretentionPercentage,markUpretentionAmount,segmentretentionPercentage,destinationFareComponent,destinationCurrency,destinationAdditionalAmount,serviceCurrency;
	public static String segmentAdditionalPercentage,segmentAdditionalAmount,sectorAdditionalPercentage,sectorAdditionalAmount,mngtAdditionalPercentage,mngtAdditionalAmount,discountAdditionalPercentage,discountAdditionalAmount,markUpPercentage,markUpAmount,sectorretentionPercentage,sectorretentionAmount,segmentretentionAmount,commissionretentionPercentage,commissionretentionAmount,issuanceretentionPercentage,issuanceretentionAmount,stdCurrency,entityType;
	public static String markUpContractValidityFrom,markUpContractValidityTo,minSellingPriceCurrency,minSellingPriceAmount,markUpRateType,issuanceAdditionalPercentage,issuanceFareComponent,issuanceCurrency,issuanceAdditionalAmount,commissionAdditionalPercentage,commissionFareComponent,commissionCurrency,commissionAdditionalAmount,overCurrency,plbCurrency,destinationretentionPercentage,destinationretentionAmount,destinationAdditionalPercentage,retention,plbOH;
	public static String stdclientCommercialDataID,overclientCommercialDataID,plbclientCommercialDataID,segmentclientCommercialDataID,sectorclientCommercialDataID,destinationclientCommercialDataID,commissionclientCommercialDataID,issuanceclientCommercialDataID,serviceclientCommercialDataID,discountclientCommercialDataID,mngtclientCommercialDataID,markupclientCommercialDataID;

	public static void setContractValidity(JSONObject jsonObject, String commercialName, String productName){
		String from,to;
		from = jsonObject.getJSONObject("effectiveDates").get("from").toString().substring(0, 19);
		to = jsonObject.getJSONObject("effectiveDates").get("to").toString().substring(0, 19);
		switch(commercialName){
		case "Standard Commercial":{
			switch(productName){
			case "air":{Air.stdContractValidityFrom=from;Air.stdContractValidityTo=to;break;}
			case "activities":{Activities.stdContractValidityFrom=from;Activities.stdContractValidityTo=to;break;}
			case "accomodation":{Accomodation.stdContractValidityFrom=from;Accomodation.stdContractValidityTo=to;break;}
			case "carrentals":{CarRentals.stdContractValidityFrom=from;CarRentals.stdContractValidityTo=to;break;}
			case "rail":{Rail.stdContractValidityFrom=from;Rail.stdContractValidityTo=to;break;}
			case "cruise":{Cruise.stdContractValidityFrom=from;Cruise.stdContractValidityTo=to;break;}
			case "bus":{Bus.stdContractValidityFrom=from;Bus.stdContractValidityTo=to;break;}
			case "transfers":{Transfers.stdContractValidityFrom=from;Transfers.stdContractValidityTo=to;break;}
			case "insurance":{Insurance.stdContractValidityFrom=from;Insurance.stdContractValidityTo=to;break;}
			case "holidays":{Holidays.stdContractValidityFrom=from;Holidays.stdContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Overriding Commission":{
			switch(productName){
			case "air":{Air.overContractValidityFrom=from;Air.overContractValidityTo=to;break;}
			case "activities":{Activities.overContractValidityFrom=from;Activities.overContractValidityTo=to;break;}
			case "accomodation":{Accomodation.overContractValidityFrom=from;Accomodation.overContractValidityTo=to;break;}
			case "carrentals":{CarRentals.overContractValidityFrom=from;CarRentals.overContractValidityTo=to;break;}
			case "rail":{Rail.overContractValidityFrom=from;Rail.overContractValidityTo=to;break;}
			case "cruise":{Cruise.overContractValidityFrom=from;Cruise.overContractValidityTo=to;break;}
			case "bus":{Bus.overContractValidityFrom=from;Bus.overContractValidityTo=to;break;}
			case "transfers":{Transfers.overContractValidityFrom=from;Transfers.overContractValidityTo=to;break;}
			case "insurance":{Insurance.overContractValidityFrom=from;Insurance.overContractValidityTo=to;break;}
			case "holidays":{Holidays.overContractValidityFrom=from;Holidays.overContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Productivity Linked Bonus":{
			switch(productName){
			case "air":{Air.plbContractValidityFrom=from;Air.plbContractValidityTo=to;break;}
			case "activities":{Activities.plbContractValidityFrom=from;Activities.plbContractValidityTo=to;break;}
			case "accomodation":{Accomodation.plbContractValidityFrom=from;Accomodation.plbContractValidityTo=to;break;}
			case "carrentals":{CarRentals.plbContractValidityFrom=from;CarRentals.plbContractValidityTo=to;break;}
			case "rail":{Rail.plbContractValidityFrom=from;Rail.plbContractValidityTo=to;break;}
			case "cruise":{Cruise.plbContractValidityFrom=from;Cruise.plbContractValidityTo=to;break;}
			case "bus":{Bus.plbContractValidityFrom=from;Bus.plbContractValidityTo=to;break;}
			case "transfers":{Transfers.plbContractValidityFrom=from;Transfers.plbContractValidityTo=to;break;}
			case "insurance":{Insurance.plbContractValidityFrom=from;Insurance.plbContractValidityTo=to;break;}
			case "holidays":{Holidays.plbContractValidityFrom=from;Holidays.plbContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Sector Incentives":{
			switch(productName){
			case "air":{Air.sectorContractValidityFrom=from;Air.sectorContractValidityTo=to;break;}
			case "activities":{Activities.sectorContractValidityFrom=from;Activities.sectorContractValidityTo=to;break;}
			case "accomodation":{/*Accomodation.sectorContractValidityFrom=from;Accomodation.sectorContractValidityTo=to;*/break;}
			case "carrentals":{CarRentals.sectorContractValidityFrom=from;CarRentals.sectorContractValidityTo=to;break;}
			case "rail":{Rail.sectorContractValidityFrom=from;Rail.sectorContractValidityTo=to;break;}
			case "cruise":{Cruise.sectorContractValidityFrom=from;Cruise.sectorContractValidityTo=to;break;}
			case "bus":{Bus.sectorContractValidityFrom=from;Bus.sectorContractValidityTo=to;break;}
			case "transfers":{Transfers.sectorContractValidityFrom=from;Transfers.sectorContractValidityTo=to;break;}
			case "insurance":{Insurance.sectorContractValidityFrom=from;Insurance.sectorContractValidityTo=to;break;}
			case "holidays":{Holidays.sectorContractValidityFrom=from;Holidays.sectorContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Segment Fees":{
			switch(productName){
			case "air":{Air.segmentContractValidityFrom=from;Air.segmentContractValidityTo=to;break;}
			case "activities":{Activities.segmentContractValidityFrom=from;Activities.segmentContractValidityTo=to;break;}
			case "accomodation":{Accomodation.segmentContractValidityFrom=from;Accomodation.segmentContractValidityTo=to;break;}
			case "carrentals":{CarRentals.segmentContractValidityFrom=from;CarRentals.segmentContractValidityTo=to;break;}
			case "rail":{Rail.segmentContractValidityFrom=from;Rail.segmentContractValidityTo=to;break;}
			case "cruise":{Cruise.segmentContractValidityFrom=from;Cruise.segmentContractValidityTo=to;break;}
			case "bus":{Bus.segmentContractValidityFrom=from;Bus.segmentContractValidityTo=to;break;}
			case "transfers":{Transfers.segmentContractValidityFrom=from;Transfers.segmentContractValidityTo=to;break;}
			case "insurance":{Insurance.segmentContractValidityFrom=from;Insurance.segmentContractValidityTo=to;break;}
			case "holidays":{Holidays.segmentContractValidityFrom=from;Holidays.segmentContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Segments Fees":{
			switch(productName){
			case "air":{Air.segmentContractValidityFrom=from;Air.segmentContractValidityTo=to;break;}
			case "activities":{Activities.segmentContractValidityFrom=from;Activities.segmentContractValidityTo=to;break;}
			case "accomodation":{Accomodation.segmentContractValidityFrom=from;Accomodation.segmentContractValidityTo=to;break;}
			case "carrentals":{CarRentals.segmentContractValidityFrom=from;CarRentals.segmentContractValidityTo=to;break;}
			case "rail":{Rail.segmentContractValidityFrom=from;Rail.segmentContractValidityTo=to;break;}
			case "cruise":{Cruise.segmentContractValidityFrom=from;Cruise.segmentContractValidityTo=to;break;}
			case "bus":{Bus.segmentContractValidityFrom=from;Bus.segmentContractValidityTo=to;break;}
			case "transfers":{Transfers.segmentContractValidityFrom=from;Transfers.segmentContractValidityTo=to;break;}
			case "insurance":{Insurance.segmentContractValidityFrom=from;Insurance.segmentContractValidityTo=to;break;}
			case "holidays":{Holidays.segmentContractValidityFrom=from;Holidays.segmentContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Management Fee":{
			switch(productName){
			case "air":{Air.managementContractValidityFrom=from;Air.managementContractValidityTo=to;break;}
			case "activities":{Activities.managementContractValidityFrom=from;Activities.managementContractValidityTo=to;break;}
			case "accomodation":{Accomodation.managementContractValidityFrom=from;Accomodation.managementContractValidityTo=to;break;}
			case "carrentals":{CarRentals.managementContractValidityFrom=from;CarRentals.managementContractValidityTo=to;break;}
			case "rail":{Rail.managementContractValidityFrom=from;Rail.managementContractValidityTo=to;break;}
			case "cruise":{Cruise.managementContractValidityFrom=from;Cruise.managementContractValidityTo=to;break;}
			case "bus":{Bus.managementContractValidityFrom=from;Bus.managementContractValidityTo=to;break;}
			case "transfers":{Transfers.managementContractValidityFrom=from;Transfers.managementContractValidityTo=to;break;}
			case "insurance":{Insurance.managementContractValidityFrom=from;Insurance.managementContractValidityTo=to;break;}
			case "holidays":{Holidays.managementContractValidityFrom=from;Holidays.managementContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Service Charges":{
			switch(productName){
			case "air":{Air.serviceContractValidityFrom=from;Air.serviceContractValidityTo=to;break;}
			case "activities":{Activities.serviceContractValidityFrom=from;Activities.serviceContractValidityTo=to;break;}
			case "accomodation":{Accomodation.serviceContractValidityFrom=from;Accomodation.serviceContractValidityTo=to;break;}
			case "carrentals":{CarRentals.serviceContractValidityFrom=from;CarRentals.serviceContractValidityTo=to;break;}
			case "rail":{Rail.serviceContractValidityFrom=from;Rail.serviceContractValidityTo=to;break;}
			case "cruise":{Cruise.serviceContractValidityFrom=from;Cruise.serviceContractValidityTo=to;break;}
			case "bus":{Bus.serviceContractValidityFrom=from;Bus.serviceContractValidityTo=to;break;}
			case "transfers":{Transfers.serviceContractValidityFrom=from;Transfers.serviceContractValidityTo=to;break;}
			case "insurance":{Insurance.serviceContractValidityFrom=from;Insurance.serviceContractValidityTo=to;break;}
			case "holidays":{Holidays.serviceContractValidityFrom=from;Holidays.serviceContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Discount":{
			switch(productName){
			case "air":{Air.discountContractValidityFrom=from;Air.discountContractValidityTo=to;break;}
			case "activities":{Activities.discountContractValidityFrom=from;Activities.discountContractValidityTo=to;break;}
			case "accomodation":{Accomodation.discountContractValidityFrom=from;Accomodation.discountContractValidityTo=to;break;}
			case "carrentals":{CarRentals.discountContractValidityFrom=from;CarRentals.discountContractValidityTo=to;break;}
			case "rail":{Rail.discountContractValidityFrom=from;Rail.discountContractValidityTo=to;break;}
			case "cruise":{Cruise.discountContractValidityFrom=from;Cruise.discountContractValidityTo=to;break;}
			case "bus":{Bus.discountContractValidityFrom=from;Bus.discountContractValidityTo=to;break;}
			case "transfers":{Transfers.discountContractValidityFrom=from;Transfers.discountContractValidityTo=to;break;}
			case "insurance":{Insurance.discountContractValidityFrom=from;Insurance.discountContractValidityTo=to;break;}
			case "holidays":{Holidays.discountContractValidityFrom=from;Holidays.discountContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Mark-up":{
			markUpContractValidityFrom=from;markUpContractValidityTo=to;break;
		}
		case "Destination Incentives":{
			switch(productName){
			case "air":{Air.destinationContractValidityFrom=from;Air.destinationContractValidityTo=to;break;}
			case "activities":{Activities.destinationContractValidityFrom=from;Activities.destinationContractValidityTo=to;break;}
			case "accomodation":{Accomodation.destinationContractValidityFrom=from;Accomodation.destinationContractValidityTo=to;break;}
			case "carrentals":{CarRentals.destinationContractValidityFrom=from;CarRentals.destinationContractValidityTo=to;break;}
			case "rail":{Rail.destinationContractValidityFrom=from;Rail.destinationContractValidityTo=to;break;}
			case "cruise":{Cruise.destinationContractValidityFrom=from;Cruise.destinationContractValidityTo=to;break;}
			case "bus":{Bus.destinationContractValidityFrom=from;Bus.destinationContractValidityTo=to;break;}
			case "transfers":{Transfers.destinationContractValidityFrom=from;Transfers.destinationContractValidityTo=to;break;}
			case "insurance":{Insurance.destinationContractValidityFrom=from;Insurance.destinationContractValidityTo=to;break;}
			case "holidays":{Holidays.destinationContractValidityFrom=from;Holidays.destinationContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Issuance Fees":{
			switch(productName){
			case "air":{Air.issuanceContractValidityFrom=from;Air.issuanceContractValidityTo=to;break;}
			case "activities":{Activities.issuanceContractValidityFrom=from;Activities.issuanceContractValidityTo=to;break;}
			case "accomodation":{/*Accomodation.issuanceContractValidityFrom=from;Accomodation.issuanceContractValidityTo=to;*/break;}
			case "carrentals":{CarRentals.issuanceContractValidityFrom=from;CarRentals.issuanceContractValidityTo=to;break;}
			case "rail":{Rail.issuanceContractValidityFrom=from;Rail.issuanceContractValidityTo=to;break;}
			case "cruise":{Cruise.issuanceContractValidityFrom=from;Cruise.issuanceContractValidityTo=to;break;}
			case "bus":{Bus.issuanceContractValidityFrom=from;Bus.issuanceContractValidityTo=to;break;}
			case "transfers":{Transfers.issuanceContractValidityFrom=from;Transfers.issuanceContractValidityTo=to;break;}
			case "insurance":{Insurance.issuanceContractValidityFrom=from;Insurance.issuanceContractValidityTo=to;break;}
			case "holidays":{Holidays.issuanceContractValidityFrom=from;Holidays.issuanceContractValidityTo=to;break;}
			default:System.out.println("deafult of productName > setContractValidity due to: "+productName);
			}
			break;
		}
		case "Commission":{Air.commissionContractValidityFrom=from;Air.commissionContractValidityTo=to;break;}
		default:System.out.println("default of setContractValidity due to commercialName: "+commercialName);
		}
	}


	public static void getOtherFeesArrayNonTP(JSONArray otherFeeArr, JSONArray jsonArray, String name, boolean isInclusion) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = otherFeeArr.getJSONObject(i);
			if(isInclusion)
				otherFee.put(name, array);
			else otherFee.put(name+"_exclusion", array);
		}
	}


	public static void getOtherFeesArrayNonTP(JSONArray otherFeeArr, JSONArray jsonArray, String name) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = otherFeeArr.getJSONObject(i);
			otherFee.put(name, array);
		}
	}


	public static void getPLBDates(JSONArray baseArr, JSONArray calcArr, JSONArray dateArr, String date, boolean inBase) {
		String from = date+"From";
		String to = date+"To";
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArr.length();j++){
				JSONObject dateObject = dateArr.getJSONObject(j);
				JSONObject trigPayout = getTriggerPayoutObject(dateObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject DATEInc = new JSONObject();
				JSONObject DATEExc = new JSONObject();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();
				JSONArray DateInclusionArr = new JSONArray();
				JSONArray DateExclusionArr = new JSONArray();
				JSONArray mainDateArray = new JSONArray();
				if(dateObject.has(from)){
					if(dateObject.has(to)){
						DATEInc.put("operator", "BETWEEN");
						DATEInc.put("from", dateObject.getString(from).substring(0, 19));
						DATEInc.put("to", dateObject.getString(to).substring(0, 19));
					}else{
						DATEInc.put("operator", "GREATERTHANEQUALTO");
						DATEInc.put("from", dateObject.getString(from).substring(0, 19));
					}
				}else if(dateObject.has(to)){
					DATEInc.put("operator", "LESSTHANEQUALTO");
					DATEInc.put("to", dateObject.getString(to).substring(0, 19));
				}

				if(dateObject.has("blockOutFrom")){
					if(dateObject.has("blockOutTo")){
						DATEExc.put("operator", "BETWEEN");
						DATEExc.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
						DATEExc.put("to", dateObject.getString("blockOutTo").substring(0, 19));
					}else{
						DATEExc.put("operator", "GREATERTHANEQUALTO");
						DATEExc.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
					}
				}else if(dateObject.has("blockOutTo")){
					DATEExc.put("operator", "LESSTHANEQUALTO");
					DATEExc.put("to", dateObject.getString("blockOutTo").substring(0, 19));
				}

				mainDateArray.put(trigPayout);

				if(DATEInc.has("operator")){
					DateInclusionArr.put(DATEInc);
					inclusion.put("inclusion", DateInclusionArr);
					mainDateArray.put(inclusion);
				}
				if(DATEExc.has("operator")){
					DateExclusionArr.put(DATEExc);
					exclusion.put("exclusion", DateExclusionArr);
					mainDateArray.put(exclusion);
				}

				if(inBase)
					base.put(date, mainDateArray);
				else calculation.put(date, mainDateArray);
				setRuleID(baseArr, calcArr, base, calculation, dateObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getArray(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, boolean isInclusion,boolean inBase) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<jsonArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject jsonObject = jsonArray.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(jsonObject.getJSONArray("triggerOrPayout"));
				JSONArray array = new JSONArray();
				JSONObject object = new JSONObject();
				array.put(triggerPayout);
				object.put(name, jsonObject.getString(name));
				array.put(object);

				if(isInclusion){
					if(inBase)
						base.put(name, array);
					else calculation.put(name, array);
				}else{
					if(inBase)
						base.put(name+"_exclusion", array);
					else calculation.put(name+"_exclusion", array);
				}

				setRuleID(baseArr, calcArr, base, calculation, jsonObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getArrayNonTP(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, boolean isInclusion, boolean inBase) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject calculation = calcArr.getJSONObject(i);
			if(isInclusion){
				if(inBase)
					base.put(name, array);
				else calculation.put(name, array);
			}else{
				if(inBase)
					base.put(name+"_exclusion", array);
				else calculation.put(name+"_exclusion", array);
			}
		}
	}


	public static void getConnectivityTP(JSONArray baseArr, JSONObject connectivity) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray("triggerOrPayout"));
			JSONArray connectivityArr = new JSONArray();
			JSONObject connectivityObject = new JSONObject();
			if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierType",connectivity.getString("supplierType"));
			if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierName",connectivity.getString("supplierId"));
			connectivityArr.put(triggerPayout);
			connectivityArr.put(connectivityObject);
			base.put("connectivity", connectivityArr);
		}
	}


	public static void getBookingTypeTP(JSONArray baseArr, JSONArray calcArr, JSONObject bookingType, boolean isInclusion, boolean inBase) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject triggerPayout = getTriggerPayoutObject(bookingType.getJSONArray("triggerOrPayout"));
			JSONArray bookingTypeArr = new JSONArray();
			JSONObject bookingTypeObject = new JSONObject();
			if(isInclusion)
				bookingTypeObject.put("bookingType",bookingType.getString("bookingType"));
			else bookingTypeObject.put("bookingType_exclusion",bookingType.getString("bookingType"));
			bookingTypeArr.put(triggerPayout);
			bookingTypeArr.put(bookingTypeObject);
			if(inBase){
				JSONObject base = baseArr.getJSONObject(i);
				base.put("bookingType", bookingTypeArr);
			}else{
				JSONObject calculation = calcArr.getJSONObject(i);
				calculation.put("bookingType", bookingTypeArr);
			}
		}
	}


	public static void setTravelTicketing(JSONObject base, JSONObject calculation, JSONObject validity) {
		switch(validity.getString("validityType")){
		case "ticketing":{
			base.put("ticketing", setTicketingDate(validity));
			break;
		}
		case "travel":{
			calculation.put("travel", setTravelDate(validity));
			break;
		}
		default:{
			int tickinc=0,travelinc=0;//,tickexc=0,travelexc=0;
			JSONArray tickincArr =new JSONArray();
			//JSONArray tickexcArr =new JSONArray();
			JSONArray travelincArr =new JSONArray();
			//JSONArray travelexcArr =new JSONArray();
			JSONArray ticketingPlusTravel = validity.getJSONArray("ticketingPlusTravel");
			for(int i=0;i<ticketingPlusTravel.length();i++){
				JSONObject indiObj = new JSONObject();
				//JSONObject indiBlockObj = new JSONObject();
				JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(i);
				if(ticketPlusTravelObj.has("ticketingFrom")){
					if(ticketPlusTravelObj.has("ticketingTo")){
						indiObj.put("operator","BETWEEN");
						indiObj.put("from", ticketPlusTravelObj.getString("ticketingFrom").substring(0, 19));
						indiObj.put("to", ticketPlusTravelObj.getString("ticketingTo").substring(0, 19));
					}else{
						indiObj.put("operator","GREATERTHANEQUALTO");
						indiObj.put("value", ticketPlusTravelObj.getString("ticketingFrom").substring(0, 19));
					}
				}else if(ticketPlusTravelObj.has("ticketingTo")){
					indiObj.put("operator","LESSTHANEQUALTO");
					indiObj.put("value", ticketPlusTravelObj.getString("ticketingTo").substring(0, 19));
				}
				/*if(ticketPlusTravelObj.has("blockOutFrom")){
					if(ticketPlusTravelObj.has("blockOutTo")){
						indiBlockObj.put("operator", "BETWEEN");
						indiBlockObj.put("from", ticketPlusTravelObj.getString("blockOutFrom").substring(0, 19));
						indiBlockObj.put("to", ticketPlusTravelObj.getString("blockOutTo").substring(0, 19));
					}else{
						indiBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiBlockObj.put("value", ticketPlusTravelObj.getString("blockOutFrom").substring(0, 19));
					}
				}else{
					if(ticketPlusTravelObj.has("blockOutTo")){
						indiBlockObj.put("operator", "LESSTHANEQUALTO");
						indiBlockObj.put("value", ticketPlusTravelObj.getString("blockOutTo").substring(0, 19));
					}
				}*/
				if(indiObj!=null){
					tickinc=1;tickincArr.put(indiObj);
				}
				/*if(indiBlockObj!=null){
					tickexc=1;tickexcArr.put(indiBlockObj);
				}*/

				if(ticketPlusTravelObj.has("travelFrom")){
					if(ticketPlusTravelObj.has("travelTo")){
						indiObj.put("operator","BETWEEN");
						indiObj.put("from", ticketPlusTravelObj.getString("travelFrom").substring(0, 19));
						indiObj.put("to", ticketPlusTravelObj.getString("travelTo").substring(0, 19));
					}else{
						indiObj.put("operator","GREATERTHANEQUALTO");
						indiObj.put("value", ticketPlusTravelObj.getString("travelFrom").substring(0, 19));
					}
				}else if(ticketPlusTravelObj.has("travelTo")){
					indiObj.put("operator","LESSTHANEQUALTO");
					indiObj.put("value", ticketPlusTravelObj.getString("travelTo").substring(0, 19));
				}
				/*if(ticketPlusTravelObj.has("blockOutFrom")){
					if(travelObject.has("blockOutTo")){
						indiBlockObj.put("operator", "BETWEEN");
						indiBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
						indiBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
					}
				}else{
					if(travelObject.has("blockOutTo")){
						indiBlockObj.put("operator", "LESSTHANEQUALTO");
						indiBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
					}
				}*/
				if(indiObj!=null){
					travelinc=1;travelincArr.put(indiObj);
				}
				/*if(indiBlockObj!=null){
					travelexc=1;travelexcArr.put(indiBlockObj);
				}*/
			}
			JSONArray ticketingDate = new JSONArray();
			if(tickinc==1){
				JSONObject inclusion = new JSONObject();
				inclusion.put("inclusion",tickincArr);
				ticketingDate.put(inclusion);
			}
			/*if(tickexc==1){
				JSONObject exclusion = new JSONObject();
				exclusion.put("exclusion",tickexcArr);
				ticketingDate.put(exclusion);
			}*/
			base.put("ticketing", ticketingDate);
			JSONArray travelDate = new JSONArray();
			if(travelinc==1){
				JSONObject inclusion = new JSONObject();
				inclusion.put("inclusion",travelincArr);
				travelDate.put(inclusion);
			}
			/*if(travelexc==1){
				JSONObject exclusion = new JSONObject();
				exclusion.put("exclusion",travelexcArr);
				travelDate.put(exclusion);
			}*/
			calculation.put("travel", travelDate);
		}break;
		}
	}


	public static JSONArray setTravelDate(JSONObject validity) {
		JSONArray travel = validity.getJSONArray("travel");
		JSONArray incArr =new JSONArray();
		//JSONArray excArr =new JSONArray();
		int inc=0;//,exc=0;
		for(int i=0;i<travel.length();i++){
			JSONObject travelObject =travel.getJSONObject(i);
			JSONObject indiObj = new JSONObject();
			//JSONObject indiBlockObj = new JSONObject();
			if(travelObject.has("from")){
				if(travelObject.has("to")){
					indiObj.put("operator","BETWEEN");
					indiObj.put("from", travelObject.getString("from").substring(0, 19));
					indiObj.put("to", travelObject.getString("to").substring(0, 19));
				}else{
					indiObj.put("operator","GREATERTHANEQUALTO");
					indiObj.put("value", travelObject.getString("from").substring(0, 19));
				}
			}else if(travelObject.has("to")){
				indiObj.put("operator","LESSTHANEQUALTO");
				indiObj.put("value", travelObject.getString("to").substring(0, 19));
			}
			/*if(travelObject.has("blockOutFrom")){
				if(travelObject.has("blockOutTo")){
					indiBlockObj.put("operator", "BETWEEN");
					indiBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
					indiBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
				}else{
					indiBlockObj.put("operator", "GREATERTHANEQUALTO");
					indiBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
				}
			}else{
				if(travelObject.has("blockOutTo")){
					indiBlockObj.put("operator", "LESSTHANEQUALTO");
					indiBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
				}
			}*/
			if(indiObj!=null){
				inc=1;incArr.put(indiObj);
			}
			/*if(indiBlockObj!=null){
				exc=1;excArr.put(indiBlockObj);
			}*/
		}
		JSONArray travelDate = new JSONArray();
		if(inc==1){
			JSONObject inclusion = new JSONObject();
			inclusion.put("inclusion",incArr);
			travelDate.put(inclusion);
		}
		/*if(exc==1){
			JSONObject exclusion = new JSONObject();
			exclusion.put("exclusion",excArr);
			travelDate.put(exclusion);
		}*/
		return travelDate;
	}


	public static JSONArray setTicketingDate(JSONObject validity) {
		JSONArray ticketing = validity.getJSONArray("ticketing");
		JSONArray incArr =new JSONArray();
		//JSONArray excArr =new JSONArray();
		int inc=0;//,exc=0;
		for(int i=0;i<ticketing.length();i++){
			JSONObject ticketingObject =ticketing.getJSONObject(i);
			JSONObject indiObj = new JSONObject();
			//JSONObject indiBlockObj = new JSONObject();
			if(ticketingObject.has("from")){
				if(ticketingObject.has("to")){
					indiObj.put("operator","BETWEEN");
					indiObj.put("from", ticketingObject.getString("from").substring(0, 19));
					indiObj.put("to", ticketingObject.getString("to").substring(0, 19));
				}else{
					indiObj.put("operator","GREATERTHANEQUALTO");
					indiObj.put("value", ticketingObject.getString("from").substring(0, 19));
				}
			}else if(ticketingObject.has("to")){
				indiObj.put("operator","LESSTHANEQUALTO");
				indiObj.put("value", ticketingObject.getString("to").substring(0, 19));
			}
			/*if(ticketingObject.has("blockOutFrom")){
				if(ticketingObject.has("blockOutTo")){
					indiBlockObj.put("operator", "BETWEEN");
					indiBlockObj.put("from", ticketingObject.getString("blockOutFrom").substring(0, 19));
					indiBlockObj.put("to", ticketingObject.getString("blockOutTo").substring(0, 19));
				}else{
					indiBlockObj.put("operator", "GREATERTHANEQUALTO");
					indiBlockObj.put("value", ticketingObject.getString("blockOutFrom").substring(0, 19));
				}
			}else{
				if(ticketingObject.has("blockOutTo")){
					indiBlockObj.put("operator", "LESSTHANEQUALTO");
					indiBlockObj.put("value", ticketingObject.getString("blockOutTo").substring(0, 19));
				}
			}*/
			if(indiObj!=null){
				inc=1;incArr.put(indiObj);
			}
			/*if(indiBlockObj!=null){
				exc=1;excArr.put(indiBlockObj);
			}*/
		}
		JSONArray ticketingDate = new JSONArray();
		if(inc==1){
			JSONObject inclusion = new JSONObject();
			inclusion.put("inclusion",incArr);
			ticketingDate.put(inclusion);
		}
		/*if(exc==1){
			JSONObject exclusion = new JSONObject();
			exclusion.put("exclusion",excArr);
			ticketingDate.put(exclusion);
		}*/
		return ticketingDate;
	}


	public static JSONObject appendCommercialHead(String commercialName,String commercialType,String commercialProperty, boolean isCommissionable) {
		JSONObject commercialHead = new JSONObject();
		commercialHead.put("commercialHeadName", commercialName);
		commercialHead.put("commercialType", commercialType);
		commercialHead.put("commercialProperty", commercialProperty);
		commercialHead.put("isCommissionable", isCommissionable);
		return commercialHead;
	}


	public static void setAdvancedDefinitonID(String commercialName, String advanceDefinitionId, String productName) {
		switch(commercialName){
		case "Standard":{
			switch(productName){
			case "air":{Air.stdAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.stdAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "Overriding":{
			switch(productName){
			case "air":{Air.overridingAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.overridingAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "PLB":{
			switch(productName){
			case "air":{Air.plbAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.plbAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "SectorWiseIncentive":{
			switch(productName){
			case "air":{Air.sectorWiseAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.sectorWiseAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "SegmentFee":{
			switch(productName){
			case "air":{Air.segmentAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.segmentAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "ServiceCharge":{
			switch(productName){
			case "air":{Air.serviceAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.serviceAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "ManagementFee":{
			switch(productName){
			case "air":{Air.mngtAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.mngtAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "Discount":{
			switch(productName){
			case "air":{Air.discountAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.discountAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "MarkUp":{
			switch(productName){
			case "air":{Air.markupAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.markupAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "DestinationIncentive":{
			switch(productName){
			case "air":{Air.destinationAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.destinationAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "IssuanceFee":{
			switch(productName){
			case "air":{Air.issuanceAdvanceDefinitionId=advanceDefinitionId; break;}
			case "activities":{Activities.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "accomodation":{Accomodation.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "carrentals":{CarRentals.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "rail":{Rail.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "cruise":{Cruise.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "bus":{Bus.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "transfers":{Transfers.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "insurance":{Insurance.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			case "holidays":{Holidays.issuanceAdvanceDefinitionId=advanceDefinitionId;break;}
			}
			break;
		}
		case "Commission":{Air.commissionAdvanceDefinitionId=advanceDefinitionId; break;}
		default:System.out.print("default of setApplicableOnID");
		}
	}


	public static String getFareComponent(JSONArray fareComponents, String percentage) {
		String fareComponent=null;int flag=0;
		for(int i=0;i<fareComponents.length();i++){
			if(fareComponents.getString(i).equals("Basic") || fareComponents.getString(i).equals("BaseFare")){
				flag=1;
			}
		}
		if(flag==1){
			fareComponent="Basic";
			for(int i=0;i<fareComponents.length();i++){
				if(!(fareComponents.getString(i).equals("Basic") || fareComponents.getString(i).equals("BaseFare"))){
					fareComponent+=","+fareComponents.getString(i)+";"+percentage;
				}
			}
		}else{
			for(int i=0;i<fareComponents.length();i++){
				if(i==0)
					fareComponent=fareComponents.getString(i);
				else fareComponent+=","+fareComponents.getString(i)+";"+percentage;
			}
		}
		return fareComponent;
	}


	public static JSONObject getCommercialHeadData(String commercialName, String commercialType, String commercialProperty, JSONObject jsonObject, String productName, String clientCommercialDataID) throws ParseException {
		setContractValidity(jsonObject, commercialName,productName);
		JSONObject entityType = jsonObject.getJSONObject(CommonFunctions.entityType);
		switch(commercialName){
		case "Standard Commercial":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				stdAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				stdFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				stdCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				stdAdditionalAmount = entityType.get("amount").toString();
			setLocalID("Standard",jsonObject.getString("_id"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("Standard", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("Standard",commercialType,commercialProperty,false);
		}
		case "Overriding Commission":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				overAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				overFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				overCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				overAdditionalAmount = entityType.get("amount").toString();
			setLocalID("Overriding",jsonObject.getString("_id"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("Overriding", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("Overriding",commercialType,commercialProperty,true);
		}
		case "Productivity Linked Bonus":{
			plbOH="slab";
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				plbAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				plbFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				plbCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				plbAdditionalAmount = entityType.get("amount").toString();
			setLocalID("PLB",jsonObject.getString("_id"),productName);
			if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0)
				setApplicableOnID("PLB",jsonObject.getJSONArray("applicableOnId"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("PLB", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("PLB",commercialType,commercialProperty,true);
		}
		case "Segment Fees":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				segmentAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				segmentFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				segmentCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				segmentAdditionalAmount = entityType.get("amount").toString();
			setLocalID("SegmentFee",jsonObject.getString("_id"),productName);
			if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0)
				setApplicableOnID("SegmentFee",jsonObject.getJSONArray("applicableOnId"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("SegmentFee", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("SegmentFee",commercialType,commercialProperty,true);
		}
		case "Segments Fees":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				segmentAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				segmentFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				segmentCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				segmentAdditionalAmount = entityType.get("amount").toString();
			setLocalID("SegmentFee",jsonObject.getString("_id"),productName);
			if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0)
				setApplicableOnID("SegmentFee",jsonObject.getJSONArray("applicableOnId"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("SegmentFee", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("SegmentFee",commercialType,commercialProperty,true);
		}
		case "Sector Incentives":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				sectorAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				sectorFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				sectorCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				sectorAdditionalAmount = entityType.get("amount").toString();
			setLocalID("SectorWiseIncentive",jsonObject.getString("_id"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("SectorWiseIncentive", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("SectorWiseIncentive",commercialType,commercialProperty,true);
		}
		case "Management Fee":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				mngtAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				mngtFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				mngtCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				mngtAdditionalAmount = entityType.get("amount").toString();
			setLocalID("ManagementFee",jsonObject.getString("_id"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("ManagementFee", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("ManagementFee",commercialType,commercialProperty,true);
		}
		case "Service Charges":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				serviceAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				serviceFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				serviceCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				serviceAdditionalAmount =entityType.get("amount").toString();
			setLocalID("ServiceCharge",jsonObject.getString("_id"),productName);
			if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0)
				setApplicableOnID("ServiceCharge",jsonObject.getJSONArray("applicableOnId"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("ServiceCharge", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("ServiceCharge",commercialType,commercialProperty,true);
		}
		case "Discount":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				discountAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				discountFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				discountCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				discountAdditionalAmount = entityType.get("amount").toString();
			setLocalID("Discount",jsonObject.getString("_id"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("Discount", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("Discount",commercialType,commercialProperty,true);
		}
		case "Destination Incentives":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				destinationAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				destinationFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				destinationCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				destinationAdditionalAmount = entityType.get("amount").toString();
			setLocalID("DestinationIncentive",jsonObject.getString("_id"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("DestinationIncentive", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("DestinationIncentive",commercialType,commercialProperty,true);
		}
		case "Issuance Fees":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				issuanceAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				issuanceFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				issuanceCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				issuanceAdditionalAmount = entityType.get("amount").toString();
			setLocalID("IssuanceFee",jsonObject.getString("_id"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("IssuanceFee", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("IssuanceFee",commercialType,commercialProperty,true);
		}
		case "Commission":{
			if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
				commissionAdditionalPercentage = entityType.get("percentage").toString();
			if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
				commissionFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
			if(entityType.has("currency"))
				commissionCurrency = entityType.getString("currency");
			if(entityType.has("amount") && !entityType.get("amount").equals(0))
				commissionAdditionalAmount = entityType.get("amount").toString();
			setLocalID("Commission",jsonObject.getString("_id"),productName);
			if(jsonObject.has("advanceDefinitionId"))
				setAdvancedDefinitonID("Commission", jsonObject.getString("advanceDefinitionId"), productName);
			return appendCommercialHead("Commission",commercialType,commercialProperty,true);
		}
		default:System.out.println("default of getCommercialHeadData due to commercialName: "+commercialName);
		}
		return null;
	}


	private static void setApplicableOnID(String commercialName, JSONArray applicableOnArray, String productName) {
		switch(productName){
		case "air": {
			switch(commercialName){
			case "PLB":{Air.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Air.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Air.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Air.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Air.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Air.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Air.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "activities": {
			switch(commercialName){
			case "PLB":{Activities.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Activities.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Activities.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Activities.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Activities.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Activities.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Activities.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "accomodation": {
			switch(commercialName){
			case "PLB":{Accomodation.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Accomodation.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Accomodation.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Accomodation.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Accomodation.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Accomodation.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Accomodation.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "bus": {
			switch(commercialName){
			case "PLB":{Bus.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Bus.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Bus.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Bus.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Bus.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Bus.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Bus.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "rail": {
			switch(commercialName){
			case "PLB":{Rail.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Rail.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Rail.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Rail.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Rail.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Rail.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Rail.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "cruise": {
			switch(commercialName){
			case "PLB":{Cruise.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Cruise.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Cruise.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Cruise.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Cruise.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Cruise.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Cruise.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "insurance": {
			switch(commercialName){
			case "PLB":{Insurance.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Insurance.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Insurance.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Insurance.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Insurance.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Insurance.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Insurance.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "holidays":{
			switch(commercialName){
			case "PLB":{Holidays.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Holidays.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Holidays.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Holidays.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Holidays.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Holidays.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Holidays.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "carrentals": {
			switch(commercialName){
			case "PLB":{CarRentals.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{CarRentals.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{CarRentals.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{CarRentals.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{CarRentals.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{CarRentals.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{CarRentals.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "visa": {
			switch(commercialName){
			case "PLB":{Visa.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Visa.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Visa.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Visa.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Visa.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Visa.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Visa.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		case "transfers": {
			switch(commercialName){
			case "PLB":{Transfers.plbapplicableOnArray=applicableOnArray;break;}
			case "ServiceCharge":{Transfers.serviceapplicableOnArray=applicableOnArray;break;}
			case "SegmentFee":{Transfers.segmentapplicableOnArray=applicableOnArray;break;}
			case "Productivity Linked Bonus":{Transfers.plbapplicableOnArray=applicableOnArray;break;}
			case "Service Charges":{Transfers.serviceapplicableOnArray=applicableOnArray;break;}
			case "Segment Fees":{Transfers.segmentapplicableOnArray=applicableOnArray;break;}
			case "Segments Fees":{Transfers.segmentapplicableOnArray=applicableOnArray;break;}
			}break;
		}
		}
	}


	public static String getCommercialName(String commercialName) {
		switch(commercialName){
		case "Standard Commercial": return "Standard";
		case "Overriding Commission": return "Overriding";
		case "Productivity Linked Bonus": return "PLB";
		case "Sector Incentives": return "SectorWiseIncentive";
		case "Segment Fees": return "SegmentFee";
		case "Segments Fees": return "SegmentFee";
		case "Management Fee": return "ManagementFee";
		case "Service Charges": return "ServiceCharge";
		case "Discount": return "Discount";
		case "MarkUp": return "MarkUp";
		case "Destination Incentives": return "DestinationIncentive";
		case "Issuance Fees": return "IssuanceFee";
		case "Commission": return "Commission";
		case "Maintenance Fees": return "MaintenanceFees";
		case "Integration Fees": return "IntegrationFees";
		case "Licence Fees": return "LicenceFees";
		case "Web Service Fees": return "WebServiceFees";
		case "Loyalty Bonus": return "LoyaltyBonus";
		case "Preference Benefit": return "PreferenceBenefit";
		case "Retainer Fee": return "RetainerFee";
		case "Listing Fee": return "ListingFee";
		case "Content Access Fee": return "ContentAccessFee";
		case "Sign Up Fees": return "SignUpFees";
		case "Sign Up Bonus": return "SignUpBonus";
		case "Look To Book": return "LookToBook";
		case "MSF Fees": return "MSFFees";
		case "Incentives On Top Up": return "IncentivesOnTopUp";
		case "Termination Fees": return "TerminationFees";
		case "Penalty Fee / Kick Back": return "PenaltyFee";
		case "Free Of Cost (FOC)": return "FreeOfCost";
		case "Lost Ticket": return "LostTicket";
		case "Remittance Fees": return "RemittanceFees";
		case "Training Fees": return "TrainingFees";
		default:System.out.println("deafult of getCommercialName");
		}
		return null;
	}


	public static JSONObject getCommercialHeadData(String commercialName, String commercialType, JSONObject jsonObject, String productName, String clientCommercialDataID) throws ParseException{
		if(commercialType.equals("Receivable")){
			JSONObject receivableToCompany = new JSONObject();
			JSONObject retentionCommercialsProductBased = jsonObject.getJSONObject("retentionCommercialsProductBased");
			for(int i=0;i<retentionCommercialsProductBased.getJSONArray("receivableToCompany").length();i++){
				receivableToCompany = retentionCommercialsProductBased.getJSONArray("receivableToCompany").getJSONObject(i);
				if(receivableToCompany.has("commercialHead")){
					if(receivableToCompany.get("commercialHead").equals(commercialName)){
						priority=1;
						clientCommercialDataID=clientCommercialDataID+"|retentionCommercialsProductBased_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.retention;
						setContractValidity(receivableToCompany,commercialName,productName);
						setRetentionCommercials("ProductBased",commercialName,receivableToCompany,clientCommercialDataID);
						String name = getCommercialName(commercialName);
						setLocalID(name,receivableToCompany.getString("_id"),productName);
						if(receivableToCompany.has("applicableOnId") && receivableToCompany.getJSONArray("applicableOnId").length()>0)
							setApplicableOnID(commercialName,receivableToCompany.getJSONArray("applicableOnId"),productName);
						if(receivableToCompany.has("advanceDefinitionId"))
							setAdvancedDefinitonID(name,receivableToCompany.getString("advanceDefinitionId"), productName);
						if(name.equals("Standard"))
							return appendCommercialHead(name,commercialType,"Retention",false);
						else return appendCommercialHead(name,commercialType,"Retention",true);
					}
				}
			}
			JSONObject retentionCommercialsSupplierBased = new JSONObject();
			retentionCommercialsSupplierBased = jsonObject.getJSONObject("retentionCommercialsSupplierBased");
			for(int i=0;i<retentionCommercialsSupplierBased.getJSONArray("receivableToCompany").length();i++){
				receivableToCompany =retentionCommercialsSupplierBased.getJSONArray("receivableToCompany").getJSONObject(i);
				if(receivableToCompany.has("commercialHead")){
					if(receivableToCompany.get("commercialHead").equals(commercialName)){
						clientCommercialDataID=clientCommercialDataID+"|retentionCommercialsSupplierBased_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+entityType;
						setContractValidity(receivableToCompany,commercialName,productName);
						setRetentionCommercials("SupplierBased",commercialName,receivableToCompany,clientCommercialDataID);
						String name = getCommercialName(commercialName);
						setLocalID(name,receivableToCompany.getString("_id"),productName);
						if(receivableToCompany.has("applicableOnId") && receivableToCompany.getJSONArray("applicableOnId").length()>0)
							setApplicableOnID(commercialName,receivableToCompany.getJSONArray("applicableOnId"),productName);
						if(receivableToCompany.has("advanceDefinitionId"))
							setAdvancedDefinitonID(name,receivableToCompany.getString("advanceDefinitionId"), productName);
						if(name.equals("Standard"))
							return appendCommercialHead(name,commercialType,"Retention",false);
						else return appendCommercialHead(name,commercialType,"Retention",true);
					}
				}
			}
		}else{
			JSONObject payableToClient = new JSONObject();
			JSONObject retentionCommercialsProductBased = jsonObject.getJSONObject("retentionCommercialsProductBased");
			for(int i=0;i<retentionCommercialsProductBased.getJSONArray("payableToClient").length();i++){
				payableToClient = retentionCommercialsProductBased.getJSONArray("payableToClient").getJSONObject(i);
				if(payableToClient.has("commercialHead")){
					if(payableToClient.get("commercialHead").equals(commercialName)){
						priority=1;
						clientCommercialDataID=clientCommercialDataID+"|retentionCommercialsProductBased_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.retention;
						setContractValidity(payableToClient,commercialName,productName);
						setRetentionCommercials("ProductBased",commercialName,payableToClient,clientCommercialDataID);
						String name = getCommercialName(commercialName);
						setLocalID(name,payableToClient.getString("_id"),productName);
						if(payableToClient.has("applicableOnId") && payableToClient.getJSONArray("applicableOnId").length()>0)
							setApplicableOnID(commercialName,payableToClient.getJSONArray("applicableOnId"),productName);
						if(payableToClient.has("advanceDefinitionId"))
							setAdvancedDefinitonID(name,payableToClient.getString("advanceDefinitionId"), productName);
						if(name.equals("Standard"))
							return appendCommercialHead(name,commercialType,"Retention",false);
						else return appendCommercialHead(name,commercialType,"Retention",true);
					}
				}
			}
			JSONObject retentionCommercialsSupplierBased = new JSONObject();
			retentionCommercialsSupplierBased = jsonObject.getJSONObject("retentionCommercialsSupplierBased");
			for(int i=0;i<retentionCommercialsSupplierBased.getJSONArray("payableToClient").length();i++){
				payableToClient =retentionCommercialsSupplierBased.getJSONArray("payableToClient").getJSONObject(i);
				if(payableToClient.has("commercialHead")){
					if(payableToClient.get("commercialHead").equals(commercialName)){
						clientCommercialDataID=clientCommercialDataID+"|retentionCommercialsSupplierBased_payableToClient|"+payableToClient.getString("_id")+"|"+entityType;
						setContractValidity(payableToClient,commercialName,productName);
						setRetentionCommercials("SupplierBased",commercialName,payableToClient,clientCommercialDataID);
						String name = getCommercialName(commercialName);
						setLocalID(name,payableToClient.getString("_id"),productName);
						if(payableToClient.has("applicableOnId") && payableToClient.getJSONArray("applicableOnId").length()>0)
							setApplicableOnID(commercialName,payableToClient.getJSONArray("applicableOnId"),productName);
						if(payableToClient.has("advanceDefinitionId"))
							setAdvancedDefinitonID(name,payableToClient.getString("advanceDefinitionId"), productName);
						if(name.equals("Standard"))
							return appendCommercialHead(name,commercialType,"Retention",false);
						else return appendCommercialHead(name,commercialType,"Retention",true);
					}
				}
			}
		}
		return null;
	}


	public static void setLocalID(String name, String localID, String productName) {
		switch(name){
		case "Standard":{
			switch(productName){
			case "air":{Air.stdLocalID=localID;break;}
			case "activities":{Activities.stdLocalID=localID;break;}
			case "accomodation":{Accomodation.stdLocalID=localID;break;}
			case "carrentals":{CarRentals.stdLocalID=localID;break;}
			case "rail":{Rail.stdLocalID=localID;break;}
			case "cruise":{Cruise.stdLocalID=localID;break;}
			case "bus":{Bus.stdLocalID=localID;break;}
			case "transfers":{Transfers.stdLocalID=localID;break;}
			case "insurance":{Insurance.stdLocalID=localID;break;}
			case "holidays":{Holidays.stdLocalID=localID;break;}
			}
			break;
		}
		case "Overriding":{
			switch(productName){
			case "air":{Air.overridingLocalID=localID;break;}
			case "activities":{Activities.overridingLocalID=localID;break;}
			case "accomodation":{Accomodation.overridingLocalID=localID;break;}
			case "carrentals":{CarRentals.overridingLocalID=localID;break;}
			case "rail":{Rail.overridingLocalID=localID;break;}
			case "cruise":{Cruise.overridingLocalID=localID;break;}
			case "bus":{Bus.overridingLocalID=localID;break;}
			case "transfers":{Transfers.overridingLocalID=localID;break;}
			case "insurance":{Insurance.overridingLocalID=localID;break;}
			case "holidays":{Holidays.overridingLocalID=localID;break;}
			}
			break;
		}
		case "PLB":{
			switch(productName){
			case "air":{Air.plbLocalID=localID;break;}
			case "activities":{Activities.plbLocalID=localID;break;}
			case "accomodation":{Accomodation.plbLocalID=localID;break;}
			case "carrentals":{CarRentals.plbLocalID=localID;break;}
			case "rail":{Rail.plbLocalID=localID;break;}
			case "cruise":{Cruise.plbLocalID=localID;break;}
			case "bus":{Bus.plbLocalID=localID;break;}
			case "transfers":{Transfers.plbLocalID=localID;break;}
			case "insurance":{Insurance.plbLocalID=localID;break;}
			case "holidays":{Holidays.plbLocalID=localID;break;}
			}
			break;
		}
		case "SectorWiseIncentive":{
			switch(productName){
			case "air":{Air.sectorWiseLocalID=localID;break;}
			case "activities":{Activities.sectorWiseLocalID=localID;break;}
			case "accomodation":{Accomodation.sectorWiseLocalID=localID;break;}
			case "carrentals":{CarRentals.sectorWiseLocalID=localID;break;}
			case "rail":{Rail.sectorWiseLocalID=localID;break;}
			case "cruise":{Cruise.sectorWiseLocalID=localID;break;}
			case "bus":{Bus.sectorWiseLocalID=localID;break;}
			case "transfers":{Transfers.sectorWiseLocalID=localID;break;}
			case "insurance":{Insurance.sectorWiseLocalID=localID;break;}
			case "holidays":{Holidays.sectorWiseLocalID=localID;break;}
			}
			break;
		}
		case "SegmentFee":{
			switch(productName){
			case "air":{Air.segmentLocalID=localID;break;}
			case "activities":{Activities.segmentLocalID=localID;break;}
			case "accomodation":{Accomodation.segmentLocalID=localID;break;}
			case "carrentals":{CarRentals.segmentLocalID=localID;break;}
			case "rail":{Rail.segmentLocalID=localID;break;}
			case "cruise":{Cruise.segmentLocalID=localID;break;}
			case "bus":{Bus.segmentLocalID=localID;break;}
			case "transfers":{Transfers.segmentLocalID=localID;break;}
			case "insurance":{Insurance.segmentLocalID=localID;break;}
			case "holidays":{Holidays.segmentLocalID=localID;break;}
			}
			break;
		}
		case "ServiceCharge":{
			switch(productName){
			case "air":{Air.serviceLocalID=localID;break;}
			case "activities":{Activities.serviceLocalID=localID;break;}
			case "accomodation":{Accomodation.serviceLocalID=localID;break;}
			case "carrentals":{CarRentals.serviceLocalID=localID;break;}
			case "rail":{Rail.serviceLocalID=localID;break;}
			case "cruise":{Cruise.serviceLocalID=localID;break;}
			case "bus":{Bus.serviceLocalID=localID;break;}
			case "transfers":{Transfers.serviceLocalID=localID;break;}
			case "insurance":{Insurance.serviceLocalID=localID;break;}
			case "holidays":{Holidays.serviceLocalID=localID;break;}
			}
			break;
		}
		case "ManagementFee":{
			switch(productName){
			case "air":{Air.mngtLocalID=localID;break;}
			case "activities":{Activities.mngtLocalID=localID;break;}
			case "accomodation":{Accomodation.mngtLocalID=localID;break;}
			case "carrentals":{CarRentals.mngtLocalID=localID;break;}
			case "rail":{Rail.mngtLocalID=localID;break;}
			case "cruise":{Cruise.mngtLocalID=localID;break;}
			case "bus":{Bus.mngtLocalID=localID;break;}
			case "transfers":{Transfers.mngtLocalID=localID;break;}
			case "insurance":{Insurance.mngtLocalID=localID;break;}
			case "holidays":{Holidays.mngtLocalID=localID;break;}
			}
			break;
		}
		case "Discount":{
			switch(productName){
			case "air":{Air.discountLocalID=localID;break;}
			case "activities":{Activities.discountLocalID=localID;break;}
			case "accomodation":{Accomodation.discountLocalID=localID;break;}
			case "carrentals":{CarRentals.discountLocalID=localID;break;}
			case "rail":{Rail.discountLocalID=localID;break;}
			case "cruise":{Cruise.discountLocalID=localID;break;}
			case "bus":{Bus.discountLocalID=localID;break;}
			case "transfers":{Transfers.discountLocalID=localID;break;}
			case "insurance":{Insurance.discountLocalID=localID;break;}
			case "holidays":{Holidays.discountLocalID=localID;break;}
			}
			break;
		}
		case "MarkUp":{
			switch(productName){
			case "air":{Air.markupLocalID=localID;break;}
			case "activities":{Activities.markupLocalID=localID;break;}
			case "accomodation":{Accomodation.markupLocalID=localID;break;}
			case "carrentals":{CarRentals.markupLocalID=localID;break;}
			case "rail":{Rail.markupLocalID=localID;break;}
			case "cruise":{Cruise.markupLocalID=localID;break;}
			case "bus":{Bus.markupLocalID=localID;break;}
			case "transfers":{Transfers.markupLocalID=localID;break;}
			case "insurance":{Insurance.markupLocalID=localID;break;}
			case "holidays":{Holidays.markupLocalID=localID;break;}
			}
			break;
		}
		case "DestinationIncentive":{
			switch(productName){
			case "air":{Air.destinationLocalID=localID;break;}
			case "activities":{Activities.destinationLocalID=localID;break;}
			case "accomodation":{Accomodation.destinationLocalID=localID;break;}
			case "carrentals":{CarRentals.destinationLocalID=localID;break;}
			case "rail":{Rail.destinationLocalID=localID;break;}
			case "cruise":{Cruise.destinationLocalID=localID;break;}
			case "bus":{Bus.destinationLocalID=localID;break;}
			case "transfers":{Transfers.destinationLocalID=localID;break;}
			case "insurance":{Insurance.destinationLocalID=localID;break;}
			case "holidays":{Holidays.destinationLocalID=localID;break;}
			}
			break;
		}
		case "IssuanceFee":{
			switch(productName){
			case "air":{Air.issuanceLocalID=localID;break;}
			case "activities":{Activities.issuanceLocalID=localID;break;}
			case "accomodation":{Accomodation.issuanceLocalID=localID;break;}
			case "carrentals":{CarRentals.issuanceLocalID=localID;break;}
			case "rail":{Rail.issuanceLocalID=localID;break;}
			case "cruise":{Cruise.issuanceLocalID=localID;break;}
			case "bus":{Bus.issuanceLocalID=localID;break;}
			case "transfers":{Transfers.issuanceLocalID=localID;break;}
			case "insurance":{Insurance.issuanceLocalID=localID;break;}
			case "holidays":{Holidays.issuanceLocalID=localID;break;}
			}
			break;}
		case "Commission":{Air.commissionLocalID=localID;break;}
		default:System.out.print("default of setApplicableOnID");
		}

	}


	public static JSONObject commercialCall(String advancedDT, String calculationDT,String commercialName,JSONObject mdmCommDefn,JSONObject mainJson,String productName, boolean advancedApplicable, String productCategory, String productCategorySubType, String id) throws Exception{
		switch(productName){
		case "air": {
			Air.appendAirCommercialDetails(advancedDT,calculationDT,commercialName,mdmCommDefn,mainJson,advancedApplicable,id);
			break;
		}
		case "activities": {
			Activities.appendActivitiesCommercialDetails(advancedDT,calculationDT,commercialName,mdmCommDefn,mainJson,productName,advancedApplicable,id);
			break;
		}
		case "accomodation": {
			Accomodation.appendAccoCommercialDetails(advancedDT,calculationDT,commercialName,mdmCommDefn,mainJson,productName,advancedApplicable,id);
			break;
		}
		case "bus": {
			Bus.appendBusCommercialDetails(advancedDT, calculationDT, commercialName, mdmCommDefn, mainJson, productName, advancedApplicable, id);
			break;
		}
		case "rail": {}
		case "cruise": {
			Cruise.appendCruiseCommercialDetails(advancedDT, calculationDT, commercialName, mdmCommDefn, mainJson, productName, advancedApplicable, id);
			break;
		}
		case "insurance": {}
		case "holidays":{
			Holidays.appendHolidaysCommercialDetails(advancedDT,calculationDT,commercialName,mdmCommDefn,mainJson,productName,advancedApplicable,id,productCategory, productCategorySubType);
			break;
		}
		case "carrentals": {
			CarRentals.appendCarRentalsCommercialDetails(advancedDT,calculationDT,commercialName,mdmCommDefn,mainJson,productName,advancedApplicable,id);
			break;
		}
		case "visa": {}
		case "transfers": {
			Transfers.appendTransfersCommercialDetails(advancedDT, calculationDT, commercialName, mdmCommDefn, mainJson, productName, advancedApplicable, id);
			break;
		}
		}
		return mainJson;
	}


	public static void insertPLBSalePlusTravel(JSONArray salePlusTravel, JSONArray baseArr, JSONArray calcArr) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(j);
				JSONObject trigPayout = CommonFunctions.getTriggerPayoutObject(salePlusTravelObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray saleArray = new JSONArray();
				JSONArray travelArray = new JSONArray();
				JSONObject saleinclusion = new JSONObject();
				JSONObject saleexclusion = new JSONObject();
				JSONObject travelinclusion = new JSONObject();
				JSONObject travelexclusion = new JSONObject();
				JSONArray salesDateInclusionArr = new JSONArray();
				JSONArray travelDateInclusionArr = new JSONArray();
				JSONArray salesDateExclusionArr = new JSONArray();
				JSONArray travelDateExclusionArr = new JSONArray();
				JSONObject sale = salePlusTravelObject.getJSONObject("sales");
				JSONObject travel = salePlusTravelObject.getJSONObject("travel");
				JSONObject saleDate = new JSONObject();
				JSONObject travelDate = new JSONObject();
				JSONObject saleExcDate = new JSONObject();
				JSONObject travelExcDate = new JSONObject();
				//sale
				if(sale.has("saleFrom")){
					if(sale.has("saleTo")){
						saleDate.put("operator", "BETWEEN");
						saleDate.put("from", sale.getString("saleFrom"));
						saleDate.put("to", sale.getString("saleTo"));
					}else{
						saleDate.put("operator", "GREATERTHANEQUALTO");
						saleDate.put("from", sale.getString("saleFrom"));
					}
				}else if(sale.has("saleTo")){
					saleDate.put("operator", "LESSTHANEQUALTO");
					saleDate.put("to", sale.getString("saleTo"));
				}
				//travel
				if(travel.has("travelFrom")){
					if(travel.has("travelTo")){
						travelDate.put("operator", "BETWEEN");
						travelDate.put("from", travel.getString("travelFrom"));
						travelDate.put("to", travel.getString("travelTo"));
					}else{
						travelDate.put("operator", "GREATERTHANEQUALTO");
						travelDate.put("from", travel.getString("travelFrom"));
					}
				}else if(travel.has("travelTo")){
					travelDate.put("operator", "LESSTHANEQUALTO");
					travelDate.put("to", travel.getString("travelTo"));
				}
				//blockOut sale
				if(sale.has("blockOutFrom")){
					if(sale.has("blockOutTo")){
						saleExcDate.put("operator", "BETWEEN");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
						saleExcDate.put("to", sale.getString("blockOutTo"));
					}else{
						saleExcDate.put("operator", "GREATERTHANEQUALTO");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
					}
				}else if(sale.has("blockOutTo")){
					saleExcDate.put("operator", "LESSTHANEQUALTO");
					saleExcDate.put("to", sale.getString("blockOutTo"));
				}
				//blockOut travel
				if(travel.has("blockOutFrom")){
					if(travel.has("blockOutTo")){
						travelExcDate.put("operator", "BETWEEN");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
						travelExcDate.put("to", travel.getString("blockOutTo"));
					}else{
						travelExcDate.put("operator", "GREATERTHANEQUALTO");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
					}
				}else if(travel.has("blockOutTo")){
					travelExcDate.put("operator", "LESSTHANEQUALTO");
					travelExcDate.put("to", travel.getString("blockOutTo"));
				}

				saleArray.put(trigPayout);
				travelArray.put(trigPayout);

				if(saleDate.has("operator")){
					salesDateInclusionArr.put(saleDate);
					saleinclusion.put("inclusion", salesDateInclusionArr);
					saleArray.put(saleinclusion);
				}
				if(travelDate.has("operator")){
					travelDateInclusionArr.put(travelDate);
					travelinclusion.put("inclusion", travelDateInclusionArr);
					travelArray.put(travelinclusion);
				}
				if(saleExcDate.has("operator")){
					salesDateExclusionArr.put(saleExcDate);
					saleexclusion.put("exclusion", salesDateExclusionArr);
					saleArray.put(saleexclusion);
				}
				if(travelExcDate.has("operator")){
					travelDateExclusionArr.put(travelExcDate);
					travelexclusion.put("exclusion", travelDateExclusionArr);
					travelArray.put(travelexclusion);
				}

				base.put("sale", saleArray);
				base.put("travel", travelArray);
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, salePlusTravelObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void insertSalePlusTravel(JSONArray advancedArr, JSONArray calculationArr, JSONArray salePlusTravel) {
		int length=advancedArr.length();
		for(int j=0;j<length;j++){
			for(int i=0;i<salePlusTravel.length();i++){
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(i);
				JSONObject sale = salePlusTravelObject.getJSONObject("sales");
				JSONObject travel = salePlusTravelObject.getJSONObject("travel");
				JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(j).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(j).toString()));
				JSONArray saleArray = new JSONArray();
				JSONArray travelArray = new JSONArray();
				JSONObject saleinclusion = new JSONObject();
				JSONObject saleexclusion = new JSONObject();
				JSONObject travelinclusion = new JSONObject();
				JSONObject travelexclusion = new JSONObject();
				JSONArray salesDateInclusionArr = new JSONArray();
				JSONArray travelDateInclusionArr = new JSONArray();
				JSONArray salesDateExclusionArr = new JSONArray();
				JSONArray travelDateExclusionArr = new JSONArray();
				JSONObject saleDate = new JSONObject();
				JSONObject travelDate = new JSONObject();
				JSONObject saleExcDate = new JSONObject();
				JSONObject travelExcDate = new JSONObject();

				//sale
				if(sale.has("saleFrom")){
					if(sale.has("saleTo")){
						saleDate.put("operator", "BETWEEN");
						saleDate.put("from", sale.getString("saleFrom"));
						saleDate.put("to", sale.getString("saleTo"));
					}else{
						saleDate.put("operator", "GREATERTHANEQUALTO");
						saleDate.put("from", sale.getString("saleFrom"));
					}
				}else if(sale.has("saleTo")){
					saleDate.put("operator", "LESSTHANEQUALTO");
					saleDate.put("to", sale.getString("saleTo"));
				}
				//travel
				if(travel.has("travelFrom")){
					if(travel.has("travelTo")){
						travelDate.put("operator", "BETWEEN");
						travelDate.put("from", travel.getString("travelFrom"));
						travelDate.put("to", travel.getString("travelTo"));
					}else{
						travelDate.put("operator", "GREATERTHANEQUALTO");
						travelDate.put("from", travel.getString("travelFrom"));
					}
				}else if(travel.has("travelTo")){
					travelDate.put("operator", "LESSTHANEQUALTO");
					travelDate.put("to", travel.getString("travelTo"));
				}
				//blockOut sale
				if(sale.has("blockOutFrom")){
					if(sale.has("blockOutTo")){
						saleExcDate.put("operator", "BETWEEN");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
						saleExcDate.put("to", sale.getString("blockOutTo"));
					}else{
						saleExcDate.put("operator", "GREATERTHANEQUALTO");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
					}
				}else if(sale.has("blockOutTo")){
					saleExcDate.put("operator", "LESSTHANEQUALTO");
					saleExcDate.put("to", sale.getString("blockOutTo"));
				}
				//blockOut travel
				if(travel.has("blockOutFrom")){
					if(travel.has("blockOutTo")){
						travelExcDate.put("operator", "BETWEEN");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
						travelExcDate.put("to", travel.getString("blockOutTo"));
					}else{
						travelExcDate.put("operator", "GREATERTHANEQUALTO");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
					}
				}else if(travel.has("blockOutTo")){
					travelExcDate.put("operator", "LESSTHANEQUALTO");
					travelExcDate.put("to", travel.getString("blockOutTo"));
				}

				if(saleDate.has("operator")){
					salesDateInclusionArr.put(saleDate);
					saleinclusion.put("inclusion", salesDateInclusionArr);
					saleArray.put(saleinclusion);
				}if(travelDate.has("operator")){
					travelDateInclusionArr.put(travelDate);
					travelinclusion.put("inclusion", travelDateInclusionArr);
					travelArray.put(travelinclusion);
				}if(saleExcDate.has("operator")){
					salesDateExclusionArr.put(saleExcDate);
					saleexclusion.put("exclusion", salesDateExclusionArr);
					saleArray.put(saleexclusion);
				}if(travelExcDate.has("operator")){
					travelDateExclusionArr.put(travelExcDate);
					travelexclusion.put("exclusion", travelDateExclusionArr);
					travelArray.put(travelexclusion);
				}

				base.put("sale", saleArray);
				base.put("travel", travelArray);

				CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, salePlusTravelObject.getString("_id"));
			}
		}
		for(int j=0;j<length;j++){
			advancedArr.remove(0);
			calculationArr.remove(0);
		}
	}


	public static void insertPLBTicketingPlusTravel(JSONArray ticketingPlusTravel, JSONArray baseArr, JSONArray calcArr) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<ticketingPlusTravel.length();j++){
				JSONObject salePlusTravelObject = ticketingPlusTravel.getJSONObject(j);
				JSONObject trigPayout = CommonFunctions.getTriggerPayoutObject(salePlusTravelObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray saleArray = new JSONArray();
				JSONArray travelArray = new JSONArray();
				JSONObject saleinclusion = new JSONObject();
				JSONObject saleexclusion = new JSONObject();
				JSONObject travelinclusion = new JSONObject();
				JSONObject travelexclusion = new JSONObject();
				JSONArray salesDateInclusionArr = new JSONArray();
				JSONArray travelDateInclusionArr = new JSONArray();
				JSONArray salesDateExclusionArr = new JSONArray();
				JSONArray travelDateExclusionArr = new JSONArray();
				JSONObject ticket = salePlusTravelObject.getJSONObject("ticket");
				JSONObject travel = salePlusTravelObject.getJSONObject("travel");
				JSONObject saleDate = new JSONObject();
				JSONObject travelDate = new JSONObject();
				JSONObject saleExcDate = new JSONObject();
				JSONObject travelExcDate = new JSONObject();
				//ticket
				if(ticket.has("ticketingFrom")){
					if(ticket.has("ticketingTo")){
						saleDate.put("operator", "BETWEEN");
						saleDate.put("from", ticket.getString("ticketingFrom"));
						saleDate.put("to", ticket.getString("ticketingTo"));
					}else{
						saleDate.put("operator", "GREATERTHANEQUALTO");
						saleDate.put("from", ticket.getString("ticketingFrom"));
					}
				}else if(ticket.has("ticketingTo")){
					saleDate.put("operator", "LESSTHANEQUALTO");
					saleDate.put("to", ticket.getString("ticketingTo"));
				}
				//travel
				if(travel.has("travelFrom")){
					if(travel.has("travelTo")){
						travelDate.put("operator", "BETWEEN");
						travelDate.put("from", travel.getString("travelFrom"));
						travelDate.put("to", travel.getString("travelTo"));
					}else{
						travelDate.put("operator", "GREATERTHANEQUALTO");
						travelDate.put("from", travel.getString("travelFrom"));
					}
				}else if(travel.has("travelTo")){
					travelDate.put("operator", "LESSTHANEQUALTO");
					travelDate.put("to", travel.getString("travelTo"));
				}
				//blockOut ticket
				if(ticket.has("blockOutFrom")){
					if(ticket.has("blockOutTo")){
						saleExcDate.put("operator", "BETWEEN");
						saleExcDate.put("from", ticket.getString("blockOutFrom"));
						saleExcDate.put("to", ticket.getString("blockOutTo"));
					}else{
						saleExcDate.put("operator", "GREATERTHANEQUALTO");
						saleExcDate.put("from", ticket.getString("blockOutFrom"));
					}
				}else if(ticket.has("blockOutTo")){
					saleExcDate.put("operator", "LESSTHANEQUALTO");
					saleExcDate.put("to", ticket.getString("blockOutTo"));
				}
				//blockOut travel
				if(travel.has("blockOutFrom")){
					if(travel.has("blockOutTo")){
						travelExcDate.put("operator", "BETWEEN");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
						travelExcDate.put("to", travel.getString("blockOutTo"));
					}else{
						travelExcDate.put("operator", "GREATERTHANEQUALTO");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
					}
				}else if(travel.has("blockOutTo")){
					travelExcDate.put("operator", "LESSTHANEQUALTO");
					travelExcDate.put("to", travel.getString("blockOutTo"));
				}

				saleArray.put(trigPayout);
				travelArray.put(trigPayout);

				if(saleDate.has("operator")){
					salesDateInclusionArr.put(saleDate);
					saleinclusion.put("inclusion", salesDateInclusionArr);
					saleArray.put(saleinclusion);
				}
				if(travelDate.has("operator")){
					travelDateInclusionArr.put(travelDate);
					travelinclusion.put("inclusion", travelDateInclusionArr);
					travelArray.put(travelinclusion);
				}
				if(saleExcDate.has("operator")){
					salesDateExclusionArr.put(saleExcDate);
					saleexclusion.put("exclusion", salesDateExclusionArr);
					saleArray.put(saleexclusion);
				}
				if(travelExcDate.has("operator")){
					travelDateExclusionArr.put(travelExcDate);
					travelexclusion.put("exclusion", travelDateExclusionArr);
					travelArray.put(travelexclusion);
				}

				String baseRuleID = base.getString("RuleID")+salePlusTravelObject.getString("_id");
				String calculationRuleID = calculation.getString("RuleID")+salePlusTravelObject.getString("_id");
				base.put("RuleID", baseRuleID);
				calculation.put("RuleID", calculationRuleID);
				calculation.put("selectedRow", baseRuleID);

				base.put("ticketing", saleArray);
				base.put("travel", travelArray);

				baseArr.put(base);
				calcArr.put(calculation);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static JSONObject addCommercialDetails(String supplier,String entityName,JSONArray entityMarket,String entityType,JSONArray commHead,JSONObject mdmCommDefn,JSONObject mainJson,String productName, String productCategory, String productCategorySubType, String id, JSONObject flightsAndNonAir, String clientCommercialDataID) throws Exception{
		for(int i=0;i<commHead.length();i++){
			switch(commHead.getJSONObject(i).getString("commercialHeadName")){
			case "Standard":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("StandardClientCommercialAdvancedDT", "StandardClientCommercialCalculationDT", "Standard", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("StandardClientCommercialAdvancedDT", "StandardClientCommercialCalculationDT", "Standard", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "Overriding":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("OverridingClientCommercialAdvancedDT", "OverridingClientCommercialCalculationDT", "Overriding", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("OverridingClientCommercialAdvancedDT", "OverridingClientCommercialCalculationDT", "Overriding", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "PLB":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("PLBClientCommercialAdvancedDT", "PLBClientCommercialCalculationDT", "PLB", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("PLBClientCommercialAdvancedDT", "PLBClientCommercialCalculationDT", "PLB", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "SegmentFee":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("SegmentFeeClientCommercialAdvancedDT", "SegmentFeeClientCommercialCalculationDT", "SegmentFee", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("SegmentFeeClientCommercialAdvancedDT", "SegmentFeeClientCommercialCalculationDT", "SegmentFee", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "SectorWiseIncentive":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("SectorWiseIncentiveClientCommercialAdvancedDT", "SectorWiseIncentiveClientCommercialCalculationDT", "SectorWiseIncentive", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("SectorWiseIncentiveClientCommercialAdvancedDT", "SectorWiseIncentiveClientCommercialCalculationDT", "SectorWiseIncentive", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "DestinationIncentive":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("DestinationIncentiveClientCommercialAdvancedDT", "DestinationIncentiveClientCommercialCalculationDT", "DestinationIncentive", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("DestinationIncentiveClientCommercialAdvancedDT", "DestinationIncentiveClientCommercialCalculationDT", "DestinationIncentive", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "ManagementFee":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("ManagementFeeClientCommercialAdvancedDT", "ManagementFeeClientCommercialCalculationDT", "ManagementFee", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("ManagementFeeClientCommercialAdvancedDT", "ManagementFeeClientCommercialCalculationDT", "ManagementFee", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "ServiceCharge":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("ServiceChargeClientCommercialAdvancedDT", "ServiceChargeClientCommercialCalculationDT", "ServiceCharge", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("ServiceChargeClientCommercialAdvancedDT", "ServiceChargeClientCommercialCalculationDT", "ServiceCharge", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "Discount":{
				//if(commHead.getJSONObject(i).getBoolean("advancedDefinitionApplicable"))
				commercialCall("DiscountClientCommercialAdvancedDT", "DiscountClientCommercialCalculationDT", "Discount", mdmCommDefn, mainJson, productName, true , productCategory, productCategorySubType,id);
				//else commercialCall("DiscountClientCommercialAdvancedDT", "DiscountClientCommercialCalculationDT", "Discount", mdmCommDefn, mainJson, productName, false , productCategory, productCategorySubType,id,bookingId);
				break;
			}
			case "MarkUp":{
				setMarkUpCommercialDetails(mainJson,productName,id,flightsAndNonAir,mdmCommDefn,clientCommercialDataID);
				break;
			}
			}
		}
		return mainJson;
	}


	private static void setMarkUpCommercialDetails(JSONObject mainJson, String productName, String id, JSONObject flightsAndNonAir, JSONObject mdmCommDefn, String clientCommercialDataID) {
		JSONArray markUpArr = flightsAndNonAir.getJSONArray("markup");
		JSONArray advancedArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		for(int e=0;e<markUpArr.length();e++){
			JSONObject markUpObject = markUpArr.getJSONObject(e);
			clientCommercialDataID=clientCommercialDataID+"|markup|"+markUpObject.getString("_id")+"|"+entityType;
			setContractValidity(markUpObject, "Mark-up",productName);
			setMinSellingPrice(markUpObject);
			setMarkUpCalculation(markUpObject);
			JSONObject markUpBase = new JSONObject();
			JSONObject markUpCalc = new JSONObject();
			markUpBase.put("type", "advanced");
			markUpBase.put("RuleID", "Advanced_"+markUpObject.getString("_id"));
			markUpBase.put("selectedRow", id);
			markUpBase.put("agendaGroup", id+"_MarkUp");
			//markUpBase.put("entitySelectedRow", "Advanced_"+markUpObject.getString("_id"));
			markUpCalc.put("RuleID", "Calculation_"+markUpObject.getString("_id"));
			markUpCalc.put("selectedRow", "Advanced_"+markUpObject.getString("_id"));
			markUpCalc.put("agendaGroup", id+"_MarkUp");
			markUpCalc.put("type", "calculation");
			markUpCalc.put("mdmRuleID",clientCommercialDataID);
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", markUpContractValidityFrom);
			contractValidity.put("to", markUpContractValidityTo);
			markUpBase.put("contractValidity", contractValidity);
			markUpCalc.put("currency", minSellingPriceCurrency);
			markUpCalc.put("minSellingPrice", minSellingPriceAmount);
			markUpCalc.put("markUpPercentage", markUpPercentage);
			//markUpCalc.put("currency", markUpCurrency);
			markUpCalc.put("markUpAmount", markUpAmount);
			markUpCalc.put("fareComponent", markUpFareComponent);

			advancedArr.put(markUpBase);
			calcArr.put(markUpCalc);

			if(markUpObject.has("advanceDefinitionId")){
				JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray("advancedDefinitionData");
				for(int k=0;k<advancedDefinitionData.length();k++){
					JSONObject advancedDefinitionObject = advancedDefinitionData.getJSONObject(k);
					if(markUpObject.getString("advanceDefinitionId").equals(advancedDefinitionObject.getString("_id"))){
						switch(productName){
						case "air":{
							JSONObject advanceDefinitionAir = advancedDefinitionObject.getJSONObject("advanceDefinitionAir");
							Air.setAdvancedDefinition(advancedArr,calcArr,advanceDefinitionAir,markUpObject.getString("advanceDefinitionId"));
							break;
						}
						case "accomodation":{
							JSONObject advanceDefinitionAccommodation = advancedDefinitionObject.getJSONObject("advanceDefinitionAccommodation");
							Accomodation.appendAccomodationAdvancedDefinition(advancedArr,calcArr,advanceDefinitionAccommodation,id);
							break;
						}
						case "activities":{
							JSONObject advanceDefinitionActivities = advancedDefinitionObject.getJSONObject("advanceDefinitionActivities");
							Activities.appendAdvancedDefinition(advancedArr,calcArr,advanceDefinitionActivities,markUpObject.getString("advanceDefinitionId"));
							break;
						}
						case "carrentals":{
							JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject("advanceDefinitionTransportation");
							CarRentals.appendTransportationAdvancedDefinition(advancedArr,calcArr,advanceDefinitionTransportation,markUpObject.getString("advanceDefinitionId"));
							break;
						}
						case "bus":{
							JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject("advanceDefinitionTransportation");
							Bus.appendTransportationAdvancedDefinition(advancedArr,calcArr,advanceDefinitionTransportation,markUpObject.getString("advanceDefinitionId"));
							break;
						}
						case "rail":{}
						case "cruise":{
							JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject("advanceDefinitionTransportation");
							setTransportationAdvancedDefinition(advanceDefinitionTransportation, advancedArr,calcArr);
							break;
						}
						case "insurance":{}
						case "holidays":{
							JSONObject advanceDefinitionHolidays = advancedDefinitionObject.getJSONObject("advanceDefinition").getJSONObject("advanceDefinitionHolidays");
							Holidays.setHolidaysAdvancedDefinition(advancedArr,calcArr,advanceDefinitionHolidays,markUpObject.getString("advanceDefinitionId"), "MarkUp", mainJson,mdmCommDefn.getJSONArray("clientCommercialOtherHead"));
							break;
						}
						case "visa":{}
						case "transfers":{
							JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject("advanceDefinitionTransportation");
							Transfers.appendTransportationAdvancedDefinition(advancedArr,calcArr,advanceDefinitionTransportation,markUpObject.getString("advanceDefinitionId"));
							break;
						}
						default:System.out.println("Default of MarkUp Adv Defn coz of productName: "+productName);
						}
					}
				}
			}

			/*if(markUp.has("rateType"))
				markUpRateType = markUp.getString("rateType");*/
		}
		
		for(int i=0;i<calcArr.length();i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			String ruleId = calculation.getString("mdmRuleID")+"|"+calculation.getString("selectedRow");
			calculation.put("mdmRuleID", ruleId);
		}
		
		mainJson.put("MarkUpClientCommercialAdvancedDT", advancedArr);
		mainJson.put("MarkUpClientCommercialCalculationDT", calcArr);

	}


	public static void setTransportationOtherFeesDestination(JSONArray otherFeeArr, JSONObject advanceDefinitionTransportation){
		if(advanceDefinitionTransportation.getJSONObject("travelDestination").has("destinations")){
			JSONArray destinationArray = advanceDefinitionTransportation.getJSONObject("travelDestination").getJSONArray("destinations");
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<destinationArray.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject destinationObj = destinationArray.getJSONObject(j);
					if(advanceDefinitionTransportation.getJSONObject("travelDestination").getBoolean("isInclusion")){
						if(destinationObj.has("continent") && !destinationObj.getString("continent").equalsIgnoreCase("All"))
							otherFee.put("continent", destinationObj.getString("continent"));
						if(destinationObj.has("country") && !destinationObj.getString("country").equalsIgnoreCase("All"))
							otherFee.put("country", destinationObj.getString("country"));
						if(destinationObj.has("state") && !destinationObj.getString("state").equalsIgnoreCase("All"))
							otherFee.put("state", destinationObj.getString("state"));
						if(destinationObj.has("city") && !destinationObj.getString("city").equalsIgnoreCase("All"))
							otherFee.put("city", destinationObj.getString("city"));
					}else{
						if(destinationObj.has("continent") && !destinationObj.getString("continent").equalsIgnoreCase("All"))
							otherFee.put("continent_exclusion", destinationObj.getString("continent"));
						if(destinationObj.has("country") && !destinationObj.getString("country").equalsIgnoreCase("All"))
							otherFee.put("country_exclusion", destinationObj.getString("country"));
						if(destinationObj.has("state") && !destinationObj.getString("state").equalsIgnoreCase("All"))
							otherFee.put("state_exclusion", destinationObj.getString("state"));
						if(destinationObj.has("city") && !destinationObj.getString("city").equalsIgnoreCase("All"))
							otherFee.put("city_exclusion", destinationObj.getString("city"));
					}
					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, destinationObj.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}


	public static void setOtherFeesTransportationAdvancedDefinition(JSONObject advanceDefinitionTransportation, JSONArray otherFeeArr) {
		//ancillary name, ancillary type, applicable on : not in schema
		if(advanceDefinitionTransportation.has("validity")){
			JSONObject validity = advanceDefinitionTransportation.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "sale":{
				setOtherFeesDate(otherFeeArr,validity.getJSONArray("sale"),"sale");
				break;
			}
			case "travel":{
				setOtherFeesDate(otherFeeArr,validity.getJSONArray("travel"),"travel");
				break;
			}
			default:{
				setOtherFeeSalePlusTravelDate(otherFeeArr, validity.getJSONArray("salePlusTravel"));
			}
			}
		}

		if(advanceDefinitionTransportation.has("travelDestination"))
			setTransportationOtherFeesDestination(otherFeeArr, advanceDefinitionTransportation);

		if(advanceDefinitionTransportation.has("others")){
			JSONObject others = advanceDefinitionTransportation.getJSONObject("others");
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				otherFee.put("bookingType", others.getString("bookingType"));
			}
		}

		if(advanceDefinitionTransportation.has("connectivity")){
			JSONObject connectivity = advanceDefinitionTransportation.getJSONObject("connectivity");
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierType",connectivity.getString("supplierType"));
				if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierName",connectivity.getString("supplierId"));
			}
		}

		if(advanceDefinitionTransportation.has("credentials") && advanceDefinitionTransportation.getJSONArray("credentials").length()>0)
			getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray("credentials"), "credentials");

		if(advanceDefinitionTransportation.has("nationality") && advanceDefinitionTransportation.getJSONArray("nationality").length()>0)
			getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray("nationality"), "clientNationality");

		if(advanceDefinitionTransportation.has("passengerTypes") && advanceDefinitionTransportation.getJSONArray("passengerTypes").length()>0)
			getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray("passengerTypes"), "passengerTypes");
	}


	public static void setOtherFeeSalePlusTravelDate(JSONArray otherFeeArr, JSONArray salePlusTravel) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(j);
				JSONArray tickincArr =new JSONArray();
				JSONArray tickexcArr =new JSONArray();
				JSONArray travelincArr =new JSONArray();
				JSONArray travelexcArr =new JSONArray();
				JSONObject indiTicketObj = new JSONObject();
				JSONObject indiTravelObj = new JSONObject();
				JSONObject indiTicketBlockObj = new JSONObject();
				JSONObject indiTravelBlockObj = new JSONObject();
				JSONArray ticketingDate = new JSONArray();
				JSONArray travelDate = new JSONArray();
				JSONObject inclusionTkt = new JSONObject();
				JSONObject exclusionTkt = new JSONObject();
				JSONObject inclusionTra = new JSONObject();
				JSONObject exclusionTra = new JSONObject();

				JSONObject sales = salePlusTravelObject.getJSONObject("sales");
				if(sales.has("saleFrom")){
					if(sales.has("saleTo")){
						indiTicketObj.put("operator","BETWEEN");
						indiTicketObj.put("from", sales.getString("saleFrom").substring(0, 19));
						indiTicketObj.put("to", sales.getString("saleTo").substring(0, 19));
					}else{
						indiTicketObj.put("operator","GREATERTHANEQUALTO");
						indiTicketObj.put("value", sales.getString("saleFrom").substring(0, 19));
					}
				}else if(sales.has("saleTo")){
					indiTicketObj.put("operator","LESSTHANEQUALTO");
					indiTicketObj.put("value", sales.getString("saleTo").substring(0, 19));
				}

				if(sales.has("blockOutFrom")){
					if(sales.has("blockOutTo")){
						indiTicketBlockObj.put("operator", "BETWEEN");
						indiTicketBlockObj.put("from", sales.getString("blockOutFrom").substring(0, 19));
						indiTicketBlockObj.put("to", sales.getString("blockOutTo").substring(0, 19));
					}else{
						indiTicketBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTicketBlockObj.put("value", sales.getString("blockOutFrom").substring(0, 19));
					}
				}else if(sales.has("blockOutTo")){
					indiTicketBlockObj.put("operator", "LESSTHANEQUALTO");
					indiTicketBlockObj.put("value", sales.getString("blockOutTo").substring(0, 19));
				}

				JSONObject travelObject = salePlusTravelObject.getJSONObject("travel");
				if(travelObject.has("travelFrom")){
					if(travelObject.has("travelTo")){
						indiTravelObj.put("operator","BETWEEN");
						indiTravelObj.put("from", travelObject.getString("travelFrom").substring(0, 19));
						indiTravelObj.put("to", travelObject.getString("travelTo").substring(0, 19));
					}else{
						indiTravelObj.put("operator","GREATERTHANEQUALTO");
						indiTravelObj.put("value", travelObject.getString("travelFrom").substring(0, 19));
					}
				}else if(travelObject.has("travelTo")){
					indiTravelObj.put("operator","LESSTHANEQUALTO");
					indiTravelObj.put("value", travelObject.getString("travelTo").substring(0, 19));
				}

				if(travelObject.has("blockOutFrom")){
					if(travelObject.has("blockOutTo")){
						indiTravelBlockObj.put("operator", "BETWEEN");
						indiTravelBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
						indiTravelBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiTravelBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTravelBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
					}
				}else if(travelObject.has("blockOutTo")){
					indiTravelBlockObj.put("operator", "LESSTHANEQUALTO");
					indiTravelBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
				}


				if(indiTicketObj!=null){
					tickincArr.put(indiTicketObj);
					inclusionTkt.put("inclusion",tickincArr);
					ticketingDate.put(inclusionTkt);
				}
				if(indiTicketBlockObj!=null){
					tickexcArr.put(indiTicketBlockObj);
					exclusionTkt.put("exclusion",tickexcArr);
					ticketingDate.put(exclusionTkt);
				}
				if(indiTravelObj!=null){
					travelincArr.put(indiTravelObj);
					inclusionTra.put("inclusion",travelincArr);
					travelDate.put(inclusionTra);
				}
				if(indiTravelBlockObj!=null){
					travelexcArr.put(indiTravelBlockObj);
					exclusionTra.put("exclusion",travelexcArr);
					travelDate.put(exclusionTra);
				}
				otherFee.put("sale", ticketingDate);
				otherFee.put("travel", travelDate);

				setOtherFeesRuleID(otherFeeArr, otherFee, salePlusTravelObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}


	public static void setTravelTicketing(JSONArray baseArr, JSONArray calcArr, JSONObject validity) {
		switch(validity.getString("validityType")){
		case "ticketing":{
			setDate(baseArr,calcArr,validity.getJSONArray("ticketing"),"ticketing",true);
			break;
		}
		case "travel":{
			setDate(baseArr,calcArr,validity.getJSONArray("travel"),"travel",false);
			break;
		}
		default:{
			int length = baseArr.length();
			JSONArray ticketingPlusTravel = validity.getJSONArray("ticketingPlusTravel");
			for(int i=0;i<length;i++){
				for(int j=0;j<ticketingPlusTravel.length();j++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(j);

					JSONArray tickincArr =new JSONArray();
					JSONArray tickexcArr =new JSONArray();
					JSONArray travelincArr =new JSONArray();
					JSONArray travelexcArr =new JSONArray();
					JSONObject indiTicketObj = new JSONObject();
					JSONObject indiTravelObj = new JSONObject();
					JSONObject indiTicketBlockObj = new JSONObject();
					JSONObject indiTravelBlockObj = new JSONObject();
					JSONArray ticketingDate = new JSONArray();
					JSONArray travelDate = new JSONArray();
					JSONObject inclusionTkt = new JSONObject();
					JSONObject exclusionTkt = new JSONObject();
					JSONObject inclusionTra = new JSONObject();
					JSONObject exclusionTra = new JSONObject();

					JSONObject ticketingObject = ticketPlusTravelObj.getJSONObject("ticket");
					if(ticketingObject.has("ticketingFrom")){
						if(ticketingObject.has("ticketingTo")){
							indiTicketObj.put("operator","BETWEEN");
							indiTicketObj.put("from", ticketingObject.getString("ticketingFrom").substring(0, 19));
							indiTicketObj.put("to", ticketingObject.getString("ticketingTo").substring(0, 19));
						}else{
							indiTicketObj.put("operator","GREATERTHANEQUALTO");
							indiTicketObj.put("value", ticketingObject.getString("ticketingFrom").substring(0, 19));
						}
					}else if(ticketingObject.has("ticketingTo")){
						indiTicketObj.put("operator","LESSTHANEQUALTO");
						indiTicketObj.put("value", ticketingObject.getString("ticketingTo").substring(0, 19));
					}

					if(ticketingObject.has("blockOutFrom")){
						if(ticketingObject.has("blockOutTo")){
							indiTicketBlockObj.put("operator", "BETWEEN");
							indiTicketBlockObj.put("from", ticketingObject.getString("blockOutFrom").substring(0, 19));
							indiTicketBlockObj.put("to", ticketingObject.getString("blockOutTo").substring(0, 19));
						}else{
							indiTicketBlockObj.put("operator", "GREATERTHANEQUALTO");
							indiTicketBlockObj.put("value", ticketingObject.getString("blockOutFrom").substring(0, 19));
						}
					}else{
						if(ticketingObject.has("blockOutTo")){
							indiTicketBlockObj.put("operator", "LESSTHANEQUALTO");
							indiTicketBlockObj.put("value", ticketingObject.getString("blockOutTo").substring(0, 19));
						}
					}

					JSONObject travelObject = ticketPlusTravelObj.getJSONObject("travel");
					if(travelObject.has("travelFrom")){
						if(travelObject.has("travelTo")){
							indiTravelObj.put("operator","BETWEEN");
							indiTravelObj.put("from", travelObject.getString("travelFrom").substring(0, 19));
							indiTravelObj.put("to", travelObject.getString("travelTo").substring(0, 19));
						}else{
							indiTravelObj.put("operator","GREATERTHANEQUALTO");
							indiTravelObj.put("value", travelObject.getString("travelFrom").substring(0, 19));
						}
					}else if(travelObject.has("travelTo")){
						indiTravelObj.put("operator","LESSTHANEQUALTO");
						indiTravelObj.put("value", travelObject.getString("travelTo").substring(0, 19));
					}
					if(travelObject.has("blockOutFrom")){
						if(travelObject.has("blockOutTo")){
							indiTravelBlockObj.put("operator", "BETWEEN");
							indiTravelBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
							indiTravelBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
						}else{
							indiTravelBlockObj.put("operator", "GREATERTHANEQUALTO");
							indiTravelBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
						}
					}else{
						if(travelObject.has("blockOutTo")){
							indiTravelBlockObj.put("operator", "LESSTHANEQUALTO");
							indiTravelBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
						}
					}

					if(indiTicketObj!=null){
						tickincArr.put(indiTicketObj);
						inclusionTkt.put("inclusion",tickincArr);
						ticketingDate.put(inclusionTkt);
					}
					if(indiTicketBlockObj!=null){
						tickexcArr.put(indiTicketBlockObj);
						exclusionTkt.put("exclusion",tickexcArr);
						ticketingDate.put(exclusionTkt);
					}
					if(indiTravelObj!=null){
						travelincArr.put(indiTravelObj);
						inclusionTra.put("inclusion",travelincArr);
						travelDate.put(inclusionTra);
					}
					if(indiTravelBlockObj!=null){
						travelexcArr.put(indiTravelBlockObj);
						exclusionTra.put("exclusion",travelexcArr);
						travelDate.put(exclusionTra);
					}
					base.put("ticketing", ticketingDate);
					calculation.put("travel", travelDate);

					setRuleID(baseArr, calcArr, base, calculation, ticketPlusTravelObj.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}break;
		}
	}


	public static void setDefaultAdvDefnID(String productName) {
		switch(productName){
		case "air":{Air.markupAdvanceDefinitionId=null;break;}
		case "activities":{Activities.markupAdvanceDefinitionId=null;break;}
		case "accomodation":{Accomodation.markupAdvanceDefinitionId=null;break;}
		case "carrentals":{CarRentals.markupAdvanceDefinitionId=null;break;}
		case "holidays":{Holidays.markupAdvanceDefinitionId=null;break;}
		case "rail":{Rail.markupAdvanceDefinitionId=null;break;}
		case "bus":{Bus.markupAdvanceDefinitionId=null;break;}
		case "cruise":{Cruise.markupAdvanceDefinitionId=null;break;}
		case "insurance":{Insurance.markupAdvanceDefinitionId=null;break;}
		case "transfers":{Transfers.markupAdvanceDefinitionId=null;break;}
		default:System.out.println("default of setDeafultAdvDefnID");
		}
		stdclientCommercialDataID=null;overclientCommercialDataID=null;plbclientCommercialDataID=null;segmentclientCommercialDataID=null;
		sectorclientCommercialDataID=null;destinationclientCommercialDataID=null;commissionclientCommercialDataID=null;issuanceclientCommercialDataID=null;
		serviceclientCommercialDataID=null;discountclientCommercialDataID=null;mngtclientCommercialDataID=null;markupclientCommercialDataID=null;
	}


	public static void setRetentionCommercials(String retentionType, String commercialName, JSONObject receivableToCompany, String clientCommercialDataID) {
		if(retentionType.equals("ProductBased")){
			JSONObject retention = receivableToCompany.getJSONObject(CommonFunctions.retention);
			switch(commercialName){
			case "Standard Commercial":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					stdretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					stdretentionAmount = retention.get("retentionAmount").toString();
				stdclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Overriding Commission":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					overretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					overretentionAmount = retention.get("retentionAmount").toString();
				overclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Productivity Linked Bonus":{
				//slab wala in applicableOn
				plbOH = "slab";
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					plbretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					plbretentionAmount = retention.get("retentionAmount").toString();
				plbclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Segment Fees":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					segmentretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					segmentretentionAmount = retention.get("retentionAmount").toString();
				segmentclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Segments Fees":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					segmentretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					segmentretentionAmount = retention.get("retentionAmount").toString();
				segmentclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Sector Incentives":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					sectorretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					sectorretentionAmount = retention.get("retentionAmount").toString();
				sectorclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Management Fee":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					mngtretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					mngtretentionAmount = retention.get("retentionAmount").toString();
				mngtclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Service Charges":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					serviceretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					serviceretentionAmount = retention.get("retentionAmount").toString();
				serviceclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Discount":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					discountretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					discountretentionAmount = retention.get("retentionAmount").toString();
				discountclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Mark-up":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					markUpretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					markUpretentionAmount = retention.get("retentionAmount").toString();
				markupclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Commission":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					commissionretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					commissionretentionAmount = retention.get("retentionAmount").toString();
				commissionclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Issuance Fees":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					issuanceretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					issuanceretentionAmount = retention.get("retentionAmount").toString();
				issuanceclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Destination Incentives":{
				if(retention.has("retentionPercent") && !retention.get("retentionPercent").equals(0))
					destinationretentionPercentage = retention.get("retentionPercent").toString();
				if(retention.has("retentionAmount") && !retention.get("retentionAmount").equals(0))
					destinationretentionAmount = retention.get("retentionAmount").toString();
				destinationclientCommercialDataID=clientCommercialDataID;
				break;
			}
			default:System.out.println("default of setRetentionCommercials: ProductBased > retention due to: "+commercialName);
			}
		}else{
			JSONObject entityType = receivableToCompany.getJSONObject(CommonFunctions.entityType);
			switch(commercialName){
			case "Standard Commercial":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					stdretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					stdretentionAmount = entityType.get("amount").toString();
				stdclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Overriding Commission":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					overretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					overretentionAmount = entityType.get("amount").toString();
				overclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Productivity Linked Bonus":{
				//retentionwala in ApplicableOn
				plbOH = "retention";
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					plbretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					plbretentionAmount = entityType.get("amount").toString();
				plbclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Segment Fees":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					segmentretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					segmentretentionAmount = entityType.get("amount").toString();
				segmentclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Segments Fees":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					segmentretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					segmentretentionAmount = entityType.get("amount").toString();
				segmentclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Sector Incentives":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					sectorretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					sectorretentionAmount = entityType.get("amount").toString();
				sectorclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Management Fee":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					mngtretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					mngtretentionAmount = entityType.get("amount").toString();
				mngtclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Service Charges":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					serviceretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					serviceretentionAmount = entityType.get("amount").toString();
				serviceclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Discount":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					discountretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					discountretentionAmount = entityType.get("amount").toString();
				discountclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Mark-up":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					markUpretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					markUpretentionAmount = entityType.get("amount").toString();
				markupclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Commission":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					commissionretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					commissionretentionAmount = entityType.get("amount").toString();
				commissionclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Issuance Fees":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					issuanceretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					issuanceretentionAmount = entityType.get("amount").toString();
				issuanceclientCommercialDataID=clientCommercialDataID;
				break;
			}
			case "Destination Incentives":{
				if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
					destinationretentionPercentage = entityType.get("percentage").toString();
				if(entityType.has("amount") && !entityType.get("amount").equals(0))
					destinationretentionAmount = entityType.get("amount").toString();
				destinationclientCommercialDataID=clientCommercialDataID;
				break;
			}
			default:System.out.println("default of setRetentionCommercials: SupplierBased > entityType");
			}
		}
	}


	public static void insertsalesAndTravelDates(JSONObject transportation, JSONObject advanced, JSONObject mdmAdvDefn) {
		if(transportation.getJSONObject("validity").has("validityType")){
			String validityType = transportation.getJSONObject("validity").getString("validityType");
			switch(validityType){
			case "sale":{
				if(transportation.getJSONObject("validity").getJSONArray("sale")!=null)
					advanced.put("sale", getTransportationDate(transportation.getJSONObject("validity").getJSONArray("sale"))); break;
			}
			case "travel":{
				if(transportation.getJSONObject("validity").getJSONArray("travel")!=null)
					advanced.put("travel", getTransportationDate(transportation.getJSONObject("validity").getJSONArray("travel"))); break;
			}
			default:{
				JSONObject salePlusTravel = new JSONObject();
				salePlusTravel = transportation.getJSONObject("validity").getJSONObject("salePlusTravel");
				//sale
				JSONArray sale = new JSONArray();
				sale = salePlusTravel.getJSONArray("sale");
				JSONArray inclusionArr = new JSONArray();
				JSONArray exclusionArr = new JSONArray();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray saleArr = new JSONArray();
				for(int i=0;i<sale.length();i++){
					JSONObject inclusionIndiObj = new JSONObject();
					JSONObject inclusionIndiObjMDM = new JSONObject();
					inclusionIndiObjMDM =sale.getJSONObject(i);
					if(inclusionIndiObjMDM.get("ticketingFrom") instanceof String){
						inclusionIndiObj.put("operator", "BETWEEN");
						inclusionIndiObj.put("from", inclusionIndiObjMDM.get("ticketingFrom").toString().substring(0, 19));
						inclusionIndiObj.put("to", inclusionIndiObjMDM.get("ticketingTo").toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}
					//blockOut
					JSONObject exclusionIndiObj = new JSONObject();
					JSONObject exclusionIndiObjMDM = new JSONObject();
					exclusionIndiObjMDM =sale.getJSONObject(i);
					if(exclusionIndiObjMDM.get("ticketingBlockOutFrom") instanceof String){
						exclusionIndiObj.put("operator", "BETWEEN");
						exclusionIndiObj.put("from", exclusionIndiObjMDM.get("ticketingBlockOutFrom").toString().substring(0, 19));
						exclusionIndiObj.put("to", exclusionIndiObjMDM.get("ticketingBlockOutTo").toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}
				}
				inclusionObject.put("inclusion",inclusionArr);
				saleArr.put(inclusionObject);
				exclusionObject.put("exclusion",exclusionArr);
				saleArr.put(exclusionObject);
				advanced.put("sale", saleArr);
				//travel
				JSONArray travel = new JSONArray();
				travel = salePlusTravel.getJSONArray("travel");
				JSONArray travelinclusionArr = new JSONArray();
				JSONArray travelexclusionArr = new JSONArray();
				JSONObject travelinclusionObject = new JSONObject();
				JSONObject travelexclusionObject = new JSONObject();
				JSONArray travelArr = new JSONArray();
				for(int i=0;i<travel.length();i++){
					JSONObject inclusionIndiObj = new JSONObject();
					JSONObject inclusionIndiObjMDM = new JSONObject();
					inclusionIndiObjMDM = travel.getJSONObject(i);
					if(inclusionIndiObjMDM.get("travelFrom") instanceof String){
						inclusionIndiObj.put("operator", "BETWEEN");
						inclusionIndiObj.put("from", inclusionIndiObjMDM.get("travelFrom").toString().substring(0, 19));
						inclusionIndiObj.put("to", inclusionIndiObjMDM.get("travelTo").toString().substring(0, 19));
						travelinclusionArr.put(inclusionIndiObj);
					}
					//blockOut
					JSONObject exclusionIndiObj = new JSONObject();
					JSONObject exclusionIndiObjMDM = new JSONObject();
					exclusionIndiObjMDM =travel.getJSONObject(i);
					exclusionIndiObj.put("operator", "BETWEEN");
					exclusionIndiObj.put("from", exclusionIndiObjMDM.get("travelBlockOutFrom").toString().substring(0, 19));
					exclusionIndiObj.put("to", exclusionIndiObjMDM.get("travelBlockOutTo").toString().substring(0, 19));
					travelexclusionArr.put(exclusionIndiObj);
				}
				travelinclusionObject.put("inclusion",travelinclusionArr);
				travelArr.put(travelinclusionObject);
				travelexclusionObject.put("exclusion",travelexclusionArr);
				travelArr.put(travelexclusionObject);
				advanced.put("travel", travelArr);
			}
			}
		}
	}


	public static JSONArray getTransportationDate(JSONArray sale){
		JSONArray inclusionArr = new JSONArray();
		JSONArray exclusionArr = new JSONArray();
		JSONObject inclusionObject = new JSONObject();
		JSONObject exclusionObject = new JSONObject();
		JSONArray saleArr = new JSONArray();
		for(int i=0;i<sale.length();i++){
			JSONObject inclusionIndiObj = new JSONObject();
			JSONObject inclusionIndiObjMDM = new JSONObject();
			inclusionIndiObjMDM =sale.getJSONObject(i);
			inclusionIndiObj.put("operator", "BETWEEN");
			inclusionIndiObj.put("from", inclusionIndiObjMDM.get("from").toString().substring(0, 19));
			inclusionIndiObj.put("to", inclusionIndiObjMDM.get("to").toString().substring(0, 19));
			inclusionArr.put(inclusionIndiObj);
			if(inclusionIndiObjMDM.has("blockOut")){
				for(int j=0;j<inclusionIndiObjMDM.getJSONArray("blockOut").length();j++){
					JSONObject exclusionIndiObj = new JSONObject();
					JSONObject exclusionIndiObjMDM = new JSONObject();
					exclusionIndiObjMDM =inclusionIndiObjMDM.getJSONArray("blockOut").getJSONObject(j);
					exclusionIndiObj.put("operator", "BETWEEN");
					exclusionIndiObj.put("from", exclusionIndiObjMDM.get("from").toString().substring(0, 19));
					exclusionIndiObj.put("to", exclusionIndiObjMDM.get("to").toString().substring(0, 19));
					exclusionArr.put(exclusionIndiObj);
				}
				exclusionObject.put("exclusion",exclusionArr);
				saleArr.put(exclusionObject);
			}
		}
		inclusionObject.put("inclusion",inclusionArr);
		saleArr.put(inclusionObject);
		return saleArr;
	}


	public static JSONArray getAncillaryDetails(String attribute, JSONArray ancillary) {
		JSONArray ancillaryName = new JSONArray();
		JSONArray ancillaryType = new JSONArray();
		for(int i=0;i<ancillary.length();i++){
			ancillaryName.put(ancillary.getJSONObject(i).getString("ancillaryName"));
			ancillaryType.put(ancillary.getJSONObject(i).getString("ancillaryType"));
		}
		if(attribute.equals("name"))
			return ancillaryName;
		else return ancillaryType;
	}


	public static String getProductName(JSONObject mdmCommDefn) {
		String productCategory = mdmCommDefn.get("productCategory").toString();
		switch(productCategory){
		case "Accommodation":return "accomodation";
		case "Activities": return "activities";
		case "Combination": return "combination";
		case "Holidays": return "holidays";
		case "Other Products": {
			String subCategory = mdmCommDefn.get("subCategory").toString();
			switch(subCategory){
			case "Insurance": return "insurance";
			case "Visa": return "visa";
			}
		}
		case "Transportation":{
			String subCategory = mdmCommDefn.get("subCategory").toString();
			switch(subCategory){
			case "Bus": return "bus";
			case "Car": return "carrentals";
			case "Cruise": return "cruise";
			case "European Rail": return "rail";
			case "Flight": return "air";
			case "Indian Rail": return "rail";
			case "Rail": return "rail";
			case "Rental": return "rentals";
			case "Transfer": return "transfers";
			}
		}
		}
		return null;
	}


	public static boolean isTransactional(String commName) {
		switch(commName){
		case "Standard Commercial":{return true;}
		case "Overriding Commission":{return true;}
		case "Productivity Linked Bonus":{return true;}
		case "Segment Fees":{return true;}
		case "Segments Fees":{return true;}
		case "Sector Incentives":{return true;}
		case "Management Fee":{return true;}
		case "Service Charges":{return true;}
		case "Discount":{return true;}
		case "Destination Incentives":{return true;}
		case "Issuance Fees":{return true;}
		case "Commission":{return true;}
		}
		return false;
	}


	public static void setDate(JSONArray advancedArr, JSONArray calculationArr, JSONArray dateArray, String date, boolean inBase) {
		String from = date+"From";
		String to = date+"To";

		int length = advancedArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(i).toString()));
				JSONObject dateObject =dateArray.getJSONObject(j);

				JSONArray incArr =new JSONArray();
				JSONArray excArr =new JSONArray();
				JSONObject indiObj = new JSONObject();
				JSONObject indiBlockObj = new JSONObject();
				JSONArray Date = new JSONArray();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();

				if(dateObject.has(from)){
					if(dateObject.has(to)){
						indiObj.put("operator","BETWEEN");
						indiObj.put("from", dateObject.getString(from).substring(0, 19));
						indiObj.put("to", dateObject.getString(to).substring(0, 19));
					}else{
						indiObj.put("operator","GREATERTHANEQUALTO");
						indiObj.put("value", dateObject.getString(from).substring(0, 19));
					}
				}else if(dateObject.has(to)){
					indiObj.put("operator","LESSTHANEQUALTO");
					indiObj.put("value", dateObject.getString(to).substring(0, 19));
				}

				if(dateObject.has("blockOutFrom")){
					if(dateObject.has("blockOutTo")){
						indiBlockObj.put("operator", "BETWEEN");
						indiBlockObj.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
						indiBlockObj.put("to", dateObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiBlockObj.put("value", dateObject.getString("blockOutFrom").substring(0, 19));
					}
				}else{
					if(dateObject.has("blockOutTo")){
						indiBlockObj.put("operator", "LESSTHANEQUALTO");
						indiBlockObj.put("value", dateObject.getString("blockOutTo").substring(0, 19));
					}
				}

				if(indiObj.has("operator")){
					incArr.put(indiObj);
					inclusion.put("inclusion",incArr);
					Date.put(inclusion);
				}
				if(indiBlockObj.has("operator")){
					excArr.put(indiBlockObj);
					exclusion.put("exclusion",excArr);
					Date.put(exclusion);
				}

				if(inBase)
					base.put(date, Date);
				else calculation.put(date, Date);

				setRuleID(advancedArr,calculationArr,base,calculation,dateObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			advancedArr.remove(0);
			calculationArr.remove(0);
		}
	}


	public static void setRuleID(JSONArray advancedArr, JSONArray calculationArr, JSONObject base,JSONObject calculation, String ID) {
		String baseID = base.getString("RuleID");
		String calcID = calculation.getString("RuleID");
		base.put("RuleID", baseID+ID);
		calculation.put("RuleID", calcID+ID);
		//base.put("entitySelectedRow", baseID+ID);
		calculation.put("selectedRow", baseID+ID);
		advancedArr.put(base);
		calculationArr.put(calculation);
	}


	public static void getCalculationDetails(JSONArray commHead, String commercialName, String retentionPercentage, String retentionAmount, String additionalPercentage, String additionalAmount, String fareComponent, String currency, JSONObject calculation){
		for(int j=0;j<commHead.length();j++){
			if(commHead.getJSONObject(j).get("commercialHeadName").toString().equals(commercialName)){
				switch(commHead.getJSONObject(j).getString("commercialProperty")){
				case "Retention":{
					calculation.put("retentionPercentage", retentionPercentage);
					calculation.put("retentionAmount", retentionAmount);
					break;
				}
				case "Additional":{
					calculation.put("additionalPercentage", additionalPercentage);
					calculation.put("additionalAmount", additionalAmount);
					calculation.put("fareComponent", fareComponent);
					calculation.put("currency", currency);
					break;
				}
				case "MarkUp":{
					calculation.put("markUpPercentage", CommonFunctions.markUpPercentage);
					calculation.put("markUpAmount", CommonFunctions.markUpAmount);
					calculation.put("fareComponent", CommonFunctions.markUpFareComponent);
					calculation.put("currency", CommonFunctions.markUpCurrency);
					calculation.put("minimumSellingPrice", CommonFunctions.minSellingPriceAmount);
					break;
				}
				default:{
					//Fixed
				}
				}
			}
		}
	}


	public static JSONObject getTriggerPayoutObject(JSONArray triggerOrPayout) {
		JSONObject triggerPayout = new JSONObject();
		boolean trigger=false,payout=false;
		for(int i=0;i<triggerOrPayout.length();i++){
			String value = triggerOrPayout.getString(i);
			if(value.equalsIgnoreCase("trigger"))
				trigger=true;

			if(value.equalsIgnoreCase("payout"))
				payout=true;
		}
		triggerPayout.put("trigger", trigger);
		triggerPayout.put("payout", payout);

		return triggerPayout;
	}


	public static void getPLBDates(JSONArray baseArr, JSONArray calcArr, JSONArray dateArr, String date) {
		String from = date+"From";
		String to = date+"To";
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArr.length();j++){
				JSONObject dateObject = dateArr.getJSONObject(j);
				JSONObject trigPayout = getTriggerPayoutObject(dateObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject DATEInc = new JSONObject();
				JSONObject DATEExc = new JSONObject();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();
				JSONArray DateInclusionArr = new JSONArray();
				JSONArray DateExclusionArr = new JSONArray();
				JSONArray mainDateArray = new JSONArray();
				if(dateObject.has(from)){
					if(dateObject.has(to)){
						DATEInc.put("operator", "BETWEEN");
						DATEInc.put("from", dateObject.getString(from).substring(0, 19));
						DATEInc.put("to", dateObject.getString(to).substring(0, 19));
					}else{
						DATEInc.put("operator", "GREATERTHANEQUALTO");
						DATEInc.put("from", dateObject.getString(from).substring(0, 19));
					}
				}else if(dateObject.has(to)){
					DATEInc.put("operator", "LESSTHANEQUALTO");
					DATEInc.put("to", dateObject.getString(to).substring(0, 19));
				}

				if(dateObject.has("blockOutFrom")){
					if(dateObject.has("blockOutTo")){
						DATEExc.put("operator", "BETWEEN");
						DATEExc.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
						DATEExc.put("to", dateObject.getString("blockOutTo").substring(0, 19));
					}else{
						DATEExc.put("operator", "GREATERTHANEQUALTO");
						DATEExc.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
					}
				}else if(dateObject.has("blockOutTo")){
					DATEExc.put("operator", "LESSTHANEQUALTO");
					DATEExc.put("to", dateObject.getString("blockOutTo").substring(0, 19));
				}

				mainDateArray.put(trigPayout);

				if(DATEInc.has("operator")){
					DateInclusionArr.put(DATEInc);
					inclusion.put("inclusion", DateInclusionArr);
					mainDateArray.put(inclusion);
				}
				if(DATEExc.has("operator")){
					DateExclusionArr.put(DATEExc);
					exclusion.put("exclusion", DateExclusionArr);
					mainDateArray.put(exclusion);
				}

				base.put(date, mainDateArray);
				setRuleID(baseArr, calcArr, base, calculation, dateObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getTriggerPayoutArray(JSONArray baseArr, JSONArray calcArr, JSONArray array, String name, boolean inBase){
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<array.length();j++){
				JSONObject object = array.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(object.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray requestArr = new JSONArray();
				JSONObject requestObject = new JSONObject();
				requestObject.put(name, object.getString(name));
				requestArr.put(triggerPayout);
				requestArr.put(requestObject);
				if(inBase)
					base.put(name, requestArr);
				else calculation.put(name, requestArr);
				setRuleID(baseArr,calcArr,base,calculation,object.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getTriggerPayoutArrayIncExc(JSONArray baseArr, JSONArray calcArr, JSONArray roomTypes, String name, boolean isInclusion, boolean inBase) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<roomTypes.length();j++){
				JSONObject roomTypesObject = roomTypes.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(roomTypesObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray roomTypesArr = new JSONArray();
				JSONObject roomTypesInnerObject = new JSONObject();
				if(isInclusion)
					roomTypesInnerObject.put(name, roomTypesObject.getString(name));
				else roomTypesInnerObject.put(name+"_exclusion", roomTypesObject.getString(name));
				roomTypesArr.put(triggerPayout);
				roomTypesArr.put(roomTypesInnerObject);
				if(inBase)
					base.put(name, roomTypesArr);
				else calculation.put(name, roomTypesArr);
				setRuleID(baseArr,calcArr,base,calculation,roomTypesObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}

	}


	public static void getConnectivity(JSONArray baseArr, JSONObject connectivity) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray("triggerOrPayout"));
			JSONArray connectivityArr = new JSONArray();
			JSONObject connectivityObject = new JSONObject();
			if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierType",connectivity.getString("supplierType"));
			if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierName",connectivity.getString("supplierId"));
			connectivityArr.put(triggerPayout);
			connectivityArr.put(connectivityObject);
			base.put("connectivity", connectivityArr);
		}
	}


	public static void getBookingType(JSONArray baseArr, JSONObject bookingType, boolean isInclusion) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(bookingType.getJSONArray("triggerOrPayout"));
			JSONArray bookingTypeArr = new JSONArray();
			JSONObject bookingTypeObject = new JSONObject();
			if(isInclusion)
				bookingTypeObject.put("bookingType",bookingType.getString("bookingType"));
			else bookingTypeObject.put("bookingType_exclusion",bookingType.getString("bookingType"));
			bookingTypeArr.put(triggerPayout);
			bookingTypeArr.put(bookingTypeObject);
			base.put("bookingType", bookingTypeArr);
		}
	}


	public static void getDestination(JSONArray baseArr, JSONArray calcArr, JSONArray travel, boolean isInclusion, boolean inBase) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travel.length();j++){
				JSONObject object = travel.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(object.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray requestArr = new JSONArray();
				JSONObject requestObject = new JSONObject();
				requestArr.put(triggerPayout);
				if(isInclusion){
					if(object.has("continent") && !object.getString("continent").equalsIgnoreCase("All"))
						requestObject.put("continent", object.getString("continent"));
					if(object.has("country") && !object.getString("country").equalsIgnoreCase("All"))
						requestObject.put("country", object.getString("country"));
					if(object.has("state") && !object.getString("state").equalsIgnoreCase("All"))
						requestObject.put("state", object.getString("state"));
					if(object.has("city") && !object.getString("city").equalsIgnoreCase("All"))
						requestObject.put("city", object.getString("city"));
				}else{
					if(object.has("continent") && !object.getString("continent").equalsIgnoreCase("All"))
						requestObject.put("continent_exclusion", object.getString("continent"));
					if(object.has("country") && !object.getString("country").equalsIgnoreCase("All"))
						requestObject.put("country_exclusion", object.getString("country"));
					if(object.has("state") && !object.getString("state").equalsIgnoreCase("All"))
						requestObject.put("state_exclusion", object.getString("state"));
					if(object.has("city") && !object.getString("city").equalsIgnoreCase("All"))
						requestObject.put("city_exclusion", object.getString("city"));
				}
				requestArr.put(requestObject);
				if(inBase)
					base.put("travelDestination", requestArr);
				else calculation.put("travelDestination", requestArr);
				setRuleID(baseArr,calcArr,base,calculation,object.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setMarkUpCalculation(JSONObject markUp) {
		JSONObject entityType = markUp.getJSONObject(CommonFunctions.entityType);
		if(entityType.has("percentage") && !entityType.get("percentage").equals(0))
			markUpPercentage = entityType.get("percentage").toString();
		if(entityType.has("currency"))
			markUpCurrency = entityType.getString("currency");
		if(entityType.has("amount") && !entityType.get("amount").equals(0))
			markUpAmount = entityType.get("amount").toString();
		if(entityType.has("fareComponents") && entityType.getJSONArray("fareComponents").length()>0)
			markUpFareComponent = getFareComponent(entityType.getJSONArray("fareComponents"),entityType.get("percentage").toString());
	}


	public static void setMinSellingPrice(JSONObject markUp) {
		if(CommonFunctions.entityType.equals("company")){
			JSONObject markupToMinSellingPriceCompany = markUp.getJSONObject("markupToMinSellingPriceCompany");
			if(markupToMinSellingPriceCompany.has("currency"))
				minSellingPriceCurrency = markupToMinSellingPriceCompany.getString("currency");
			if(markupToMinSellingPriceCompany.has("amount") && !markupToMinSellingPriceCompany.get("amount").equals(0))
				minSellingPriceAmount = markupToMinSellingPriceCompany.get("amount").toString();
		}else{
			JSONObject markupToMinSellingPriceClient = markUp.getJSONObject("markupToMinSellingPriceClient");
			if(markupToMinSellingPriceClient.has("currency"))
				minSellingPriceCurrency = markupToMinSellingPriceClient.getString("currency");
			if(markupToMinSellingPriceClient.has("amount") && !markupToMinSellingPriceClient.get("amount").equals(0))
				minSellingPriceAmount = markupToMinSellingPriceClient.get("amount").toString();
		}

	}


	public static void getTriggerPayoutEnumValues(JSONArray baseArr, JSONArray triggerOrPayout, JSONArray jsonArray, String name, boolean isInclusion) {
		int length =baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(triggerOrPayout);
			JSONArray array = new JSONArray();
			array.put(triggerPayout);
			JSONObject object = new JSONObject();
			if(isInclusion)
				object.put(name, jsonArray);
			else object.put(name+"_exclusion", jsonArray);
			array.put(object);
			base.put(name, array);
		}
	}


	public static void getAirConnectivity(JSONArray baseArr, JSONObject connectivity) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray("triggerOrPayout"));
			JSONArray connectivityArr = new JSONArray();
			JSONObject connectivityObject = new JSONObject();
			if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierType",connectivity.getString("supplierType"));
			if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierName",connectivity.getString("supplierName"));
			connectivityArr.put(triggerPayout);
			connectivityArr.put(connectivityObject);
			base.put("connectivity", connectivityArr);
		}
	}


	public static void setOtherFeeTicketing(JSONArray otherFeeArr, JSONObject validity){
		switch(validity.getString("validityType")){
		case "ticketing":{
			setOtherFeesDate(otherFeeArr,validity.getJSONArray("ticketing"),"ticketing");
			break;
		}
		case "travel":{
			setOtherFeesDate(otherFeeArr,validity.getJSONArray("travel"),"travel");
			break;
		}
		default:{
			int length = otherFeeArr.length();
			JSONArray ticketingPlusTravel = validity.getJSONArray("ticketingPlusTravel");
			for(int i=0;i<length;i++){
				for(int j=0;j<ticketingPlusTravel.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(j);

					JSONArray tickincArr =new JSONArray();
					JSONArray tickexcArr =new JSONArray();
					JSONArray travelincArr =new JSONArray();
					JSONArray travelexcArr =new JSONArray();
					JSONObject indiTicketObj = new JSONObject();
					JSONObject indiTravelObj = new JSONObject();
					JSONObject indiTicketBlockObj = new JSONObject();
					JSONObject indiTravelBlockObj = new JSONObject();
					JSONArray ticketingDate = new JSONArray();
					JSONArray travelDate = new JSONArray();
					JSONObject inclusionTkt = new JSONObject();
					JSONObject exclusionTkt = new JSONObject();
					JSONObject inclusionTra = new JSONObject();
					JSONObject exclusionTra = new JSONObject();

					JSONObject ticketingObject = ticketPlusTravelObj.getJSONObject("ticket");
					if(ticketingObject.has("ticketingFrom")){
						if(ticketingObject.has("ticketingTo")){
							indiTicketObj.put("operator","BETWEEN");
							indiTicketObj.put("from", ticketingObject.getString("ticketingFrom").substring(0, 19));
							indiTicketObj.put("to", ticketingObject.getString("ticketingTo").substring(0, 19));
						}else{
							indiTicketObj.put("operator","GREATERTHANEQUALTO");
							indiTicketObj.put("value", ticketingObject.getString("ticketingFrom").substring(0, 19));
						}
					}else if(ticketingObject.has("ticketingTo")){
						indiTicketObj.put("operator","LESSTHANEQUALTO");
						indiTicketObj.put("value", ticketingObject.getString("ticketingTo").substring(0, 19));
					}

					if(ticketingObject.has("blockOutFrom")){
						if(ticketingObject.has("blockOutTo")){
							indiTicketBlockObj.put("operator", "BETWEEN");
							indiTicketBlockObj.put("from", ticketingObject.getString("blockOutFrom").substring(0, 19));
							indiTicketBlockObj.put("to", ticketingObject.getString("blockOutTo").substring(0, 19));
						}else{
							indiTicketBlockObj.put("operator", "GREATERTHANEQUALTO");
							indiTicketBlockObj.put("value", ticketingObject.getString("blockOutFrom").substring(0, 19));
						}
					}else{
						if(ticketingObject.has("blockOutTo")){
							indiTicketBlockObj.put("operator", "LESSTHANEQUALTO");
							indiTicketBlockObj.put("value", ticketingObject.getString("blockOutTo").substring(0, 19));
						}
					}

					JSONObject travelObject = ticketPlusTravelObj.getJSONObject("travel");
					if(travelObject.has("travelFrom")){
						if(travelObject.has("travelTo")){
							indiTravelObj.put("operator","BETWEEN");
							indiTravelObj.put("from", travelObject.getString("travelFrom").substring(0, 19));
							indiTravelObj.put("to", travelObject.getString("travelTo").substring(0, 19));
						}else{
							indiTravelObj.put("operator","GREATERTHANEQUALTO");
							indiTravelObj.put("value", travelObject.getString("travelFrom").substring(0, 19));
						}
					}else if(travelObject.has("travelTo")){
						indiTravelObj.put("operator","LESSTHANEQUALTO");
						indiTravelObj.put("value", travelObject.getString("travelTo").substring(0, 19));
					}
					if(travelObject.has("blockOutFrom")){
						if(travelObject.has("blockOutTo")){
							indiTravelBlockObj.put("operator", "BETWEEN");
							indiTravelBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
							indiTravelBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
						}else{
							indiTravelBlockObj.put("operator", "GREATERTHANEQUALTO");
							indiTravelBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
						}
					}else{
						if(travelObject.has("blockOutTo")){
							indiTravelBlockObj.put("operator", "LESSTHANEQUALTO");
							indiTravelBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
						}
					}

					if(indiTicketObj!=null){
						tickincArr.put(indiTicketObj);
						inclusionTkt.put("inclusion",tickincArr);
						ticketingDate.put(inclusionTkt);
					}
					if(indiTicketBlockObj!=null){
						tickexcArr.put(indiTicketBlockObj);
						exclusionTkt.put("exclusion",tickexcArr);
						ticketingDate.put(exclusionTkt);
					}
					if(indiTravelObj!=null){
						travelincArr.put(indiTravelObj);
						inclusionTra.put("inclusion",travelincArr);
						travelDate.put(inclusionTra);
					}
					if(indiTravelBlockObj!=null){
						travelexcArr.put(indiTravelBlockObj);
						exclusionTra.put("exclusion",travelexcArr);
						travelDate.put(exclusionTra);
					}
					otherFee.put("ticketing", ticketingDate);
					otherFee.put("travel", travelDate);

					setOtherFeesRuleID(otherFeeArr, otherFee, ticketPlusTravelObj.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}break;
		}
	}


	public static void setOtherFeesRuleID(JSONArray otherFeeArr, JSONObject otherFee, String ID) {
		String otherFeeRuleID = otherFee.getString("RuleID")+ID;
		otherFee.put("RuleID", otherFeeRuleID);
		otherFeeArr.put(otherFee);
	}


	public static void setOtherFeesDate(JSONArray otherFeeArr, JSONArray dateArray, String date) {
		String from = date+"From";
		String to = date+"To";

		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArray.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject dateObject =dateArray.getJSONObject(j);

				JSONArray incArr =new JSONArray();
				JSONArray excArr =new JSONArray();
				JSONObject indiObj = new JSONObject();
				JSONObject indiBlockObj = new JSONObject();
				JSONArray Date = new JSONArray();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();

				if(dateObject.has(from)){
					if(dateObject.has(to)){
						indiObj.put("operator","BETWEEN");
						indiObj.put("from", dateObject.getString(from).substring(0, 19));
						indiObj.put("to", dateObject.getString(to).substring(0, 19));
					}else{
						indiObj.put("operator","GREATERTHANEQUALTO");
						indiObj.put("value", dateObject.getString(from).substring(0, 19));
					}
				}else if(dateObject.has(to)){
					indiObj.put("operator","LESSTHANEQUALTO");
					indiObj.put("value", dateObject.getString(to).substring(0, 19));
				}

				if(dateObject.has("blockOutFrom")){
					if(dateObject.has("blockOutTo")){
						indiBlockObj.put("operator", "BETWEEN");
						indiBlockObj.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
						indiBlockObj.put("to", dateObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiBlockObj.put("value", dateObject.getString("blockOutFrom").substring(0, 19));
					}
				}else{
					if(dateObject.has("blockOutTo")){
						indiBlockObj.put("operator", "LESSTHANEQUALTO");
						indiBlockObj.put("value", dateObject.getString("blockOutTo").substring(0, 19));
					}
				}

				if(indiObj.has("operator")){
					incArr.put(indiObj);
					inclusion.put("inclusion",incArr);
					Date.put(inclusion);
				}
				if(indiBlockObj.has("operator")){
					excArr.put(indiBlockObj);
					exclusion.put("exclusion",excArr);
					Date.put(exclusion);
				}
				otherFee.put(date, Date);
				setOtherFeesRuleID(otherFeeArr, otherFee, dateObject.getString("_id"));                  
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}


	public static void setCalculationParameters(String commercialName, JSONObject calculation, JSONObject mainJson) {
		JSONArray commHead = new JSONArray(); 
		commHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
		switch(commercialName){
		case "Standard":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("Standard")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", stdretentionPercentage);
						calculation.put("retentionAmount", stdretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", stdAdditionalPercentage);
						calculation.put("additionalAmount", stdAdditionalAmount);
						calculation.put("fareComponent", stdFareComponent);
						calculation.put("currency", stdCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}
			break;
		}
		case "Overriding":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("Overriding")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", overretentionPercentage);
						calculation.put("retentionAmount", overretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", overAdditionalPercentage);
						calculation.put("additionalAmount", overAdditionalAmount);
						calculation.put("fareComponent", overFareComponent);
						calculation.put("currency", overCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}
			break;
		}
		case "PLB":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("PLB")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", plbretentionPercentage);
						calculation.put("retentionAmount", plbretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", plbAdditionalPercentage);
						calculation.put("additionalAmount", plbAdditionalAmount);
						calculation.put("fareComponent", plbFareComponent);
						calculation.put("currency", plbCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}break;
		}
		case "SectorWiseIncentive":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("SectorWiseIncentive")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", sectorretentionPercentage);
						calculation.put("retentionAmount", sectorretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", sectorAdditionalPercentage);
						calculation.put("additionalAmount", sectorAdditionalAmount);
						calculation.put("fareComponent", sectorFareComponent);
						calculation.put("currency", sectorCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}break;
		}
		case "DestinationIncentive":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("SectorWiseIncentive")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", destinationretentionPercentage);
						calculation.put("retentionAmount", destinationretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", destinationAdditionalPercentage);
						calculation.put("additionalAmount", destinationAdditionalAmount);
						calculation.put("fareComponent", destinationFareComponent);
						calculation.put("currency", destinationCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}break;
		}
		case "SegmentFee":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("SegmentFee")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", segmentretentionPercentage);
						calculation.put("retentionAmount", segmentretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", segmentAdditionalPercentage);
						calculation.put("additionalAmount", segmentAdditionalAmount);
						calculation.put("fareComponent", segmentFareComponent);
						calculation.put("currency", segmentCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}break;
		}
		case "ServiceCharge":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("ServiceCharge")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", serviceretentionPercentage);
						calculation.put("retentionAmount", serviceretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", serviceAdditionalPercentage);
						calculation.put("additionalAmount", serviceAdditionalAmount);
						calculation.put("fareComponent", serviceFareComponent);
						calculation.put("currency", serviceCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}break;
		}
		case "ManagementFee":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("ManagementFee")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", mngtretentionPercentage);
						calculation.put("retentionAmount", mngtretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", mngtAdditionalPercentage);
						calculation.put("additionalAmount", mngtAdditionalAmount);
						calculation.put("fareComponent", mngtFareComponent);
						calculation.put("currency", mngtCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}break;
		}
		case "Discount":{
			for(int j=0;j<commHead.length();j++){
				if(commHead.getJSONObject(j).getString("commercialHeadName").equals("Discount")){
					if(commHead.getJSONObject(j).getString("commercialProperty").equals("Retention")){
						calculation.put("retentionPercentage", discountretentionPercentage);
						calculation.put("retentionAmount", discountretentionAmount);
					}else if(commHead.getJSONObject(j).getString("commercialProperty").equals("Additional")){
						calculation.put("additionalPercentage", discountAdditionalPercentage);
						calculation.put("additionalAmount", discountAdditionalAmount);
						calculation.put("fareComponent", discountFareComponent);
						calculation.put("currency", discountCurrency);
					}else{
						//Fixed or Mark-up
					}
				}
			}break;
		}
		case "MarkUp":{
			for(int i=0;i<commHead.length();i++){
				if(commHead.getJSONObject(i).getString("commercialHeadName").equals("MarkUp")){
					calculation.put("markUpPercentage", markUpPercentage);
					calculation.put("markUpAmount", markUpAmount);
					calculation.put("currency", minSellingPriceCurrency);
					calculation.put("fareComponent", markUpFareComponent);
					calculation.put("minSellingPrice", minSellingPriceAmount);
				}
			}break;
		}
		default:System.out.println("default of Accomodation.setCalculationParameters due to: "+commercialName);
		}

	}


	public static void setTransportationAdvancedDefinition(JSONObject advanceDefinitionTransportation, JSONArray baseArr, JSONArray calcArr) {
		//ancillary name, ancillary type, applicable on : not in schema
		if(advanceDefinitionTransportation.has("validity")){
			JSONObject validity = advanceDefinitionTransportation.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "sale":{
				JSONObject sale = validity.getJSONArray("sale").getJSONObject(0);
				if(sale.has("triggerOrPayout") && sale.getJSONArray("triggerOrPayout").length()>0)
					getPLBDates(baseArr, calcArr, validity.getJSONArray("sale"), "sale", true);//inBase : true
				else setDate(baseArr, calcArr, validity.getJSONArray("sale"), "sale", true);//inBase : true
				break;
			}
			case "travel":{
				JSONObject travel = validity.getJSONArray("travel").getJSONObject(0);
				if(travel.has("triggerOrPayout") && travel.getJSONArray("triggerOrPayout").length()>0)
					getPLBDates(baseArr, calcArr, validity.getJSONArray("travel"), "travel", true);//inBase : true
				else setDate(baseArr, calcArr, validity.getJSONArray("travel"), "travel", true);//inBase : true
				break;
			}
			default:{
				setSalePlusTravelDate(baseArr,calcArr, validity.getJSONArray("salePlusTravel"), true);//inBase : true
			}
			}
		}
		if(advanceDefinitionTransportation.has("travelDestination")){
			JSONObject travelDestination = advanceDefinitionTransportation.getJSONObject("travelDestination");
			JSONArray destinations = travelDestination.getJSONArray("destinations");
			JSONObject destObject = destinations.getJSONObject(0);
			if(destObject.has("triggerOrPayout") && destObject.getJSONArray("triggerOrPayout").length()>0){
				if(travelDestination.getBoolean("isInclusion"))
					setPLBTransportationDestination(baseArr,calcArr,destinations,true,false);//isBase : false
				else setPLBTransportationDestination(baseArr,calcArr,destinations,false,false);//isBase : false
			}else{
				if(travelDestination.getBoolean("isInclusion"))
					setTransportationDestination(baseArr,calcArr,destinations,true,false);//isBase : false
				else setTransportationDestination(baseArr,calcArr,destinations,false,false);//isBase : false
			}
		}

		if(advanceDefinitionTransportation.has("others")){
			JSONObject others = advanceDefinitionTransportation.getJSONObject("others");
			if(others.has("triggerOrPayout") && others.getJSONArray("triggerOrPayout").length()>0)
				getBookingTypeTP(baseArr, calcArr, others, true, true);//isInclusion : true
			else{
				for(int i=0;i<baseArr.length();i++){
					JSONObject base = baseArr.getJSONObject(i);
					base.put("bookingType", others.getString("bookingType"));//inBase
				}
			}
		}

		if(advanceDefinitionTransportation.has("connectivity")){
			JSONObject connectivity = advanceDefinitionTransportation.getJSONObject("connectivity");
			if(connectivity.has("triggerOrPayout") && connectivity.getJSONArray("triggerOrPayout").length()>0)
				getConnectivityTP(baseArr,connectivity);
			else{
				for(int i=0;i<baseArr.length();i++){
					JSONObject base = baseArr.getJSONObject(i);
					if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
						base.put("connectivitySupplierType",connectivity.getString("supplierType"));
					if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
						base.put("connectivitySupplierName",connectivity.getString("supplierId"));
				}
			}
		}

		if(advanceDefinitionTransportation.has("credentials") && advanceDefinitionTransportation.getJSONArray("credentials").length()>0){
			JSONObject credentials = advanceDefinitionTransportation.getJSONArray("credentials").getJSONObject(0);
			if(credentials.has("triggerOrPayout") && credentials.getJSONArray("triggerOrPayout").length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("credentials"), "credentials", true, true);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("credentials"), "credentials", true, true);
		}

		if(advanceDefinitionTransportation.has("nationality") && advanceDefinitionTransportation.getJSONArray("nationality").length()>0){
			JSONObject nationality = advanceDefinitionTransportation.getJSONArray("nationality").getJSONObject(0);
			if(nationality.has("triggerOrPayout") && nationality.getJSONArray("triggerOrPayout").length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("nationality"), "clientNationality", true, true);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("nationality"), "clientNationality", true, true);
		}

		if(advanceDefinitionTransportation.has("passengerTypes") && advanceDefinitionTransportation.getJSONArray("passengerTypes").length()>0){
			JSONObject passengerTypes = advanceDefinitionTransportation.getJSONArray("passengerTypes").getJSONObject(0);
			if(passengerTypes.has("triggerOrPayout") && passengerTypes.getJSONArray("triggerOrPayout").length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("passengerTypes"), "passengerTypes", true, false);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("passengerTypes"), "passengerTypes", true, false);
		}
	}


	private static void setPLBTransportationDestination(JSONArray baseArr, JSONArray calcArr, JSONArray destinations, boolean isInclusion, boolean inBase) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<destinations.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject destination = destinations.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(destination.getJSONArray("triggerOrPayout"));
				JSONArray destinationArray = new JSONArray();
				destinationArray.put(triggerPayout);
				JSONObject values = new JSONObject();
				if(isInclusion){
					if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
						values.put("continent", destination.getString("continent"));
					if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
						values.put("country", destination.getString("country"));
					if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
						values.put("state", destination.getString("state"));
					if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
						values.put("city", destination.getString("city"));
				}else{
					if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
						values.put("continent_exclusion", destination.getString("continent"));
					if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
						values.put("country_exclusion", destination.getString("country"));
					if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
						values.put("state_exclusion", destination.getString("state"));
					if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
						values.put("city_exclusion", destination.getString("city"));
				}
				destinationArray.put(values);

				if(inBase)
					base.put("travelDestination", destinationArray);
				else calculation.put("travelDestination", destinationArray);

				setRuleID(baseArr, calcArr, base, calculation, destination.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setTransportationDestination(JSONArray baseArr, JSONArray calcArr, JSONArray destinations, boolean isInclusion, boolean inBase) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<destinations.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject destination = destinations.getJSONObject(j);
				if(inBase){
					if(isInclusion){
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							base.put("continent", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							base.put("country", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							base.put("state", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							base.put("city", destination.getString("city"));
					}else{
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							base.put("continent_exclusion", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							base.put("country_exclusion", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							base.put("state_exclusion", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							base.put("city_exclusion", destination.getString("city"));
					}
				}else{
					if(isInclusion){
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							calculation.put("continent", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							calculation.put("country", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							calculation.put("state", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							calculation.put("city", destination.getString("city"));
					}else{
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							calculation.put("continent_exclusion", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							calculation.put("country_exclusion", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							calculation.put("state_exclusion", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							calculation.put("city_exclusion", destination.getString("city"));
					}
				}
				setRuleID(baseArr, calcArr, base, calculation, destination.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setSalePlusTravelDate(JSONArray baseArr, JSONArray calcArr, JSONArray salePlusTravel, boolean inBase) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(j);

				JSONArray tickincArr =new JSONArray();
				JSONArray tickexcArr =new JSONArray();
				JSONArray travelincArr =new JSONArray();
				JSONArray travelexcArr =new JSONArray();
				JSONObject indiTicketObj = new JSONObject();
				JSONObject indiTravelObj = new JSONObject();
				JSONObject indiTicketBlockObj = new JSONObject();
				JSONObject indiTravelBlockObj = new JSONObject();
				JSONArray ticketingDate = new JSONArray();
				JSONArray travelDate = new JSONArray();
				JSONObject inclusionTkt = new JSONObject();
				JSONObject exclusionTkt = new JSONObject();
				JSONObject inclusionTra = new JSONObject();
				JSONObject exclusionTra = new JSONObject();

				JSONObject sales = salePlusTravelObject.getJSONObject("sales");
				if(sales.has("saleFrom")){
					if(sales.has("saleTo")){
						indiTicketObj.put("operator","BETWEEN");
						indiTicketObj.put("from", sales.getString("saleFrom").substring(0, 19));
						indiTicketObj.put("to", sales.getString("saleTo").substring(0, 19));
					}else{
						indiTicketObj.put("operator","GREATERTHANEQUALTO");
						indiTicketObj.put("value", sales.getString("saleFrom").substring(0, 19));
					}
				}else if(sales.has("saleTo")){
					indiTicketObj.put("operator","LESSTHANEQUALTO");
					indiTicketObj.put("value", sales.getString("saleTo").substring(0, 19));
				}

				if(sales.has("blockOutFrom")){
					if(sales.has("blockOutTo")){
						indiTicketBlockObj.put("operator", "BETWEEN");
						indiTicketBlockObj.put("from", sales.getString("blockOutFrom").substring(0, 19));
						indiTicketBlockObj.put("to", sales.getString("blockOutTo").substring(0, 19));
					}else{
						indiTicketBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTicketBlockObj.put("value", sales.getString("blockOutFrom").substring(0, 19));
					}
				}else if(sales.has("blockOutTo")){
					indiTicketBlockObj.put("operator", "LESSTHANEQUALTO");
					indiTicketBlockObj.put("value", sales.getString("blockOutTo").substring(0, 19));
				}

				JSONObject travelObject = salePlusTravelObject.getJSONObject("travel");
				if(travelObject.has("travelFrom")){
					if(travelObject.has("travelTo")){
						indiTravelObj.put("operator","BETWEEN");
						indiTravelObj.put("from", travelObject.getString("travelFrom").substring(0, 19));
						indiTravelObj.put("to", travelObject.getString("travelTo").substring(0, 19));
					}else{
						indiTravelObj.put("operator","GREATERTHANEQUALTO");
						indiTravelObj.put("value", travelObject.getString("travelFrom").substring(0, 19));
					}
				}else if(travelObject.has("travelTo")){
					indiTravelObj.put("operator","LESSTHANEQUALTO");
					indiTravelObj.put("value", travelObject.getString("travelTo").substring(0, 19));
				}

				if(travelObject.has("blockOutFrom")){
					if(travelObject.has("blockOutTo")){
						indiTravelBlockObj.put("operator", "BETWEEN");
						indiTravelBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
						indiTravelBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiTravelBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTravelBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
					}
				}else if(travelObject.has("blockOutTo")){
					indiTravelBlockObj.put("operator", "LESSTHANEQUALTO");
					indiTravelBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
				}


				if(indiTicketObj!=null){
					tickincArr.put(indiTicketObj);
					inclusionTkt.put("inclusion",tickincArr);
					ticketingDate.put(inclusionTkt);
				}
				if(indiTicketBlockObj!=null){
					tickexcArr.put(indiTicketBlockObj);
					exclusionTkt.put("exclusion",tickexcArr);
					ticketingDate.put(exclusionTkt);
				}
				if(indiTravelObj!=null){
					travelincArr.put(indiTravelObj);
					inclusionTra.put("inclusion",travelincArr);
					travelDate.put(inclusionTra);
				}
				if(indiTravelBlockObj!=null){
					travelexcArr.put(indiTravelBlockObj);
					exclusionTra.put("exclusion",travelexcArr);
					travelDate.put(exclusionTra);
				}

				if(inBase){
					base.put("sale", ticketingDate);
					base.put("travel", travelDate);
				}else{
					calculation.put("sale", ticketingDate);
					calculation.put("travel", travelDate);
				}

				setRuleID(baseArr, calcArr, base, calculation, salePlusTravelObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void appendProductCategoryAndSubType(JSONObject ipJson, String productName, String productCategory, String productCategorySubType) {
		switch(productName){
		case "accomodation":{
			ipJson.put("productCategorySubType", productCategorySubType);
			break;
		}
		case "activities":{
			break;
		}
		case "holidays":{
			ipJson.put("productCategory", productCategory);
			ipJson.put("productCategorySubType", productCategorySubType);
			break;
		}
		}
	}


	public static void getTravelDestination(JSONArray advancedArr, JSONArray calcArr, JSONArray destinations, boolean isInclusion, boolean inAdvanced) {
		int length= calcArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<destinations.length();j++){
				JSONObject advanced = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject destination = destinations.getJSONObject(j);
				if(inAdvanced){
					if(isInclusion){
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							advanced.put("continent", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							advanced.put("country", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							advanced.put("state", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							advanced.put("city", destination.getString("city"));
					}else{
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							advanced.put("continent_exclusion", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							advanced.put("country_exclusion", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							advanced.put("state_exclusion", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							advanced.put("city_exclusion", destination.getString("city"));
					}
				}else{
					if(isInclusion){
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							calculation.put("continent", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							calculation.put("country", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							calculation.put("state", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							calculation.put("city", destination.getString("city"));
					}else{
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							calculation.put("continent_exclusion", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							calculation.put("country_exclusion", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							calculation.put("state_exclusion", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							calculation.put("city_exclusion", destination.getString("city"));
					}
				}
				setRuleID(advancedArr, calcArr, advanced, calculation, destination.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			advancedArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setMDMRuleID(String commercialName, JSONObject calculation) {
		switch(commercialName){
		case "Standard":{calculation.put("mdmRuleID", stdclientCommercialDataID);break;}
		case "Overriding":{calculation.put("mdmRuleID", overclientCommercialDataID);break;}
		case "PLB":{calculation.put("mdmRuleID", plbclientCommercialDataID);break;}
		case "SectorWiseIncentive":{calculation.put("mdmRuleID", sectorclientCommercialDataID);break;}
		case "ManagementFee":{calculation.put("mdmRuleID", mngtclientCommercialDataID);break;}
		case "SegmentFee":{calculation.put("mdmRuleID", segmentclientCommercialDataID);break;}
		case "ServiceCharge":{calculation.put("mdmRuleID", serviceclientCommercialDataID);break;}
		case "Discount":{calculation.put("mdmRuleID", discountclientCommercialDataID);break;}
		case "MarkUp":{calculation.put("mdmRuleID", markupclientCommercialDataID);break;}
		case "Commission":{calculation.put("mdmRuleID", commissionclientCommercialDataID);break;}
		case "DestinationIncentive":{calculation.put("mdmRuleID", destinationclientCommercialDataID);break;}
		case "IssuanceFee":{calculation.put("mdmRuleID", issuanceclientCommercialDataID);break;}
		default:System.out.println("default of setMDMRuleID due to CommercialName :"+commercialName);
		}
	}
	
	public static void setAmmendRequest(JSONObject budgetMarginAttachedTo, JSONObject mdmCommDefn, String productName, String kafkaMethod) throws Exception{
		String bookingId = budgetMarginAttachedTo.getString("bookingId");
		String advancedId = budgetMarginAttachedTo.getString("advancedId");
		String commercialName = budgetMarginAttachedTo.getString("commercialName");
		String mdmRuleID = budgetMarginAttachedTo.getString("mdmruleId");
		String[] values = mdmRuleID.split("\\|");
		JSONObject mainJson = new JSONObject();
		for(int i=0;i<mdmCommDefn.getJSONArray("clientCommercialData").length();i++){
			JSONObject clientCommercialData = mdmCommDefn.getJSONArray("clientCommercialData").getJSONObject(i);
			if(clientCommercialData.getString("_id").equals(values[1])){
				JSONObject flightsAndNonAir = clientCommercialData.getJSONObject("commercialDetails").getJSONObject("flightsAndNonAir");
				if(values[2].equals("markup")){
					JSONArray markup = flightsAndNonAir.getJSONArray("markup");
					for(int j=0;j<markup.length();j++){
						JSONObject markUp = markup.getJSONObject(j);
						if(markUp.getString("_id").equals(values[3])){
							JSONObject object = markUp.getJSONObject(values[4]);
							JSONObject calculation = new JSONObject();
							calculation.put("RuleID", mdmRuleID+bookingId);
							calculation.put("selectedRow", advancedId);
							calculation.put("type", "calculation");
							calculation.put("bookingId", bookingId);
							if(object.has("percentage") && !object.get("percentage").equals(0))
								calculation.put("markUpPercentage", object.get("percentage").toString());
							if(object.has("amount") && !object.get("amount").equals(0))
								calculation.put("markUpAmount", object.get("amount").toString());
							if(object.has("currency"))
								calculation.put("currency", object.getString("currency"));
							if(object.has("fareComponents") && object.getJSONArray("fareComponents").length()>0)
								calculation.put("fareComponent", getFareComponent(object.getJSONArray("fareComponents"),object.get("percentage").toString()));
							calculation.put("mdmRuleID", mdmRuleID+bookingId);
							calculation.put("priority", 1);
							mainJson.put("MarkUpClientCommercialCalculationDT", calculation);
							//ghochi for holidays :: 2 DTs
						}
					}
				}else{
					String[] val = values[2].split("\\_");
					JSONArray array = flightsAndNonAir.getJSONObject(val[0]).getJSONArray(val[1]);
					for(int j=0;j<array.length();j++){
						JSONObject object = array.getJSONObject(j);
						if(object.getString("_id").equals(values[3])){
							JSONObject calcObject = object.getJSONObject(values[4]);
							JSONObject calculation = new JSONObject();
							calculation.put("RuleID", mdmRuleID+bookingId);
							calculation.put("selectedRow", advancedId);
							calculation.put("bookingId", bookingId);
							calculation.put("type", "calculation");
							switch(val[0]){
							case "additionalCommercials":{
								if(calcObject.has("percentage") && !calcObject.get("percentage").equals(0))
									calculation.put("additionalPercentage", calcObject.get("percentage").toString());
								if(calcObject.has("amount") && !calcObject.get("amount").equals(0))
									calculation.put("additionalAmount", calcObject.get("amount").toString());
								if(calcObject.has("currency"))
									calculation.put("currency", calcObject.getString("currency"));
								if(calcObject.has("fareComponents") && calcObject.getJSONArray("fareComponents").length()>0)
									calculation.put("fareComponent", getFareComponent(calcObject.getJSONArray("fareComponents"),calcObject.get("percentage").toString()));
								break;
							}
							case "retentionCommercialsSupplierBased":{
								if(calcObject.has("percentage") && !calcObject.get("percentage").equals(0))
									calculation.put("retentionPercentage", calcObject.get("percentage").toString());
								if(calcObject.has("amount") && !calcObject.get("amount").equals(0))
									calculation.put("retentionAmount", calcObject.get("amount").toString());
								break;
							}
							case "retentionCommercialsProductBased":{
								if(calcObject.has("retentionPercent") && !calcObject.get("retentionPercent").equals(0))
									calculation.put("retentionPercentage", calcObject.get("retentionPercent").toString());
								if(calcObject.has("retentionAmount") && !calcObject.get("retentionAmount").equals(0))
									calculation.put("retentionAmount", calcObject.get("retentionAmount").toString());
								break;
							}
							}
							calculation.put("mdmRuleID", mdmRuleID+bookingId);
							calculation.put("priority", 1);
							mainJson.put(getDecisionTableName(commercialName), calculation);
						}
					}
				}
			}
		}
		System.out.println(productName.toUpperCase()+" Transactional (bookingId): "+mainJson.toString());
		Configuration.hitJSONService(mainJson,productName,kafkaMethod);
	}


	private static String getDecisionTableName(String commercialName) {
		switch(commercialName){
		case "Standard Commercial": return "StandardClientCommercialCalculationDT";
		case "Overriding Commission": return "OverridingClientCommercialCalculationDT";
		case "Productivity Linked Bonus": return "PLBClientCommercialCalculationDT";
		case "Sector Incentives": return "SectorWiseIncentiveClientCommercialCalculationDT";
		case "Segment Fees": return "SegmentFeeClientCommercialCalculationDT";
		case "Segments Fees": return "SegmentFeeClientCommercialCalculationDT";
		case "Management Fee": return "ManagementFeeClientCommercialCalculationDT";
		case "Service Charges": return "ServiceChargeClientCommercialCalculationDT";
		case "Discount": return "DiscountClientCommercialCalculationDT";
		case "Destination Incentives": return "DestinationIncentiveClientCommercialCalculationDT";
		case "Issuance Fees": return "IssuanceFeeClientCommercialCalculationDT";
		case "Commission": return "CommissionClientCommercialCalculationDT";
		case "Maintenance Fees": return "MaintenanceFeeDT";
		case "Integration Fees": return "IntegrationFeeDT";
		case "Licence Fees": return "LicenceFeeDT";
		case "Web Service Fees": return "WebServiceFeeDT";
		case "Loyalty Bonus": return "LoyaltyBonusDT";
		case "Preference Benefit": return "PreferenceBenefitDT";
		case "Retainer Fee": return "RetainerFeeDT";
		case "Listing Fee": return "ListingFeeDT";
		case "Content Access Fee": return "ContentAccessFeeDT";
		case "Sign Up Fees": return "SignUpFeeDT";
		case "Sign Up Bonus": return "SignUpBonusDT";
		case "Look To Book": return "LookToBookCumulativeDT";
		//case "MSF Fees": return "MSFFees";
		case "Incentives On Top Up": return "IncentivesOnTopUpDT";
		case "Termination Fees": return "TerminationFeeDT";
		case "Penalty Fee / Kick Back": return "PenaltyFeeDT";
		//case "Free Of Cost (FOC)": return "FreeOfCost";
		case "Lost Ticket": return "LostTicketDT";
		//case "Remittance Fees": return "RemittanceFees";
		case "Training Fees": return "TrainingFeeDT";
		default:System.out.println("deafult of getCommercialName");
		}
		return null;
	}
}
