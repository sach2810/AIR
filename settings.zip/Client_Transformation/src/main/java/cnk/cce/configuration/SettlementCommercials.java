package cnk.cce.configuration;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.products.Accomodation;
import cnk.cce.products.Activities;
import cnk.cce.products.Air;
import cnk.cce.products.Holidays;

public class SettlementCommercials {
	public static JSONObject main = new JSONObject();

	public static String settlementCommercials(String commercialType, String productName, JSONObject mdmCommDefn, JSONObject jsonObject, String entityName, JSONArray entityMarket, String entityType, String supplier, String id,String productCategory, String productCategorySubType, String kafkaMethod) throws Exception {
		String value=CommonFunctions.entityType;
		String commercialName=CommonFunctions.getCommercialName(jsonObject.get("commercialHead").toString());
		JSONObject mainJson = new JSONObject();
		if(!main.toString().equals("{}") && !main.isNull("CommercialDefinitionDT") && main.has("CommercialDefinitionDT")){
			//indicates that values already inserted once in it
			mainJson=new JSONObject(new JSONTokener(main.toString()));
			JSONArray commercialHeadArr = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
			JSONObject comm = new JSONObject();
			comm.put("commercialHeadName", commercialName);
			comm.put("commercialType", commercialType);
			comm.put("contractType", "Final");		//if in case we get contractType, we can insert here
			comm.put("isApplicable", true);
			commercialHeadArr.put(comm);
		}else{
			JSONObject commJson = new JSONObject();
			commJson.put("RuleID", id);
			commJson.put("type", "definition");
			commJson.put("supplier", supplier);
			appendProductCategoryAndSubType(commJson, productName, productCategory, productCategorySubType);
			commJson.put("entityName", entityName);
			if(entityMarket.length()>0)
				commJson.put("entityMarket", entityMarket);
			JSONArray commercialHeadArr = new JSONArray();
			JSONObject comm = new JSONObject();
			comm.put("commercialHeadName", commercialName);
			comm.put("commercialType", commercialType);
			comm.put("contractType", "Final");		//if in case we get contractType, we can insert here
			comm.put("isApplicable", true);
			commercialHeadArr.put(comm);
			commJson.put("commercialHead", commercialHeadArr);

			mainJson.put("CommercialDefinitionDT", commJson);
		}

		switch(jsonObject.get("commercialHead").toString()){
		case "Maintenance Fees":{
			otherFees("MaintenanceFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Integration Fees":{
			otherFees("IntegrationFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Licence Fees":{
			otherFees("LicenceFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Web Service Fees":{
			otherFees("WebServiceFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Loyalty Bonus":{
			otherFees("LoyaltyBonusDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Training Fees":{
			otherFees("TrainingFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Preference Benefit":{
			otherFees("PreferenceBenefitDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Retainer Fee":{
			otherFees("RetainerFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Listing Fee":{
			otherFees("ListingFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Content Access Fee":{
			otherFees("ContentAccessFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Sign Up Fees":{
			otherFees("SignUpFeeDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			break;
		}
		case "Sign Up Bonus":{
			setSignUpBonus(jsonObject,mainJson,mdmCommDefn, commercialName,id,commercialType,value,entityName,entityMarket,entityType,supplier,productName,kafkaMethod);
			break;
		}
		case "Look To Book":{
			setLookToBookDetails(mdmCommDefn,jsonObject,mainJson,id,commercialName,value);
			break;
		}	
		case "MSF Fees":{
			//no schema for remittance in client
		}
		case "Incentives On Top Up":{
			setIncentiveOnTopUp(mdmCommDefn,jsonObject,mainJson,id,commercialName,value);
			break;
		}
		case "Termination Fees":{
			setTerminationFeeDetails(jsonObject,mdmCommDefn,mainJson,value,id,commercialName);
			break;
		}
		case "Penalty Fee / Kick Back":{
			setPenaltyFeeDetails(mdmCommDefn,jsonObject,mainJson,id,commercialName,value);
			break;
		}
		case "Free Of Cost (FOC)":{
			break;
		}
		case "Lost Ticket":{
			otherFees("LostTicketDT",mainJson,mdmCommDefn,jsonObject,value,id,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,kafkaMethod);
			System.out.println("LostTicketDT: "+mainJson);
			break;
		}
		case "Remittance Fees":{
			//no schema for remittance in client
		}
		default:System.out.println("default of settlementCommercials bcoz of: "+jsonObject.get("commercialHead").toString());
		}
		main=new JSONObject(new JSONTokener(mainJson.toString()));
		return main.toString();
	}


	private static void setPenaltyFeeDetails(JSONObject mdmCommDefn, JSONObject jsonObject, JSONObject mainJson, String id, String commercialName, String value) {
		if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0){
			JSONArray penaltyFeeArr = new JSONArray();
			for(int k=0;k<jsonObject.getJSONArray("applicableOnId").length();k++){
				for(int i=0;i<mdmCommDefn.getJSONArray("clientCommercialOtherHead").length();i++){
					JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray("clientCommercialOtherHead").getJSONObject(i);
					if(clientCommercialOtherHead.getString("_id").equals(jsonObject.getJSONArray("applicableOnId").getString(k))){
						JSONArray penaltyCriteria =  clientCommercialOtherHead.getJSONObject("commercialHeads").getJSONArray("penaltyCriteria");
						for(int j=0;j<penaltyCriteria.length();j++){
							JSONObject penaltyCriteriaObject = penaltyCriteria.getJSONObject(j);
							JSONObject penaltyFee = new JSONObject();
							JSONObject slabDetails = new JSONObject(); 
							JSONObject slabTypeVal = new JSONObject();
							penaltyFee.put("RuleID", penaltyCriteriaObject.getString("_id"));
							penaltyFee.put("selectedRow", id);
							penaltyFee.put("type", commercialName);
							JSONObject contractValidity = new JSONObject();
							contractValidity.put("operator", "BETWEEN");
							contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
							contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
							penaltyFee.put("contractValidity", contractValidity);

							if(penaltyCriteriaObject.has("minToAchiveFrom") && penaltyCriteriaObject.has("minToAchiveTo")){
								String minToAchieve = penaltyCriteriaObject.get("minToAchiveFrom").toString();
								String maxToAchieve = penaltyCriteriaObject.get("minToAchiveTo").toString();
								String targetto = penaltyCriteriaObject.get("targetTo").toString();
								slabDetails.put("slabType", penaltyCriteriaObject.getString("slabType"));
								slabTypeVal.put("minimumToAchieve",minToAchieve+"*"+targetto);
								slabTypeVal.put("maximumToAchieve",maxToAchieve+"*"+targetto);
								slabDetails.put("slabTypeValue", slabTypeVal);
								penaltyFee.put("slabDetails", slabDetails);
							}else{
								slabDetails.put("slabType", penaltyCriteriaObject.getString("slabType"));
								if(penaltyCriteriaObject.get("targetTo").equals(0)){
									slabTypeVal.put("operator", "GREATERTHANEQUALTO");
									slabTypeVal.put("value", penaltyCriteriaObject.get("targetFrom").toString());
								}else{
									slabTypeVal.put("operator","BETWEEN");
									slabTypeVal.put("from", penaltyCriteriaObject.get("targetFrom").toString());
									slabTypeVal.put("to", penaltyCriteriaObject.get("targetTo").toString());
								}
								slabDetails.put("slabTypeValue", slabTypeVal);
								penaltyFee.put("slabDetails", slabDetails);
							}
							JSONObject penalty = penaltyCriteriaObject.getJSONObject("penalty");
							if(penalty.getBoolean("isPercentage")){
								if(penalty.getJSONObject("percentage").has("slabType"))
									penaltyFee.put("matchingSlabType", penalty.getJSONObject("percentage").getString("slabType"));
								if(penalty.getJSONObject("percentage").has("value") && !penalty.getJSONObject("percentage").get("value").equals(0))
									penaltyFee.put("percentage", penalty.getJSONObject("percentage").get("value").toString());
							}else{
								if(penalty.getJSONObject("amount").has("currency"))
									penaltyFee.put("commercialAmount", penalty.getJSONObject("amount").getString("currency"));
								if(penalty.getJSONObject("amount").has("value") && !penalty.getJSONObject("amount").get("value").equals(0))
									penaltyFee.put("commercialCurrency", penalty.getJSONObject("amount").get("value").toString());
							}
							penaltyFeeArr.put(penaltyFee);
						}
					}
				}
			}
			mainJson.put("PenaltyFeeDT", penaltyFeeArr);
		}else{
			JSONObject penaltyFee = new JSONObject();
			penaltyFee.put("RuleID", jsonObject.getString("_id"));
			penaltyFee.put("selectedRow", id);
			penaltyFee.put("type", commercialName);
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
			contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
			penaltyFee.put("contractValidity", contractValidity);
			if(jsonObject.getJSONObject(value).has("amount") && !jsonObject.getJSONObject(value).get("amount").equals(0))
				penaltyFee.put("commercialAmount", jsonObject.getJSONObject(value).get("amount").toString());
			if(jsonObject.getJSONObject(value).has("currency"))
				penaltyFee.put("commercialCurrency", jsonObject.getJSONObject(value).getString("currency"));
			mainJson.put("PenaltyFeeDT", penaltyFee);
		}
	}


	private static void setLookToBookDetails(JSONObject mdmCommDefn, JSONObject jsonObject, JSONObject mainJson, String id, String commercialName, String value) {
		JSONArray lookToBookArr = new JSONArray();
		if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0){
			for(int k=0;k<jsonObject.getJSONArray("applicableOnId").length();k++){
				for(int i=0;i<mdmCommDefn.getJSONArray("clientCommercialOtherHead").length();i++){
					JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray("clientCommercialOtherHead").getJSONObject(i);
					if(clientCommercialOtherHead.getString("_id").equals(jsonObject.getJSONArray("applicableOnId").getString(k))){
						JSONObject lookToBook =  clientCommercialOtherHead.getJSONObject("commercialHeads").getJSONObject("lookToBook");
						JSONObject l2b = new JSONObject();
						setLookToBook(jsonObject,l2b,id,commercialName);

						if(lookToBook.getString("byRatioOrRate").equals("ratio")){
							for(int m=0;m<lookToBook.getJSONArray("byRatio").length();m++){
								JSONObject lookRatio = lookToBook.getJSONArray("byRatio").getJSONObject(m);
								l2b.put("RuleID", lookRatio.getString("_id"));
								JSONObject lookToBookObject = new JSONObject();
								lookToBookObject.put("from",lookRatio.getJSONObject("lookRatio").get("from").toString());
								lookToBookObject.put("to",lookRatio.getJSONObject("lookRatio").get("to").toString());
								lookToBookObject.put("bookRatio", lookRatio.get("bookRatio").toString());
								lookToBookObject.put("amountPerAccessLook", lookRatio.get("amountPerexcessLook").toString());
								if(lookRatio.has("currency"))
									lookToBookObject.put("currency", lookRatio.getString("currency"));
								l2b.put("lookToBook", lookToBookObject);
								lookToBookArr.put(l2b);
							}
						}else{
							JSONObject lookToBookRate = new JSONObject();
							JSONObject l2bByRate = lookToBook.getJSONObject("byRate");
							l2b.put("RuleID", clientCommercialOtherHead.getString("_id"));
							JSONObject ratePerLook = new JSONObject();
							JSONObject ratePerBook = new JSONObject();
							if(l2bByRate.getJSONObject("ratePerLook").has("currency"))
								ratePerLook.put("currency", l2bByRate.getJSONObject("ratePerLook").getString("currency"));
							if(l2bByRate.getJSONObject("ratePerLook").has("amount") && !l2bByRate.getJSONObject("ratePerLook").get("amount").equals(0))
								ratePerLook.put("amount", l2bByRate.getJSONObject("ratePerLook").get("amount").toString());
							if(l2bByRate.getJSONObject("ratePerBook").has("currency"))
								ratePerBook.put("currency", l2bByRate.getJSONObject("ratePerBook").getString("currency"));
							if(l2bByRate.getJSONObject("ratePerBook").has("amount") && !l2bByRate.getJSONObject("ratePerBook").get("amount").equals(0))
								ratePerBook.put("amount", l2bByRate.getJSONObject("ratePerBook").get("amount").toString());
							lookToBookRate.put("lookRate", ratePerLook);
							lookToBookRate.put("bookRate", ratePerBook);
							l2b.put("lookToBook", lookToBookRate);
							lookToBookArr.put(l2b);
						}
					}
				}
			}
			mainJson.put("LookToBookCumulativeDT", lookToBookArr);
		}else{
			JSONObject lookToBook = new JSONObject();
			lookToBook.put("RuleID", jsonObject.getString("_id"));
			setLookToBook(jsonObject,lookToBook,id,commercialName);
			if(jsonObject.getJSONObject(value).has("amount") && !jsonObject.getJSONObject(value).get("amount").equals(0))
				lookToBook.put("commercialAmount", jsonObject.getJSONObject(value).get("amount").toString());
			if(jsonObject.getJSONObject(value).has("currency"))
				lookToBook.put("commercialCurrency", jsonObject.getJSONObject(value).getString("currency"));
			mainJson.put("LookToBookCumulativeDT", lookToBook);
		}
	}


	private static void setLookToBook(JSONObject jsonObject, JSONObject l2b, String id, String commercialName) {
		l2b.put("selectedRow", id);
		l2b.put("type", commercialName);
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
		contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
		l2b.put("contractValidity", contractValidity);
	}


	private static void setIncentiveOnTopUp(JSONObject mdmCommDefn, JSONObject jsonObject, JSONObject mainJson, String id, String commercialName, String value) {
		JSONArray iotpArray = new JSONArray();
		if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0){
			for(int k=0;k<jsonObject.getJSONArray("applicableOnId").length();k++){
				for(int i=0;i<mdmCommDefn.getJSONArray("clientCommercialOtherHead").length();i++){
					JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray("clientCommercialOtherHead").getJSONObject(i);
					if(clientCommercialOtherHead.getString("_id").equals(jsonObject.getJSONArray("applicableOnId").getString(k))){
						JSONObject incentiveOnTopUp =  clientCommercialOtherHead.getJSONObject("commercialHeads").getJSONObject("incentiveOnTopUp");
						switch(incentiveOnTopUp.getString("periodOfTopUp")){
						case "daily":{
							for(int j=0;j<incentiveOnTopUp.getJSONArray("daily").length();j++){
								JSONObject iotp = new JSONObject();
								JSONObject iotpDaily =incentiveOnTopUp.getJSONArray("daily").getJSONObject(j);
								JSONObject daily = new JSONObject();
								JSONObject periodForTopUp = new JSONObject();
								JSONObject contractValidity = new JSONObject();
								contractValidity.put("operator", "BETWEEN");
								contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
								contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
								iotp.put("contractValidity", contractValidity);
								iotp.put("selectedRow", id);
								iotp.put("type", commercialName);
								iotp.put("RuleID",iotpDaily.getString("_id"));
								if(incentiveOnTopUp.has("modeOfPayment"))
									iotp.put("modeOfPayment", incentiveOnTopUp.getString("modeOfPayment"));
								if(incentiveOnTopUp.has("bankId"))
									iotp.put("bankName", incentiveOnTopUp.getString("bankId"));
								if(incentiveOnTopUp.has("currency"))
									iotp.put("incentiveCurrency", incentiveOnTopUp.getString("currency"));
								if(incentiveOnTopUp.has("amount") && !incentiveOnTopUp.get("amount").equals(0))
									iotp.put("incentiveAmount", incentiveOnTopUp.get("amount").toString());
								if(iotpDaily.has("timeOfTheDayHrs"))
									daily.put("hours", iotpDaily.get("timeOfTheDayHrs").toString());
								if(iotpDaily.has("timeOfTheDayMin"))
									daily.put("minutes", iotpDaily.get("timeOfTheDayMin").toString());
								periodForTopUp.put("daily", daily);
								iotp.put("periodForTopUp", periodForTopUp);
								iotpArray.put(iotp);
							}
							break;
						}
						case "weekly":{
							JSONObject weekly = new JSONObject();
							JSONObject iotp = new JSONObject();
							JSONObject periodForTopUp = new JSONObject();
							JSONArray iotpWeekly =incentiveOnTopUp.getJSONArray("weekly");
							JSONObject contractValidity = new JSONObject();
							contractValidity.put("operator", "BETWEEN");
							contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
							contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
							iotp.put("contractValidity", contractValidity);
							iotp.put("selectedRow", id);
							iotp.put("type", commercialName);
							iotp.put("RuleID",clientCommercialOtherHead.getString("_id"));
							if(incentiveOnTopUp.has("modeOfPayment"))
								iotp.put("modeOfPayment", incentiveOnTopUp.getString("modeOfPayment"));
							if(incentiveOnTopUp.has("bankId"))
								iotp.put("bankName", incentiveOnTopUp.getString("bankId"));
							if(incentiveOnTopUp.has("currency"))
								iotp.put("incentiveCurrency", incentiveOnTopUp.getString("currency"));
							if(incentiveOnTopUp.has("amount") && !incentiveOnTopUp.get("amount").equals(0))
								iotp.put("incentiveAmount", incentiveOnTopUp.get("amount").toString());
							Set<String> tempo = new HashSet<String>();
							for(int j=0;j<iotpWeekly.length();j++){
								JSONObject temp = iotpWeekly.getJSONObject(j);
								if(temp.has("daysOfTheWeek")){
									tempo.add(temp.getString("daysOfTheWeek"));
									weekly.put("dayOfWeek", tempo);
								}
							}

							periodForTopUp.put("weekly", weekly);
							iotp.put("periodForTopUp", periodForTopUp);
							iotpArray.put(iotp);
							break;
						}
						case "fortNightly":{
							for(int j=0;j<incentiveOnTopUp.getJSONArray("fortNightly").length();j++){
								JSONObject iotpFortnightly =incentiveOnTopUp.getJSONArray("fortNightly").getJSONObject(j);
								JSONObject iotp = new JSONObject();
								JSONObject fortnighly = new JSONObject();
								JSONObject periodForTopUp = new JSONObject();
								JSONArray dayOfWeekInMonth = new JSONArray();
								JSONArray monthFortnightly = new JSONArray();
								JSONObject contractValidity = new JSONObject();
								contractValidity.put("operator", "BETWEEN");
								contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
								contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
								iotp.put("contractValidity", contractValidity);
								iotp.put("selectedRow", id);
								iotp.put("type", commercialName);
								iotp.put("RuleID",iotpFortnightly.getString("_id"));
								if(incentiveOnTopUp.has("modeOfPayment"))
									iotp.put("modeOfPayment", incentiveOnTopUp.getString("modeOfPayment"));
								if(incentiveOnTopUp.has("bankId"))
									iotp.put("bankName", incentiveOnTopUp.getString("bankId"));
								if(incentiveOnTopUp.has("currency"))
									iotp.put("incentiveCurrency", incentiveOnTopUp.getString("currency"));
								if(incentiveOnTopUp.has("amount") && !incentiveOnTopUp.get("amount").equals(0))
									iotp.put("incentiveAmount", incentiveOnTopUp.get("amount").toString());
								if(iotpFortnightly.has("day1"))
									dayOfWeekInMonth.put(iotpFortnightly.get("day1").toString());
								if(iotpFortnightly.has("day2"))
									dayOfWeekInMonth.put(iotpFortnightly.get("day2").toString());
								fortnighly.put("dayOfWeekInMonth", dayOfWeekInMonth);
								int f = iotpFortnightly.getInt("repeatEvery");
								for(int bc=1;bc<=12;bc++){
									if(bc%f==0){
										monthFortnightly.put(""+bc);
									}
								}
								fortnighly.put("month",monthFortnightly);
								periodForTopUp.put("fortnighly", fortnighly);
								iotp.put("periodForTopUp", periodForTopUp);
								iotpArray.put(iotp);
							}
							break;
						}
						default:{
							System.out.println("default of periodOfTopUp");
						}
						}
					}
				}
			}
			mainJson.put("IncentivesOnTopUpDT", iotpArray);
		}else{
			JSONObject iotp = new JSONObject();
			iotp.put("RuleID", jsonObject.getString("_id"));
			iotp.put("selectedRow", id);
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
			contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
			iotp.put("contractValidity", contractValidity);
			if(jsonObject.getJSONObject(value).has("percentage") && !jsonObject.getJSONObject(value).get("percentage").equals(0))
				iotp.put("incentivePercentage", jsonObject.getJSONObject(value).get("percentage").toString());
			mainJson.put("IncentivesOnTopUpDT", iotp);
		}
	}


	private static void setTerminationFeeDetails(JSONObject jsonObject, JSONObject mdmCommDefn, JSONObject mainJson, String value, String id, String commercialName) {
		if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0){
			JSONObject terminationFeeP = new JSONObject();
			for(int i=0;i<jsonObject.getJSONArray("applicableOnId").length();i++){
				for(int j=0;j<mdmCommDefn.getJSONArray("clientCommercialOtherHead").length();j++){
					JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray("clientCommercialOtherHead").getJSONObject(j);
					if(clientCommercialOtherHead.getString("_id").equals(jsonObject.getJSONArray("applicableOnId").getString(i))){
						JSONObject terminationFee =  clientCommercialOtherHead.getJSONObject("commercialHeads").getJSONObject("terminationFee");
						terminationFeeP.put("RuleID", jsonObject.getJSONArray("applicableOnId").getString(i));
						setTerminationFeeDetails(terminationFeeP,terminationFee,id,commercialName);
						if(terminationFee.getJSONObject("payable").getBoolean("fixed")){
							if(terminationFee.getJSONObject("fixed").has("currency"))
								terminationFeeP.put("commercialCurrency",terminationFee.getJSONObject("fixed").getString("currency"));
							if(terminationFee.getJSONObject("fixed").has("value") && !terminationFee.getJSONObject("fixed").get("value").equals(0))
								terminationFeeP.put("commercialAmount",terminationFee.getJSONObject("fixed").get("value").toString());
						}else{
							JSONArray returnableCommHeadArr =new JSONArray();
							for(int n=0;n<terminationFee.getJSONArray("returnOfPayable").length();n++){
								JSONObject returnableCommHead =new JSONObject();
								if(terminationFee.getJSONArray("returnOfPayable").getJSONObject(n).has("commercialHead"))
									returnableCommHead.put("commercialName", terminationFee.getJSONArray("returnOfPayable").getJSONObject(n).getString("commercialHead"));
								if(terminationFee.getJSONArray("returnOfPayable").getJSONObject(n).has("interestOnAmount") && !terminationFee.getJSONArray("returnOfPayable").getJSONObject(n).get("interestOnAmount").equals(0))
									returnableCommHead.put("commercialPercentage", terminationFee.getJSONArray("returnOfPayable").getJSONObject(n).get("interestOnAmount").toString());
								returnableCommHeadArr.put(returnableCommHead);
							}
							terminationFeeP.put("returnableCommercialHead",returnableCommHeadArr);
						}
					}
				}
			}
			mainJson.put("TerminationFeeDT", terminationFeeP);
		}else{
			JSONObject terminationFee = new JSONObject();
			terminationFee.put("RuleID", jsonObject.getString("_id"));
			setTerminationFeeDetailsNoOtherHeads(terminationFee,jsonObject,id,commercialName);
			if(jsonObject.getJSONObject(value).has("amount") && !jsonObject.getJSONObject(value).get("amount").equals(0))
				terminationFee.put("commercialAmount", jsonObject.getJSONObject(value).get("amount").toString());
			if(jsonObject.getJSONObject(value).has("currency"))
				terminationFee.put("commercialCurrency", jsonObject.getJSONObject(value).getString("currency"));
			mainJson.put("TerminationFeeDT", terminationFee);
		}
	}


	private static void setTerminationFeeDetailsNoOtherHeads(JSONObject terminationFeeP, JSONObject terminationFee, String id, String commercialName) {
		terminationFeeP.put("selectedRow", id);
		terminationFeeP.put("type", commercialName);
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", terminationFee.getJSONObject("effectiveDates").getString("from").substring(0, 19));
		contractValidity.put("to", terminationFee.getJSONObject("effectiveDates").getString("to").substring(0, 19));
		terminationFeeP.put("contractValidity", contractValidity);
	}
	
	
	private static void setTerminationFeeDetails(JSONObject terminationFeeP, JSONObject terminationFee, String id, String commercialName) {
		terminationFeeP.put("selectedRow", id);
		terminationFeeP.put("type", commercialName);
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", terminationFee.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", terminationFee.getString("contractValidityTo").substring(0, 19));
		terminationFeeP.put("contractValidity", contractValidity);
	}


	private static void setSignUpBonus(JSONObject jsonObject, JSONObject mainJson, JSONObject mdmCommDefn, String commercialName,String id,String commercialType, String value, String entityName, JSONArray entityMarket, String entityType,String supplier,String productName,String kafkaMethod) {
		if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0){
			JSONArray signUpBonusArr = new JSONArray();
			for(int i=0;i<jsonObject.getJSONArray("applicableOnId").length();i++){
				JSONObject signUpBonus = new JSONObject();
				signUpBonus.put("RuleID", jsonObject.getJSONArray("applicableOnId").getString(i));
				signUpBonus.put("selectedRow", id);
				signUpBonus.put("type", commercialName);
				JSONObject contractValidity = new JSONObject();
				contractValidity.put("operator", "BETWEEN");
				contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
				contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
				signUpBonus.put("contractValidity", contractValidity);
				//CommonFunctions.signUpBonusApplicableOnID = jsonObject.getJSONArray("applicableOnId").getString(i);
				getClientOtherHeads("signUpBonus",commercialType,mdmCommDefn,entityName,entityMarket,entityType,supplier,id,commercialName,productName,kafkaMethod,mainJson,signUpBonus,jsonObject.getJSONArray("applicableOnId").getString(i));
				if(jsonObject.getJSONObject(value).has("amount") && !jsonObject.getJSONObject(value).get("amount").equals(0))
					signUpBonus.put("commercialAmount", jsonObject.getJSONObject(value).get("amount").toString());
				if(jsonObject.getJSONObject(value).has("currency"))
					signUpBonus.put("commercialCurrency", jsonObject.getJSONObject(value).getString("currency"));
				signUpBonusArr.put(signUpBonus);
			}
			mainJson.put("SignUpBonusDT", signUpBonusArr);
		}else{
			JSONObject signUpBonus = new JSONObject();
			signUpBonus.put("RuleID", jsonObject.getString("_id"));
			signUpBonus.put("selectedRow", id);
			signUpBonus.put("type", commercialName);
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
			contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
			signUpBonus.put("contractValidity", contractValidity);
			if(jsonObject.getJSONObject(value).has("amount") && !jsonObject.getJSONObject(value).get("amount").equals(0))
				signUpBonus.put("commercialAmount", jsonObject.getJSONObject(value).get("amount").toString());
			if(jsonObject.getJSONObject(value).has("currency"))
				signUpBonus.put("commercialCurrency", jsonObject.getJSONObject(value).getString("currency"));
			mainJson.put("SignUpBonusDT", signUpBonus);
		}

	}


	public static void otherFees(String DTname, JSONObject mainJson, JSONObject mdmCommDefn, JSONObject jsonObject, String value, String id, String commercialName, String supplier, String entityName, JSONArray entityMarket, String entityType, String commercialType, String productName, String kafkaMethod){
		JSONArray otherFeeArr = new JSONArray();
		if(jsonObject.has("applicableOnId") && jsonObject.getJSONArray("applicableOnId").length()>0){
			for(int i=0;i<jsonObject.getJSONArray("applicableOnId").length();i++){
				JSONObject otherFee = new JSONObject();
				otherFee.put("RuleID", jsonObject.getJSONArray("applicableOnId").getString(i));
				setOtherFeesDetails(jsonObject,otherFee,mainJson,commercialName,id);
				//CommonFunctions.otherFeeApplicableOnID = jsonObject.getJSONArray("applicableOnId").getString(i);
				getClientOtherHeads("otherFees",commercialType,mdmCommDefn,entityName,entityMarket,entityType,supplier,id,commercialName,productName,kafkaMethod,mainJson,otherFee,jsonObject.getJSONArray("applicableOnId").getString(i));
				otherFeeArr.put(otherFee);
			}
			mainJson.put(DTname, otherFeeArr);
		}else{
			JSONObject otherFee = new JSONObject();
			otherFee.put("RuleID", jsonObject.getString("_id"));
			setOtherFeesDetails(jsonObject,otherFee,mainJson,commercialName,id);
			if(jsonObject.getJSONObject(value).has("amount") && !jsonObject.getJSONObject(value).get("amount").equals(0))
				otherFee.put("commercialAmount", jsonObject.getJSONObject(value).get("amount").toString());
			if(jsonObject.getJSONObject(value).has("currency"))
				otherFee.put("commercialCurrency", jsonObject.getJSONObject(value).getString("currency"));
			otherFeeArr.put(otherFee);
			mainJson.put(DTname, otherFeeArr);
		}

		if(jsonObject.has("advanceDefinitionId") && jsonObject.getString("advanceDefinitionId").length()!=0){
			for(int j=0;j<mdmCommDefn.getJSONArray("advancedDefinitionData").length();j++){
				JSONObject advDefData = mdmCommDefn.getJSONArray("advancedDefinitionData").getJSONObject(j);
				if(jsonObject.getString("advanceDefinitionId").equals(advDefData.getString("_id"))){
					switch(productName){
					case "accomodation":{
						JSONObject advanceDefinitionAccommodation = advDefData.getJSONObject("advanceDefinitionAccommodation");
						Accomodation.appendAccomodationOtherFeesAdvDefn(advanceDefinitionAccommodation,otherFeeArr,mdmCommDefn,jsonObject,id);
						break;
					}
					case "holidays":{
						JSONObject advanceDefinitionHolidays = advDefData.getJSONObject("advanceDefinitionHolidays");
						Holidays.setOtherFeesHolidaysAdvancedDefinition(advanceDefinitionHolidays, otherFeeArr);
						break;
					}
					case "activities":{
						JSONObject advanceDefinitionActivities = advDefData.getJSONObject("advanceDefinitionActivities");
						Activities.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionActivities);
						break;
					}
					case "bus":{
						JSONObject advanceDefinitionTransportation = advDefData.getJSONObject("advanceDefinitionTransportation");
						CommonFunctions.setOtherFeesTransportationAdvancedDefinition(advanceDefinitionTransportation, otherFeeArr);
						break;
					}
					case "carrentals":{
						JSONObject advanceDefinitionTransportation = advDefData.getJSONObject("advanceDefinitionTransportation");
						CommonFunctions.setOtherFeesTransportationAdvancedDefinition(advanceDefinitionTransportation, otherFeeArr);
						break;
					}
					case "cruise":{
						JSONObject advanceDefinitionTransportation = advDefData.getJSONObject("advanceDefinitionTransportation");
						CommonFunctions.setOtherFeesTransportationAdvancedDefinition(advanceDefinitionTransportation, otherFeeArr);
						break;
					}
					case "rail":{
						break;
					}
					case "air":{
						JSONObject advanceDefinitionAir = advDefData.getJSONObject("advanceDefinitionAir");
						Air.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionAir, id);
						break;
					}
					case "rentals":{
						break;
					}
					case "transfers":{
						JSONObject advanceDefinitionTransportation = advDefData.getJSONObject("advanceDefinitionTransportation");
						CommonFunctions.setOtherFeesTransportationAdvancedDefinition(advanceDefinitionTransportation, otherFeeArr);
						break;
					}
					}
				}
			}
		}
	}


	private static void setOtherFeesDetails(JSONObject jsonObject, JSONObject otherFee, JSONObject mainJson, String commercialName, String id) {
		otherFee.put("selectedRow", id);
		otherFee.put("type", commercialName);
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", jsonObject.getJSONObject("effectiveDates").getString("from").substring(0, 19));
		contractValidity.put("to", jsonObject.getJSONObject("effectiveDates").getString("to").substring(0, 19));
		otherFee.put("contractValidity", contractValidity);
		/*JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
		for(int i=0;i<commercialHead.length();i++){
			JSONObject commHeadObj = commercialHead.getJSONObject(i);
			if(commHeadObj.getString("commercialHeadName").equals(commercialName)){
				commHeadObj.put("refundable", true);
				commHeadObj.put("recurring", true);
			}
		}*/
	}


	public static void setSettlementRuleID(JSONObject otherFee, String id) {
		String RuleID = otherFee.getString("RuleID")+id;
		otherFee.put("RuleID", RuleID);
	}


	public static void appliedOnOtherFees(JSONObject mdmOtherFees, JSONObject otherFee) {
		JSONArray percentArr = new JSONArray();
		try{
			for(int i=0;i<mdmOtherFees.getJSONArray("percentage").length();i++){
				JSONObject percent = mdmOtherFees.getJSONArray("percentage").getJSONObject(i);
				JSONObject percentObj = new JSONObject();
				if(percent.has("appliedOnCommercialHead"))
					percentObj.put("commercialName", percent.getString("appliedOnCommercialHead"));
				if(percent.has("percent") && !percent.get("percent").equals(0))
					percentObj.put("commercialPercentage", percent.get("percent").toString());
				percentArr.put(percentObj);
			}
			otherFee.put("percentage", percentArr);
		}catch(Exception e){}
	}


	public static void appendProductCategoryAndSubType(JSONObject commJson, String productName, String productCategory, String productCategorySubType) {
		switch(productName){
		case "accomodation":{
			commJson.put("productCategorySubType", productCategorySubType);
			break;
		}
		case "holidays":{
			commJson.put("productCategory", productCategory);
			commJson.put("productCategorySubType", productCategorySubType);
			break;
		}
		/*case "activities":{
			commJson.put("productCategorySubType", productCategorySubType);
			break;
		}*/
		}
	}


	private static JSONObject getClientOtherHeads(String otherHead, String commercialType, JSONObject mdmCommDefn, String entityName,JSONArray entityMarket, String entityType, String supplier, String id, String commercialName, String productName, String kafkaMethod, JSONObject mainJson, JSONObject object, String advDefnID){
		switch(otherHead){
		case "otherFees":{
			for(int i=0;i<mdmCommDefn.getJSONArray("clientCommercialOtherHead").length();i++){
				JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray("clientCommercialOtherHead").getJSONObject(i);
				//System.out.println("ClientOtherHeads ka ID:"+clientCommercialOtherHead.getString("_id"));
				if(clientCommercialOtherHead.getString("_id").equals(advDefnID)){
					JSONObject otherFees = clientCommercialOtherHead.getJSONObject("commercialHeads").getJSONObject("otherFees");
					JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
					for(int c=0;c<commercialHead.length();c++){
						JSONObject commHeadObj = commercialHead.getJSONObject(c);
						if(commHeadObj.getString("commercialHeadName").equals(commercialName)){
							if(otherFees.has("refundable"))
								commHeadObj.put("refundable", true);
							else commHeadObj.put("refundable", false);
							if(otherFees.has("recurring"))
								commHeadObj.put("recurring", true);
							else commHeadObj.put("recurring", false);
						}
					}
					if(otherFees.has("percent") && otherFees.getJSONArray("percent").length()>0){
						JSONArray percent = otherFees.getJSONArray("percent");
						JSONArray percentageArr = new JSONArray();
						for(int j=0;j<percent.length();j++){
							JSONObject percentObject = percent.getJSONObject(j);
							JSONObject json = new JSONObject();
							if(percentObject.has("commercialHead"))
								json.put("commercialName", percentObject.getString("commercialHead"));
							if(percentObject.has("percentage") && !percentObject.get("percentage").equals(0))
								json.put("commercialPercentage", percentObject.get("percentage").toString());
							percentageArr.put(json);
						}
						object.put("percentage",percentageArr);
					}else{
						if(otherFees.getJSONObject("fixed").has("value") && !otherFees.getJSONObject("fixed").get("value").equals(0))
							object.put("commercialAmount", otherFees.getJSONObject("fixed").get("value").toString());
						if(otherFees.getJSONObject("fixed").has("currency"))
							object.put("commercialCurrency", otherFees.getJSONObject("fixed").getString("currency"));
					}
				}
			}break;
		}
		case "signUpBonus":{
			for(int i=0;i<mdmCommDefn.getJSONArray("clientCommercialOtherHead").length();i++){
				JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray("clientCommercialOtherHead").getJSONObject(i);
				if(advDefnID.equals(clientCommercialOtherHead.getString("_id"))){
					JSONObject signupbonus = clientCommercialOtherHead.getJSONObject("commercialHeads").getJSONObject("signUpBonus");
					JSONObject slabDetails = new JSONObject();
					slabDetails.put("slabType", signupbonus.getString("slabtype"));
					JSONObject slabTypeValueObj = new JSONObject();
					slabTypeValueObj.put("operator", "BETWEEN");
					slabTypeValueObj.put("from", signupbonus.get("targetFrom").toString());
					slabTypeValueObj.put("to", signupbonus.get("targetTo").toString());
					slabDetails.put("slabTypeValue", slabTypeValueObj);
					object.put("slabDetails", slabDetails);
				}
			}
			break;
		}
		default:System.out.println("default of getClientSettlementHead");
		}
		return object;
	}
}
