package cnk.cce.configuration;

import java.io.InputStream;
import java.util.Map;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.products.Holidays;
import org.json.JSONArray;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Properties;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
/*import java.io.File;
import org.apache.commons.io.FileUtils;*/


public class Configuration {

	public static final String PROP_USER_ID = "userID";
	public static final String PROP_PASSWORD = "password";
	public static final String HTTP_AUTH_BASIC_PREFIX = "Basic ";
	private static String mUserID;
	private transient static String mPassword;
	private transient static String mHttpBasicAuth;
	static JSONObject mdmReq;
	static String method = "";
	static String requestUrl = "";
	
	public static void main(String args[]){
		KafkaConsumer<String, String> consumer = null;
		try {
			/*String kafkaMethod = "POST";
			String content = FileUtils.readFileToString(new File("D:\\AVAMAR BACKUP\\Milan Tank\\Documents\\MDMFormatForAccomodation_Client.json"), "utf-8");
			JSONObject mdmCommDefn = new JSONObject(content);
			readJSON(mdmCommDefn,kafkaMethod);*/
			
			Properties properties = new Properties();
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			String str = "";
			String topic = "MDM.DEV.CLIENTCOMMERCIAL.PUB";
			
			try(InputStream in = classLoader.getResourceAsStream("kafkaConfiguration.properties")){
				properties.load(in);

				Enumeration<Object> enuKeys = properties.keys();
				while (enuKeys.hasMoreElements()) {
					String key = (String) enuKeys.nextElement();
					String value = properties.getProperty(key);
					properties.put(key, value);
				}
			}catch(FileNotFoundException e){e.printStackTrace();} catch(IOException e){e.printStackTrace();}

			consumer = new KafkaConsumer<String, String>(properties);
			consumer.subscribe(Arrays.asList(topic));
			System.out.println("Subscribed to topic " + topic);

			while (true) {
				ConsumerRecords<String, String> records = consumer.poll(100);
				for (ConsumerRecord<String, String> record : records) {
					System.out.printf("offset = %d, message = %s\n", record.offset(), record.value());
					str = record.value();
					JSONObject mdmData = new JSONObject(str);
					method = mdmData.getString("method");
					try{
						readJSON(mdmData.getJSONObject("data"),method);
						consumer.commitSync();
					}
					catch(Exception ex){
						ex.printStackTrace();
						consumer.commitSync();
						continue;
					}
				}
			}
		}catch(Exception e){e.printStackTrace();consumer.commitSync();}
	}

	
	private static void readJSON(JSONObject mdmCommDefn, String kafkaMethod) throws Exception {
		if(mdmCommDefn.has("budgetedMarginDetails") && mdmCommDefn.getJSONObject("budgetedMarginDetails").getJSONArray("budgetMargins").length()>0){
			JSONArray budgetMargins = mdmCommDefn.getJSONObject("budgetedMarginDetails").getJSONArray("budgetMargins");
			for(int i=0;i<budgetMargins.length();i++){
				for(int j=0;j<mdmCommDefn.getJSONArray("clientCommercialData").length();j++){
					JSONObject clientCommercialData = mdmCommDefn.getJSONArray("clientCommercialData").getJSONObject(j);
					String budgetedMarginDetailId = clientCommercialData.getString("budgetedMarginDetailId");
					if(budgetMargins.getJSONObject(i).getString("_id").equals(budgetedMarginDetailId)){
						String supplier = null,entityName=null,entityType=null,settlementString = null, productCategorySubType = null;
						boolean settlement = false;
						String productName=CommonFunctions.getProductName(budgetMargins.getJSONObject(i));
						String productCategory = budgetMargins.getJSONObject(i).getString("productCategory");
						if(budgetMargins.getJSONObject(i).has("subCategory"))
							productCategorySubType = budgetMargins.getJSONObject(i).getString("subCategory");
						if(productName.equals("holidays"))
							Holidays.setBudgetMarginDetails(budgetMargins.getJSONObject(i));
						JSONObject budgetMarginAttachedTo = mdmCommDefn.getJSONObject("budgetedMarginDetails").getJSONObject("budgetMarginAttachedTo");
						if(budgetMarginAttachedTo.has("bookingId"))
							CommonFunctions.setAmmendRequest(budgetMarginAttachedTo,mdmCommDefn,productName,kafkaMethod);
						else{
							if(mdmCommDefn.getJSONObject("budgetedMarginDetails").has("entityId"))
								entityName = mdmCommDefn.getJSONObject("budgetedMarginDetails").getString("entityId");
							if(budgetMarginAttachedTo.has("entityType"))
								entityType = budgetMarginAttachedTo.getString("entityType");
							String id = clientCommercialData.getString("_id")+"_"+entityName+"_"+entityType;
							JSONObject flightsAndNonAir = clientCommercialData.getJSONObject("commercialDetails").getJSONObject("flightsAndNonAir");
							JSONArray entityMarket = new JSONArray();
							if(flightsAndNonAir.has("supplierId") && !flightsAndNonAir.getString("supplierId").equalsIgnoreCase("All"))
								supplier = flightsAndNonAir.getString("supplierId");
							JSONObject ipJson = new JSONObject();
							ipJson.put("type","definition");
							ipJson.put("supplier",supplier);
							ipJson.put("entityType",entityType);
							ipJson.put("entityName",entityName);
							//ipJson.put("bookingId", bookingId);
							if(budgetMarginAttachedTo.has("entityMarket") && !budgetMarginAttachedTo.getJSONArray("entityMarket").getString(0).equalsIgnoreCase("All")){
								entityMarket=budgetMarginAttachedTo.getJSONArray("entityMarket");
								ipJson.put("entityMarket",entityMarket);
							}

							if(entityType.equalsIgnoreCase("Client Group")){
								CommonFunctions.entityType = "company";
								CommonFunctions.retention = "companyRetention";
							}else{
								CommonFunctions.entityType = "client";
								CommonFunctions.retention = "clientRetention";
							}

							String clientCommercialDataID=clientCommercialData.get("__v")+"|"+clientCommercialData.getString("_id");

							JSONArray commHead = new JSONArray();
							//Additional Payables
							JSONObject additionalJSON = flightsAndNonAir.getJSONObject("additionalCommercials");
							if(additionalJSON.getJSONArray("payableToClient").length()>0){
								for(int c=0;c<additionalJSON.getJSONArray("payableToClient").length();c++){
									JSONObject payableToClient = additionalJSON.getJSONArray("payableToClient").getJSONObject(c);
									if(payableToClient.has("commercialHead")){
										if(CommonFunctions.isTransactional(payableToClient.getString("commercialHead"))){
											switch(payableToClient.getString("commercialHead")){
											case "Standard Commercial":{
												CommonFunctions.stdclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Standard Commercial","Payable","Additional",payableToClient,productName,clientCommercialDataID));break;
											}
											case "Overriding Commission":{
												CommonFunctions.overclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Overriding Commission","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Productivity Linked Bonus":{
												CommonFunctions.plbclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Productivity Linked Bonus","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Segment Fees":{
												CommonFunctions.segmentclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Segment Fees","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Segments Fees":{
												CommonFunctions.segmentclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Segments Fees","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Sector Incentives":{
												CommonFunctions.sectorclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Sector Incentives","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Management Fee":{
												CommonFunctions.mngtclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Management Fee","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Service Charges":{
												CommonFunctions.serviceclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Service Charges","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Discount":{
												CommonFunctions.discountclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Discount","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Destination Incentives":{
												CommonFunctions.destinationclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Destination Incentives","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Issuance Fees":{
												CommonFunctions.issuanceclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Issuance Fees","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											case "Commission":{
												CommonFunctions.commissionclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_payableToClient|"+payableToClient.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Commission","Payable","Additional",payableToClient,productName,clientCommercialDataID)); break;
											}
											default:System.out.println("default of Additional payableToClient");
											}
										}else{
											settlement=true;
											settlementString = SettlementCommercials.settlementCommercials("Payable",productName,mdmCommDefn,payableToClient,entityName,entityMarket,entityType,supplier,id,productCategory,productCategorySubType,kafkaMethod);
										}
									}
								}
							}
							//Additional Recievables
							if(additionalJSON.getJSONArray("receivableToCompany").length()>0){
								for(int d=0;d<additionalJSON.getJSONArray("receivableToCompany").length();d++){
									JSONObject receivableToCompany = additionalJSON.getJSONArray("receivableToCompany").getJSONObject(d);
									if(receivableToCompany.has("commercialHead")){
										if(CommonFunctions.isTransactional(receivableToCompany.getString("commercialHead"))){
											switch(receivableToCompany.getString("commercialHead")){
											case "Standard Commercial":{
												CommonFunctions.stdclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Standard Commercial","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Overriding Commission":{
												CommonFunctions.overclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Overriding Commission","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Productivity Linked Bonus":{
												CommonFunctions.plbclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Productivity Linked Bonus","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Segment Fees":{
												CommonFunctions.segmentclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Segment Fees","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Segments Fees":{
												CommonFunctions.segmentclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Segments Fees","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Sector Incentives":{
												CommonFunctions.sectorclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Sector Incentives","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Management Fee":{
												CommonFunctions.mngtclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Management Fee","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Service Charges":{
												CommonFunctions.serviceclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Service Charges","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Discount":{
												CommonFunctions.discountclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Discount","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Destination Incentives":{
												CommonFunctions.destinationclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Destination Incentives","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Issuance Fees":{
												CommonFunctions.issuanceclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Issuance Fees","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											case "Commission":{
												CommonFunctions.commissionclientCommercialDataID=clientCommercialDataID+"|additionalCommercials_receivableToCompany|"+receivableToCompany.getString("_id")+"|"+CommonFunctions.entityType;
												commHead.put(CommonFunctions.getCommercialHeadData("Commission","Receivable","Additional",receivableToCompany,productName,clientCommercialDataID)); break;
											}
											default:System.out.println("defualt of Additional receivableToCompany");
											}
										}else{
											settlement=true;
											settlementString = SettlementCommercials.settlementCommercials("Receivable",productName,mdmCommDefn,receivableToCompany,entityName,entityMarket,entityType,supplier,id,productCategory,productCategorySubType,kafkaMethod);
										}
									}
								}
							}
							//Retention Recievables
							JSONArray receivables = flightsAndNonAir.getJSONObject("supplierCommercialSelection").getJSONArray("receivables");
							if(receivables.length()>0){
								for(int a=0;a<receivables.length();a++){
									switch(receivables.getString(a)){
									case "Standard Commercial":{commHead.put(CommonFunctions.getCommercialHeadData("Standard Commercial","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Overriding Commission":{commHead.put(CommonFunctions.getCommercialHeadData("Overriding Commission","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Productivity Linked Bonus":{commHead.put(CommonFunctions.getCommercialHeadData("Productivity Linked Bonus","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Segment Fees":{commHead.put(CommonFunctions.getCommercialHeadData("Segment Fees","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Segments Fees":{commHead.put(CommonFunctions.getCommercialHeadData("Segments Fees","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Sector Incentives":{commHead.put(CommonFunctions.getCommercialHeadData("Sector Incentives","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Management Fee":{commHead.put(CommonFunctions.getCommercialHeadData("Management Fee","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Service Charges":{commHead.put(CommonFunctions.getCommercialHeadData("Service Charges","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Discount":{commHead.put(CommonFunctions.getCommercialHeadData("Discount","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Destination Incentives":{commHead.put(CommonFunctions.getCommercialHeadData("Destination Incentives","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Issuance Fees":{commHead.put(CommonFunctions.getCommercialHeadData("Issuance Fees","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Commission":{commHead.put(CommonFunctions.getCommercialHeadData("Commission","Receivable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									default:System.out.println("No Retention Receivable Commercials");
									}
								}
							}
							//Retention Payables
							JSONArray payables = flightsAndNonAir.getJSONObject("supplierCommercialSelection").getJSONArray("payables");
							if(payables.length()>0){
								for(int b=0;b<payables.length();b++){
									switch(payables.getString(b)){
									case "Standard Commercial":{commHead.put(CommonFunctions.getCommercialHeadData("Standard Commercial","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Overriding Commission":{commHead.put(CommonFunctions.getCommercialHeadData("Overriding Commission","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Productivity Linked Bonus":{commHead.put(CommonFunctions.getCommercialHeadData("Productivity Linked Bonus","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Segment Fees":{commHead.put(CommonFunctions.getCommercialHeadData("Segment Fees","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Sector Incentives":{commHead.put(CommonFunctions.getCommercialHeadData("Sector Incentives","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Management Fee":{commHead.put(CommonFunctions.getCommercialHeadData("Management Fee","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Service Charges":{commHead.put(CommonFunctions.getCommercialHeadData("Service Charges","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Discount":{commHead.put(CommonFunctions.getCommercialHeadData("Discount","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Destination Incentives":{commHead.put(CommonFunctions.getCommercialHeadData("Destination Incentives","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Issuance Fees":{commHead.put(CommonFunctions.getCommercialHeadData("Issuance Fees","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									case "Commission":{commHead.put(CommonFunctions.getCommercialHeadData("Commission","Payable",flightsAndNonAir,productName,clientCommercialDataID)); break;}
									default:System.out.println("No Retention Payble Commercials");
									}
								}
							}
							//MarkUp
							if(flightsAndNonAir.has("markup") && flightsAndNonAir.getJSONArray("markup").length()>0)
								commHead.put(CommonFunctions.appendCommercialHead("MarkUp", "Receivable", "MarkUp", true));		//advancedDefnApplicable=true :: Receivable ???

							ipJson.put("commercialHead",commHead);
							if(CommonFunctions.priority==1)
								ipJson.put("priority","-1");
							ipJson.put("RuleID", id);
							CommonFunctions.appendProductCategoryAndSubType(ipJson,productName,productCategory,productCategorySubType);
							JSONObject mainJson = new JSONObject();
							mainJson.put("CommercialDefinitionDT",ipJson);

							CommonFunctions.addCommercialDetails(supplier,entityName,entityMarket,entityType,commHead,mdmCommDefn,mainJson,productName,productCategory,productCategorySubType,id,flightsAndNonAir,clientCommercialDataID);
							CommonFunctions.priority=0;
							CommonFunctions.setDefaultAdvDefnID(productName);
							
							System.out.println(productName.toUpperCase()+" Transactional: "+mainJson.toString());
							hitJSONService(mainJson,productName,kafkaMethod);
							if(settlement){
								System.out.println(productName.toUpperCase()+" Settlement: "+settlementString);
								while(SettlementCommercials.main.length()>0)
									SettlementCommercials.main.remove(SettlementCommercials.main.keys().next());
								hitSettlementJSONService(settlementString, productName, kafkaMethod);
							}
						}
					}
				}
			}
		}
	}


	public static void hitJSONService(JSONObject mainJson, String productName, String kafkaMethod) throws Exception {
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = "kieserver";      
		mPassword = "kieserver1!";
		mHttpBasicAuth = HTTP_AUTH_BASIC_PREFIX.concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(kafkaMethod){
		case "POST":{
			URL = "http://10.24.2.81:8080/RuleConfigurator/rest/cce/"+productName+"/client/transactional/create";
			//URL = "http://localhost:8080/RuleConfigurator/rest/cce/"+productName+"/client/transactional/create";
			break;
		}
		case "PUT":{
			URL = "http://10.24.2.81:8080/RuleConfigurator/rest/cce/"+productName+"/client/transactional/update";
			break;
		}
		case "DELETE":{
			URL = "http://10.24.2.81:8080/RuleConfigurator/rest/cce/"+productName+"/client/transactional/delete";
			break;
		}
		default:System.out.println("default of hitJSONservice");
		}
		if(URL!=null){
			URL productURL = new URL(URL);
			System.out.println(consumeJSONService("10.24.2.81:8080",productURL,mHttpHeaders,mainJson.toString()));
		}else System.out.println("Method name is other than POST,PUT or DELETE");
	}


	public static void hitSettlementJSONService(String mainJson, String productName, String kafkaMethod) throws Exception {
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = "kieserver";      
		mPassword = "kieserver1!";
		mHttpBasicAuth = HTTP_AUTH_BASIC_PREFIX.concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(kafkaMethod){
		case "POST":{
			URL = "http://10.24.2.81:8080/RuleConfigurator/rest/cce/"+productName+"/client/settlement/create";
			//URL = "http://localhost:8080/RuleConfigurator/rest/cce/"+productName+"/client/settlement/create";
			break;
		}
		case "PUT":{
			URL = "http://10.24.2.81:8080/RuleConfigurator/rest/cce/"+productName+"/client/settlement/update";
			break;
		}
		case "DELETE":{
			URL = "http://10.24.2.81:8080/RuleConfigurator/rest/cce/"+productName+"/client/settlement/delete";
			break;
		}
		default:System.out.println("default of hitJSONservice");
		}
		if(URL!=null){
			URL productURL = new URL(URL);
			System.out.println(consumeJSONService("10.24.2.81:8080",productURL,mHttpHeaders,mainJson));
		}else System.out.println("Method name is other than POST,PUT or DELETE");
	}


	private static JSONObject consumeJSONService(String tgtSysId, URL tgtSysURL, Map<String, String> httpHdrs, String reqJsonStr) throws Exception {
		HttpURLConnection svcConn = null;
		try {
			svcConn = (HttpURLConnection) tgtSysURL.openConnection();
			InputStream httpResStream = consumeService(tgtSysId, svcConn, httpHdrs, reqJsonStr.getBytes());
			if (httpResStream != null) {
				JSONObject resJson = new JSONObject(new JSONTokener(httpResStream));
				return resJson;
			}
		}
		catch (Exception x) {}
		finally {
			if (svcConn != null) {
				svcConn.disconnect();
			}
		}
		return null;
	}


	private static InputStream consumeService(String tgtSysId, HttpURLConnection svcConn, Map<String, String> httpHdrs, byte[] payload) throws Exception {
		svcConn.setDoOutput(true);
		svcConn.setRequestMethod("POST");
		Set<Entry<String,String>> httpHeaders = httpHdrs.entrySet();
		if(httpHeaders != null && httpHeaders.size() > 0){
			Iterator<Entry<String,String>> httpHeadersIter = httpHeaders.iterator();
			while(httpHeadersIter.hasNext()){
				Entry<String,String> httpHeader = httpHeadersIter.next();
				svcConn.setRequestProperty(httpHeader.getKey(), httpHeader.getValue());
			}
		}
		OutputStream httpOut = svcConn.getOutputStream();
		httpOut.write(payload);
		httpOut.flush();
		httpOut.close();

		int resCode = svcConn.getResponseCode();
		if(resCode == HttpURLConnection.HTTP_OK)
			return svcConn.getInputStream();
		
		return null;
	}
}