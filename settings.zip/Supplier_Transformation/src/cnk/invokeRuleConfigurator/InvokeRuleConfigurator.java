package cnk.invokeRuleConfigurator;

import java.io.InputStream;
import java.util.Map;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONObject;
import org.json.JSONTokener;

public class InvokeRuleConfigurator {

	public static final String PROP_USER_ID = "userID";
	public static final String PROP_PASSWORD = "password";
	public static final String HTTP_AUTH_BASIC_PREFIX = "Basic ";
	private static String mUserID;
	private transient static String mPassword;
	private transient static String mHttpBasicAuth;
	static JSONObject mdmReq;
	static String method = "";
	static String requestUrl = "";

	public static void invokeRuleConfigurator(String request, String productName, String kafkaMethod) throws Exception{
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = "kieserver";      
		mPassword = "kieserver1!";
		mHttpBasicAuth = HTTP_AUTH_BASIC_PREFIX.concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(kafkaMethod){
		case "POST":{
			URL = "http://10.24.2.185:8080/RuleConfigurator/rest/cce/"+productName+"/supplier/transactional/create";
			break;
		}
		case "PUT":{
			URL = "http://10.24.2.185:8080/RuleConfigurator/rest/cce/"+productName+"/supplier/transactional/update";
			break;
		}
		case "DELETE":{
			URL = "http://10.24.2.185:8080/RuleConfigurator/rest/cce/"+productName+"/supplier/transactional/delete";
			break;
		}
		default:System.out.println("default of hitJSONservice");
		}
		if(URL!=null){
			URL productURL = new URL(URL);
			System.out.println(consumeJSONService("10.24.2.185:8080",productURL,mHttpHeaders,request));
		}else System.out.println("Method name is other than POST,PUT or DELETE");
	}
	
	
	public static void invokeSettlementRuleConfigurator(String request, String productName, String kafkaMethod) throws Exception{
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = "kieserver";      
		mPassword = "kieserver1!";
		mHttpBasicAuth = HTTP_AUTH_BASIC_PREFIX.concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(kafkaMethod){
		case "POST":{
			URL = "http://10.24.2.185:8080/RuleConfigurator/rest/cce/"+productName+"/supplier/settlement/create";
			break;
		}
		case "PUT":{
			URL = "http://10.24.2.185:8080/RuleConfigurator/rest/cce/"+productName+"/supplier/settlement/update";
			break;
		}
		case "DELETE":{
			URL = "http://10.24.2.185:8080/RuleConfigurator/rest/cce/"+productName+"/supplier/settlement/delete";
			break;
		}
		default:System.out.println("default of hitJSONservice");
		}
		if(URL!=null){
			URL productURL = new URL(URL);
			System.out.println(consumeJSONService("10.24.2.185:8080",productURL,mHttpHeaders,request));
		}else System.out.println("Method name is other than POST,PUT or DELETE");
	}
	

	private static JSONObject consumeJSONService(String tgtSysId, URL tgtSysURL, Map<String, String> httpHdrs, String reqJsonStr) throws Exception {
		HttpURLConnection svcConn = null;
		try{
			svcConn = (HttpURLConnection) tgtSysURL.openConnection();
			/*if (logger.isTraceEnabled()) {
				logger.trace(String.format("%s JSON Request = %s", tgtSysId, reqJsonStr));
			}*/
			InputStream httpResStream = consumeService(tgtSysId, svcConn, httpHdrs, reqJsonStr.getBytes());
			if(httpResStream != null){
				return new JSONObject(new JSONTokener(httpResStream));
				//JSONObject resJson = new JSONObject(new JSONTokener(httpResStream));
				/*if (logger.isTraceEnabled()) {
					logger.trace(String.format("%s JSON Response = %s", tgtSysId, resJson.toString()));
				}
				return resJson;*/
			}
		}
		catch(Exception x){
			//logger.warn(String.format("%s JSON Service <%s> Consume Error", tgtSysId, tgtSysURL), x);
		}
		finally{
			if(svcConn != null)
				svcConn.disconnect();
		}
		return null;
	}


	private static InputStream consumeService(String tgtSysId, HttpURLConnection svcConn, Map<String, String> httpHdrs, byte[] payload) throws Exception {
		svcConn.setDoOutput(true);
		svcConn.setRequestMethod("POST");

		Set<Entry<String,String>> httpHeaders = httpHdrs.entrySet();
		if (httpHeaders != null && httpHeaders.size() > 0) {
			Iterator<Entry<String,String>> httpHeadersIter = httpHeaders.iterator();
			while (httpHeadersIter.hasNext()) {
				Entry<String,String> httpHeader = httpHeadersIter.next();
				svcConn.setRequestProperty(httpHeader.getKey(), httpHeader.getValue());
			}
		}
		//logger.trace(String.format("Sending request to %s",tgtSysId));
		OutputStream httpOut = svcConn.getOutputStream();
		httpOut.write(payload);
		httpOut.flush();
		httpOut.close();

		int resCode = svcConn.getResponseCode();
		//logger.debug(String.format("Receiving response from %s with HTTP response status: %s", tgtSysId, resCode));
		if (resCode == HttpURLConnection.HTTP_OK) {
			return svcConn.getInputStream();
		}
		return null;
	}
}
