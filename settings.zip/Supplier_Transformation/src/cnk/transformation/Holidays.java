package cnk.transformation;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.kafkaConsumer.ReceiveMDMRequest;
import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;

public class Holidays {
	public static String overCT,plbCT,destCT,segCT,serCT,issCT,mngtCT,commDefnRuleID;
	public static boolean overSet,plbSet,destSet,segSet,serSet,issSet,mngtSet;

	public static String setCommercials(JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		JSONObject mainJson = new JSONObject();
		JSONArray baseArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		if(mdmDefn.has("SupplierCommercialData") && mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
			String supplierCommercialDataID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
			JSONObject standardCommercial = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
			JSONObject commDefn = CommonFunctions.getStandardCommercialDefiniton(mdmDefn,productCategory,productCategorySubType,supplier,supplierMarkets,"Standard");
			commDefn.put("productCategory", productCategory);
			commDefn.put("productCategorySubType", productCategorySubType);
			mainJson.put("CommercialDefinitionDT", commDefn);

			JSONObject base = new JSONObject();
			JSONObject calculation = new JSONObject();
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", standardCommercial.getString("contractValidityFrom").substring(0, 19));
			contractValidity.put("to", standardCommercial.getString("contractValidityTo").substring(0, 19));
			base.put("contractValidity", contractValidity);
			base.put("RuleID", "BASE"+supplierCommercialDataID);
			base.put("type", "base");
			calculation.put("type", "calculation");
			commDefnRuleID= CommonFunctions.commDefnID;
			base.put("selectedRow", commDefnRuleID);
			calculation.put("RuleID", "CALCULATION"+supplierCommercialDataID);
			calculation.put("selectedRow", "BASE"+supplierCommercialDataID);
			baseArr.put(base);
			calcArr.put(calculation);
			mainJson.put("StandardCommercialBaseDT", baseArr);
			mainJson.put("StandardCommercialCalculationDT", calcArr);

			JSONObject holidays = standardCommercial.getJSONObject("product").getJSONObject("holidays");
			if(holidays.getJSONArray("supplierRate").length()>0)
				CommonFunctions.getSupplierRate(holidays.getJSONArray("supplierRate"),calcArr);

			if(holidays.getJSONArray("products").length()>0){
				JSONArray products = holidays.getJSONArray("products");
				getHolidaysProductDetails(products,baseArr,calcArr);
			}

			if(standardCommercial.getJSONArray("clients").length()>0)
				CommonFunctions.getClientDetails(baseArr,calcArr,standardCommercial.getJSONArray("clients"));

			if(standardCommercial.has("advanceDefinationId")){
				String advDefnID = standardCommercial.getString("advanceDefinationId");
				for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
					if(advanceDefinationData.getString("_id").equals(advDefnID)){
						JSONObject advanceDefinitionHolidays = advanceDefinationData.getJSONObject("advanceDefinitionHolidays");
						setHolidaysAdvancedDefinition(advanceDefinitionHolidays,baseArr,calcArr);
					}
				}
			}
			
			String stdmdmRuleID = supplierCommercialDataID+"|standardCommercial|null|";
			String fixed = stdmdmRuleID+="fixed";

			int length = baseArr.length();
			for(int i=0;i<length;i++){
				if(standardCommercial.getBoolean("isFixed")){
					calcArr.getJSONObject(i).put("mdmRuleID", fixed);
					CommonFunctions.getFixedDetails(calcArr.getJSONObject(i),standardCommercial.getJSONObject("fixed"));
				}else CommonFunctions.getSlabDetails(baseArr,calcArr,standardCommercial.getJSONArray("slab"),stdmdmRuleID);
			}

			JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
			setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,supplierCommercialDataID);
		}

		System.out.println("Holidays Transactional: "+mainJson.toString());
		return mainJson.toString();
	}


	public static void setHolidaysAdvancedDefinition(JSONObject advanceDefinitionHolidays, JSONArray baseArr, JSONArray calcArr) {
		if(advanceDefinitionHolidays.has("validity")){
			JSONObject validity = advanceDefinitionHolidays.getJSONObject("validity");
			switch(validity.getString("saleOrTravel")){
			case "sales":{
				JSONObject sales = validity.getJSONArray("sales").getJSONObject(0);
				if(sales.has("triggerOrPayout") && sales.getJSONArray("triggerOrPayout").length()>0)
					CommonFunctions.getPLBDates(baseArr, calcArr, validity.getJSONArray("sales"), "sale", false);
				else CommonFunctions.setDate(baseArr, calcArr, validity.getJSONArray("sales"), "sale", false);
				break;
			}
			case "travel":{
				JSONObject travel = validity.getJSONArray("travel").getJSONObject(0);
				if(travel.has("triggerOrPayout") && travel.getJSONArray("triggerOrPayout").length()>0)
					CommonFunctions.getPLBDates(baseArr, calcArr, validity.getJSONArray("travel"), "travel", false);
				else CommonFunctions.setDate(baseArr, calcArr, validity.getJSONArray("travel"), "travel", false);
				break;
			}
			default:System.out.println("default of Holidays.setHolidaysAdvancedDefinition");
			}
		}

		if(advanceDefinitionHolidays.has("travelDestinations") && advanceDefinitionHolidays.getJSONArray("travelDestinations").length()>0){
			JSONObject travelDestinations = advanceDefinitionHolidays.getJSONArray("travelDestinations").getJSONObject(0);
			if(travelDestinations.has("triggerOrPayout") && travelDestinations.getJSONArray("triggerOrPayout").length()>0)
				setPLBHolidaysDestinations(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray("travelDestinations"));
			else setHolidaysDestinations(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray("travelDestinations"));
		}
		
		if(advanceDefinitionHolidays.has("credentials") && advanceDefinitionHolidays.getJSONArray("credentials").length()>0){
			JSONObject credentials = advanceDefinitionHolidays.getJSONArray("credentials").getJSONObject(0);
			if(credentials.has("triggerOrPayout") && credentials.getJSONArray("triggerOrPayout").length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("credentials"), "credentials", true, true);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("credentials"), "credentials", true, true);
		}
		
		if(advanceDefinitionHolidays.has("nationality") && advanceDefinitionHolidays.getJSONArray("nationality").length()>0){
			JSONObject nationality = advanceDefinitionHolidays.getJSONArray("nationality").getJSONObject(0);
			if(nationality.has("triggerOrPayout") && nationality.getJSONArray("triggerOrPayout").length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("nationality"), "clientNationality", true, true);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("nationality"), "clientNationality", true, true);
		}
		
		if(advanceDefinitionHolidays.has("tourTypes") && advanceDefinitionHolidays.getJSONArray("tourTypes").length()>0){
			JSONObject tourTypes = advanceDefinitionHolidays.getJSONArray("tourTypes").getJSONObject(0);
			if(tourTypes.has("triggerOrPayout") && tourTypes.getJSONArray("triggerOrPayout").length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("tourTypes"), "tourTypes", true, false);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("tourTypes"), "tourTypes", true, false);
		}
		
		if(advanceDefinitionHolidays.has("connectivity")){
			JSONObject connectivity = advanceDefinitionHolidays.getJSONObject("connectivity");
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				if(connectivity.has("triggerOrPayout") && connectivity.getJSONArray("triggerOrPayout").length()>0){
					CommonFunctions.getConnectivityTP(baseArr, connectivity);
					break;
				}
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					base.put("connectivitySupplierType",connectivity.getString("supplierType"));
				if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
					base.put("connectivitySupplierName",connectivity.getString("supplierId"));
			}
		}
		
		if(advanceDefinitionHolidays.has("roomLevel")){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
			if(roomLevel.has("bookingType")){
				JSONObject bookingType = roomLevel.getJSONObject("bookingType");
				if(bookingType.has("triggerOrPayout") && bookingType.getJSONArray("triggerOrPayout").length()>0){
					CommonFunctions.getBookingTypeTP(calcArr, bookingType, true);
				}else{
					int length=calcArr.length();
					for(int i=0;i<length;i++){
						JSONObject calculation = calcArr.getJSONObject(i);
						calculation.put("bookingType", bookingType.getString("bookingType"));
					}
				}
			}	
		}
		
		if(advanceDefinitionHolidays.has("applicableOn") && advanceDefinitionHolidays.getJSONArray("applicableOn").length()>0){
			setHolidaysApplicableOn(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray("applicableOn"),advanceDefinitionHolidays);
		}else{
			if(advanceDefinitionHolidays.has("passengerType") && advanceDefinitionHolidays.getJSONArray("passengerType").length()>0){
				JSONObject passengerType = advanceDefinitionHolidays.getJSONArray("passengerType").getJSONObject(0);
				if(passengerType.has("triggerOrPayout") && passengerType.getJSONArray("triggerOrPayout").length()>0)
					CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType", true, false);
				else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType", true, false);
			}
			
			if(advanceDefinitionHolidays.has("roomLevel")){
				JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
				if(roomLevel.has("roomCategories") && roomLevel.getJSONArray("roomCategories").length()>0){
					JSONObject roomCategories = roomLevel.getJSONArray("roomCategories").getJSONObject(0);
					if(roomCategories.has("triggerOrPayout") && roomCategories.getJSONArray("triggerOrPayout").length()>0)
						CommonFunctions.getArray(baseArr, calcArr, roomLevel.getJSONArray("roomCategories"), "roomCategories", true, false);
					else CommonFunctions.getArrayNonTP(baseArr, calcArr,roomLevel.getJSONArray("roomCategories"),"roomCategories",true,false);
				}
				
				if(roomLevel.has("roomTypes") && roomLevel.getJSONArray("roomTypes").length()>0){
					JSONObject roomTypes = roomLevel.getJSONArray("roomTypes").getJSONObject(0);
					if(roomTypes.has("triggerOrPayout") && roomTypes.getJSONArray("triggerOrPayout").length()>0)
						CommonFunctions.getArray(baseArr, calcArr, roomLevel.getJSONArray("roomTypes"), "roomTypes", true, false);
					else CommonFunctions.getArrayNonTP(baseArr, calcArr,roomLevel.getJSONArray("roomTypes"),"roomTypes",true,false);
				}
			}
			
			for(int i=0;i<calcArr.length();i++){
				JSONObject calculation = calcArr.getJSONObject(i);
				calculation.put("postProcessingBoolean", true);	//only for holidays
			}
		}
	}
	
	
	private static void setPLBHolidaysDestinations(JSONArray baseArr, JSONArray calcArr, JSONArray travelDestinationsArr) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(travelDestinations.getJSONArray("triggerOrPayout"));
				JSONArray destinatn = new JSONArray();
				JSONObject desti = new JSONObject();
				destinatn.put(triggerPayout);
				
				if(travelDestinations.has("destination") && !travelDestinations.getString("destination").equalsIgnoreCase("All"))
					desti.put("toContinent", travelDestinations.getString("destination"));
				if(travelDestinations.has("country") && !travelDestinations.getString("country").equalsIgnoreCase("All"))
					desti.put("toCountry", travelDestinations.getString("country"));
				if(travelDestinations.has("city") && !travelDestinations.getString("city").equalsIgnoreCase("All"))
					desti.put("toCity", travelDestinations.getString("city"));
				if(travelDestinations.has("state") && !travelDestinations.getString("state").equalsIgnoreCase("All"))
					desti.put("toState", travelDestinations.getString("state"));

				destinatn.put(desti);
				calculation.put("travelDestinations", destinatn);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, travelDestinations.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
		
	}


	private static void setHolidaysApplicableOn(JSONArray baseArr, JSONArray calcArr, JSONArray applicableOnArr, JSONObject advanceDefinitionHolidays) {
		if(advanceDefinitionHolidays.has("passengerType") && advanceDefinitionHolidays.getJSONArray("passengerType").length()>0){
			JSONObject passengerType = advanceDefinitionHolidays.getJSONArray("passengerType").getJSONObject(0);
			if(passengerType.has("triggerOrPayout") && passengerType.getJSONArray("triggerOrPayout").length()>0)
				getArrayApplicableOn(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType");
			else getArrayNonTPApplicableOn(calcArr, advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType");
		}
		
		if(advanceDefinitionHolidays.has("roomLevel")){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
			if(roomLevel.has("roomCategories") && roomLevel.getJSONArray("roomCategories").length()>0){
				JSONObject roomCategories = roomLevel.getJSONArray("roomCategories").getJSONObject(0);
				if(roomCategories.has("triggerOrPayout") && roomCategories.getJSONArray("triggerOrPayout").length()>0)
					getArrayApplicableOn(baseArr, calcArr, roomLevel.getJSONArray("roomCategories"), "roomCategories");
				else getArrayNonTPApplicableOn(calcArr,roomLevel.getJSONArray("roomCategories"),"roomCategories");
			}
			
			if(roomLevel.has("roomTypes") && roomLevel.getJSONArray("roomTypes").length()>0){
				JSONObject roomTypes = roomLevel.getJSONArray("roomTypes").getJSONObject(0);
				if(roomTypes.has("triggerOrPayout") && roomTypes.getJSONArray("triggerOrPayout").length()>0)
					getArrayApplicableOn(baseArr, calcArr, roomLevel.getJSONArray("roomTypes"), "roomTypes");
				else getArrayNonTPApplicableOn(calcArr,roomLevel.getJSONArray("roomTypes"),"roomTypes");
			}
		}
		
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<applicableOnArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				calculation.put("productName_applicableOn", applicableOnArr.getString(j));
				calculation.put("applicableOnBoolean", true);
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, applicableOnArr.getString(j));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void getArrayApplicableOn(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name) {
		int length=calcArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<jsonArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject jsonObject = jsonArray.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(jsonObject.getJSONArray("triggerOrPayout"));
				JSONArray array = new JSONArray();
				array.put(triggerPayout);
				JSONObject object = new JSONObject();
				object.put(name+"_applicableOn", jsonObject.getString(name));
				array.put(object);
				calculation.put(name, array);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, jsonObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void getArrayNonTPApplicableOn(JSONArray calcArr, JSONArray jsonArray, String name) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			calculation.put(name+"_applicableOn", array);
		}
	}


	public static void setAdvancedCommercials(JSONObject mdmDefn, JSONArray commercialHead, JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject standardCommercial, String supplier, JSONArray supplierMarkets,String productCategory, String productCategorySubType, String productName, String supplierCommercialDataID) throws Exception {
		Boolean settlement=false;
		JSONObject settlementObject = new JSONObject();
		String advanceCommercialDataID = supplierCommercialDataID+"|advanceCommercialData|";
		String tempAdvCommID = advanceCommercialDataID;
		for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length();i++){
			JSONObject advanceCommercialData = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i);
			JSONObject advanceCommercial = advanceCommercialData.getJSONObject("advanceCommercial");
			advanceCommercialDataID+=advanceCommercialData.getString("_id");
			String displayName = advanceCommercial.getJSONObject("commercialHeadInfo").getString("displayName");
			switch(displayName){
			case "Overriding Commission":{
				JSONObject overRidingCommission = advanceCommercial.getJSONObject("overRidingCommission");
				setContractType("Overriding Commission",overRidingCommission);
				setAdvancedCommercial(mainJson,"OverridingCommercialBaseDT","OverridingCommercialCalculationDT","Overriding",overRidingCommission,mdmDefn,commercialHead,overCT,overSet,advanceCommercialDataID);
				break;
			}
			case "Productivity Linked Bonus":{
				JSONObject plb = advanceCommercial.getJSONObject("plb");
				setContractType("Productivity Linked Bonus",plb);
				setAdvancedCommercial(mainJson,"PLBCommercialBaseDT","PLBCommercialCalculationDT","PLB",plb,mdmDefn,commercialHead,plbCT,plbSet,advanceCommercialDataID);
				break;
			}
			case "Destination Incentives":{
				JSONObject destinationIncentives = advanceCommercial.getJSONObject("destinationIncentives");
				setContractType("Destination Incentives",destinationIncentives);
				setAdvancedCommercial(mainJson,"DestinationIncentivesCommercialBaseDT","DestinationIncentiveCommercialCalculationDT","DestinationIncentives",destinationIncentives,mdmDefn,commercialHead,destCT,destSet,advanceCommercialDataID);
				break;
			}
			case "Segment Fees":{
				JSONObject segmentFees = advanceCommercial.getJSONObject("segmentFees");
				setContractType("Segment Fees",segmentFees);
				setAdvancedCommercial(mainJson,"SegmentFeesCommercialBaseDT","SegmentFeesCommercialCalculationDT","SegmentFees",segmentFees,mdmDefn,commercialHead,segCT,segSet,advanceCommercialDataID);
				break;
			}
			case "Service Charges":{
				JSONObject serviceCharge = advanceCommercial.getJSONObject("serviceCharge");
				setContractType("Service Charges",serviceCharge);
				setAdvancedCommercial(mainJson,"ServiceChargeCommercialBaseDT","ServiceChargeCommercialCalculationDT","ServiceCharges",serviceCharge,mdmDefn,commercialHead,serCT,serSet,advanceCommercialDataID);
				break;
			}
			case "Issuance Fees":{
				JSONObject issuanceFees = advanceCommercial.getJSONObject("issuanceFees");
				setContractType("Issuance Fees",issuanceFees);
				setAdvancedCommercial(mainJson,"IssuanceFeesCommercialBaseDT","IssuanceFeesCommercialCalculationDT","IssuanceFees",issuanceFees,mdmDefn,commercialHead,issCT,issSet,advanceCommercialDataID);
				break;
			}
			case "Management Fee":{
				JSONObject managementFee = advanceCommercial.getJSONObject("managementFee");
				setContractType("Management Fee",managementFee);
				setAdvancedCommercial(mainJson,"ManagementFeesBaseDT","ManagementFeesCalculationDT","ManagementFee",managementFee,mdmDefn,commercialHead,mngtCT,mngtSet,advanceCommercialDataID);
				break;
			}
			default:{
				settlement=true;
				String commercialName = CommonFunctions.getCommercialName(displayName);
				String commDefnID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
				String contractType = null;
				if(standardCommercial.getJSONObject("commercialInformation").has("isProvisional")){
					if(standardCommercial.getJSONObject("commercialInformation").getBoolean("isProvisional"))
						contractType="Provisional";
					else contractType="Final";
				}
				settlementObject = SettlementCommercials.settlementCommercials(commercialName,mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i),supplier,supplierMarkets,productCategory,productCategorySubType,productName,contractType,commDefnID,mdmDefn.getJSONArray("advanceDefinationData"));
			}
			}
			advanceCommercialDataID = tempAdvCommID;
		}
		if(settlement){
			System.out.println("Holidays Settlement: "+settlementObject.toString());
			InvokeRuleConfigurator.invokeSettlementRuleConfigurator(settlementObject.toString(),productName,ReceiveMDMRequest.method);
			SettlementCommercials.main=null;
		}

	}


	private static void setContractType(String displayName, JSONObject jsonObject) {
		String contractType="Final";boolean settlementTransactionWise=false;
		if(jsonObject.getJSONObject("commercialInformation").has("isProvisional")){
			if(jsonObject.getJSONObject("commercialInformation").getBoolean("isProvisional"))
				contractType="Provisional";
			else contractType="Final";
		}
		if(jsonObject.has("isSettlementTransactionWise"))
			settlementTransactionWise= jsonObject.getBoolean("isSettlementTransactionWise");
		
		switch(displayName){
		case "Overriding Commission":{overCT=contractType;overSet=settlementTransactionWise;break;}
		case "Productivity Linked Bonus":{plbCT=contractType;plbSet=settlementTransactionWise;break;}
		case "Destination Incentives":{destCT=contractType;destSet=settlementTransactionWise;break;}
		case "Segment Fees":{segCT=contractType;segSet=settlementTransactionWise;break;}
		case "Service Charges":{serCT=contractType;serSet=settlementTransactionWise;break;}
		case "Issuance Fees":{issCT=contractType;issSet=settlementTransactionWise;break;}
		case "Management Fee":{mngtCT=contractType;mngtSet=settlementTransactionWise;break;}
		default:System.out.println("default of Holidays.setContractType");
		}
	}


	public static void setHolidaysDestinations(JSONArray baseArr, JSONArray calcArr, JSONArray travelDestinationsArr) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				if(travelDestinations.has("destination") && !travelDestinations.getString("destination").equalsIgnoreCase("All"))
					calculation.put("toContinent", travelDestinations.getString("destination"));
				if(travelDestinations.has("country") && !travelDestinations.getString("country").equalsIgnoreCase("All"))
					calculation.put("toCountry", travelDestinations.getString("country"));
				if(travelDestinations.has("city") && !travelDestinations.getString("city").equalsIgnoreCase("All"))
					calculation.put("toCity", travelDestinations.getString("city"));
				if(travelDestinations.has("state") && !travelDestinations.getString("state").equalsIgnoreCase("All"))
					calculation.put("toState", travelDestinations.getString("state"));

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, travelDestinations.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setAdvancedCommercial(JSONObject mainJson, String baseDT, String calculationDT, String commercialName, JSONObject advanceCommercialNameObject, JSONObject mdmDefn, JSONArray commercialHead, String contractType, boolean settlementTransactionWise, String advanceCommercialDataID) {
		String netOffCommercialHead=null;
		String commercialType = advanceCommercialNameObject.getJSONObject("commercialInformation").getString("commercialType");
		if(advanceCommercialNameObject.has("calculation")){
			if(advanceCommercialNameObject.getJSONObject("calculation").has("netOffCommercialHead"))
				netOffCommercialHead = CommonFunctions.getCommercialName(advanceCommercialNameObject.getJSONObject("calculation").getString("netOffCommercialHead"));
		}
		CommonFunctions.setCommercialHead(commercialName,commercialHead,netOffCommercialHead,commercialType,contractType,settlementTransactionWise);

		JSONArray baseArr =new JSONArray();
		JSONArray calcArr =new JSONArray();
		JSONObject base = new JSONObject();
		JSONObject calculation = new JSONObject();
		base.put("RuleID", "BASE");
		base.put("selectedRow", commDefnRuleID);
		calculation.put("RuleID", "CALCULATION");
		calculation.put("selectedRow", "BASE");
		base.put("type", "base");
		calculation.put("type", "calculation");
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", advanceCommercialNameObject.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", advanceCommercialNameObject.getString("contractValidityTo").substring(0, 19));
		base.put("contractValidity", contractValidity);
		baseArr.put(base);
		calcArr.put(calculation);
		mainJson.put(baseDT, baseArr);
		mainJson.put(calculationDT, calcArr);
		
		if(advanceCommercialNameObject.getJSONArray("supplierRate").length()>0)
			CommonFunctions.getSupplierRate(advanceCommercialNameObject.getJSONArray("supplierRate"),calcArr);
		
		if(advanceCommercialNameObject.getJSONArray("client").length()>0)
			CommonFunctions.getClientDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("client"));
		
		boolean slab=false;
		if((advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.getString("calculationType").equals("slab")) || (!advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.has("slab"))){
			slab=true;
			advanceCommercialDataID+="|";
			CommonFunctions.getSlabDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("slab"),advanceCommercialDataID);
		}
		
		if(!slab){
			int length=calcArr.length();
			advanceCommercialDataID+="|fixed";
			for(int i=0;i<length;i++){
				calcArr.getJSONObject(i).put("mdmRuleID", advanceCommercialDataID);
				CommonFunctions.getFixedDetails(calcArr.getJSONObject(i), advanceCommercialNameObject.getJSONObject("fixed"));
			}
		}
		
		if(advanceCommercialNameObject.has("advanceDefinationId")){
			String advDefnID = advanceCommercialNameObject.getString("advanceDefinationId");
			for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
				JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
				if(advanceDefinationData.getString("_id").equals(advDefnID)){
					JSONObject advanceDefinitionHolidays = advanceDefinationData.getJSONObject("advanceDefinitionHolidays");
					setHolidaysAdvancedDefinition(advanceDefinitionHolidays, baseArr, calcArr);
				}
			}
		}
	}


	public static void getHolidaysProductDetails(JSONArray products, JSONArray baseArr, JSONArray calcArr) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<products.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject productObject = products.getJSONObject(j);
				if(productObject.has("productName") && !productObject.getString("productName").equalsIgnoreCase("All"))
					calculation.put("productName", productObject.getString("productName"));
				if(productObject.has("productFlavourName") && !productObject.getString("productFlavourName").equalsIgnoreCase("All"))
					calculation.put("productFlavourName", productObject.getString("productFlavourName"));
				if(productObject.has("productType") && !productObject.getString("productType").equalsIgnoreCase("All"))
					calculation.put("productType", productObject.getString("productType"));
				if(productObject.has("flavourType") && !productObject.getString("flavourType").equalsIgnoreCase("All"))
					calculation.put("flavourType", productObject.getString("flavourType"));
				if(productObject.has("brandName") && !productObject.getString("brandName").equalsIgnoreCase("All"))
					calculation.put("brandName", productObject.getString("brandName"));

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, productObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void setOtherFeesHolidaysAdvancedDefinition(JSONObject advanceDefinitionHolidays, JSONArray otherFeeArr){
		if(advanceDefinitionHolidays.has("validity")){
			JSONObject validity = advanceDefinitionHolidays.getJSONObject("validity");
			switch(validity.getString("saleOrTravel")){
			case "sales":{
				CommonFunctions.setOtherFeesDate(otherFeeArr,validity.getJSONArray("sales"),"sale");
				break;
			}
			case "travel":{
				CommonFunctions.setOtherFeesDate(otherFeeArr,validity.getJSONArray("travel"),"travel");
				break;
			}
			default:System.out.println("default of Holidays.setHolidaysAdvancedDefinition");
			}
		}

		if(advanceDefinitionHolidays.has("travelDestinations") && advanceDefinitionHolidays.getJSONArray("travelDestinations").length()>0)
			setOtherFeeHolidaysDestinations(otherFeeArr,advanceDefinitionHolidays.getJSONArray("travelDestinations"));

		if(advanceDefinitionHolidays.has("credentials") && advanceDefinitionHolidays.getJSONArray("credentials").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionHolidays.getJSONArray("credentials"), "credentials");

		if(advanceDefinitionHolidays.has("nationality") && advanceDefinitionHolidays.getJSONArray("nationality").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray("nationality"), "clientNationality");

		if(advanceDefinitionHolidays.has("tourTypes") && advanceDefinitionHolidays.getJSONArray("tourTypes").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray("tourTypes"), "tourTypes");

		if(advanceDefinitionHolidays.has("connectivity")){
			JSONObject connectivity = advanceDefinitionHolidays.getJSONObject("connectivity");
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierType",connectivity.getString("supplierType"));
				if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierName",connectivity.getString("supplierId"));
			}
		}

		if(advanceDefinitionHolidays.has("roomLevel")){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
			if(roomLevel.has("bookingType")){
				JSONObject bookingType = roomLevel.getJSONObject("bookingType");
				int length=otherFeeArr.length();
				for(int i=0;i<length;i++){
					JSONObject otherFee = otherFeeArr.getJSONObject(i);
					otherFee.put("bookingType", bookingType.getString("bookingType"));
				}
			}	
		}

		if(advanceDefinitionHolidays.has("passengerType") && advanceDefinitionHolidays.getJSONArray("passengerType").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray("passengerType"), "passengerType");

		if(advanceDefinitionHolidays.has("roomLevel")){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject("roomLevel");
			if(roomLevel.has("roomCategories") && roomLevel.getJSONArray("roomCategories").length()>0)
				CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,roomLevel.getJSONArray("roomCategories"),"roomCategories");
			if(roomLevel.has("roomTypes") && roomLevel.getJSONArray("roomTypes").length()>0)
				CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,roomLevel.getJSONArray("roomTypes"),"roomTypes");
		}
	}
	
	
	public static void setOtherFeeHolidaysDestinations(JSONArray otherFeeArr, JSONArray travelDestinationsArr) {
		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				if(travelDestinations.has("destination") && !travelDestinations.getString("destination").equalsIgnoreCase("All"))
					otherFee.put("toContinent", travelDestinations.getString("destination"));
				if(travelDestinations.has("country") && !travelDestinations.getString("country").equalsIgnoreCase("All"))
					otherFee.put("toCountry", travelDestinations.getString("country"));
				if(travelDestinations.has("city") && !travelDestinations.getString("city").equalsIgnoreCase("All"))
					otherFee.put("toCity", travelDestinations.getString("city"));
				if(travelDestinations.has("state") && !travelDestinations.getString("state").equalsIgnoreCase("All"))
					otherFee.put("toState", travelDestinations.getString("state"));

				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, travelDestinations.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
}
