package cnk.transformation;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class SettlementCommercials {
	public static JSONObject main = new JSONObject();

	public static JSONObject settlementCommercials(String commercialName, JSONObject jsonObject, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName, String contractType, String commDefnID, JSONArray advanceDefinationData){
		JSONObject mainJson = new JSONObject();
		if(main.length()!=0 && !main.toString().equals("{}") && main.has("CommercialDefinitionDT")){
			//indicates that values already inserted once in it
			mainJson=new JSONObject(new JSONTokener(main.toString()));
			JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
			JSONObject comm = new JSONObject();
			comm.put("commercialHeadName", commercialName);
			comm.put("contractType", contractType);
			comm.put("isApplicable", true);
			//plbApplicable Only for FOC
			commercialHead.put(comm);
		}else{
			JSONObject commJson = new JSONObject();
			commJson.put("RuleID", commDefnID);
			commJson.put("type", "definition");
			commJson.put("supplier", supplier);
			commJson.put("supplierMarket", supplierMarkets);
			appendProductCategoryAndSubType(commJson,productName,productCategory,productCategorySubType);
			JSONObject comm = new JSONObject();
			comm.put("commercialHeadName", commercialName);
			comm.put("contractType", contractType);
			comm.put("isApplicable", true);
			//plbApplicable Only for FOC
			JSONArray commercialHeadArr = new JSONArray();
			commercialHeadArr.put(comm);
			commJson.put("commercialHead", commercialHeadArr);
			mainJson.put("CommercialDefinitionDT", commJson);
		}

		JSONArray commercialHeadArr = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
		switch(commercialName){
		case "MaintenanceFees":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"MaintenanceFees");
			mainJson.put("MaintenanceFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("MaintenanceFeeDT: "+mainJson);
			break;
		}
		case "IntegrationFees":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"IntegrationFees");
			mainJson.put("IntegrationFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("IntegrationFeeDT: "+mainJson);
			break;
		}
		case "LicenceFees":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"LicenceFees");
			mainJson.put("LicenceFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("LicenceFeeDT: "+mainJson);
			break;
		}
		case "WebServiceFees":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"WebServiceFees");
			mainJson.put("WebServiceFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("WebServiceFeeDT: "+mainJson);
			break;
		}
		case "LoyaltyBonus":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"LoyaltyBonus");
			mainJson.put("LoyaltyBonusDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("LoyaltyBonusDT: "+mainJson);
			break;
		}
		case "TrainingFees":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"TrainingFees");
			mainJson.put("TrainingFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("TrainingFeeDT: "+mainJson);
			break;
		}
		case "PreferenceBenefit":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"PreferenceBenefit");
			mainJson.put("PreferenceBenefitDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("PreferenceBenefitDT: "+mainJson);
			break;
		}
		case "RetainerFee":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"RetainerFee");
			mainJson.put("RetainerFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("RetainerFeeDT: "+mainJson);
			break;
		}
		case "ListingFee":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"ListingFee");
			mainJson.put("ListingFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("ListingFeeDT: "+mainJson);
			break;
		}
		case "ContentAccessFee":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"ContentAccessFee");
			mainJson.put("ContentAccessFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("ContentAccessFeeDT: "+mainJson);
			break;
		}
		case "SignUpFees":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"SignUpFees");
			mainJson.put("SignUpFeeDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("SignUpFeeDT: "+mainJson);
			break;
		}
		case "SignUpBonus":{
			JSONObject signUpBonusObj = jsonObject.getJSONObject("advanceCommercial").getJSONObject("signupBonus");
			setCommercialType(commercialHeadArr,signUpBonusObj,"SignUpBonus");
			mainJson.put("SignUpBonusDT", getSignUpBonus(signUpBonusObj,commDefnID, productCategory));
			System.out.println("SignUpBonusDT: "+mainJson);
			break;
		}
		case "LookToBook":{
			JSONObject ltb = jsonObject.getJSONObject("advanceCommercial").getJSONObject("lookToBook");
			setCommercialType(commercialHeadArr,ltb,"LookToBook");
			setLookToBook(ltb,mainJson,jsonObject,commDefnID);
			break;	
		}
		case "MSFFees":{
			JSONObject msfMDM = jsonObject.getJSONObject("advanceCommercial").getJSONObject("MSfFees");
			setCommercialType(commercialHeadArr,msfMDM,"MSFFees");
			mainJson.put("MSFFeeDT", getMSFFee(msfMDM,jsonObject,commDefnID));
			System.out.println("MSFFeeDT: "+mainJson);
			break;
		}
		case "IncentivesOnTopUp":{
			JSONObject incentivesOnTopUpMDM = jsonObject.getJSONObject("advanceCommercial").getJSONObject("incentiveOnTopup");
			setCommercialType(commercialHeadArr,incentivesOnTopUpMDM,"IncentivesOnTopUp");
			mainJson.put("IncentivesOnTopUpDT", getIncentiveOnTopUp(incentivesOnTopUpMDM,commDefnID));
			System.out.println("IncentivesOnTopUpDT :"+mainJson);
			break;
		}
		case "TerminationFees":{
			JSONObject terminationFeeMDM = jsonObject.getJSONObject("advanceCommercial").getJSONObject("terminationFees");
			setCommercialType(commercialHeadArr,terminationFeeMDM,"TerminationFees");
			mainJson.put("TerminationFeeDT",getTerminationFee(terminationFeeMDM,jsonObject,commDefnID));
			System.out.println("TerminationFeeDT: "+mainJson);
			break;
		}
		case "PenaltyFee":{
			JSONObject penaltyFeeMDM = jsonObject.getJSONObject("advanceCommercial").getJSONObject("penaltyFeeOrKickBack");
			setCommercialType(commercialHeadArr,penaltyFeeMDM,"PenaltyFee");
			mainJson.put("PenaltyFeeDT", getPenaltyFee(penaltyFeeMDM, commDefnID));
			System.out.println("PenaltyFeeDT : "+mainJson);
			break;
		}
		case "FOC":{
			switch(productName){
			case "accomodation":
				mainJson = setFOC(mainJson, jsonObject, commercialHeadArr, "freeOfCostAccommodation", "products");
				break;
			case "activities":
				mainJson = setFOC(mainJson, jsonObject, commercialHeadArr, "freeOfCostActivities","productInformation");
				break;
			case "air":
				mainJson = setFOC(mainJson, jsonObject, commercialHeadArr, "freeOfCostFlights", "product");
				break;
			case "holidays":
				mainJson = setFOC(mainJson, jsonObject, commercialHeadArr, "freeOfCostHolidays","productInformation");
				break;
			}
			//System.out.println("FreeOfCostsDT" + mainJson);
			break;
		}
		case "LostTicket":{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees"),"LostTicket");
			mainJson.put("LostTicketDT", otherFees(jsonObject,commDefnID,productName,advanceDefinationData));
			System.out.println("LostTicketDT: "+mainJson);
			break;
		}
		case "RemittanceFees":{
			JSONObject remmitanceMDM = jsonObject.getJSONObject("advanceCommercial").getJSONObject("remittanceFees");
			setCommercialType(commercialHeadArr,remmitanceMDM,"RemittanceFees");
			getRemittanceFee(remmitanceMDM,mainJson,jsonObject,commDefnID);
			System.out.println("RemittanceFeeDT: "+mainJson);
			break;
		}
		}
		main=new JSONObject(new JSONTokener(mainJson.toString()));
		return main;
	}


	public static void setCommercialType(JSONArray commercialHeadArr, JSONObject jsonObject, String commercialName) {
		for(int k=0;k<commercialHeadArr.length();k++){
			JSONObject commercialHeadObj = commercialHeadArr.getJSONObject(k);
			if(commercialHeadObj.getString("commercialHeadName").equals(commercialName)){
				commercialHeadObj.put("commercialType", jsonObject.getJSONObject("commercialInformation").getString("commercialType"));
			}
		}
	}


	public static void getRemittanceFee(JSONObject remmitanceMDM, JSONObject mainJson, JSONObject jsonObject, String commDefnID) {
		JSONArray remittanceFeeArr = new JSONArray();
		if(remmitanceMDM.getBoolean("isFixed")){
			JSONObject remittanceFee = new JSONObject();
			remittanceFee.put("selectedRow", commDefnID);
			remittanceFee.put("type", "remittanceFee");
			JSONObject cv = new JSONObject();
			cv.put("operator", "BETWEEN");
			cv.put("from", remmitanceMDM.get("effectiveFrom").toString().substring(0, 19));
			cv.put("to", remmitanceMDM.get("effectiveTo").toString().substring(0, 19));
			remittanceFee.put("contractValidity", cv);
			remittanceFee.put("RuleID", jsonObject.getString("_id"));
			JSONObject fixed = remmitanceMDM.getJSONObject("fixed");
			if(fixed.getBoolean("isPercentage"))
				remittanceFee.put("percentage", fixed.get("percent").toString());
			else{
				remittanceFee.put("commercialCurrency", fixed.getJSONObject("amount").getString("currency"));
				remittanceFee.put("commercialAmount", fixed.getJSONObject("amount").get("value").toString());
			}
			mainJson.put("RemittanceFeeDT", remittanceFee);
			System.out.println("RemittanceFeeDT: "+mainJson);
		}else{
			for(int i=0;i<remmitanceMDM.getJSONArray("slabs").length();i++){
				JSONObject remittanceFee = new JSONObject();
				remittanceFee.put("selectedRow", commDefnID);
				remittanceFee.put("type", "remittanceFee");
				JSONObject cv = new JSONObject();
				cv.put("operator", "BETWEEN");
				cv.put("from", remmitanceMDM.get("effectiveFrom").toString().substring(0, 19));
				cv.put("to", remmitanceMDM.get("effectiveTo").toString().substring(0, 19));
				remittanceFee.put("contractValidity", cv);
				JSONObject slabs = remmitanceMDM.getJSONArray("slabs").getJSONObject(i);
				remittanceFee.put("totalSettlementCurrency", slabs.getString("currency"));
				JSONObject totalSettlementAmount = new JSONObject();
				if(slabs.has("transactionFromValue") && slabs.has("transactionToValue")){
					totalSettlementAmount.put("operator", "BETWEEN");
					totalSettlementAmount.put("from", slabs.get("transactionFromValue").toString());
					totalSettlementAmount.put("to", slabs.get("transactionToValue").toString());
				}
				else if(slabs.has("transactionFromValue")){
					totalSettlementAmount.put("operator", "GREATERTHANEQUALTO");
					totalSettlementAmount.put("value", slabs.get("transactionFromValue").toString());
				}else{
					totalSettlementAmount.put("operator", "LESSTHANEQUALTO");
					totalSettlementAmount.put("value", slabs.get("transactionToValue").toString());
				}
				remittanceFee.put("totalSettlementAmount", totalSettlementAmount);
				if(slabs.getBoolean("isPercentage"))
					remittanceFee.put("percentage",slabs.get("percentage").toString());
				else{
					remittanceFee.put("commercialCurrency",slabs.getJSONObject("amount").getString("currency"));
					remittanceFee.put("commercialAmount",slabs.getJSONObject("amount").get("value").toString());
				}
				remittanceFee.put("RuleID", slabs.getString("_id"));
				remittanceFeeArr.put(remittanceFee);
			}
			mainJson.put("RemittanceFeeDT", remittanceFeeArr);
		}
	}


	public static JSONArray getPenaltyFee(JSONObject penaltyFeeMDM, String commDefnID) {
		JSONArray penaltyFeeArr = new JSONArray();
		JSONArray penaltyCriteriaMDMarr = penaltyFeeMDM.getJSONArray("penaltyCriteria");
		for(int i=0;i<penaltyCriteriaMDMarr.length();i++){
			JSONObject penaltyCRitObj = penaltyCriteriaMDMarr.getJSONObject(i);
			JSONObject penaltyFee = new JSONObject();
			JSONObject slabDetails = new JSONObject();
			JSONObject slabTypeVal = new JSONObject();
			penaltyFee.put("contractValidity", getContractValidity(penaltyFeeMDM));
			penaltyFee.put("selectedRow", commDefnID);
			penaltyFee.put("type", "penaltyFee");
			penaltyFee.put("RuleID", penaltyCRitObj.getString("_id"));
			if(penaltyCRitObj.getJSONObject("condition").has("minimumPercentToAchieve") && penaltyCRitObj.getJSONObject("condition").getJSONObject("minimumPercentToAchieve")!=null ){
				String minToAchieve = penaltyCRitObj.getJSONObject("condition").getJSONObject("minimumPercentToAchieve").get("from").toString();
				String maxToAchieve = penaltyCRitObj.getJSONObject("condition").getJSONObject("minimumPercentToAchieve").get("to").toString();
				slabDetails.put("slabType", penaltyCRitObj.getJSONObject("condition").getString("slabType"));
				slabTypeVal.put("minimumToAchieve",minToAchieve+"*"+penaltyCRitObj.getJSONObject("condition").get("targetTo"));
				slabTypeVal.put("maximumToAchieve",maxToAchieve+"*"+penaltyCRitObj.getJSONObject("condition").get("targetTo"));
				slabDetails.put("slabTypeValue", slabTypeVal);
				penaltyFee.put("slabDetails", slabDetails);
			}else{
				slabDetails.put("slabType", penaltyCRitObj.getJSONObject("condition").getString("slabType"));
				if(penaltyCRitObj.getJSONObject("condition").has("targetFrom") && penaltyCRitObj.getJSONObject("condition").has("targetTo")){
					slabTypeVal.put("operator", "BETWEEN");
					slabTypeVal.put("from", penaltyCRitObj.getJSONObject("condition").get("targetFrom").toString());
					slabTypeVal.put("to", penaltyCRitObj.getJSONObject("condition").get("targetTo").toString());
				}else if(penaltyCRitObj.getJSONObject("condition").has("targetFrom")){
					slabTypeVal.put("operator","GREATERTHANEQUALTO");
					slabTypeVal.put("value", penaltyCRitObj.getJSONObject("condition").get("targetFrom").toString());
				}else{
					slabTypeVal.put("operator","LESSTHANEQUALTO");
					slabTypeVal.put("value", penaltyCRitObj.getJSONObject("condition").get("targetTo").toString());
				}
				slabDetails.put("slabTypeValue", slabTypeVal);
				penaltyFee.put("slabDetails", slabDetails);
			}
			if(penaltyCRitObj.getJSONObject("penalty").getBoolean("isPercentage")){
				penaltyFee.put("matchingSlabType",penaltyCRitObj.getJSONObject("penalty").getJSONObject("percent").getString("slabType"));
				penaltyFee.put("percentage", penaltyCRitObj.getJSONObject("penalty").getJSONObject("percent").get("percent").toString());
			}else{
				penaltyFee.put("commercialAmount", penaltyCRitObj.getJSONObject("penalty").getJSONObject("amount").get("value").toString());
				penaltyFee.put("commercialCurrency", penaltyCRitObj.getJSONObject("penalty").getJSONObject("amount").getString("currency"));
			}
			penaltyFeeArr.put(penaltyFee);
		}
		return penaltyFeeArr;
	}


	public static JSONObject getTerminationFee(JSONObject terminationFeeMDM, JSONObject jsonObject, String commDefnID) {
		JSONObject terminationFee = new JSONObject();
		terminationFee.put("contractValidity", getContractValidity(terminationFeeMDM));
		terminationFee.put("selectedRow", commDefnID);
		terminationFee.put("RuleID", jsonObject.getString("_id"));
		terminationFee.put("type", "terminationFee");
		if(terminationFeeMDM.getJSONObject("payable").getBoolean("fixed")){
			terminationFee.put("commercialCurrency",terminationFeeMDM.getJSONObject("fixed").getString("currency"));
			terminationFee.put("commercialAmount",terminationFeeMDM.getJSONObject("fixed").get("value").toString());
		}else{
			JSONArray returnableCommHeadArr =new JSONArray();
			for(int i=0;i<terminationFeeMDM.getJSONArray("returnOfPayable").length();i++){
				JSONObject returnableCommHead =new JSONObject();
				returnableCommHead.put("commercialName", terminationFeeMDM.getJSONArray("returnOfPayable").getJSONObject(i).getString("commercialHead"));
				returnableCommHead.put("commercialPercentage", terminationFeeMDM.getJSONArray("returnOfPayable").getJSONObject(i).get("interestOnAmount").toString());
				returnableCommHeadArr.put(returnableCommHead);
			}
			terminationFee.put("returnableCommercialHead",returnableCommHeadArr);
		}
		return terminationFee;
	}


	public static JSONArray getIncentiveOnTopUp(JSONObject incentivesOnTopUpMDM, String commDefnID) {
		JSONArray incentivesOnTopUpArr = new JSONArray();
		JSONArray supplierRateType = new JSONArray();
		JSONArray supplierRateCode = new JSONArray();
		JSONArray topUpAmountArrMDM = incentivesOnTopUpMDM.getJSONArray("topUpAmount");
		Set<String> supplierRateTypeSet = new HashSet<String>();
		Set<String> supplierRateCodeSet = new HashSet<String>();
		for(int i=0;i<topUpAmountArrMDM.length();i++){
			for(int l=0;l<incentivesOnTopUpMDM.getJSONArray("rateType").length();l++){
				JSONObject iotpRateTypeObj = incentivesOnTopUpMDM.getJSONArray("rateType").getJSONObject(l);
				if(iotpRateTypeObj.has("supplierRateType") && !iotpRateTypeObj.getString("supplierRateType").equalsIgnoreCase("All"))
					supplierRateTypeSet.add(iotpRateTypeObj.getString("supplierRateType"));
				if(iotpRateTypeObj.has("supplierRateCode") && !iotpRateTypeObj.getString("supplierRateCode").equalsIgnoreCase("All"))
					supplierRateCodeSet.add(iotpRateTypeObj.getString("supplierRateCode"));
			}
			supplierRateType = new JSONArray(supplierRateTypeSet);
			supplierRateCode = new JSONArray(supplierRateCodeSet);
		}
		for(int i=0;i<topUpAmountArrMDM.length();i++){
			JSONObject topUpAmount = topUpAmountArrMDM.getJSONObject(i);
			switch(incentivesOnTopUpMDM.getString("periodForTopUp")){
			case "daily":{
				for(int j=0;j<incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONArray("daily").length();j++){
					JSONObject iotpDaily =incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONArray("daily").getJSONObject(j);
					JSONObject incentivesOnTopUp = new JSONObject();
					JSONObject daily = new JSONObject();
					JSONObject periodForTopUp = new JSONObject();
					incentivesOnTopUp.put("contractValidity", getContractValidity(incentivesOnTopUpMDM));
					incentivesOnTopUp.put("selectedRow", commDefnID);
					incentivesOnTopUp.put("type", "incentivesOnTopUp");
					incentivesOnTopUp.put("RuleID",iotpDaily.getString("_id")+topUpAmount.getString("_id"));
					if(topUpAmount.has("modeOfPayment")&&!topUpAmount.getString("modeOfPayment").equalsIgnoreCase("All"))
						incentivesOnTopUp.put("modeOfPayment", topUpAmount.getString("modeOfPayment"));
					if(topUpAmount.has("bankName")&&!topUpAmount.getString("bankName").equalsIgnoreCase("All"))
						incentivesOnTopUp.put("bankName", topUpAmount.getString("bankName"));
					incentivesOnTopUp.put("incentiveCurrency", topUpAmount.getString("currency"));
					incentivesOnTopUp.put("incentiveAmount", topUpAmount.get("amount").toString());
					incentivesOnTopUp.put("incentivePercentage", topUpAmount.get("incentivesInPercentage").toString());
					incentivesOnTopUp.put("incentiveRateType", supplierRateType);
					incentivesOnTopUp.put("incentiveRateCode", supplierRateCode);
					daily.put("hour", iotpDaily.get("hour").toString());
					daily.put("minute", iotpDaily.get("minute").toString());
					periodForTopUp.put("daily", daily);
					incentivesOnTopUp.put("periodForTopUp", periodForTopUp);
					incentivesOnTopUpArr.put(incentivesOnTopUp);
				}
				break;
			}
			case "weekly":{
				JSONObject weekly = new JSONObject();
				JSONObject incentivesOnTopUp = new JSONObject();
				JSONObject periodForTopUp = new JSONObject();
				incentivesOnTopUp.put("contractValidity", getContractValidity(incentivesOnTopUpMDM));
				incentivesOnTopUp.put("selectedRow", commDefnID);
				incentivesOnTopUp.put("type", "incentivesOnTopUp");
				incentivesOnTopUp.put("RuleID",topUpAmount.getString("_id"));
				if(topUpAmount.has("modeOfPayment")&&!topUpAmount.getString("modeOfPayment").equalsIgnoreCase("All"))
					incentivesOnTopUp.put("modeOfPayment", topUpAmount.getString("modeOfPayment"));
				if(topUpAmount.has("bankName")&&!topUpAmount.getString("bankName").equalsIgnoreCase("All"))
					incentivesOnTopUp.put("bankName", topUpAmount.getString("bankName"));
				incentivesOnTopUp.put("incentiveCurrency", topUpAmount.getString("currency"));
				incentivesOnTopUp.put("incentiveAmount", topUpAmount.get("amount").toString());
				incentivesOnTopUp.put("incentivePercentage", topUpAmount.get("incentivesInPercentage").toString());
				incentivesOnTopUp.put("incentiveRateType", supplierRateType);
				incentivesOnTopUp.put("incentiveRateCode", supplierRateCode);
				weekly.put("dayOfWeek", incentivesOnTopUpMDM.getJSONObject("periodicity").get("weekly"));
				periodForTopUp.put("weekly", weekly);
				incentivesOnTopUp.put("periodForTopUp", periodForTopUp);
				incentivesOnTopUpArr.put(incentivesOnTopUp);
				break;
			}
			case "fortnightly":{
				for(int j=0;j<incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONArray("fortnightly").length();j++){
					JSONObject iotpFortnightly =incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONArray("fortnightly").getJSONObject(j);
					JSONObject incentivesOnTopUp = new JSONObject();
					JSONObject fortnighly = new JSONObject();
					JSONObject periodForTopUp = new JSONObject();
					JSONArray dayOfWeekInMonth = new JSONArray();
					JSONArray monthFortnightly = new JSONArray();
					incentivesOnTopUp.put("contractValidity", getContractValidity(incentivesOnTopUpMDM));
					incentivesOnTopUp.put("selectedRow", commDefnID);
					incentivesOnTopUp.put("type", "incentivesOnTopUp");
					incentivesOnTopUp.put("RuleID",iotpFortnightly.getString("_id")+topUpAmount.getString("_id"));
					if(topUpAmount.has("modeOfPayment")&&!topUpAmount.getString("modeOfPayment").equalsIgnoreCase("All"))
						incentivesOnTopUp.put("modeOfPayment", topUpAmount.getString("modeOfPayment"));
					if(topUpAmount.has("bankName")&&!topUpAmount.getString("bankName").equalsIgnoreCase("All"))
						incentivesOnTopUp.put("bankName", topUpAmount.getString("bankName"));
					incentivesOnTopUp.put("incentiveCurrency", topUpAmount.getString("currency"));
					incentivesOnTopUp.put("incentiveAmount", topUpAmount.get("amount").toString());
					incentivesOnTopUp.put("incentivePercentage", topUpAmount.get("incentivesInPercentage").toString());
					incentivesOnTopUp.put("incentiveRateType", supplierRateType);
					incentivesOnTopUp.put("incentiveRateCode", supplierRateCode);
					dayOfWeekInMonth.put(iotpFortnightly.get("day1").toString());
					dayOfWeekInMonth.put(iotpFortnightly.get("day2").toString());
					fortnighly.put("dayOfWeekInMonth", dayOfWeekInMonth);
					int f = iotpFortnightly.getInt("repeatEvery");
					for(int k=1;k<=12;k++){
						if(k%f==0){
							monthFortnightly.put(""+k);
						}
					}
					fortnighly.put("month",monthFortnightly);
					periodForTopUp.put("fortnighly", fortnighly);
					incentivesOnTopUp.put("periodForTopUp", periodForTopUp);
					incentivesOnTopUpArr.put(incentivesOnTopUp);
				}
				break;
			}
			case "monthly":{
				JSONObject incentivesOnTopUp = new JSONObject();
				JSONObject monthly = new JSONObject();
				JSONObject periodForTopUp = new JSONObject();
				JSONArray monthMonthly = new JSONArray();
				incentivesOnTopUp.put("contractValidity", getContractValidity(incentivesOnTopUpMDM));
				incentivesOnTopUp.put("selectedRow", commDefnID);
				incentivesOnTopUp.put("type", "incentivesOnTopUp");
				incentivesOnTopUp.put("RuleID",topUpAmount.getString("_id"));
				if(topUpAmount.has("modeOfPayment")&&!topUpAmount.getString("modeOfPayment").equalsIgnoreCase("All"))
					incentivesOnTopUp.put("modeOfPayment", topUpAmount.getString("modeOfPayment"));
				if(topUpAmount.has("bankName")&&!topUpAmount.getString("bankName").equalsIgnoreCase("All"))
					incentivesOnTopUp.put("bankName", topUpAmount.getString("bankName"));
				incentivesOnTopUp.put("incentiveCurrency", topUpAmount.getString("currency"));
				incentivesOnTopUp.put("incentiveAmount", topUpAmount.get("amount").toString());
				incentivesOnTopUp.put("incentivePercentage", topUpAmount.get("incentivesInPercentage").toString());
				incentivesOnTopUp.put("incentiveRateType", supplierRateType);
				incentivesOnTopUp.put("incentiveRateCode", supplierRateCode);
				if(incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONObject("monthly").has("option1")){
					monthly.put("dayInMonth", incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONObject("monthly").getJSONObject("option1").get("day").toString());
					int t = incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONObject("monthly").getJSONObject("option1").getInt("repeatEvery");
					for(int k=1;k<=12;k++){
						if(k%t==0){
							monthMonthly.put(""+k);
						}
					}
					monthly.put("month", monthMonthly);
					periodForTopUp.put("monthly", monthly);
					incentivesOnTopUp.put("periodForTopUp", periodForTopUp);
					incentivesOnTopUpArr.put(incentivesOnTopUp);

				}
				else{
					JSONArray weekOfMonthArr =new JSONArray();
					JSONArray dayOfWeekArr = new JSONArray();
					weekOfMonthArr.put(incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONObject("monthly").getJSONObject("option2").get("weekOfMonth").toString());		
					dayOfWeekArr.put(incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONObject("monthly").getJSONObject("option2").get("dayOfWeek"));
					monthly.put("dayOfWeekInMonth", weekOfMonthArr);			
					monthly.put("dayOfWeek",dayOfWeekArr );
					int t = incentivesOnTopUpMDM.getJSONObject("periodicity").getJSONObject("monthly").getJSONObject("option2").getInt("repeatEvery");
					for(int k=1;k<=12;k++){
						if(k%t==0){
							monthMonthly.put(""+k);
						}
					}
					monthly.put("month", monthMonthly);
					periodForTopUp.put("monthly", monthly);
					incentivesOnTopUp.put("periodForTopUp", periodForTopUp);
					incentivesOnTopUpArr.put(incentivesOnTopUp);
				}
				break;
			}
			}
		}
		return incentivesOnTopUpArr;
	}


	public static JSONObject getMSFFee(JSONObject msfMDM, JSONObject jsonObject, String commDefnID) {
		JSONObject msfFee = new JSONObject();
		msfFee.put("contractValidity", getContractValidity(msfMDM));
		msfFee.put("selectedRow", commDefnID);
		msfFee.put("RuleID", jsonObject.getString("_id"));
		msfFee.put("type", "msfFee");
		if(msfMDM.getJSONObject("paymentRule").has("transactionType"))
			msfFee.put("transactionType", msfMDM.getJSONObject("paymentRule").getString("transactionType"));
		if(msfMDM.getJSONObject("paymentRule").has("MSFchargesType"))
			msfFee.put("msfChargeType", msfMDM.getJSONObject("paymentRule").getString("MSFchargesType"));
		if(msfMDM.getJSONObject("paymentRule").has("paymentType") && msfMDM.getJSONObject("paymentRule").getJSONArray("paymentType").length()>0)
			msfFee.put("paymentType", msfMDM.getJSONObject("paymentRule").get("paymentType"));
		if(msfMDM.getJSONObject("paymentRule").has("cardTypes") && msfMDM.getJSONObject("paymentRule").getJSONArray("cardTypes").length()>0)
			msfFee.put("cardType", msfMDM.getJSONObject("paymentRule").get("cardTypes"));
		if(msfMDM.has("fixed")){
			JSONObject fixed = msfMDM.getJSONObject("fixed");
			msfFee.put("serviceTaxApplicable", fixed.getBoolean("isServiceTaxApplied"));
			if(fixed.getBoolean("isPercentage"))
				msfFee.put("percentage",fixed.getJSONObject("percentage").get("value").toString());
			if(fixed.getBoolean("isAmount")){
				msfFee.put("currency",fixed.getJSONObject("amount").getString("currency"));
				msfFee.put("amount",fixed.getJSONObject("amount").get("value").toString());
			}
		}
		return msfFee;
	}


	public static void setLookToBook(JSONObject ltb, JSONObject mainJson, JSONObject jsonObject, String commDefnID) {
		JSONArray ltbArr = new JSONArray();
//		JSONArray productChainArr = new JSONArray();
//		JSONArray productBrandArr = new JSONArray();
//		JSONArray productNameArr = new JSONArray();
//		JSONArray productArrMDM = ltb.getJSONArray("products");
//	
//		for(int j=0;j<productArrMDM.length();j++){
//			JSONObject productObj = productArrMDM.getJSONObject(j);
//			if(productObj.has("productId") && !productObj.getString("productId").equalsIgnoreCase("All"))
//				productNameArr.put(productObj.getString("productId"));
//			if(productObj.has("chain")&& !productObj.getString("chain").equalsIgnoreCase("All"))
//				productChainArr.put( productObj.getString("chain"));
//			if(productObj.has("brand")&& !productObj.getString("brand").equalsIgnoreCase("All"))
//				productBrandArr.put(productObj.getString("brand"));
//		
		

		if(ltb.getBoolean("isLTBbyRatio")){
			for(int i=0;i<ltb.getJSONArray("LTBbyRatio").length();i++){
				JSONObject lookToBook = new JSONObject();
				lookToBook.put("contractValidity", getContractValidity(ltb));
				lookToBook.put("selectedRow", commDefnID);
				lookToBook.put("type", "lookToBook");
				JSONObject lookToBookObject = new JSONObject();
				JSONObject lookRatio = ltb.getJSONArray("LTBbyRatio").getJSONObject(i);
				lookToBookObject.put("from",lookRatio.getJSONObject("lookRatio").get("from").toString());
				lookToBookObject.put("to",lookRatio.getJSONObject("lookRatio").get("to").toString());
				lookToBookObject.put("bookRatio", lookRatio.get("bookRatio").toString());
				lookToBookObject.put("currency", lookRatio.optJSONObject("amountPerExcessLook").optString("currency"));
				lookToBookObject.put("amountPerAccessLook", lookRatio.getJSONObject("amountPerExcessLook").get("amount").toString());
				lookToBook.put("RuleID", lookRatio.getString("_id"));
				lookToBook.put("lookToBook", lookToBookObject);
//				lookToBook.put("productName", productNameArr);
//				lookToBook.put("productBrand", productBrandArr);
//				lookToBook.put("productChain", productChainArr);
				ltbArr.put(lookToBook);
			}
				mainJson.put("LookToBookCumulativeDT", ltbArr);
				System.out.println("LookToBookCumulativeDT [RATIO]: "+mainJson);
		}else{
				JSONObject lookToBook = new JSONObject();
				lookToBook.put("contractValidity", getContractValidity(ltb));
				lookToBook.put("selectedRow", commDefnID);
				lookToBook.put("type", "lookToBook");
				JSONObject LTBbyRate = ltb.getJSONObject("LTBbyRate");
				JSONObject lookToBookObject = new JSONObject();
				JSONObject lookRate = new JSONObject();
				JSONObject bookRate = new JSONObject();
				lookToBook.put("RuleID", jsonObject.getString("_id"));
				lookRate.put("amount", LTBbyRate.getJSONObject("ratePerLook").get("amount").toString());
				lookRate.put("currency", LTBbyRate.getJSONObject("ratePerLook").getString("currency"));
				lookToBookObject.put("lookRate", lookRate);
				bookRate.put("amount", LTBbyRate.getJSONObject("ratePerBook").get("amount").toString());
				bookRate.put("currency", LTBbyRate.getJSONObject("ratePerBook").getString("currency"));
				lookToBookObject.put("bookRate", bookRate);
				lookToBook.put("lookToBook", lookToBookObject);
//				lookToBook.put("productName", productNameArr);
//				lookToBook.put("productBrand", productBrandArr);
//				lookToBook.put("productChain", productChainArr);
				mainJson.put("LookToBookCumulativeDT", lookToBook);
				System.out.println("LookToBookCumulativeDT [RATE]: "+mainJson);
		}
	}


	public static JSONArray getSignUpBonus(JSONObject signUpBonusObj, String commDefnID, String productCategory) {
		JSONArray signUpBonusArr = new JSONArray();
		for(int i=0;i<signUpBonusObj.getJSONArray("signupBonusCriteria").length();i++){
			JSONObject signUpBonus = new JSONObject();
			JSONObject signupBonusCriteria = signUpBonusObj.getJSONArray("signupBonusCriteria").getJSONObject(i);
			signUpBonus.put("selectedRow", commDefnID);
			signUpBonus.put("type", "signUpBonus");
			signUpBonus.put("commercialCurrency", signUpBonusObj.getJSONObject("signupBonus").getString("currency"));
			signUpBonus.put("commercialAmount", signUpBonusObj.getJSONObject("signupBonus").get("value").toString());
			signUpBonus.put("contractValidity",getContractValidity(signUpBonusObj));
			//signUpBonus.put("productCategory", productCategory);
			//signUpBonus.put("productCategorySubType", productCategorySubType);
			signUpBonus.put("RuleID", signupBonusCriteria.getString("_id"));
			signUpBonus.put("slabType", signupBonusCriteria.getString("slabType"));
			if(signupBonusCriteria.has("targetFrom") && signupBonusCriteria.has("targetTo")){
				signUpBonus.put("slabTypeValue", "BETWEEN;"+signupBonusCriteria.get("targetFrom")+";"+signupBonusCriteria.get("targetTo"));
			}else if(signupBonusCriteria.has("targetTo")){
				signUpBonus.put("slabTypeValue", "LESSTHANEQUALTO;"+signupBonusCriteria.get("targetTo"));
			}else{
				signUpBonus.put("slabTypeValue", "GREATERTHANEQUALTO;"+signupBonusCriteria.get("targetFrom"));
			}
			signUpBonusArr.put(signUpBonus);
		}
		return signUpBonusArr;
	}


	public static JSONObject setFOC(JSONObject mainJson, JSONObject jsonObject, JSONArray commercialHeadArr, String focProd, String prodInfo) {
		JSONArray focArr = new JSONArray();
		JSONObject tempMain = new JSONObject();
		JSONObject focUtilization = new JSONObject();
		String dtName= null;
		Set<String> utilizationProductCategorySet = new HashSet<String>();
		Set<String> utilizationproductCategorySubTypeSet = new HashSet<String>();
		Set<String> utilizationproductIdSet = new HashSet<String>();
		JSONObject focMDMObj = jsonObject.getJSONObject("advanceCommercial").getJSONObject(focProd);

		for(int k=0;k<commercialHeadArr.length();k++){
			JSONObject commercialHeadObj = commercialHeadArr.getJSONObject(k);
			if(commercialHeadObj.getString("commercialHeadName").equals("FOC")){
				commercialHeadObj.put("commercialType", jsonObject.getJSONObject("advanceCommercial").getJSONObject(focProd).getJSONObject("commercialInformation").getString("commercialType"));
				commercialHeadObj.put("plbApplicable", focMDMObj.getBoolean("isPLBApplicable"));
			}
		}

		if(focMDMObj.has("freeOfCostUtilization")){
			if(focMDMObj.getJSONArray("freeOfCostUtilization").length()>0){
				for(int i =0; i<focMDMObj.getJSONArray("freeOfCostUtilization").length();i++){
					JSONObject focUtilizationObj = focMDMObj.getJSONArray("freeOfCostUtilization").getJSONObject(i);
					if(focUtilizationObj.has("productCategory") && !focUtilizationObj.getString("productCategory").equalsIgnoreCase("All"))
						utilizationProductCategorySet.add(focUtilizationObj.getString("productCategory"));
					if(focUtilizationObj.has("productCategorySubType") && !focUtilizationObj.getString("productCategorySubType").equalsIgnoreCase("All"))
						utilizationproductCategorySubTypeSet.add(focUtilizationObj.getString("productCategorySubType"));
					if(focUtilizationObj.has("productId") && !focUtilizationObj.getString("productId").equalsIgnoreCase("All"))
						utilizationproductIdSet.add(focUtilizationObj.getString("productId"));
				}
				focUtilization.put("productCategory", utilizationProductCategorySet);
				focUtilization.put("productCategorySubType", utilizationproductCategorySubTypeSet);
				focUtilization.put("productName", utilizationproductIdSet);		
			}
		}
		
		JSONArray slabRunning = new JSONArray();
		if(focMDMObj.has("slabOrRunning"))
			slabRunning = focMDMObj.getJSONArray("slabOrRunning");
		else if(focMDMObj.has("slabsOrRunning"))
			slabRunning = focMDMObj.getJSONArray("slabsOrRunning");
		
		for(int i = 0;i<slabRunning.length();i++){
			JSONObject focObj = new JSONObject();
			JSONArray slabArr = new JSONArray();
			JSONObject slabObj = new JSONObject();
			JSONObject freeOfCosts = new JSONObject();
			JSONObject slabOrRunning = slabRunning.getJSONObject(i);
			slabObj.put("contractValidity", getContractValidity(focMDMObj));
			if(!focProd.equals("freeOfCostHolidays"))
				freeOfCosts.put("focUtilisation", focUtilization);	
			slabObj.putOpt("freeOfCosts", freeOfCosts);
			slabObj.put("RuleID", slabOrRunning.getString("_id"));
			slabObj.put("type", "foc");

			if(focProd.equals("freeOfCostFlights") && slabOrRunning.getJSONArray("product").length()>0)
				slabObj.put("productName", slabOrRunning.getJSONArray("product"));

			if(slabOrRunning.has("IATANumbers") && slabOrRunning.getJSONArray("IATANumbers").length()>0)
				slabObj.put("IATANumber", slabOrRunning.getJSONArray("IATANumbers"));
				
			if(slabOrRunning.has("IATANos") && slabOrRunning.getJSONArray("IATANos").length()>0)
				slabObj.put("IATANumber", slabOrRunning.getJSONArray("IATANos"));
			
			if(slabOrRunning.has("slab")){
				dtName = "FreeOfCostSlabDT";
				JSONObject slab = new JSONObject();
				JSONObject slabObject = slabOrRunning.getJSONObject("slab");
				slab.put("slabType", slabObject.getString("slabType"));
				if(slabObject.has("fromValue")){
					if(slabObject.has("toValue"))
						slab.put("slabTypeValue","BETWEEN"+";"+slabObject.get("fromValue").toString()+";"+slabObject.get("toValue").toString());
					else slab.put("slabTypeValue","GREATERTHANEQUALTO"+";"+slabObject.get("fromValue").toString());
				}
				else if(slabObject.has("toValue"))
					slab.put("slabTypeValue","LESSTHANEQUALTO"+";"+slabObject.get("toValue").toString());

				if(slabObject.has("roomCategory"))
					slabObj.put("slab_roomCategory", slabObject.getString("roomCategory"));

				if(slabObject.has("cabinClass"))
					slabObj.put("slab_cabinClass", slabObject.getString("cabinClass"));

				if(slabObj.has("freeOfCosts"))
					slabObj.getJSONObject("freeOfCosts").put("slab", slab);
				else{
					JSONObject foc = new JSONObject();
					foc.put("slab", slab);
					slabObj.put("freeOfCosts", foc);	
				}
			}
			
			if(slabOrRunning.has("running")){
				dtName = "FreeofCostRunningDT";
				JSONObject every = new JSONObject();
				JSONObject running = slabOrRunning.getJSONObject("running");
				if(running.has("every"))
					every.put("every", running.getString("every"));
				if(running.has("typeIs"))
					every.put("type", running.getString("typeIs"));
				if(running.has("roomCategory"))
					every.put("roomCategory", running.getString("roomCategory"));
				if(running.has("cabinClass"))
					every.put("cabinClass", running.getString("cabinClass"));

				if(slabObj.has("freeOfCosts"))
					slabObj.getJSONObject("freeOfCosts").put("every", every);
				else{
					JSONObject foc = new JSONObject();
					foc.put("every", every);
					slabObj.put("freeOfCosts", foc);	
				}
			}

			if(slabOrRunning.has("freeOfCostRoom")){
				JSONObject focRooms = new JSONObject();
				JSONObject freeOfCostRoom = slabOrRunning.getJSONObject("freeOfCostRoom");
				if(freeOfCostRoom.has("roomCategory"))
					focRooms.put("rooms_roomCategory", freeOfCostRoom.getString("roomCategory"));
				if(freeOfCostRoom.has("roomType"))
					focRooms.put("rooms_roomType", freeOfCostRoom.getString("roomType"));
				if(freeOfCostRoom.has("noOfRooms"))
					focRooms.put("rooms_numberOfRooms", freeOfCostRoom.get("noOfRooms").toString());
				if(freeOfCostRoom.has("freeOfCostPercent"))
					focRooms.put("rooms_percentage", freeOfCostRoom.get("freeOfCostPercent").toString());
				if(freeOfCostRoom.has("priceComponents"))
					focRooms.put("rooms_priceComponent", freeOfCostRoom.getJSONArray("priceComponents"));

				slabObj.getJSONObject("freeOfCosts").put("focRooms", focRooms);
			}

			if(slabOrRunning.has("freeOfCostUpgrades")){
				JSONObject focUpgrades = new JSONObject();
				JSONObject freeOfCostUpgrades = slabOrRunning.getJSONObject("freeOfCostUpgrades");
				if(freeOfCostUpgrades.has("upgradeToRoomCategory"))
					focUpgrades.put("upgrades_roomCategory", freeOfCostUpgrades.getString("upgradeToRoomCategory"));
				if(freeOfCostUpgrades.has("upgradeToCabinClass"))
					focUpgrades.put("upgrades_cabinClass", freeOfCostUpgrades.getString("upgradeToCabinClass"));
				if(freeOfCostUpgrades.has("rbd"))
					focUpgrades.put("upgrades_rbd", freeOfCostUpgrades.getString("rbd"));
				if(freeOfCostUpgrades.has("noOfUpgrades"))
					focUpgrades.put("upgrades_numberOfUpgrades", freeOfCostUpgrades.get("noOfUpgrades").toString());
				if(freeOfCostUpgrades.has("freeOfCostPercent"))
					focUpgrades.put("upgrades_percentage", freeOfCostUpgrades.get("freeOfCostPercent").toString());
				if(freeOfCostUpgrades.has("priceComponents"))
					focUpgrades.put("upgrades_priceComponent", freeOfCostUpgrades.getJSONArray("priceComponents"));
				if(freeOfCostUpgrades.has("fareComponents"))
					focUpgrades.put("upgrades_priceComponent", freeOfCostUpgrades.getJSONArray("fareComponents"));

				slabObj.getJSONObject("freeOfCosts").put("focUpgrades", focUpgrades);
			}

			if(slabOrRunning.has("freeOfCostTickets")){
				JSONObject focTickets = new JSONObject();
				JSONObject freeOfCostTickets = slabOrRunning.getJSONObject("freeOfCostTickets");
				if(freeOfCostTickets.has("cabinClass"))
					focTickets.put("tickets_cabinClass", freeOfCostTickets.getString("cabinClass"));
				if(freeOfCostTickets.has("rbd"))
					focTickets.put("tickets_rbd", freeOfCostTickets.getString("rbd"));
				if(freeOfCostTickets.has("noOfTickets"))
					focTickets.put("tickets_noOfTickets", freeOfCostTickets.get("noOfTickets").toString());
				if(freeOfCostTickets.has("freeOfCostPercent"))
					focTickets.put("tickets_percentage", freeOfCostTickets.get("freeOfCostPercent").toString());
				if(freeOfCostTickets.has("fareComponents"))
					focTickets.put("tickets_priceComponent", freeOfCostTickets.getJSONArray("fareComponents"));

				slabObj.getJSONObject("freeOfCosts").put("focTickets", focTickets);
			}

			if(slabOrRunning.has("supplierRate")){	
				if(slabOrRunning.getJSONArray("supplierRate").length()>0){
					HashSet<String> supplierRatetype = new HashSet<>();
					HashSet<String> supplierRateCode = new HashSet<>();
					for(int j=0;j<slabOrRunning.getJSONArray("supplierRate").length();j++){
						if(slabOrRunning.getJSONArray("supplierRate").getJSONObject(j).has("supplierRatetype"))
							supplierRatetype.add(slabOrRunning.getJSONArray("supplierRate").getJSONObject(j).getString("supplierRatetype"));
						if(slabOrRunning.getJSONArray("supplierRate").getJSONObject(j).has("supplierRateCode"))
							supplierRateCode.add(slabOrRunning.getJSONArray("supplierRate").getJSONObject(j).getString("supplierRateCode"));
					}
					slabObj.put("supplierRateType", supplierRatetype);
					slabObj.put("supplierRateCode", supplierRateCode);
				}
			}
			slabArr.put(slabObj);
			focObj.put(dtName, slabArr);

			if(slabOrRunning.getJSONArray("client").length()>0){
				JSONArray clientArr = new JSONArray();
				for(int j=0;j<slabOrRunning.getJSONArray("client").length();j++){
					JSONObject client = slabOrRunning.getJSONArray("client").getJSONObject(j);
					JSONObject clientObj = new JSONObject(new JSONTokener(focObj.getJSONArray(dtName).getJSONObject(0).toString()));
					if(client.has("clientType") && !client.getString("clientType").equalsIgnoreCase("All"))
						clientObj.put("clientType",client.getString("clientType"));
					if(client.has("clientGroup") && !client.getString("clientGroup").equalsIgnoreCase("All"))
						clientObj.put("clientGroup",client.getString("clientGroup"));
					if(client.has("clientName") && !client.getString("clientName").equalsIgnoreCase("All"))
						clientObj.put("clientName",client.getString("clientName"));

					clientObj.put("RuleID", clientObj.getString("RuleID")+client.getString("_id"));
					clientArr.put(clientObj);
				}
				focObj.put(dtName,clientArr);
			}

			if(slabOrRunning.optJSONArray("freeOfCost") != null && slabOrRunning.getJSONArray("freeOfCost").length()>0){
				JSONArray arr = new JSONArray();
				for(int j =0; j<focObj.getJSONArray(dtName).length(); j++){
					for(int k=0;k<slabOrRunning.getJSONArray("freeOfCost").length();k++){
						JSONObject fcObj = slabOrRunning.getJSONArray("freeOfCost").getJSONObject(k);
						JSONObject obj = new JSONObject(new JSONTokener(focObj.getJSONArray(dtName).getJSONObject(j).toString()));
						JSONObject foc = new JSONObject();
						if(fcObj.has("noOfFree"))
							foc.put("numberOfFree",fcObj.get("noOfFree").toString());
						if(fcObj.has("freeOfCostPercent"))
							foc.put("percentage",fcObj.get("freeOfCostPercent").toString());
						if(fcObj.has("priceComponents"))
							foc.put("priceComponent",fcObj.getString("priceComponents"));

						obj.getJSONObject("freeOfCosts").put("freeOfCost", foc);
						obj.put("RuleID", obj.getString("RuleID")+fcObj.getString("_id"));
						arr.put(obj);
					}
				}
				focObj.put(dtName,arr);
			}

			if(!focProd.equals("freeOfCostFlights")){
				if(slabOrRunning.getJSONArray(prodInfo).length()>0){
					JSONArray prodArr = new JSONArray();
					for(int j =0; j<focObj.getJSONArray(dtName).length(); j++){
						for(int k=0;k<slabOrRunning.getJSONArray(prodInfo).length();k++){
							JSONObject prod = slabOrRunning.getJSONArray(prodInfo).getJSONObject(k);
							JSONObject prodObj = new JSONObject(new JSONTokener(focObj.getJSONArray(dtName).getJSONObject(j).toString()));
							if(prod.has("chain") && !prod.getString("chain").equalsIgnoreCase("All"))
								prodObj.put("productChain",prod.getString("chain"));
							if(prod.has("brand") && !prod.getString("brand").equalsIgnoreCase("All"))
								prodObj.put("productBrand",prod.getString("brand"));
							if(prod.has("productId") && !prod.getString("productId").equalsIgnoreCase("All"))
								prodObj.put("productName",prod.getString("productId"));
							if(prod.has("productCategorySubType") && !prod.getString("productCategorySubType").equalsIgnoreCase("All"))
								prodObj.put("productCategorySubType",prod.getString("productCategorySubType"));
							if(prod.has("productType") && !prod.getString("productType").equalsIgnoreCase("All"))
								prodObj.put("productType",prod.getString("productType"));
							if(prod.has("productNameSubtype") && !prod.getString("productNameSubtype").equalsIgnoreCase("All"))
								prodObj.put("productNameSubtype",prod.getString("productNameSubtype"));

							prodObj.put("RuleID", prodObj.getString("RuleID")+prod.getString("_id"));
							prodArr.put(prodObj);
						}
					}
					focObj.put(dtName,prodArr);
				}
			}
			focArr.put(focObj);
		}	
		if(focArr.getJSONObject(0).getJSONArray(dtName).length()>1){
			for(int i =0;i<focArr.length();i++){
				for(int j=0; j<focArr.getJSONObject(i).getJSONArray(dtName).length();j++){
					tempMain.accumulate(dtName, focArr.getJSONObject(i).getJSONArray(dtName).getJSONObject(j));
				}
			}
			mainJson.put(dtName, tempMain.getJSONArray(dtName));
			return mainJson;
		}
		else{
			mainJson.put(dtName, focArr.getJSONObject(0).getJSONArray(dtName));
			return mainJson;
		}
	}


	public static JSONArray otherFees(JSONObject jsonObject, String commDefnID, String productName, JSONArray advanceDefinationData) {
		JSONObject otherFeeObjectMDM = jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees");
		JSONArray otherFeeArr = new JSONArray();
		JSONObject otherFee = new JSONObject();
		otherFee.put("RuleID", jsonObject.getString("_id"));
		otherFee.put("type", "otherFee");
		otherFee.put("selectedRow", commDefnID);
		otherFee.put("contractValidity",getContractValidity(otherFeeObjectMDM));
		if(otherFeeObjectMDM.getBoolean("isFixed")){
			JSONObject fixed = otherFeeObjectMDM.getJSONObject("fixed");
			otherFee.put("commercialCurrency", fixed.getString("currency"));
			otherFee.put("commercialAmount", fixed.get("value").toString());
		}else appliedOnOtherFees(otherFeeObjectMDM, otherFee);
		applyOn(otherFeeObjectMDM, otherFee);
		otherFeeArr.put(otherFee);
		
		if(otherFeeObjectMDM.has("advanceDefinationId")){
			for(int i=0;i<advanceDefinationData.length();i++){
				JSONObject advanceDefinationDataObj = advanceDefinationData.getJSONObject(i);
				if(advanceDefinationDataObj.getString("_id").equals(otherFeeObjectMDM.getString("advanceDefinationId"))){
					return setAdvancedDefintionOtherFees(advanceDefinationDataObj,productName,jsonObject,commDefnID,otherFeeArr);
				}
			}
		}
		return null;
	}


	public static JSONArray setAdvancedDefintionOtherFees(JSONObject advanceDefinationDataObj, String productName, JSONObject jsonObject, String commDefnID, JSONArray otherFeeArr) {
		switch(productName){
		case "accomodation":{
			JSONObject advanceDefinitionAccommodation = advanceDefinationDataObj.getJSONObject("advanceDefinitionAccommodation");
			Accomodation.setAccomodationOtherFeesDestination(advanceDefinitionAccommodation,otherFeeArr,jsonObject,commDefnID);
			Accomodation.setAccoOtherFeesAdvancedDefinition(advanceDefinitionAccommodation,otherFeeArr);
			Accomodation.setAccoValidity(advanceDefinitionAccommodation,otherFeeArr);
			break;
		}
		case "holidays":{
			JSONObject advanceDefinitionHolidays = advanceDefinationDataObj.getJSONObject("advanceDefinitionHolidays");
			Holidays.setOtherFeesHolidaysAdvancedDefinition(advanceDefinitionHolidays, otherFeeArr);
			break;
		}
		case "activities":{
			JSONObject advanceDefinitionActivities = advanceDefinationDataObj.getJSONObject("advanceDefinitionActivities");
			Activities.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionActivities,jsonObject, commDefnID);
			break;
		}
		case "bus":{
			JSONObject advanceDefinitionBus = advanceDefinationDataObj.getJSONObject("advanceDefinitionTransportation");
			CommonFunctions.setTransportationOtherFeesAdvancedDefinition(advanceDefinitionBus, otherFeeArr);
			break;
		}
		case "carrentals":{
			JSONObject advanceDefinitionCarRentals = advanceDefinationDataObj.getJSONObject("advanceDefinitionTransportation");
			CarRentals.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionCarRentals, jsonObject, commDefnID);
			break;
		}
		case "cruise":{
			JSONObject advanceDefinitionCruise = advanceDefinationDataObj.getJSONObject("advanceDefinitionTransportation");
			CommonFunctions.setTransportationOtherFeesAdvancedDefinition(advanceDefinitionCruise, otherFeeArr);
			break;
		}
		case "rail":{
			//JSONObject advanceDefinitionRail = advanceDefinationDataObj.getJSONObject("advanceDefinitionTransportation");
			break;
		}
		case "air":{
			JSONObject advanceDefinitionAir = advanceDefinationDataObj.getJSONObject("advanceDefinitionAir");
			Air.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionAir);
			break;
		}
		case "rentals":{}
		case "transfers":{
			JSONObject advanceDefinitionTransfers = advanceDefinationDataObj.getJSONObject("advanceDefinitionTransportation");
			CommonFunctions.setTransportationOtherFeesAdvancedDefinition(advanceDefinitionTransfers, otherFeeArr);
			break;
		}
		}
		return otherFeeArr;
	}


	public static void appliedOnOtherFees(JSONObject mdmOtherFees, JSONObject otherFee) {
		if(mdmOtherFees.has("percentage") && mdmOtherFees.getJSONArray("percentage").length()>0){
			JSONArray percentArr = new JSONArray();
			for(int i=0;i<mdmOtherFees.getJSONArray("percentage").length();i++){
				JSONObject percent = mdmOtherFees.getJSONArray("percentage").getJSONObject(i);
				JSONObject percentObj = new JSONObject();
				percentObj.put("commercialName", percent.getString("appliedOnCommercialHead"));
				percentObj.put("commercialPercentage", percent.get("percent").toString());
				percentArr.put(percentObj);
			}
			otherFee.put("percentage", percentArr);
		}
	}


	public static void applyOn(JSONObject mdmOtherFees, JSONObject otherFee) {
		if(mdmOtherFees.has("applyOn") && mdmOtherFees.getJSONArray("applyOn").length()>0){
			JSONArray productCategory = new JSONArray();
			JSONArray productCategorySubType = new JSONArray();
			for(int i=0;i<mdmOtherFees.getJSONArray("applyOn").length();i++){
				JSONObject applyOn = mdmOtherFees.getJSONArray("applyOn").getJSONObject(i);
				if(applyOn.getString("productCategory").length()!=0)
					productCategory.put(applyOn.getString("productCategory"));
				if(applyOn.getString("productCategorySubType").length()!=0)
					productCategorySubType.put(applyOn.getString("productCategorySubType"));
			}
			otherFee.put("applicableProductCategory", productCategory);
			otherFee.put("applicableProductCategorySubType", productCategorySubType);
		}
	}


	public static JSONObject getContractValidity(JSONObject mdmOtherFees) {
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", mdmOtherFees.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", mdmOtherFees.getString("contractValidityTo").substring(0, 19));
		return contractValidity;
	}


	public static void appendProductCategoryAndSubType(JSONObject commJson, String productName, String productCategory, String productCategorySubType) {
		switch(productName){
		case "accomodation":{
			commJson.put("productCategorySubType", productCategorySubType);
			break;
		}
		case "holidays":{
			commJson.put("productCategory", productCategory);
			commJson.put("productCategorySubType", productCategorySubType);
			break;
		}
		case "carrentals":{
			commJson.put("productCategorySubType", productCategorySubType);
			break;
		}
		
		}
	}
}
