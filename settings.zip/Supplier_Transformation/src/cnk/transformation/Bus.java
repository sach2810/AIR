package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;
import cnk.kafkaConsumer.ReceiveMDMRequest;

public class Bus {
	public static String commDefnRuleID,overCT,plbCT,destCT,segCT,serCT,issCT,mngtCT;
	public static boolean overSet,plbSet,destSet,segSet,serSet,issSet,mngtSet;

	public static String setCommercials(JSONObject mdmDefn, String productName,  String productCategory, String productCategorySubType, String supplier, JSONArray supplierMarkets) throws Exception{
		JSONObject mainJson = new JSONObject();
		if(mdmDefn.has("SupplierCommercialData") && mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
			String supplierCommercialDataID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
			JSONArray baseArr = new JSONArray();
			JSONArray calcArr = new JSONArray();
			JSONObject standardCommercial = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
			JSONObject commDefn = CommonFunctions.getStandardCommercialDefiniton(mdmDefn,productCategory,productCategorySubType,supplier,supplierMarkets,"Standard");
			mainJson.put("CommercialDefinitionDT", commDefn);

			JSONObject base = new JSONObject();
			JSONObject calculation = new JSONObject();
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", standardCommercial.getString("contractValidityFrom").substring(0, 19));
			contractValidity.put("to", standardCommercial.getString("contractValidityTo").substring(0, 19));
			base.put("contractValidity", contractValidity);
			base.put("RuleID", "BASE"+supplierCommercialDataID);
			base.put("productCategory", productCategory);
			base.put("productCategorySubType", productCategorySubType);
			base.put("type", "base");
			calculation.put("type", "calculation");
			commDefnRuleID= CommonFunctions.commDefnID;
			base.put("selectedRow", commDefnRuleID);
			calculation.put("RuleID", "CALCULATION"+supplierCommercialDataID);
			calculation.put("selectedRow", "BASE"+supplierCommercialDataID);
			baseArr.put(base);
			calcArr.put(calculation);
			mainJson.put("StandardCommercialBaseDT", baseArr);
			mainJson.put("StandardCommercialCalculationDT", calcArr);

			setBusDetails(standardCommercial,baseArr,calcArr);

			if(standardCommercial.has("advanceDefinationId")){
				String advDefnID = standardCommercial.getString("advanceDefinationId");
				for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
					if(advanceDefinationData.getString("_id").equals(advDefnID)){
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject("advanceDefinitionTransportation");
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true);
					}
				}
			}
			
			String stdmdmRuleID = supplierCommercialDataID+"|standardCommercial|null|";
			String fixed = stdmdmRuleID+="fixed";

			int length = baseArr.length();
			for(int i=0;i<length;i++){
				if(standardCommercial.getBoolean("isFixed")){
					calcArr.getJSONObject(i).put("mdmRuleID", fixed);
					CommonFunctions.getFixedDetails(calcArr.getJSONObject(i),standardCommercial.getJSONObject("fixed"));
				}else CommonFunctions.getSlabDetails(baseArr,calcArr,standardCommercial.getJSONArray("slab"),stdmdmRuleID);
			}
			JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
			setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategorySubType,productName,productCategory,supplierCommercialDataID);
		}

		System.out.println("Bus Transactional: "+mainJson.toString());
		return mainJson.toString();
	}


	private static void setBusDetails(JSONObject standardCommercial, JSONArray baseArr, JSONArray calcArr) {
		if(standardCommercial.has("product")){
			if(standardCommercial.getJSONObject("product").has("transportation")){
				JSONObject transportation = standardCommercial.getJSONObject("product").getJSONObject("transportation");
				if(transportation.has("product")){
					if(transportation.getJSONObject("product").has("bus")){
						JSONObject bus = transportation.getJSONObject("product").getJSONObject("bus");
						if(bus.has("operators") && bus.getJSONArray("operators").length()>0){
							for(int i=0;i<calcArr.length();i++){
								JSONObject cal = calcArr.getJSONObject(i);
								cal.put("operatorName", bus.getJSONArray("operators"));
							}
						}

						if(bus.has("routes") && bus.getJSONArray("routes").length()>0){
							JSONArray routes = bus.getJSONArray("routes");
							setRouteDetails(baseArr,calcArr,routes);
						}
					}

					if(transportation.getJSONObject("product").has("genericProduct")){
						for(int i=0;i<baseArr.length();i++){
							JSONObject baseP = baseArr.getJSONObject(i);
							baseP.put("productName", transportation.getJSONObject("product").getJSONObject("genericProduct").getJSONArray("productId"));
						}
					}
				}
			}
		}
	}


	private static void setRouteDetails(JSONArray baseArr, JSONArray calcArr, JSONArray routes) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<routes.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject route = routes.getJSONObject(j);
				if(route.has("operatorCountry") && !route.getString("operatorCountry").equalsIgnoreCase("All"))
					calculation.put("operatorCountry", route.getString("operatorCountry"));
				if(route.has("fromCity") && !route.getString("fromCity").equalsIgnoreCase("All"))
					calculation.put("routeFromCity", route.getString("fromCity"));
				if(route.has("toCity") && !route.getString("toCity").equalsIgnoreCase("All"))
					calculation.put("routeToCity", route.getString("toCity"));
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, route.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setAdvancedCommercials(JSONObject mdmDefn, JSONArray commercialHead, JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject standardCommercial, String supplier, JSONArray supplierMarkets, String productCategorySubType, String productName, String productCategory, String supplierCommercialDataID) throws Exception {
		Boolean settlement=false;
		JSONObject settlementObject = new JSONObject();
		String advanceCommercialDataID = supplierCommercialDataID+"|advanceCommercialData|";
		String tempAdvCommID = advanceCommercialDataID;
		for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length();i++){
			String CommName = "";
			String CommHeadName ="";
			JSONObject advanceCommercialData = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i);
			JSONObject advanceCommercial = advanceCommercialData.getJSONObject("advanceCommercial");
			advanceCommercialDataID+=advanceCommercialData.getString("_id");
			String displayName = advanceCommercial.getJSONObject("commercialHeadInfo").getString("displayName");
			switch(displayName){
			case "Overriding Commission":{
				CommName = "overRidingCommission";
				CommHeadName = "Overriding";
				JSONObject overRidingCommission = advanceCommercial.getJSONObject("overRidingCommission");
				setContractType("Overriding Commission",overRidingCommission);
				setAdvancedCommercial(mainJson,"OverridingCommercialBaseDT","OverridingCommercialCalculationDT","Overriding",overRidingCommission,mdmDefn,commercialHead,overCT,overSet,productCategory,productCategorySubType,productName,advanceCommercialDataID);
				break;
			}
			case "Productivity Linked Bonus":{
				CommName = "plb";
				CommHeadName = "PLB";
				JSONObject plb = advanceCommercial.getJSONObject("plb");
				setContractType("Productivity Linked Bonus",plb);
				setAdvancedCommercial(mainJson,"PLBCommercialBaseDT","PLBCommercialCalculationDT","PLB",plb,mdmDefn,commercialHead,plbCT,plbSet,productCategory,productCategorySubType,productName,advanceCommercialDataID);
				break;
			}
			case "Sector Incentives":{
				CommName = "sectorWiseIncentives";
				CommHeadName = "SectorWiseIncentives";
				JSONObject sectorWiseIncentives = advanceCommercial.getJSONObject("sectorWiseIncentives");
				setContractType("Sector Incentives",sectorWiseIncentives);
				setAdvancedCommercial(mainJson,"SectorWiseIncentivesCommercialBaseDT","SectorWiseIncentivesCommercialCalculationDT","SectorWiseIncentives",sectorWiseIncentives,mdmDefn,commercialHead,destCT,destSet,productCategory,productCategorySubType,productName,advanceCommercialDataID);
				break;
			}
			case "Segment Fees":{
				CommName = "segmentFees";
				CommHeadName = "SegmentFees";
				JSONObject segmentFees = advanceCommercial.getJSONObject("segmentFees");
				setContractType("Segment Fees",segmentFees);
				setAdvancedCommercial(mainJson,"SegmentFeesCommercialBaseDT","SegmentFeesCommercialCalculationDT","SegmentFees",segmentFees,mdmDefn,commercialHead,segCT,segSet,productCategory,productCategorySubType,productName,advanceCommercialDataID);
				break;
			}
			case "Service Charges":{
				CommName = "serviceCharge";
				CommHeadName = "ServiceCharges";
				JSONObject serviceCharge = advanceCommercial.getJSONObject("serviceCharge");
				setContractType("Service Charges",serviceCharge);
				setAdvancedCommercial(mainJson,"ServiceChargeCommercialBaseDT","ServiceChargeCommercialCalculationDT","ServiceCharges",serviceCharge,mdmDefn,commercialHead,serCT,serSet,productCategory,productCategorySubType,productName,advanceCommercialDataID);
				break;
			}
			case "Issuance Fees":{
				CommName = "issuanceFees";
				CommHeadName = "IssuanceFees";
				JSONObject issuanceFees = advanceCommercial.getJSONObject("issuanceFees");
				setContractType("Issuance Fees",issuanceFees);
				setAdvancedCommercial(mainJson,"IssuanceFeesCommercialBaseDT","IssuanceFeesCommercialCalculationDT","IssuanceFees",issuanceFees,mdmDefn,commercialHead,issCT,issSet,productCategory,productCategorySubType,productName,advanceCommercialDataID);
				break;
			}
			case "Management Fee":{
				CommName = "managementFee";
				CommHeadName = "ManagementFee";
				JSONObject managementFee = advanceCommercial.getJSONObject("managementFee");
				setContractType("Management Fee",managementFee);
				setAdvancedCommercial(mainJson,"ManagementFeesBaseDT","ManagementFeesCalculationDT","ManagementFee",managementFee,mdmDefn,commercialHead,mngtCT,mngtSet,productCategory,productCategorySubType,productName,advanceCommercialDataID);
				break;
			}
			default:{
				settlement=true;
				String commercialName = CommonFunctions.getCommercialName(displayName);
				String commDefnID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
				String contractType = null;
				if(standardCommercial.getJSONObject("commercialInformation").has("isProvisional")){
					if(standardCommercial.getJSONObject("commercialInformation").getBoolean("isProvisional"))
						contractType="Provisional";
					else contractType="Final";
				}
				settlementObject = SettlementCommercials.settlementCommercials(commercialName,mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i),supplier,supplierMarkets,productCategory,productCategorySubType,productName,contractType,commDefnID,mdmDefn.getJSONArray("advanceDefinationData"));
			}

			}
			if(CommName!= null && CommName.trim().length()>1){
				JSONObject commObj = null;
				commObj = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").getJSONObject(CommName);
				mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead").put(CommonFunctions.getCommercialHead(commObj,CommHeadName));
			}
			advanceCommercialDataID = tempAdvCommID;
		}
		if(settlement){
			System.out.println("Bus Settlement: "+settlementObject.toString());
			InvokeRuleConfigurator.invokeSettlementRuleConfigurator(settlementObject.toString(),productName,ReceiveMDMRequest.method);
			SettlementCommercials.main=null;
		}
	}


	public static void setAdvancedCommercial(JSONObject mainJson, String baseDT, String calculationDT, String commercialName, JSONObject advanceCommercialNameObject, JSONObject mdmDefn, JSONArray commercialHead, String contractType, boolean settlementTransactionWise, String productCategory, String productCategorySubType, String productName, String advanceCommercialDataID) {
		String netOffCommercialHead=null;
		String commercialType = advanceCommercialNameObject.getJSONObject("commercialInformation").getString("commercialType");
		if(advanceCommercialNameObject.has("calculation")){
			if(advanceCommercialNameObject.getJSONObject("calculation").has("netOffCommercialHead"))
				netOffCommercialHead = CommonFunctions.getCommercialName(advanceCommercialNameObject.getJSONObject("calculation").getString("netOffCommercialHead"));
		}
		CommonFunctions.setCommercialHead(commercialName,commercialHead,netOffCommercialHead,commercialType,contractType,settlementTransactionWise);

		JSONArray baseArr =new JSONArray();
		JSONArray calcArr =new JSONArray();
		JSONObject base = new JSONObject();
		JSONObject calculation = new JSONObject();
		base.put("RuleID", "BASE");
		base.put("selectedRow", commDefnRuleID);
		base.put("productCategory", productCategory);
		base.put("productCategorySubType", productCategorySubType);
		base.put("productName", productName);
		calculation.put("RuleID", "CALCULATION");
		calculation.put("selectedRow", "BASE");
		base.put("type", "base");
		calculation.put("type", "calculation");
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", advanceCommercialNameObject.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", advanceCommercialNameObject.getString("contractValidityTo").substring(0, 19));
		base.put("contractValidity", contractValidity);
		baseArr.put(base);
		calcArr.put(calculation);
		mainJson.put(baseDT, baseArr);
		mainJson.put(calculationDT, calcArr);

		if(advanceCommercialNameObject.getJSONArray("supplierRate").length()>0)
			CommonFunctions.getSupplierRate(advanceCommercialNameObject.getJSONArray("supplierRate"),calcArr);

		if(advanceCommercialNameObject.getJSONArray("product").length()>0){
			JSONArray product = advanceCommercialNameObject.getJSONArray("product");
			CommonFunctions.getProductDetails(product,baseArr,calcArr);
			baseArr.remove(0);
			calcArr.remove(0);
		}

		if(advanceCommercialNameObject.getJSONArray("client").length()>0)
			CommonFunctions.getClientDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("client"));

		boolean slab=false;
		if((advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.getString("calculationType").equals("slab")) || (!advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.has("slab"))){
			slab=true;
			advanceCommercialDataID+="|";
			CommonFunctions.getSlabDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("slab"),advanceCommercialDataID);
		}

		if(!slab){
			int length=calcArr.length();
			advanceCommercialDataID+="|fixed";
			for(int i=0;i<length;i++){
				calcArr.getJSONObject(i).put("mdmRuleID", advanceCommercialDataID);
				CommonFunctions.getFixedDetails(calcArr.getJSONObject(i), advanceCommercialNameObject.getJSONObject("fixed"));
			}
		}

		if(advanceCommercialNameObject.has("advanceDefinationId")){
			String advDefnID = advanceCommercialNameObject.getString("advanceDefinationId");
			for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
				JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
				if(advanceDefinationData.getString("_id").equals(advDefnID)){
					JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject("advanceDefinitionTransportation");
					CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true);
				}
			}
		}
	}


	private static void setContractType(String displayName, JSONObject jsonObject) {
		String contractType="Final";boolean settlementTransactionWise=false;
		if(jsonObject.getJSONObject("commercialInformation").has("isProvisional")){
			if(jsonObject.getJSONObject("commercialInformation").getBoolean("isProvisional"))
				contractType="Provisional";
			else contractType="Final";
		}
		if(jsonObject.has("isSettlementTransactionWise"))
			settlementTransactionWise= jsonObject.getBoolean("isSettlementTransactionWise");

		switch(displayName){
		case "Overriding Commission":{overCT=contractType;overSet=settlementTransactionWise;break;}
		case "Productivity Linked Bonus":{plbCT=contractType;plbSet=settlementTransactionWise;break;}
		case "Destination Incentives":{destCT=contractType;destSet=settlementTransactionWise;break;}
		case "Segment Fees":{segCT=contractType;segSet=settlementTransactionWise;break;}
		case "Service Charges":{serCT=contractType;serSet=settlementTransactionWise;break;}
		case "Issuance Fees":{issCT=contractType;issSet=settlementTransactionWise;break;}
		case "Management Fee":{mngtCT=contractType;mngtSet=settlementTransactionWise;break;}
		default:System.out.println("default of Holidays.setContractType");
		}
	}
}
