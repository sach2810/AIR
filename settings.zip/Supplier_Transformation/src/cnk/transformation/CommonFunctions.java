package cnk.transformation;

import java.util.HashSet;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class CommonFunctions {
	public static String commDefnID;
	
	public static JSONObject getStandardCommercialDefiniton(JSONObject mdmDefn, String productCategory,String productCategorySubType, String supplier, JSONArray supplierMarkets, String commercialName) {
		JSONObject commDefn = new JSONObject();
		if(supplier!=null)
			commDefn.put("supplier", supplier);
		commDefnID=productCategorySubType+supplier+"_"+mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
		commDefn.put("RuleID", commDefnID);
		commDefn.put("type", "definition");
		JSONObject commercialDefinition = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition");
		if(commercialDefinition.has("supplierMarkets"))
			if(!(commercialDefinition.getJSONArray("supplierMarkets").getString(0).equalsIgnoreCase("ALL")))
				commDefn.put("supplierMarket",commercialDefinition.getJSONArray("supplierMarkets"));
		JSONObject commHead = new JSONObject();
		JSONObject standardCommercial = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
		commHead.put("commercialHeadName", commercialName);
		commHead.put("commercialType", standardCommercial.getJSONObject("commercialInformation").getString("commercialType"));
		commHead.put("settlementTransactionWise", standardCommercial.getBoolean("isSettlementTransactionWise"));
		if(standardCommercial.getJSONObject("commercialInformation").has("isProvisional"))
			commHead.put("contractType", "Provisional");
		else commHead.put("contractType", "Final");
		commHead.put("commissionable", standardCommercial.getBoolean("isCommisionable"));
		if(standardCommercial.getJSONObject("calculation").has("markDown")){
			if(standardCommercial.getJSONObject("calculation").getJSONObject("markDown").has("applicable"))
				commHead.put("markDownApplicable", standardCommercial.getJSONObject("calculation").getJSONObject("markDown").getBoolean("applicable"));
			if(standardCommercial.getJSONObject("calculation").getJSONObject("markDown").has("clientType"))
				commHead.put("markDownClientApplicable", standardCommercial.getJSONObject("calculation").getJSONObject("markDown").getString("clientType"));
		}
		if(standardCommercial.getJSONObject("calculation").getJSONObject("markUp").has("minimumPercent"))
			commHead.put("minimumMarkUpPercentage", standardCommercial.getJSONObject("calculation").getJSONObject("markUp").get("minimumPercent"));
		if(standardCommercial.getJSONObject("calculation").getJSONObject("markUp").has("maximumPercent"))
			commHead.put("maximumMarkUpPercentage", standardCommercial.getJSONObject("calculation").getJSONObject("markUp").get("maximumPercent"));
		if(standardCommercial.getJSONObject("calculation").getJSONObject("markUp").has("clientType"))
			commHead.put("markUpClientType", standardCommercial.getJSONObject("calculation").getJSONObject("markUp").getString("clientType"));
		JSONArray commHeadArr = new JSONArray();
		commHeadArr.put(commHead);
		commDefn.put("commercialHead", commHeadArr);
		return commDefn;
	}
	
	
	public static JSONObject getStandardCommercialDefinitonCU(JSONObject stdComm, String productCategory, String productCategorySubType, String supplier, JSONArray supplierMarkets, String commercialHeadName) {
		JSONObject commDefn = new JSONObject();
		commDefn.put("RuleID", supplier + "_" + productCategory + "_" + productCategorySubType);
		commDefn.put("type", "definition");
		commDefn.put("supplier", supplier);
		commDefn.put("supplierMarket", supplierMarkets);
		JSONObject commHead = new JSONObject();
		commHead.put("commercialHeadName", commercialHeadName);
		commHead.put("commercialType", stdComm.getJSONObject("commercialInformation").getString("commercialType"));
		commHead.put("settlementTransactionWise",stdComm.getBoolean("isSettlementTransactionWise"));
		commHead.put("commissionable", stdComm.getBoolean("isCommisionable"));
		if (stdComm.getJSONObject("commercialInformation").has("isProvisional"))
			commHead.put("contractType", "Provisional");
		else
			commHead.put("contractType", "Final");		
		if (stdComm.getJSONObject("calculation").has("markDown")) 
		{
			if (stdComm.getJSONObject("calculation").getJSONObject("markDown").has("applicable"))
				commHead.put("markDownApplicable",stdComm.getJSONObject("calculation").getJSONObject("markDown").getBoolean("applicable"));
			if (stdComm.getJSONObject("calculation").getJSONObject("markDown").has("clientType"))
				commHead.put("markDownClientApplicable",stdComm.getJSONObject("calculation").getJSONObject("markDown").getString("clientType"));
		}
		if (stdComm.getJSONObject("calculation").getJSONObject("markUp").has("minimumPercent"))
			commHead.put("minimumMarkUpPercentage", stdComm.getJSONObject("calculation").getJSONObject("markUp").get("minimumPercent"));
		if (stdComm.getJSONObject("calculation").getJSONObject("markUp").has("maximumPercent"))
			commHead.put("maximumMarkUpPercentage", stdComm.getJSONObject("calculation").getJSONObject("markUp").get("maximumPercent"));
		if (stdComm.getJSONObject("calculation").getJSONObject("markUp").has("clientType"))
			commHead.put("markUpClientType", stdComm.getJSONObject("calculation").getJSONObject("markUp").getString("clientType"));

		JSONArray commHeadArr = new JSONArray();
		commHeadArr.put(commHead);
		commDefn.put("commercialHead", commHeadArr);
		return commDefn;
	}
	
	
	public static void setCommercialHead(String commercialName, JSONArray commHead, String netOffCommercialHead, String commercialType, String contractType, boolean settlementTransactionWise) {
		JSONObject commercialData = new JSONObject();
		commercialData.put("commercialHeadName", commercialName);
		commercialData.put("commercialType", commercialType);
		commercialData.put("settlementTransactionWise", settlementTransactionWise);
		commercialData.put("contractType", contractType);
		commercialData.put("commissionable", false);
		commercialData.put("markDownApplicable", false);
		commercialData.put("minimumMarkUpPercentage", 0);
		commercialData.put("maximumMarkUpPercentage", 0);
		if(netOffCommercialHead!=null)
			commercialData.put("nettOffCommercialHeadName", netOffCommercialHead);

		commHead.put(commercialData);
	}
	
	
	public static JSONObject getCommercialHead(JSONObject commercialObject, String commercialHeadName) {
		JSONObject commHead = new JSONObject();
		commHead.put("commercialHeadName", commercialHeadName);
		commHead.put("commercialType", commercialObject.getJSONObject("commercialInformation").getString("commercialType"));
		commHead.put("contractType", "Final");
		commHead.put("commissionable", false);
		commHead.put("markDownApplicable",false);
		commHead.put("minimumMarkUpPercentage",0);
		commHead.put("maximumMarkUpPercentage",0);
		if(commercialHeadName == "IssuanceFees" || commercialHeadName == "ServiceCharge")
			commHead.put("settlementTransactionWise",commercialObject.getBoolean("isSettlementTransactionWise"));
		else commHead.put("settlementTransactionWise", false);

		if(commercialObject.has("calculation")){
			if(commercialObject.getJSONObject("calculation").has("netOffCommercialHead"))
				commHead.putOpt("nettOffCommercialHeadName", commercialObject.getJSONObject("calculation").getString("netOffCommercialHead"));
		}
		return commHead;
	}
	
	
	public static String getFareComponentString(JSONArray fareComponentsArr) {
		String fareComponent=null;int flag=0;
		for(int i=0;i<fareComponentsArr.length();i++){
			if(fareComponentsArr.get(i).equals("Basic")){
				flag=1;
			}
		}
		if(flag==1){
			fareComponent="Basic";
			for(int i=0;i<fareComponentsArr.length();i++){
				if(!fareComponentsArr.get(i).equals("Basic")){
					fareComponent+=","+fareComponentsArr.getString(i);
				}
			}
		}else{
			for(int i=0;i<fareComponentsArr.length();i++){
				if(i==0)
					fareComponent=fareComponentsArr.getString(i);
				else fareComponent+=","+fareComponentsArr.getString(i);
			}
		}
		return fareComponent;
	}
	
	
	public static void setTravelTicketing(JSONArray baseArr, JSONArray calcArr, JSONObject validity, boolean isTicketingInBase, boolean isTravelInBase) {
		int length = baseArr.length();
		JSONArray ticketingPlusTravel = validity.getJSONArray("ticketingPlusTravel");
		for(int i=0;i<length;i++){
			for(int j=0;j<ticketingPlusTravel.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(j);
				
				JSONArray tickincArr =new JSONArray();
				JSONArray tickexcArr =new JSONArray();
				JSONArray travelincArr =new JSONArray();
				JSONArray travelexcArr =new JSONArray();
				JSONObject indiTicketObj = new JSONObject();
				JSONObject indiTravelObj = new JSONObject();
				JSONObject indiTicketBlockObj = new JSONObject();
				JSONObject indiTravelBlockObj = new JSONObject();
				JSONArray ticketingDate = new JSONArray();
				JSONArray travelDate = new JSONArray();
				JSONObject inclusionTkt = new JSONObject();
				JSONObject exclusionTkt = new JSONObject();
				JSONObject inclusionTra = new JSONObject();
				JSONObject exclusionTra = new JSONObject();
				
				JSONObject ticketingObject = ticketPlusTravelObj.getJSONObject("ticket");
				if(ticketingObject.has("ticketingFrom")){
					if(ticketingObject.has("ticketingTo")){
						indiTicketObj.put("operator","BETWEEN");
						indiTicketObj.put("from", ticketingObject.getString("ticketingFrom").substring(0, 19));
						indiTicketObj.put("to", ticketingObject.getString("ticketingTo").substring(0, 19));
					}else{
						indiTicketObj.put("operator","GREATERTHANEQUALTO");
						indiTicketObj.put("value", ticketingObject.getString("ticketingFrom").substring(0, 19));
					}
				}else if(ticketingObject.has("ticketingTo")){
					indiTicketObj.put("operator","LESSTHANEQUALTO");
					indiTicketObj.put("value", ticketingObject.getString("ticketingTo").substring(0, 19));
				}
				
				if(ticketingObject.has("blockOutFrom")){
					if(ticketingObject.has("blockOutTo")){
						indiTicketBlockObj.put("operator", "BETWEEN");
						indiTicketBlockObj.put("from", ticketingObject.getString("blockOutFrom").substring(0, 19));
						indiTicketBlockObj.put("to", ticketingObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiTicketBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTicketBlockObj.put("value", ticketingObject.getString("blockOutFrom").substring(0, 19));
					}
				}else{
					if(ticketingObject.has("blockOutTo")){
						indiTicketBlockObj.put("operator", "LESSTHANEQUALTO");
						indiTicketBlockObj.put("value", ticketingObject.getString("blockOutTo").substring(0, 19));
					}
				}
				
				JSONObject travelObject = ticketPlusTravelObj.getJSONObject("travel");
				if(travelObject.has("travelFrom")){
					if(travelObject.has("travelTo")){
						indiTravelObj.put("operator","BETWEEN");
						indiTravelObj.put("from", travelObject.getString("travelFrom").substring(0, 19));
						indiTravelObj.put("to", travelObject.getString("travelTo").substring(0, 19));
					}else{
						indiTravelObj.put("operator","GREATERTHANEQUALTO");
						indiTravelObj.put("value", travelObject.getString("travelFrom").substring(0, 19));
					}
				}else if(travelObject.has("travelTo")){
					indiTravelObj.put("operator","LESSTHANEQUALTO");
					indiTravelObj.put("value", travelObject.getString("travelTo").substring(0, 19));
				}
				if(travelObject.has("blockOutFrom")){
					if(travelObject.has("blockOutTo")){
						indiTravelBlockObj.put("operator", "BETWEEN");
						indiTravelBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
						indiTravelBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiTravelBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTravelBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
					}
				}else{
					if(travelObject.has("blockOutTo")){
						indiTravelBlockObj.put("operator", "LESSTHANEQUALTO");
						indiTravelBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
					}
				}
				
				if(indiTicketObj!=null){
					tickincArr.put(indiTicketObj);
					inclusionTkt.put("inclusion",tickincArr);
					ticketingDate.put(inclusionTkt);
				}
				if(indiTicketBlockObj!=null){
					tickexcArr.put(indiTicketBlockObj);
					exclusionTkt.put("exclusion",tickexcArr);
					ticketingDate.put(exclusionTkt);
				}
				if(indiTravelObj!=null){
					travelincArr.put(indiTravelObj);
					inclusionTra.put("inclusion",travelincArr);
					travelDate.put(inclusionTra);
				}
				if(indiTravelBlockObj!=null){
					travelexcArr.put(indiTravelBlockObj);
					exclusionTra.put("exclusion",travelexcArr);
					travelDate.put(exclusionTra);
				}
				
				if(isTicketingInBase)
					base.put("ticketing", ticketingDate);
				else calculation.put("ticketing", ticketingDate);
				
				if(isTravelInBase)
					base.put("travel", travelDate);
				else calculation.put("travel", travelDate);
				
				setRuleID(baseArr, calcArr, base, calculation, ticketPlusTravelObj.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void insertSalePlusTravel(JSONArray baseArr, JSONArray calcArr, JSONArray salePlusTravel, boolean isSalesInBase, boolean isTravelInBase) {
		int length=baseArr.length();
		for(int j=0;j<length;j++){
			for(int i=0;i<salePlusTravel.length();i++){
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(i);
				JSONObject sale = salePlusTravelObject.getJSONObject("sales");
				JSONObject travel = salePlusTravelObject.getJSONObject("travel");
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(j).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(j).toString()));
				JSONArray saleArray = new JSONArray();
				JSONArray travelArray = new JSONArray();
				JSONObject saleinclusion = new JSONObject();
				JSONObject saleexclusion = new JSONObject();
				JSONObject travelinclusion = new JSONObject();
				JSONObject travelexclusion = new JSONObject();
				JSONArray salesDateInclusionArr = new JSONArray();
				JSONArray travelDateInclusionArr = new JSONArray();
				JSONArray salesDateExclusionArr = new JSONArray();
				JSONArray travelDateExclusionArr = new JSONArray();
				JSONObject saleDate = new JSONObject();
				JSONObject travelDate = new JSONObject();
				JSONObject saleExcDate = new JSONObject();
				JSONObject travelExcDate = new JSONObject();
				
				//sale
				if(sale.has("saleFrom")){
					if(sale.has("saleTo")){
						saleDate.put("operator", "BETWEEN");
						saleDate.put("from", sale.getString("saleFrom"));
						saleDate.put("to", sale.getString("saleTo"));
					}else{
						saleDate.put("operator", "GREATERTHANEQUALTO");
						saleDate.put("from", sale.getString("saleFrom"));
					}
				}else if(sale.has("saleTo")){
					saleDate.put("operator", "LESSTHANEQUALTO");
					saleDate.put("to", sale.getString("saleTo"));
				}
				//travel
				if(travel.has("travelFrom")){
					if(travel.has("travelTo")){
						travelDate.put("operator", "BETWEEN");
						travelDate.put("from", travel.getString("travelFrom"));
						travelDate.put("to", travel.getString("travelTo"));
					}else{
						travelDate.put("operator", "GREATERTHANEQUALTO");
						travelDate.put("from", travel.getString("travelFrom"));
					}
				}else if(travel.has("travelTo")){
					travelDate.put("operator", "LESSTHANEQUALTO");
					travelDate.put("to", travel.getString("travelTo"));
				}
				//blockOut sale
				if(sale.has("blockOutFrom")){
					if(sale.has("blockOutTo")){
						saleExcDate.put("operator", "BETWEEN");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
						saleExcDate.put("to", sale.getString("blockOutTo"));
					}else{
						saleExcDate.put("operator", "GREATERTHANEQUALTO");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
					}
				}else if(sale.has("blockOutTo")){
					saleExcDate.put("operator", "LESSTHANEQUALTO");
					saleExcDate.put("to", sale.getString("blockOutTo"));
				}
				//blockOut travel
				if(travel.has("blockOutFrom")){
					if(travel.has("blockOutTo")){
						travelExcDate.put("operator", "BETWEEN");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
						travelExcDate.put("to", travel.getString("blockOutTo"));
					}else{
						travelExcDate.put("operator", "GREATERTHANEQUALTO");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
					}
				}else if(travel.has("blockOutTo")){
					travelExcDate.put("operator", "LESSTHANEQUALTO");
					travelExcDate.put("to", travel.getString("blockOutTo"));
				}
				
				if(saleDate.has("operator")){
					salesDateInclusionArr.put(saleDate);
					saleinclusion.put("inclusion", salesDateInclusionArr);
					saleArray.put(saleinclusion);
				}if(travelDate.has("operator")){
					travelDateInclusionArr.put(travelDate);
					travelinclusion.put("inclusion", travelDateInclusionArr);
					travelArray.put(travelinclusion);
				}if(saleExcDate.has("operator")){
					salesDateExclusionArr.put(saleExcDate);
					saleexclusion.put("exclusion", salesDateExclusionArr);
					saleArray.put(saleexclusion);
				}if(travelExcDate.has("operator")){
					travelDateExclusionArr.put(travelExcDate);
					travelexclusion.put("exclusion", travelDateExclusionArr);
					travelArray.put(travelexclusion);
				}
				
				if(isSalesInBase)
					base.put("sale", saleArray);
				else calculation.put("sale", saleArray);
				
				if(isTravelInBase)
					base.put("travel", travelArray);
				else calculation.put("travel", travelArray);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, salePlusTravelObject.getString("_id"));
			}
		}
		for(int j=0;j<length;j++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void insertPLBTicketingPlusTravel(JSONArray ticketingPlusTravel, JSONArray baseArr, JSONArray calcArr,boolean isTicketingInBase,boolean isTravelInBase) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<ticketingPlusTravel.length();j++){
				JSONObject salePlusTravelObject = ticketingPlusTravel.getJSONObject(j);
				JSONObject trigPayout = CommonFunctions.getTriggerPayoutObject(salePlusTravelObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray saleArray = new JSONArray();
				JSONArray travelArray = new JSONArray();
				JSONObject saleinclusion = new JSONObject();
				JSONObject saleexclusion = new JSONObject();
				JSONObject travelinclusion = new JSONObject();
				JSONObject travelexclusion = new JSONObject();
				JSONArray salesDateInclusionArr = new JSONArray();
				JSONArray travelDateInclusionArr = new JSONArray();
				JSONArray salesDateExclusionArr = new JSONArray();
				JSONArray travelDateExclusionArr = new JSONArray();
				JSONObject ticket = salePlusTravelObject.getJSONObject("ticket");
				JSONObject travel = salePlusTravelObject.getJSONObject("travel");
				JSONObject saleDate = new JSONObject();
				JSONObject travelDate = new JSONObject();
				JSONObject saleExcDate = new JSONObject();
				JSONObject travelExcDate = new JSONObject();
				//ticket
				if(ticket.has("ticketingFrom")){
					if(ticket.has("ticketingTo")){
						saleDate.put("operator", "BETWEEN");
						saleDate.put("from", ticket.getString("ticketingFrom"));
						saleDate.put("to", ticket.getString("ticketingTo"));
					}else{
						saleDate.put("operator", "GREATERTHANEQUALTO");
						saleDate.put("from", ticket.getString("ticketingFrom"));
					}
				}else if(ticket.has("ticketingTo")){
					saleDate.put("operator", "LESSTHANEQUALTO");
					saleDate.put("to", ticket.getString("ticketingTo"));
				}
				//travel
				if(travel.has("travelFrom")){
					if(travel.has("travelTo")){
						travelDate.put("operator", "BETWEEN");
						travelDate.put("from", travel.getString("travelFrom"));
						travelDate.put("to", travel.getString("travelTo"));
					}else{
						travelDate.put("operator", "GREATERTHANEQUALTO");
						travelDate.put("from", travel.getString("travelFrom"));
					}
				}else if(travel.has("travelTo")){
					travelDate.put("operator", "LESSTHANEQUALTO");
					travelDate.put("to", travel.getString("travelTo"));
				}
				//blockOut ticket
				if(ticket.has("blockOutFrom")){
					if(ticket.has("blockOutTo")){
						saleExcDate.put("operator", "BETWEEN");
						saleExcDate.put("from", ticket.getString("blockOutFrom"));
						saleExcDate.put("to", ticket.getString("blockOutTo"));
					}else{
						saleExcDate.put("operator", "GREATERTHANEQUALTO");
						saleExcDate.put("from", ticket.getString("blockOutFrom"));
					}
				}else if(ticket.has("blockOutTo")){
					saleExcDate.put("operator", "LESSTHANEQUALTO");
					saleExcDate.put("to", ticket.getString("blockOutTo"));
				}
				//blockOut travel
				if(travel.has("blockOutFrom")){
					if(travel.has("blockOutTo")){
						travelExcDate.put("operator", "BETWEEN");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
						travelExcDate.put("to", travel.getString("blockOutTo"));
					}else{
						travelExcDate.put("operator", "GREATERTHANEQUALTO");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
					}
				}else if(travel.has("blockOutTo")){
					travelExcDate.put("operator", "LESSTHANEQUALTO");
					travelExcDate.put("to", travel.getString("blockOutTo"));
				}

				saleArray.put(trigPayout);
				travelArray.put(trigPayout);

				if(saleDate.has("operator")){
					salesDateInclusionArr.put(saleDate);
					saleinclusion.put("inclusion", salesDateInclusionArr);
					saleArray.put(saleinclusion);
				}
				if(travelDate.has("operator")){
					travelDateInclusionArr.put(travelDate);
					travelinclusion.put("inclusion", travelDateInclusionArr);
					travelArray.put(travelinclusion);
				}
				if(saleExcDate.has("operator")){
					salesDateExclusionArr.put(saleExcDate);
					saleexclusion.put("exclusion", salesDateExclusionArr);
					saleArray.put(saleexclusion);
				}
				if(travelExcDate.has("operator")){
					travelDateExclusionArr.put(travelExcDate);
					travelexclusion.put("exclusion", travelDateExclusionArr);
					travelArray.put(travelexclusion);
				}
				
				if(isTicketingInBase)
					base.put("ticketing", saleArray);
				else calculation.put("ticketing", saleArray);
				
				if(isTravelInBase)
					base.put("travel", travelArray);
				else calculation.put("travel", travelArray);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, salePlusTravelObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void insertPLBSalePlusTravel(JSONArray salePlusTravel, JSONArray baseArr, JSONArray calcArr,boolean isSalesInBase, boolean isTravelInBase) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(j);
				JSONObject trigPayout = CommonFunctions.getTriggerPayoutObject(salePlusTravelObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray saleArray = new JSONArray();
				JSONArray travelArray = new JSONArray();
				JSONObject saleinclusion = new JSONObject();
				JSONObject saleexclusion = new JSONObject();
				JSONObject travelinclusion = new JSONObject();
				JSONObject travelexclusion = new JSONObject();
				JSONArray salesDateInclusionArr = new JSONArray();
				JSONArray travelDateInclusionArr = new JSONArray();
				JSONArray salesDateExclusionArr = new JSONArray();
				JSONArray travelDateExclusionArr = new JSONArray();
				JSONObject sale = salePlusTravelObject.getJSONObject("sales");
				JSONObject travel = salePlusTravelObject.getJSONObject("travel");
				JSONObject saleDate = new JSONObject();
				JSONObject travelDate = new JSONObject();
				JSONObject saleExcDate = new JSONObject();
				JSONObject travelExcDate = new JSONObject();
				//sale
				if(sale.has("saleFrom")){
					if(sale.has("saleTo")){
						saleDate.put("operator", "BETWEEN");
						saleDate.put("from", sale.getString("saleFrom"));
						saleDate.put("to", sale.getString("saleTo"));
					}else{
						saleDate.put("operator", "GREATERTHANEQUALTO");
						saleDate.put("from", sale.getString("saleFrom"));
					}
				}else if(sale.has("saleTo")){
					saleDate.put("operator", "LESSTHANEQUALTO");
					saleDate.put("to", sale.getString("saleTo"));
				}
				//travel
				if(travel.has("travelFrom")){
					if(travel.has("travelTo")){
						travelDate.put("operator", "BETWEEN");
						travelDate.put("from", travel.getString("travelFrom"));
						travelDate.put("to", travel.getString("travelTo"));
					}else{
						travelDate.put("operator", "GREATERTHANEQUALTO");
						travelDate.put("from", travel.getString("travelFrom"));
					}
				}else if(travel.has("travelTo")){
					travelDate.put("operator", "LESSTHANEQUALTO");
					travelDate.put("to", travel.getString("travelTo"));
				}
				//blockOut sale
				if(sale.has("blockOutFrom")){
					if(sale.has("blockOutTo")){
						saleExcDate.put("operator", "BETWEEN");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
						saleExcDate.put("to", sale.getString("blockOutTo"));
					}else{
						saleExcDate.put("operator", "GREATERTHANEQUALTO");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
					}
				}else if(sale.has("blockOutTo")){
					saleExcDate.put("operator", "LESSTHANEQUALTO");
					saleExcDate.put("to", sale.getString("blockOutTo"));
				}
				//blockOut travel
				if(travel.has("blockOutFrom")){
					if(travel.has("blockOutTo")){
						travelExcDate.put("operator", "BETWEEN");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
						travelExcDate.put("to", travel.getString("blockOutTo"));
					}else{
						travelExcDate.put("operator", "GREATERTHANEQUALTO");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
					}
				}else if(travel.has("blockOutTo")){
					travelExcDate.put("operator", "LESSTHANEQUALTO");
					travelExcDate.put("to", travel.getString("blockOutTo"));
				}
				
				saleArray.put(trigPayout);
				travelArray.put(trigPayout);
				
				if(saleDate.has("operator")){
					salesDateInclusionArr.put(saleDate);
					saleinclusion.put("inclusion", salesDateInclusionArr);
					saleArray.put(saleinclusion);
				}
				if(travelDate.has("operator")){
					travelDateInclusionArr.put(travelDate);
					travelinclusion.put("inclusion", travelDateInclusionArr);
					travelArray.put(travelinclusion);
				}
				if(saleExcDate.has("operator")){
					salesDateExclusionArr.put(saleExcDate);
					saleexclusion.put("exclusion", salesDateExclusionArr);
					saleArray.put(saleexclusion);
				}
				if(travelExcDate.has("operator")){
					travelDateExclusionArr.put(travelExcDate);
					travelexclusion.put("exclusion", travelDateExclusionArr);
					travelArray.put(travelexclusion);
				}
				
				if(isSalesInBase)
					base.put("sale", saleArray);
				else calculation.put("sale", saleArray);
				
				if(isTravelInBase)
					base.put("travel", travelArray);
				else calculation.put("travel", travelArray);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, salePlusTravelObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void setDate(JSONArray baseArr, JSONArray calcArr, JSONArray dateArray, String date, boolean inBase) {
		String from = date+"From";
		String to = date+"To";

		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject dateObject =dateArray.getJSONObject(j);

				JSONArray incArr =new JSONArray();
				JSONArray excArr =new JSONArray();
				JSONObject indiObj = new JSONObject();
				JSONObject indiBlockObj = new JSONObject();
				JSONArray Date = new JSONArray();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();

				if(dateObject.has(from)){
					if(dateObject.has(to)){
						indiObj.put("operator","BETWEEN");
						indiObj.put("from", dateObject.getString(from).substring(0, 19));
						indiObj.put("to", dateObject.getString(to).substring(0, 19));
					}else{
						indiObj.put("operator","GREATERTHANEQUALTO");
						indiObj.put("value", dateObject.getString(from).substring(0, 19));
					}
				}else if(dateObject.has(to)){
					indiObj.put("operator","LESSTHANEQUALTO");
					indiObj.put("value", dateObject.getString(to).substring(0, 19));
				}

				if(dateObject.has("blockOutFrom")){
					if(dateObject.has("blockOutTo")){
						indiBlockObj.put("operator", "BETWEEN");
						indiBlockObj.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
						indiBlockObj.put("to", dateObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiBlockObj.put("value", dateObject.getString("blockOutFrom").substring(0, 19));
					}
				}else{
					if(dateObject.has("blockOutTo")){
						indiBlockObj.put("operator", "LESSTHANEQUALTO");
						indiBlockObj.put("value", dateObject.getString("blockOutTo").substring(0, 19));
					}
				}

				if(indiObj.has("operator")){
					incArr.put(indiObj);
					inclusion.put("inclusion",incArr);
					Date.put(inclusion);
				}
				if(indiBlockObj.has("operator")){
					excArr.put(indiBlockObj);
					exclusion.put("exclusion",excArr);
					Date.put(exclusion);
				}
				
				if(inBase)
					base.put(date, Date);
				else calculation.put(date, Date);
				
				setRuleID(baseArr, calcArr, base, calculation, dateObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
		
		
	public static String getCommercialName(String displayName) {
		switch(displayName){
		case "Standard Commercial": return "Standard";
		case "Overriding Commission": return "Overriding";
		case "Productivity Linked Bonus": return "PLB";
		case "Sector Incentives": return "SectorWiseIncentive";
		case "Segment Fees": return "SegmentFee";
		case "Management Fee": return "ManagementFee";
		case "Service Charges": return "ServiceCharge";
		case "Discount": return "Discount";
		case "MarkUp": return "MarkUp";
		case "Destination Incentives": return "DestinationIncentive";
		case "Issuance Fees": return "IssuanceFee";
		case "Commission": return "Commission";
		case "Maintenance Fees": return "MaintenanceFees";
		case "Integration Fees": return "IntegrationFees";
		case "Licence Fees": return "LicenceFees";
		case "Web Service Fees": return "WebServiceFees";
		case "Loyalty Bonus": return "LoyaltyBonus";
		case "Preference Benefit": return "PreferenceBenefit";
		case "Retainer Fee": return "RetainerFee";
		case "Listing Fee": return "ListingFee";
		case "Content Access Fee": return "ContentAccessFee";
		case "Sign Up Fees": return "SignUpFees";
		case "Sign Up Bonus": return "SignUpBonus";
		case "Look To Book": return "LookToBook";
		case "MSF Fees": return "MSFFees";
		case "Incentives On Top Up": return "IncentivesOnTopUp";
		case "Termination Fees": return "TerminationFees";
		case "Penalty Fee / Kick Back": return "PenaltyFee";
		case "Free Of Cost (FOC)": return "FreeOfCost";
		case "Lost Ticket": return "LostTicket";
		case "Remittance Fees": return "RemittanceFees";
		case "Training Fees": return "TrainingFees";
		default:System.out.println("deafult of getCommercialName due to: "+displayName);
		}
		return null;
	}


	public static String getProductName(JSONObject commercialDefinition) {
		switch(commercialDefinition.getString("productCategory")){
		case "Accommodation":return "accomodation";
		case "Activities": return "activities";
		case "Combination": return "combination";
		case "Holidays": return "holidays";
		case "Other Products": {
			switch(commercialDefinition.getString("productCategorySubType")){
			case "Insurance": return "insurance";
			case "Visa": return "visa";
			}
		}
		case "Transportation":{
			switch(commercialDefinition.getString("productCategorySubType")){
			case "Bus": return "bus";
			case "Car": return "carrentals";
			case "Cruise": return "cruise";
			case "European Rail": return "rail";
			case "Flight": return "air";
			case "Indian Rail": return "rail";
			case "Rail": return "rail";
			case "Rental": return "rentals";
			case "Transfer": return "transfers";
			}
		}
		}
		return null;
	}


	public static void getProductDetails(JSONArray productInformationArr, JSONArray baseArr, JSONArray calcArr) {
		int length = baseArr.length();
		for(int j=0;j<length;j++){
			for(int i=0;i<productInformationArr.length();i++){
				JSONObject productInformation = productInformationArr.getJSONObject(i);
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(j).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(j).toString()));
				if(productInformation.has("productName") && !productInformation.getString("productName").equalsIgnoreCase("All"))
					calculation.put("productName", productInformation.getString("productName"));
				if(productInformation.has("brand") && !productInformation.getString("brand").equalsIgnoreCase("All"))
					calculation.put("productBrand", productInformation.getString("brand"));
				if(productInformation.has("chain") && !productInformation.getString("chain").equalsIgnoreCase("All"))
					calculation.put("productChain", productInformation.getString("chain"));

				setRuleID(baseArr, calcArr, base, calculation, productInformation.getString("_id"));
			}
		}
	}


	public static void getClientDetails(JSONArray baseArr, JSONArray calcArr, JSONArray clientArr) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<clientArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject client = clientArr.getJSONObject(j);
				if(client.has("clientName") && !client.getString("clientName").equalsIgnoreCase("All"))
					base.put("clientName", client.getString("clientName"));
				if(client.has("clientType") && !client.getString("clientType").equalsIgnoreCase("All")){
					if(client.getString("clientType").equalsIgnoreCase("Both"))
						base.put("clientType",new String[]{"B2B","B2C"});
					else base.put("clientType", client.getString("clientType"));
				}
				if(client.has("clientgroup") && !client.getString("clientgroup").equalsIgnoreCase("All"))
					base.put("clientGroup", client.getString("clientgroup"));
				setRuleID(baseArr, calcArr, base, calculation, client.getString("_id"));
			}
		}
		for(int j=0;j<length;j++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void setCLientDetails(String baseDT, String calculationDT,JSONObject commercial, JSONObject mainJson) {
		if(commercial.has("clients") || commercial.has("client")){
			JSONArray clientBaseArr = new JSONArray();
			JSONArray clientCalcArr = new JSONArray();
			JSONArray client = commercial.has("clients") ? commercial.getJSONArray("clients") : commercial.getJSONArray("client");	
			if(client.length()>0){
				for(int i =0; i<client.length(); i++){
					for(int j =0; j<mainJson.getJSONArray(baseDT).length();j++){
						JSONObject clientBaseObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(baseDT).getJSONObject(j).toString()));
						JSONObject clientCalcObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(calculationDT).getJSONObject(j).toString()));
						if(client.getJSONObject(i).has("clientType") && !client.getJSONObject(i).getString("clientType").equalsIgnoreCase("All")){
							if(client.getJSONObject(i).getString("clientType").equalsIgnoreCase("Both"))
								clientBaseObj.put("clientType",new String[]{"B2B","B2C"});
							else clientBaseObj.put("clientType",client.getJSONObject(i).getString("clientType"));
						}
						if(client.getJSONObject(i).has("clientGroup") && !client.getJSONObject(i).getString("clientGroup").equalsIgnoreCase("All"))
							clientBaseObj.put("clientGroup",client.getJSONObject(i).getString("clientGroup"));
						if(client.getJSONObject(i).has("clientName") && !client.getJSONObject(i).getString("clientName").equalsIgnoreCase("All"))
							clientBaseObj.put("clientName",client.getJSONObject(i).getString("clientName"));	
						if(client.getJSONObject(i).has("_id") && client.length()>1){
							clientBaseObj.put("RuleID", clientBaseObj.getString("RuleID")+client.getJSONObject(i).getString("_id"));
							clientCalcObj.put("RuleID", clientCalcObj.getString("RuleID")+client.getJSONObject(i).getString("_id"));
						}
						clientBaseArr.put(clientBaseObj);
						clientCalcArr.put(clientCalcObj);
					}	
				}
				mainJson.put(baseDT,clientBaseArr);
				mainJson.put(calculationDT,clientCalcArr);	
			}
		}
	}
	
	
	public static void getSlabDetails(JSONArray baseArr, JSONArray calcArr, JSONArray slabArr, String mdmruleID) {
		int length = baseArr.length();
		String tempRuleID = mdmruleID+="slab|";
		for(int i=0;i<length;i++){
			for(int j=0;j<slabArr.length();j++){
				JSONObject slab = slabArr.getJSONObject(j);
				JSONArray currencyDetails = slab.getJSONArray("currencyDetails");
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				if(slab.has("slabType"))
					calculation.put("slabType", slab.getString("slabType"));
				String slabtypeValue="BETWEEN";
				for(int k=0;k<currencyDetails.length();k++){
					JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
					slabtypeValue+=";"+currencyDetailsObject.get("fromValue").toString()+";"+currencyDetailsObject.get("toValue").toString();
					calculation.put("slabTypeValue",slabtypeValue);
				}
				getFixedDetails(calculation, slab);
				mdmruleID+=slab.getString("_id");
				calculation.put("mdmRuleID", mdmruleID);
				setRuleID(baseArr, calcArr, base, calculation, slab.getString("_id"));
				mdmruleID= tempRuleID;
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getPLBDates(JSONArray baseArr, JSONArray calcArr, JSONArray dateArr, String date, boolean inBase) {
		String from = date+"From";
		String to = date+"To";
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArr.length();j++){
				JSONObject dateObject = dateArr.getJSONObject(j);
				JSONObject trigPayout = getTriggerPayoutObject(dateObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject DATEInc = new JSONObject();
				JSONObject DATEExc = new JSONObject();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();
				JSONArray DateInclusionArr = new JSONArray();
				JSONArray DateExclusionArr = new JSONArray();
				JSONArray mainDateArray = new JSONArray();
				if(dateObject.has(from)){
					if(dateObject.has(to)){
						DATEInc.put("operator", "BETWEEN");
						DATEInc.put("from", dateObject.getString(from).substring(0, 19));
						DATEInc.put("to", dateObject.getString(to).substring(0, 19));
					}else{
						DATEInc.put("operator", "GREATERTHANEQUALTO");
						DATEInc.put("from", dateObject.getString(from).substring(0, 19));
					}
				}else if(dateObject.has(to)){
					DATEInc.put("operator", "LESSTHANEQUALTO");
					DATEInc.put("to", dateObject.getString(to).substring(0, 19));
				}

				if(dateObject.has("blockOutFrom")){
					if(dateObject.has("blockOutTo")){
						DATEExc.put("operator", "BETWEEN");
						DATEExc.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
						DATEExc.put("to", dateObject.getString("blockOutTo").substring(0, 19));
					}else{
						DATEExc.put("operator", "GREATERTHANEQUALTO");
						DATEExc.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
					}
				}else if(dateObject.has("blockOutTo")){
					DATEExc.put("operator", "LESSTHANEQUALTO");
					DATEExc.put("to", dateObject.getString("blockOutTo").substring(0, 19));
				}
				
				mainDateArray.put(trigPayout);
				
				if(DATEInc.has("operator")){
					DateInclusionArr.put(DATEInc);
					inclusion.put("inclusion", DateInclusionArr);
					mainDateArray.put(inclusion);
				}
				if(DATEExc.has("operator")){
					DateExclusionArr.put(DATEExc);
					exclusion.put("exclusion", DateExclusionArr);
					mainDateArray.put(exclusion);
				}
				
				if(inBase)
					base.put(date, mainDateArray);
				else calculation.put(date, mainDateArray);
				setRuleID(baseArr, calcArr, base, calculation, dateObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void getCarConnectivity(JSONArray baseArr, JSONObject connectivity) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray("triggerOrPayout"));
			JSONArray connectivityArr = new JSONArray();
			JSONObject connectivityObject = new JSONObject();
			if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierType",connectivity.getString("supplierType"));
			if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All")) // change as per schema supplier supplierId to supplierName
				connectivityObject.put("connectivitySupplierName",connectivity.getString("supplierName"));
			connectivityArr.put(triggerPayout);
			connectivityArr.put(connectivityObject);
			base.put("connectivity", connectivityArr);
		}
	}
		
	
	public static JSONObject getTriggerPayoutObject(JSONArray triggerOrPayout) {
		JSONObject triggerPayout = new JSONObject();
		boolean trigger=false,payout=false;
		for(int i=0;i<triggerOrPayout.length();i++){
			String value = triggerOrPayout.getString(i);
			if(value.equalsIgnoreCase("trigger"))
				trigger=true;
			
			if(value.equalsIgnoreCase("payout"))
				payout=true;
		}
		triggerPayout.put("trigger", trigger);
		triggerPayout.put("payout", payout);
		
		return triggerPayout;
	}
	

	public static void getTriggerPayoutArray(JSONArray baseArr, JSONArray calcArr, JSONArray array, String name, boolean inBase){
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<array.length();j++){
				JSONObject object = array.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(object.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray requestArr = new JSONArray();
				JSONObject requestObject = new JSONObject();
				requestObject.put(name, object.getString(name));
				requestArr.put(triggerPayout);
				requestArr.put(requestObject);
				if(inBase)
					base.put(name, requestArr);
				else calculation.put(name, requestArr);
				setRuleID(baseArr,calcArr,base,calculation,object.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void getTriggerPayoutArrayIncExc(JSONArray baseArr, JSONArray calcArr, JSONArray roomTypes, String name, boolean isInclusion, boolean inBase) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<roomTypes.length();j++){
				JSONObject roomTypesObject = roomTypes.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(roomTypesObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray roomTypesArr = new JSONArray();
				JSONObject roomTypesInnerObject = new JSONObject();
				if(isInclusion)
					roomTypesInnerObject.put(name, roomTypesObject.getString(name));
				else roomTypesInnerObject.put(name+"_exclusion", roomTypesObject.getString(name));
				roomTypesArr.put(triggerPayout);
				roomTypesArr.put(roomTypesInnerObject);
				if(inBase)
					base.put(name, roomTypesArr);
				else calculation.put(name, roomTypesArr);
				setRuleID(baseArr,calcArr,base,calculation,roomTypesObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
		
	}


	public static void getConnectivityTP(JSONArray baseArr, JSONObject connectivity) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray("triggerOrPayout"));
			JSONArray connectivityArr = new JSONArray();
			JSONObject connectivityObject = new JSONObject();
			if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierType",connectivity.getString("supplierType"));
			if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierName",connectivity.getString("supplierId"));
			connectivityArr.put(triggerPayout);
			connectivityArr.put(connectivityObject);
			base.put("connectivity", connectivityArr);
		}
	}
	
	
	public static void getAirConnectivity(JSONArray baseArr, JSONObject connectivity) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray("triggerOrPayout"));
			JSONArray connectivityArr = new JSONArray();
			JSONObject connectivityObject = new JSONObject();
			if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierType",connectivity.getString("supplierType"));
			if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All"))
				connectivityObject.put("connectivitySupplierName",connectivity.getString("supplierName"));
			connectivityArr.put(triggerPayout);
			connectivityArr.put(connectivityObject);
			base.put("connectivity", connectivityArr);
		}
	}
	
	
	public static void getBookingTypeTP(JSONArray baseArr, JSONObject bookingType, boolean isInclusion) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(bookingType.getJSONArray("triggerOrPayout"));
			JSONArray bookingTypeArr = new JSONArray();
			JSONObject bookingTypeObject = new JSONObject();
			if(isInclusion)
				bookingTypeObject.put("bookingType",bookingType.getString("bookingType"));
			else bookingTypeObject.put("bookingType_exclusion",bookingType.getString("bookingType"));
			bookingTypeArr.put(triggerPayout);
			bookingTypeArr.put(bookingTypeObject);
			base.put("bookingType", bookingTypeArr);
		}
	}
	
	
	public static void setRuleID(JSONArray baseArr, JSONArray calcArr, JSONObject base, JSONObject calculation, String ID) {
		String baseRuleID = base.getString("RuleID")+ID;
		String calculationRuleID = calculation.getString("RuleID")+ID;
		base.put("RuleID", baseRuleID);
		calculation.put("RuleID", calculationRuleID);
		calculation.put("selectedRow", baseRuleID);
		
		baseArr.put(base);
		calcArr.put(calculation);
	}
	
	
	public static void getDestination(JSONArray baseArr, JSONArray calcArr, JSONArray travel, boolean isInclusion, boolean inBase) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travel.length();j++){
				JSONObject object = travel.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(object.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray requestArr = new JSONArray();
				JSONObject requestObject = new JSONObject();
				requestArr.put(triggerPayout);
				if(isInclusion){
					if(object.has("continent") && !object.getString("continent").equalsIgnoreCase("All"))
						requestObject.put("continent", object.getString("continent"));
					if(object.has("country") && !object.getString("country").equalsIgnoreCase("All"))
						requestObject.put("country", object.getString("country"));
					if(object.has("state") && !object.getString("state").equalsIgnoreCase("All"))
						requestObject.put("state", object.getString("state"));
					if(object.has("city") && !object.getString("city").equalsIgnoreCase("All"))
						requestObject.put("city", object.getString("city"));
				}else{
					if(object.has("continent") && !object.getString("continent").equalsIgnoreCase("All"))
						requestObject.put("continent_exclusion", object.getString("continent"));
					if(object.has("country") && !object.getString("country").equalsIgnoreCase("All"))
						requestObject.put("country_exclusion", object.getString("country"));
					if(object.has("state") && !object.getString("state").equalsIgnoreCase("All"))
						requestObject.put("state_exclusion", object.getString("state"));
					if(object.has("city") && !object.getString("city").equalsIgnoreCase("All"))
						requestObject.put("city_exclusion", object.getString("city"));
				}
				requestArr.put(requestObject);
				if(inBase)
					base.put("travelDestination", requestArr);
				else calculation.put("travelDestination", requestArr);
				setRuleID(baseArr,calcArr,base,calculation,object.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void getTriggerPayoutEnumValues(JSONArray baseArr, JSONArray triggerOrPayout, JSONArray jsonArray, String name, boolean isInclusion) {
		int length =baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(triggerOrPayout);
			JSONArray array = new JSONArray();
			array.put(triggerPayout);
			JSONObject object = new JSONObject();
			if(isInclusion)
				object.put(name, jsonArray);
			else object.put(name+"_exclusion", jsonArray);
			array.put(object);
			base.put(name, array);
		}
	}
	
	
	public static void getFixedDetails(JSONObject calculation, JSONObject fixed) {
		if(fixed.getBoolean("isPercentage")){
			JSONArray percentageDetails = fixed.getJSONArray("percentageDetails");
			JSONArray fareComponentsArr = new JSONArray();
			for(int k=0;k<percentageDetails.length();k++){
				if(percentageDetails.getJSONObject(k).has("farePriceComponents")){
					String fareComp = percentageDetails.getJSONObject(k).getString("farePriceComponents");
					if(fareComp.equals("Basic") || fareComp.equalsIgnoreCase("Total")){
						fareComponentsArr.put(fareComp);
						calculation.put("percentage", percentageDetails.getJSONObject(k).get("valuePercentage").toString());
					}else fareComponentsArr.put(fareComp+";"+percentageDetails.getJSONObject(k).get("valuePercentage").toString());
				}else{
					fareComponentsArr.put("Total");
					calculation.put("percentage", percentageDetails.getJSONObject(k).get("valuePercentage").toString());
				}
			}
			calculation.put("fareComponent", CommonFunctions.getFareComponentString(fareComponentsArr));
			if(fixed.getBoolean("isAmount")){
				calculation.put("currency", fixed.getString("currency"));
				calculation.put("amountValue", fixed.get("valueAmount").toString());
			}
		}else if(fixed.getBoolean("isAmount")){
			if(!fixed.getBoolean("isPercentage"))
				calculation.put("fareComponent", "Total");
			calculation.put("currency", fixed.getString("currency"));
			calculation.put("amountValue", fixed.get("valueAmount").toString());
		}
	}


	public static void getSupplierRate(JSONArray supplierRateArr, JSONArray calculationArr) {
		Set<String> rateType = new HashSet<String>();
		Set<String> rateCode = new HashSet<String>();
		for(int i=0;i<supplierRateArr.length();i++){
			JSONObject supplierRate = supplierRateArr.getJSONObject(i);
			if(supplierRate.has("supplierRatetype") && !supplierRate.getString("supplierRatetype").equalsIgnoreCase("All"))
				rateType.add(supplierRate.getString("supplierRatetype"));
			if(supplierRate.has("supplierRateCode") && !supplierRate.getString("supplierRateCode").equalsIgnoreCase("All"))
				rateCode.add(supplierRate.getString("supplierRateCode"));
		}
		for(int i=0;i<calculationArr.length();i++){
			JSONObject calculation = calculationArr.getJSONObject(i);
			if(!rateType.isEmpty())
				calculation.put("rateType", rateType);
			if(!rateCode.isEmpty())
				calculation.put("rateCode", rateCode);
		}
	}
	
	
	public static void setOtherFeeTicketing(JSONArray otherFeeArr, JSONObject validity){
		switch(validity.getString("validityType")){
		case "ticketing":{
			setOtherFeesDate(otherFeeArr,validity.getJSONArray("ticketing"),"ticketing");
			break;
		}
		case "travel":{
			setOtherFeesDate(otherFeeArr,validity.getJSONArray("travel"),"travel");
			break;
		}
		default:{
			int length = otherFeeArr.length();
			JSONArray ticketingPlusTravel = validity.getJSONArray("ticketingPlusTravel");
			for(int i=0;i<length;i++){
				for(int j=0;j<ticketingPlusTravel.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(j);
					
					JSONArray tickincArr =new JSONArray();
					JSONArray tickexcArr =new JSONArray();
					JSONArray travelincArr =new JSONArray();
					JSONArray travelexcArr =new JSONArray();
					JSONObject indiTicketObj = new JSONObject();
					JSONObject indiTravelObj = new JSONObject();
					JSONObject indiTicketBlockObj = new JSONObject();
					JSONObject indiTravelBlockObj = new JSONObject();
					JSONArray ticketingDate = new JSONArray();
					JSONArray travelDate = new JSONArray();
					JSONObject inclusionTkt = new JSONObject();
					JSONObject exclusionTkt = new JSONObject();
					JSONObject inclusionTra = new JSONObject();
					JSONObject exclusionTra = new JSONObject();
					
					JSONObject ticketingObject = ticketPlusTravelObj.getJSONObject("ticket");
					if(ticketingObject.has("ticketingFrom")){
						if(ticketingObject.has("ticketingTo")){
							indiTicketObj.put("operator","BETWEEN");
							indiTicketObj.put("from", ticketingObject.getString("ticketingFrom").substring(0, 19));
							indiTicketObj.put("to", ticketingObject.getString("ticketingTo").substring(0, 19));
						}else{
							indiTicketObj.put("operator","GREATERTHANEQUALTO");
							indiTicketObj.put("value", ticketingObject.getString("ticketingFrom").substring(0, 19));
						}
					}else if(ticketingObject.has("ticketingTo")){
						indiTicketObj.put("operator","LESSTHANEQUALTO");
						indiTicketObj.put("value", ticketingObject.getString("ticketingTo").substring(0, 19));
					}
					
					if(ticketingObject.has("blockOutFrom")){
						if(ticketingObject.has("blockOutTo")){
							indiTicketBlockObj.put("operator", "BETWEEN");
							indiTicketBlockObj.put("from", ticketingObject.getString("blockOutFrom").substring(0, 19));
							indiTicketBlockObj.put("to", ticketingObject.getString("blockOutTo").substring(0, 19));
						}else{
							indiTicketBlockObj.put("operator", "GREATERTHANEQUALTO");
							indiTicketBlockObj.put("value", ticketingObject.getString("blockOutFrom").substring(0, 19));
						}
					}else{
						if(ticketingObject.has("blockOutTo")){
							indiTicketBlockObj.put("operator", "LESSTHANEQUALTO");
							indiTicketBlockObj.put("value", ticketingObject.getString("blockOutTo").substring(0, 19));
						}
					}
					
					JSONObject travelObject = ticketPlusTravelObj.getJSONObject("travel");
					if(travelObject.has("travelFrom")){
						if(travelObject.has("travelTo")){
							indiTravelObj.put("operator","BETWEEN");
							indiTravelObj.put("from", travelObject.getString("travelFrom").substring(0, 19));
							indiTravelObj.put("to", travelObject.getString("travelTo").substring(0, 19));
						}else{
							indiTravelObj.put("operator","GREATERTHANEQUALTO");
							indiTravelObj.put("value", travelObject.getString("travelFrom").substring(0, 19));
						}
					}else if(travelObject.has("travelTo")){
						indiTravelObj.put("operator","LESSTHANEQUALTO");
						indiTravelObj.put("value", travelObject.getString("travelTo").substring(0, 19));
					}
					if(travelObject.has("blockOutFrom")){
						if(travelObject.has("blockOutTo")){
							indiTravelBlockObj.put("operator", "BETWEEN");
							indiTravelBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
							indiTravelBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
						}else{
							indiTravelBlockObj.put("operator", "GREATERTHANEQUALTO");
							indiTravelBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
						}
					}else{
						if(travelObject.has("blockOutTo")){
							indiTravelBlockObj.put("operator", "LESSTHANEQUALTO");
							indiTravelBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
						}
					}
					
					if(indiTicketObj!=null){
						tickincArr.put(indiTicketObj);
						inclusionTkt.put("inclusion",tickincArr);
						ticketingDate.put(inclusionTkt);
					}
					if(indiTicketBlockObj!=null){
						tickexcArr.put(indiTicketBlockObj);
						exclusionTkt.put("exclusion",tickexcArr);
						ticketingDate.put(exclusionTkt);
					}
					if(indiTravelObj!=null){
						travelincArr.put(indiTravelObj);
						inclusionTra.put("inclusion",travelincArr);
						travelDate.put(inclusionTra);
					}
					if(indiTravelBlockObj!=null){
						travelexcArr.put(indiTravelBlockObj);
						exclusionTra.put("exclusion",travelexcArr);
						travelDate.put(exclusionTra);
					}
					otherFee.put("ticketing", ticketingDate);
					otherFee.put("travel", travelDate);
					
					setOtherFeesRuleID(otherFeeArr, otherFee, ticketPlusTravelObj.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}break;
		}
	
		
	}
	
	
	public static void setOtherFeesRuleID(JSONArray otherFeeArr, JSONObject otherFee, String ID) {
		String otherFeeRuleID = otherFee.getString("RuleID")+ID;
		otherFee.put("RuleID", otherFeeRuleID);
		otherFeeArr.put(otherFee);
	}
	
	
	public static void setOtherFeesDate(JSONArray otherFeeArr, JSONArray dateArray, String date) {
		String from = date+"From";
		String to = date+"To";

		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArray.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject dateObject =dateArray.getJSONObject(j);

				JSONArray incArr =new JSONArray();
				JSONArray excArr =new JSONArray();
				JSONObject indiObj = new JSONObject();
				JSONObject indiBlockObj = new JSONObject();
				JSONArray Date = new JSONArray();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();

				if(dateObject.has(from)){
					if(dateObject.has(to)){
						indiObj.put("operator","BETWEEN");
						indiObj.put("from", dateObject.getString(from).substring(0, 19));
						indiObj.put("to", dateObject.getString(to).substring(0, 19));
					}else{
						indiObj.put("operator","GREATERTHANEQUALTO");
						indiObj.put("value", dateObject.getString(from).substring(0, 19));
					}
				}else if(dateObject.has(to)){
					indiObj.put("operator","LESSTHANEQUALTO");
					indiObj.put("value", dateObject.getString(to).substring(0, 19));
				}

				if(dateObject.has("blockOutFrom")){
					if(dateObject.has("blockOutTo")){
						indiBlockObj.put("operator", "BETWEEN");
						indiBlockObj.put("from", dateObject.getString("blockOutFrom").substring(0, 19));
						indiBlockObj.put("to", dateObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiBlockObj.put("value", dateObject.getString("blockOutFrom").substring(0, 19));
					}
				}else{
					if(dateObject.has("blockOutTo")){
						indiBlockObj.put("operator", "LESSTHANEQUALTO");
						indiBlockObj.put("value", dateObject.getString("blockOutTo").substring(0, 19));
					}
				}

				if(indiObj.has("operator")){
					incArr.put(indiObj);
					inclusion.put("inclusion",incArr);
					Date.put(inclusion);
				}
				if(indiBlockObj.has("operator")){
					excArr.put(indiBlockObj);
					exclusion.put("exclusion",excArr);
					Date.put(exclusion);
				}
				otherFee.put(date, Date);
				setOtherFeesRuleID(otherFeeArr, otherFee, dateObject.getString("_id"));			
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	public static void getArrayNonTP(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, boolean isInclusion, boolean inBase) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject calculation = calcArr.getJSONObject(i);
			if(isInclusion){
				if(inBase)
					base.put(name, array);
				else calculation.put(name, array);
			}else{
				if(inBase)
					base.put(name+"_exclusion", array);
				else calculation.put(name+"_exclusion", array);
			}
		}
	}


	public static void getArray(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, boolean isInclusion,boolean inBase) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<jsonArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject jsonObject = jsonArray.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(jsonObject.getJSONArray("triggerOrPayout"));
				JSONArray array = new JSONArray();
				JSONObject object = new JSONObject();
				array.put(triggerPayout);
				object.put(name, jsonObject.getString(name));
				array.put(object);
				
				if(isInclusion){
					if(inBase)
						base.put(name, array);
					else calculation.put(name, array);
				}else{
					if(inBase)
						base.put(name+"_exclusion", array);
					else calculation.put(name+"_exclusion", array);
				}
				
				setRuleID(baseArr, calcArr, base, calculation, jsonObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setTransportationAdvancedDefinition(JSONObject advanceDefinitionTransportation, JSONArray baseArr, JSONArray calcArr, boolean isTravelInBase) {
		if(advanceDefinitionTransportation.has("validity")){
			JSONObject validity = advanceDefinitionTransportation.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "sale":{
				JSONObject sale = validity.getJSONArray("sale").getJSONObject(0);
				if(sale.has("triggerOrPayout") && sale.getJSONArray("triggerOrPayout").length()>0)
					CommonFunctions.getPLBDates(baseArr, calcArr, validity.getJSONArray("sale"), "sale", true);//inBase : true
				else CommonFunctions.setDate(baseArr, calcArr, validity.getJSONArray("sale"), "sale", true);//inBase : true
				break;
			}
			case "travel":{
				JSONObject travel = validity.getJSONArray("travel").getJSONObject(0);
				if(travel.has("triggerOrPayout") && travel.getJSONArray("triggerOrPayout").length()>0)
					CommonFunctions.getPLBDates(baseArr, calcArr, validity.getJSONArray("travel"), "travel", isTravelInBase);
				else CommonFunctions.setDate(baseArr, calcArr, validity.getJSONArray("travel"), "travel", isTravelInBase);
				break;
			}
			default:{
				CommonFunctions.setSalePlusTravelDate(baseArr,calcArr, validity.getJSONArray("salePlusTravel"), true, isTravelInBase);
			}
			}
		}
		
		if(advanceDefinitionTransportation.has("travelDestination")){
			JSONObject travelDestination = advanceDefinitionTransportation.getJSONObject("travelDestination");
			JSONArray destinations = travelDestination.getJSONArray("destinations");
			JSONObject destObject = destinations.getJSONObject(0);
			if(destObject.has("triggerOrPayout") && destObject.getJSONArray("triggerOrPayout").length()>0){
				if(travelDestination.getBoolean("isInclusion"))
					setPLBTransportationDestination(baseArr,calcArr,destinations,true,false);//isBase : false
				else setPLBTransportationDestination(baseArr,calcArr,destinations,false,false);//isBase : false
			}else{
				if(travelDestination.getBoolean("isInclusion"))
					setTransportationDestination(baseArr,calcArr,destinations,true,false);//isBase : false
				else setTransportationDestination(baseArr,calcArr,destinations,false,false);//isBase : false
			}
		}
		
		if(advanceDefinitionTransportation.has("others")){
			JSONObject others = advanceDefinitionTransportation.getJSONObject("others");
			if(others.has("triggerOrPayout") && others.getJSONArray("triggerOrPayout").length()>0)
				getBookingTypeTP(baseArr, others, true);//isInclusion : true
			else{
				for(int i=0;i<baseArr.length();i++){
					JSONObject base = baseArr.getJSONObject(i);
					base.put("bookingType", others.getString("bookingType"));//inBase
				}
			}
		}
		
		if(advanceDefinitionTransportation.has("connectivity")){
			JSONObject connectivity = advanceDefinitionTransportation.getJSONObject("connectivity");
			if(connectivity.has("triggerOrPayout") && connectivity.getJSONArray("triggerOrPayout").length()>0)
				getConnectivityTP(baseArr,connectivity);
			else{
				for(int i=0;i<baseArr.length();i++){
					JSONObject base = baseArr.getJSONObject(i);
					if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
						base.put("connectivitySupplierType",connectivity.getString("supplierType"));
					if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
						base.put("connectivitySupplierName",connectivity.getString("supplierId"));
				}
			}
		}
		
		if(advanceDefinitionTransportation.has("credentials") && advanceDefinitionTransportation.getJSONArray("credentials").length()>0){
			JSONObject credentials = advanceDefinitionTransportation.getJSONArray("credentials").getJSONObject(0);
			if(credentials.has("triggerOrPayout") && credentials.getJSONArray("triggerOrPayout").length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("credentials"), "credentials", true, true);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("credentials"), "credentials", true, true);
		}
		
		if(advanceDefinitionTransportation.has("nationality") && advanceDefinitionTransportation.getJSONArray("nationality").length()>0){
			JSONObject nationality = advanceDefinitionTransportation.getJSONArray("nationality").getJSONObject(0);
			if(nationality.has("triggerOrPayout") && nationality.getJSONArray("triggerOrPayout").length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("nationality"), "clientNationality", true, true);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("nationality"), "clientNationality", true, true);
		}
		
		if(advanceDefinitionTransportation.has("passengerTypes") && advanceDefinitionTransportation.getJSONArray("passengerTypes").length()>0){
			JSONObject passengerTypes = advanceDefinitionTransportation.getJSONArray("passengerTypes").getJSONObject(0);
			if(passengerTypes.has("triggerOrPayout") && passengerTypes.getJSONArray("triggerOrPayout").length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("passengerTypes"), "passengerTypes", true, false);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray("passengerTypes"), "passengerTypes", true, false);
		}
	}
	
	
	private static void setPLBTransportationDestination(JSONArray baseArr, JSONArray calcArr, JSONArray destinations, boolean isInclusion, boolean inBase) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<destinations.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject destination = destinations.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(destination.getJSONArray("triggerOrPayout"));
				JSONArray destinationArray = new JSONArray();
				destinationArray.put(triggerPayout);
				JSONObject values = new JSONObject();
				if(isInclusion){
					if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
						values.put("continent", destination.getString("continent"));
					if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
						values.put("country", destination.getString("country"));
					if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
						values.put("state", destination.getString("state"));
					if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
						values.put("city", destination.getString("city"));
				}else{
					if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
						values.put("continent_exclusion", destination.getString("continent"));
					if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
						values.put("country_exclusion", destination.getString("country"));
					if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
						values.put("state_exclusion", destination.getString("state"));
					if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
						values.put("city_exclusion", destination.getString("city"));
				}
				destinationArray.put(values);
				
				if(inBase)
					base.put("travelDestination", destinationArray);
				else calculation.put("travelDestination", destinationArray);

				setRuleID(baseArr, calcArr, base, calculation, destination.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setTransportationDestination(JSONArray baseArr, JSONArray calcArr, JSONArray destinations, boolean isInclusion, boolean inBase) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<destinations.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject destination = destinations.getJSONObject(j);
				if(inBase){
					if(isInclusion){
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							base.put("continent", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							base.put("country", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							base.put("state", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							base.put("city", destination.getString("city"));
					}else{
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							base.put("continent_exclusion", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							base.put("country_exclusion", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							base.put("state_exclusion", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							base.put("city_exclusion", destination.getString("city"));
					}
				}else{
					if(isInclusion){
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							calculation.put("continent", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							calculation.put("country", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							calculation.put("state", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							calculation.put("city", destination.getString("city"));
					}else{
						if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
							calculation.put("continent_exclusion", destination.getString("continent"));
						if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
							calculation.put("country_exclusion", destination.getString("country"));
						if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
							calculation.put("state_exclusion", destination.getString("state"));
						if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
							calculation.put("city_exclusion", destination.getString("city"));
					}
				}
				setRuleID(baseArr, calcArr, base, calculation, destination.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setSalePlusTravelDate(JSONArray baseArr, JSONArray calcArr, JSONArray salePlusTravel, boolean isSalesInBase, boolean isTravelInBase) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(j);

				JSONArray tickincArr =new JSONArray();
				JSONArray tickexcArr =new JSONArray();
				JSONArray travelincArr =new JSONArray();
				JSONArray travelexcArr =new JSONArray();
				JSONObject indiTicketObj = new JSONObject();
				JSONObject indiTravelObj = new JSONObject();
				JSONObject indiTicketBlockObj = new JSONObject();
				JSONObject indiTravelBlockObj = new JSONObject();
				JSONArray ticketingDate = new JSONArray();
				JSONArray travelDate = new JSONArray();
				JSONObject inclusionTkt = new JSONObject();
				JSONObject exclusionTkt = new JSONObject();
				JSONObject inclusionTra = new JSONObject();
				JSONObject exclusionTra = new JSONObject();

				JSONObject sales = salePlusTravelObject.getJSONObject("sales");
				if(sales.has("saleFrom")){
					if(sales.has("saleTo")){
						indiTicketObj.put("operator","BETWEEN");
						indiTicketObj.put("from", sales.getString("saleFrom").substring(0, 19));
						indiTicketObj.put("to", sales.getString("saleTo").substring(0, 19));
					}else{
						indiTicketObj.put("operator","GREATERTHANEQUALTO");
						indiTicketObj.put("value", sales.getString("saleFrom").substring(0, 19));
					}
				}else if(sales.has("saleTo")){
					indiTicketObj.put("operator","LESSTHANEQUALTO");
					indiTicketObj.put("value", sales.getString("saleTo").substring(0, 19));
				}

				if(sales.has("blockOutFrom")){
					if(sales.has("blockOutTo")){
						indiTicketBlockObj.put("operator", "BETWEEN");
						indiTicketBlockObj.put("from", sales.getString("blockOutFrom").substring(0, 19));
						indiTicketBlockObj.put("to", sales.getString("blockOutTo").substring(0, 19));
					}else{
						indiTicketBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTicketBlockObj.put("value", sales.getString("blockOutFrom").substring(0, 19));
					}
				}else if(sales.has("blockOutTo")){
					indiTicketBlockObj.put("operator", "LESSTHANEQUALTO");
					indiTicketBlockObj.put("value", sales.getString("blockOutTo").substring(0, 19));
				}

				JSONObject travelObject = salePlusTravelObject.getJSONObject("travel");
				if(travelObject.has("travelFrom")){
					if(travelObject.has("travelTo")){
						indiTravelObj.put("operator","BETWEEN");
						indiTravelObj.put("from", travelObject.getString("travelFrom").substring(0, 19));
						indiTravelObj.put("to", travelObject.getString("travelTo").substring(0, 19));
					}else{
						indiTravelObj.put("operator","GREATERTHANEQUALTO");
						indiTravelObj.put("value", travelObject.getString("travelFrom").substring(0, 19));
					}
				}else if(travelObject.has("travelTo")){
					indiTravelObj.put("operator","LESSTHANEQUALTO");
					indiTravelObj.put("value", travelObject.getString("travelTo").substring(0, 19));
				}

				if(travelObject.has("blockOutFrom")){
					if(travelObject.has("blockOutTo")){
						indiTravelBlockObj.put("operator", "BETWEEN");
						indiTravelBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
						indiTravelBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiTravelBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTravelBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
					}
				}else if(travelObject.has("blockOutTo")){
					indiTravelBlockObj.put("operator", "LESSTHANEQUALTO");
					indiTravelBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
				}


				if(indiTicketObj!=null){
					tickincArr.put(indiTicketObj);
					inclusionTkt.put("inclusion",tickincArr);
					ticketingDate.put(inclusionTkt);
				}
				if(indiTicketBlockObj!=null){
					tickexcArr.put(indiTicketBlockObj);
					exclusionTkt.put("exclusion",tickexcArr);
					ticketingDate.put(exclusionTkt);
				}
				if(indiTravelObj!=null){
					travelincArr.put(indiTravelObj);
					inclusionTra.put("inclusion",travelincArr);
					travelDate.put(inclusionTra);
				}
				if(indiTravelBlockObj!=null){
					travelexcArr.put(indiTravelBlockObj);
					exclusionTra.put("exclusion",travelexcArr);
					travelDate.put(exclusionTra);
				}

				if(isSalesInBase)
					base.put("sale", ticketingDate);
				else calculation.put("sale", ticketingDate);
				
				if(isTravelInBase)
					base.put("travel", travelDate);
				else calculation.put("travel", travelDate);
					
				setRuleID(baseArr, calcArr, base, calculation, salePlusTravelObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void setTransportationOtherFeesAdvancedDefinition(JSONObject advanceDefinitionTransportation, JSONArray otherFeeArr) {
		if(advanceDefinitionTransportation.has("validity")){
			JSONObject validity = advanceDefinitionTransportation.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "sale":{
				setOtherFeesDate(otherFeeArr,validity.getJSONArray("sale"), "sale");
				break;
			}
			case "travel":{
				setOtherFeesDate(otherFeeArr,validity.getJSONArray("travel"), "travel");
				break;
			}
			default:{
				setOtherFeeSalePlusTravelDate(otherFeeArr,  validity.getJSONArray("salePlusTravel"));
			}
			}
		}
		if(advanceDefinitionTransportation.has("travelDestination")){
			JSONObject travelDestination = advanceDefinitionTransportation.getJSONObject("travelDestination");
			JSONArray destinations = travelDestination.getJSONArray("destinations");
			if(travelDestination.getBoolean("isInclusion"))
				setTransportationOtherFeesDestination(otherFeeArr, destinations, true);
			else setTransportationOtherFeesDestination(otherFeeArr, destinations, false);

		}
		if(advanceDefinitionTransportation.has("others")){
			JSONObject others = advanceDefinitionTransportation.getJSONObject("others");
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				otherFee.put("bookingType", others.getString("bookingType"));
			}
		}

		if(advanceDefinitionTransportation.has("connectivity")){
			JSONObject connectivity = advanceDefinitionTransportation.getJSONObject("connectivity");
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierType",connectivity.getString("supplierType"));
				if(connectivity.has("supplierId") && !connectivity.getString("supplierId").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierName",connectivity.getString("supplierId"));
			}
		}
		if(advanceDefinitionTransportation.has("credentials") && advanceDefinitionTransportation.getJSONArray("credentials").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray("credentials"), "credentials");

		if(advanceDefinitionTransportation.has("nationality") && advanceDefinitionTransportation.getJSONArray("nationality").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray("nationality"), "clientNationality");

		if(advanceDefinitionTransportation.has("passengerTypes") && advanceDefinitionTransportation.getJSONArray("passengerTypes").length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray("passengerTypes"), "passengerTypes");

	}
	
	
	public static void setTransportationOtherFeesDestination(JSONArray otherFeeArr, JSONArray destinations, boolean isInclusion) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<destinations.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject destination = destinations.getJSONObject(j);
				if(isInclusion){
					if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
						otherFee.put("continent", destination.getString("continent"));
					if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
						otherFee.put("country", destination.getString("country"));
					if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
						otherFee.put("state", destination.getString("state"));
					if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
						otherFee.put("city", destination.getString("city"));
				}else{
					if(destination.has("continent") && !destination.getString("continent").equalsIgnoreCase("All"))
						otherFee.put("continent_exclusion", destination.getString("continent"));
					if(destination.has("country") && !destination.getString("country").equalsIgnoreCase("All"))
						otherFee.put("country_exclusion", destination.getString("country"));
					if(destination.has("state") && !destination.getString("state").equalsIgnoreCase("All"))
						otherFee.put("state_exclusion", destination.getString("state"));
					if(destination.has("city") && !destination.getString("city").equalsIgnoreCase("All"))
						otherFee.put("city_exclusion", destination.getString("city"));
				}

				setOtherFeesRuleID(otherFeeArr, otherFee, destination.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	public static void setOtherFeeSalePlusTravelDate(JSONArray otherFeeArr, JSONArray salePlusTravel) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));

				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(j);

				JSONArray tickincArr =new JSONArray();
				JSONArray tickexcArr =new JSONArray();
				JSONArray travelincArr =new JSONArray();
				JSONArray travelexcArr =new JSONArray();
				JSONObject indiTicketObj = new JSONObject();
				JSONObject indiTravelObj = new JSONObject();
				JSONObject indiTicketBlockObj = new JSONObject();
				JSONObject indiTravelBlockObj = new JSONObject();
				JSONArray ticketingDate = new JSONArray();
				JSONArray travelDate = new JSONArray();
				JSONObject inclusionTkt = new JSONObject();
				JSONObject exclusionTkt = new JSONObject();
				JSONObject inclusionTra = new JSONObject();
				JSONObject exclusionTra = new JSONObject();

				JSONObject sales = salePlusTravelObject.getJSONObject("sales");
				if(sales.has("saleFrom")){
					if(sales.has("saleTo")){
						indiTicketObj.put("operator","BETWEEN");
						indiTicketObj.put("from", sales.getString("saleFrom").substring(0, 19));
						indiTicketObj.put("to", sales.getString("saleTo").substring(0, 19));
					}else{
						indiTicketObj.put("operator","GREATERTHANEQUALTO");
						indiTicketObj.put("value", sales.getString("saleFrom").substring(0, 19));
					}
				}else if(sales.has("saleTo")){
					indiTicketObj.put("operator","LESSTHANEQUALTO");
					indiTicketObj.put("value", sales.getString("saleTo").substring(0, 19));
				}

				if(sales.has("blockOutFrom")){
					if(sales.has("blockOutTo")){
						indiTicketBlockObj.put("operator", "BETWEEN");
						indiTicketBlockObj.put("from", sales.getString("blockOutFrom").substring(0, 19));
						indiTicketBlockObj.put("to", sales.getString("blockOutTo").substring(0, 19));
					}else{
						indiTicketBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTicketBlockObj.put("value", sales.getString("blockOutFrom").substring(0, 19));
					}
				}else if(sales.has("blockOutTo")){
					indiTicketBlockObj.put("operator", "LESSTHANEQUALTO");
					indiTicketBlockObj.put("value", sales.getString("blockOutTo").substring(0, 19));
				}

				JSONObject travelObject = salePlusTravelObject.getJSONObject("travel");
				if(travelObject.has("travelFrom")){
					if(travelObject.has("travelTo")){
						indiTravelObj.put("operator","BETWEEN");
						indiTravelObj.put("from", travelObject.getString("travelFrom").substring(0, 19));
						indiTravelObj.put("to", travelObject.getString("travelTo").substring(0, 19));
					}else{
						indiTravelObj.put("operator","GREATERTHANEQUALTO");
						indiTravelObj.put("value", travelObject.getString("travelFrom").substring(0, 19));
					}
				}else if(travelObject.has("travelTo")){
					indiTravelObj.put("operator","LESSTHANEQUALTO");
					indiTravelObj.put("value", travelObject.getString("travelTo").substring(0, 19));
				}

				if(travelObject.has("blockOutFrom")){
					if(travelObject.has("blockOutTo")){
						indiTravelBlockObj.put("operator", "BETWEEN");
						indiTravelBlockObj.put("from", travelObject.getString("blockOutFrom").substring(0, 19));
						indiTravelBlockObj.put("to", travelObject.getString("blockOutTo").substring(0, 19));
					}else{
						indiTravelBlockObj.put("operator", "GREATERTHANEQUALTO");
						indiTravelBlockObj.put("value", travelObject.getString("blockOutFrom").substring(0, 19));
					}
				}else if(travelObject.has("blockOutTo")){
					indiTravelBlockObj.put("operator", "LESSTHANEQUALTO");
					indiTravelBlockObj.put("value", travelObject.getString("blockOutTo").substring(0, 19));
				}


				if(indiTicketObj!=null){
					tickincArr.put(indiTicketObj);
					inclusionTkt.put("inclusion",tickincArr);
					ticketingDate.put(inclusionTkt);
				}
				if(indiTicketBlockObj!=null){
					tickexcArr.put(indiTicketBlockObj);
					exclusionTkt.put("exclusion",tickexcArr);
					ticketingDate.put(exclusionTkt);
				}
				if(indiTravelObj!=null){
					travelincArr.put(indiTravelObj);
					inclusionTra.put("inclusion",travelincArr);
					travelDate.put(inclusionTra);
				}
				if(indiTravelBlockObj!=null){
					travelexcArr.put(indiTravelBlockObj);
					exclusionTra.put("exclusion",travelexcArr);
					travelDate.put(exclusionTra);
				}

				otherFee.put("sale", ticketingDate);
				otherFee.put("travel", travelDate);
				

				setOtherFeesRuleID(otherFeeArr, otherFee, salePlusTravelObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		
		}
	}
	
	
	public static void getOtherFeesArrayNonTP(JSONArray otherFeeArr, JSONArray jsonArray, String name) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = otherFeeArr.getJSONObject(i);
			otherFee.put(name, array);
		}
	}
	
	
	public static void setDestinationCU(String baseDT, String calculationDT, JSONObject advanceDefinition,JSONObject mainJson) {
		if (advanceDefinition.has("travelDestination")) {
			JSONArray destBaseArr = new JSONArray();
			JSONArray destCalcArr = new JSONArray();
			JSONArray destinations = advanceDefinition.getJSONObject("travelDestination").getJSONArray("destinations");
			if (destinations.length() > 0) {
				for (int i = 0; i < destinations.length(); i++) {
					for(int j = 0; j<mainJson.getJSONArray(baseDT).length(); j++){
						String continent = null,country = null,state = null,city = null;
						JSONObject destBaseObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(baseDT).getJSONObject(j).toString()));
						JSONObject destCalcObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(calculationDT).getJSONObject(j).toString()));
						if(destinations.getJSONObject(i).has("continent") && !destinations.getJSONObject(i).getString("continent").equalsIgnoreCase("All"))
							continent = destinations.getJSONObject(i).getString("continent");
						if(destinations.getJSONObject(i).has("country") && !destinations.getJSONObject(i).getString("country").equalsIgnoreCase("All"))
							country = destinations.getJSONObject(i).getString("country");
						if(destinations.getJSONObject(i).has("state") && !destinations.getJSONObject(i).getString("state").equalsIgnoreCase("All"))
							state = destinations.getJSONObject(i).getString("state");
						if(destinations.getJSONObject(i).has("city") && !destinations.getJSONObject(i).getString("city").equalsIgnoreCase("All"))
							city = destinations.getJSONObject(i).getString("city");

						if(destinations.getJSONObject(i).has("_id") && destinations.length()>1){
							destBaseObj.put("RuleID", destBaseObj.getString("RuleID")+destinations.getJSONObject(i).getString("_id"));
							destCalcObj.put("RuleID", destCalcObj.getString("RuleID")+destinations.getJSONObject(i).getString("_id"));
						}

						if (advanceDefinition.getJSONObject("travelDestination").getBoolean("isInclusion")) {
							destCalcObj.putOpt("continent", continent);							
							destCalcObj.putOpt("country", country);							
							destCalcObj.putOpt("state", state);						
							destCalcObj.putOpt("city", city);
						}else{							
							destCalcObj.putOpt("continent_exclusion", continent);						
							destCalcObj.putOpt("country_exclusion", country);						
							destCalcObj.putOpt("state_exclusion", state);							
							destCalcObj.putOpt("city_exclusion", city);
						}
						destBaseArr.put(destBaseObj);
						destCalcArr.put(destCalcObj);
					}
				}
				mainJson.put(baseDT,destBaseArr);
				mainJson.put(calculationDT,destCalcArr);
			}
		}
	}

	
	public static void setVehicleDetailsCU(String baseDT, String calculationDT, JSONObject advanceDefinitionCarRentals,JSONObject mainJson) {
		JSONArray vehicleBaseArr = new JSONArray();
		JSONArray vehicleCalcArr = new JSONArray();

		if(advanceDefinitionCarRentals.has("vehicleDetails")){
			JSONArray vehicles = advanceDefinitionCarRentals.getJSONObject("vehicleDetails").getJSONArray("vehicles");
			if (vehicles.length() > 0) {
				for (int i = 0; i < vehicles.length(); i++) {
					for(int j = 0; j<mainJson.getJSONArray(baseDT).length(); j++){
						String sippOrACRISScode = null,vehicleCategory = null,vehicleName = null,rateTypeApplicableFor = null, rateTypeApplicableForCategory = null;
						//boolean isPrepaid;
						JSONObject vehicleBaseObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(baseDT).getJSONObject(j).toString()));
						JSONObject vehicleCalcObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(calculationDT).getJSONObject(j).toString()));
						if(vehicles.getJSONObject(i).has("sippOrACRISScode"))
							sippOrACRISScode = vehicles.getJSONObject(i).getString("sippOrACRISScode");
						if(vehicles.getJSONObject(i).has("vehicleCategory"))
							vehicleCategory = vehicles.getJSONObject(i).getString("vehicleCategory");
						if(vehicles.getJSONObject(i).has("vehicleName"))
							vehicleName = vehicles.getJSONObject(i).getString("vehicleName");

						if(vehicles.getJSONObject(i).has("_id")){
							vehicleBaseObj.put("RuleID", vehicleBaseObj.getString("RuleID")+vehicles.getJSONObject(i).getString("_id"));
							vehicleCalcObj.put("RuleID", vehicleCalcObj.getString("RuleID")+vehicles.getJSONObject(i).getString("_id"));
						}
						if(advanceDefinitionCarRentals.has("rateTypeApplicableFor")){
							rateTypeApplicableFor = advanceDefinitionCarRentals.getString("rateTypeApplicableFor");
							vehicleCalcObj.put("rateTypeApplicableFor",rateTypeApplicableFor);
						}
						if(advanceDefinitionCarRentals.has("category")){
							rateTypeApplicableForCategory = advanceDefinitionCarRentals.getString("category");
							vehicleCalcObj.put("rateTypeApplicableForCategory",rateTypeApplicableForCategory);
						}
						if(advanceDefinitionCarRentals.has("isPrepaid")){
							advanceDefinitionCarRentals.getBoolean("isPrepaid");
							vehicleCalcObj.put("modeOfPayment","Prepaid");
						}
						/* else
					    	vehicleCalcObj.put("modeOfPayment","Postpaid");*/
						if (advanceDefinitionCarRentals.getJSONObject("vehicleDetails").getBoolean("isInclusion")) {
							vehicleCalcObj.putOpt("sippOrACRISScode", sippOrACRISScode);
							vehicleCalcObj.putOpt("vehicleCategory", vehicleCategory);
							vehicleCalcObj.putOpt("vehicleName", vehicleName);
						}else{	
							vehicleCalcObj.putOpt("sippOrACRISScode_exclusion", sippOrACRISScode);
							vehicleCalcObj.putOpt("vehicleCategory_exclusion", vehicleCategory);
							vehicleCalcObj.putOpt("vehicleName_exclusion", vehicleName);
						}
						vehicleBaseArr.put(vehicleBaseObj);
						vehicleCalcArr.put(vehicleCalcObj);
					}
				}
				mainJson.put(baseDT,vehicleBaseArr);
				mainJson.put(calculationDT,vehicleCalcArr);
			}
		}
	}
	
	
	public static void setSlabDetailsCU(String baseDT, String calculationDT, JSONObject commercial, JSONObject mainJson) {
		if(commercial.has("slab")){
			JSONArray slabBaseArr = new JSONArray();
			JSONArray slabCalcArr = new JSONArray();
			JSONArray slab = commercial.getJSONArray("slab");
			if(slab.length()>0){
				for(int i =0; i<slab.length(); i++){
					for(int j =0; j<mainJson.getJSONArray(baseDT).length();j++){
						JSONObject slabBaseObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(baseDT).getJSONObject(j).toString()));
						JSONObject slabCalcObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(calculationDT).getJSONObject(j).toString()));
						slabCalcObj.put("slabType", slab.getJSONObject(i).getString("slabType"));
						String slabTypeValue="BETWEEN";
						for(int k=0;k<slab.getJSONObject(i).getJSONArray("currencyDetails").length();k++){
							JSONObject currencyDetails = slab.getJSONObject(i).getJSONArray("currencyDetails").getJSONObject(k);
							slabTypeValue+= ";"+currencyDetails.get("fromValue").toString()+";"+currencyDetails.get("toValue").toString();
						}
						slabCalcObj.put("slabTypeValue", slabTypeValue);
						if(slab.getJSONObject(i).optBoolean("isPercentage")){
							JSONArray perDetails = slab.getJSONObject(i).getJSONArray("percentageDetails");
							JSONArray fareComp = new JSONArray();
							int count = 0;
							for(int k = 0;k<perDetails.length();k++){
								if(!perDetails.getJSONObject(k).has("farePriceComponents") || perDetails.getJSONObject(k).getString("farePriceComponents").equalsIgnoreCase("Total")){
									slabCalcObj.put("percentageValue", perDetails.getJSONObject(k).get("valuePercentage").toString());
									slabCalcObj.put("fareComponent", "Total");
									count++;
									break;
								}
								else if(perDetails.getJSONObject(k).getString("farePriceComponents").equalsIgnoreCase("Basic")){
									slabCalcObj.put("percentageValue", perDetails.getJSONObject(k).get("valuePercentage").toString());
									fareComp.put("Basic");
								}
								else{
									fareComp.put(perDetails.getJSONObject(k).getString("farePriceComponents").concat("|").concat(perDetails.getJSONObject(k).get("valuePercentage").toString()));
								}
							}
							if(fareComp.length()>0 && count==0){
								slabCalcObj.put("fareComponent", CommonFunctions.getFareComponentString(fareComp));
							}
						}
						if(slab.getJSONObject(i).optBoolean("isAmount")){
							slabCalcObj.put("amountValue", slab.getJSONObject(i).get("valueAmount").toString());
							slabCalcObj.put("currency", slab.getJSONObject(i).getString("currency"));
						}

						if(slab.getJSONObject(i).has("_id") && slab.length()>1){
							slabBaseObj.put("RuleID", slabBaseObj.getString("RuleID")+slab.getJSONObject(i).getString("_id"));
							slabCalcObj.put("RuleID", slabCalcObj.getString("RuleID")+slab.getJSONObject(i).getString("_id"));
						}
						slabBaseArr.put(slabBaseObj);
						slabCalcArr.put(slabCalcObj);
					}
				}
				mainJson.put(baseDT,slabBaseArr);
				mainJson.put(calculationDT,slabCalcArr);	
			}
		}
	}
	

	public static void setValidityCU(String baseDT, String calculationDT, JSONObject advanceDefinition,JSONObject mainJson) {
		if (advanceDefinition.has("validity")) {
			JSONObject validity = advanceDefinition.getJSONObject("validity");
			if(validity.has("validityType"))
				switch (validity.getString("validityType")) {
				case "sale": {
					setSaleTravelDateCU(validity.getJSONArray("sale"),validity.getString("validityType"), baseDT, calculationDT, mainJson);
					break;
				}
				case "travel": {
					setSaleTravelDateCU(validity.getJSONArray("travel"),validity.getString("validityType"), baseDT, calculationDT, mainJson);
					break;
				}
				case "sale+travel": {
					JSONArray validityBaseArr = new JSONArray();
					JSONArray validityCalcArr = new JSONArray();
					for (int i = 0; i < validity.getJSONArray("salePlusTravel").length(); i++) {
						for(int j = 0; j<mainJson.getJSONArray(baseDT).length(); j++){
							JSONObject validityBaseObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(baseDT).getJSONObject(j).toString()));
							JSONObject validityCalcObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(calculationDT).getJSONObject(j).toString()));
							JSONObject object = validity.getJSONArray("salePlusTravel").getJSONObject(i);

							if(object.has("sales")){
								JSONArray incArr = new JSONArray();
								JSONArray excArr = new JSONArray();
								JSONObject incObj = new JSONObject();
								JSONObject excObj = new JSONObject();
								if (object.getJSONObject("sales").has("saleFrom")) {
									if (object.getJSONObject("sales").has("saleTo")) {
										incObj.put("operator", "BETWEEN");
										incObj.put("from", object.getJSONObject("sales").getString("saleFrom").substring(0, 19));
										incObj.put("to", object.getJSONObject("sales").getString("saleTo").substring(0, 19));
									} else {
										incObj.put("operator", "GREATERTHANEQUALTO");
										incObj.put("value", object.getJSONObject("sales").getString("saleFrom").substring(0, 19));
									}
								} else if (object.getJSONObject("sales").has("saleTo")) {
									incObj.put("operator", "LESSTHANEQUALTO");
									incObj.put("value", object.getJSONObject("sales").getString("saleTo").substring(0, 19));
								}
								if (object.getJSONObject("sales").has("blockOutFrom")) {
									if (object.getJSONObject("sales").has("blockOutTo")) {
										excObj.put("operator", "BETWEEN");
										excObj.put("from", object.getJSONObject("sales").getString("blockOutFrom").substring(0, 19));
										excObj.put("to", object.getJSONObject("sales").getString("blockOutTo").substring(0, 19));
									} else {
										excObj.put("operator", "GREATERTHANEQUALTO");
										excObj.put("value", object.getJSONObject("sales").getString("blockOutFrom").substring(0, 19));
									}
								} else {
									if (object.getJSONObject("sales").has("blockOutTo")) {
										excObj.put("operator", "LESSTHANEQUALTO");
										excObj.put("value", object.getJSONObject("sales").getString("blockOutTo").substring(0, 19));
									}
								}
								if (incObj.length()!=0) {
									incArr.put(incObj);
								}
								if (excObj.length()!=0) {
									excArr.put(excObj);
								}		
								JSONArray date = new JSONArray();
								if (incArr.length() > 0) {
									JSONObject inclusion = new JSONObject();
									inclusion.put("inclusion", incArr);
									date.put(inclusion);
								}
								if (excArr.length() > 0) {
									JSONObject exclusion = new JSONObject();
									exclusion.put("exclusion", excArr);
									date.put(exclusion);
								}
								validityBaseObj.put("sale", date);
							}
							if(object.has("travel")){
								JSONArray incArr = new JSONArray();
								JSONArray excArr = new JSONArray();
								JSONObject incObj = new JSONObject();
								JSONObject excObj = new JSONObject();
								if (object.getJSONObject("travel").has("travelFrom")) {
									if (object.getJSONObject("travel").has("travelTo")) {
										incObj.put("operator", "BETWEEN");
										incObj.put("from", object.getJSONObject("travel").getString("travelFrom").substring(0, 19));
										incObj.put("to", object.getJSONObject("travel").getString("travelTo").substring(0, 19));
									} else {
										incObj.put("operator", "GREATERTHANEQUALTO");
										incObj.put("value", object.getString("travelFrom").substring(0, 19));
									}
								} else if (object.getJSONObject("travel").has("travelTo")) {
									incObj.put("operator", "LESSTHANEQUALTO");
									incObj.put("value", object.getJSONObject("travel").getString("travelTo").substring(0, 19));
								}
								if (object.getJSONObject("travel").has("blockOutFrom")) {
									if (object.getJSONObject("travel").has("blockOutTo")) {
										excObj.put("operator", "BETWEEN");
										excObj.put("from", object.getJSONObject("travel").getString("blockOutFrom").substring(0, 19));
										excObj.put("to", object.getJSONObject("travel").getString("blockOutTo").substring(0, 19));
									} else {
										excObj.put("operator", "GREATERTHANEQUALTO");
										excObj.put("value", object.getJSONObject("travel").getString("blockOutFrom").substring(0, 19));
									}
								} else {
									if (object.getJSONObject("travel").has("blockOutTo")) {
										excObj.put("operator", "LESSTHANEQUALTO");
										excObj.put("value", object.getJSONObject("travel").getString("blockOutTo").substring(0, 19));
									}
								}
								if (incObj.length()!=0) {
									incArr.put(incObj);
								}
								if (excObj.length()!=0) {
									excArr.put(excObj);
								}		
								JSONArray date = new JSONArray();
								if (incArr.length() > 0) {
									JSONObject inclusion = new JSONObject();
									inclusion.put("inclusion", incArr);
									date.put(inclusion);
								}
								if (excArr.length() > 0) {
									JSONObject exclusion = new JSONObject();
									exclusion.put("exclusion", excArr);
									date.put(exclusion);
								}
								validityBaseObj.put("travel", date);
							}
							if(object.has("_id") && validity.getJSONArray("salePlusTravel").length()>1){
								validityBaseObj.put("RuleID", validityBaseObj.getString("RuleID")+object.getString("_id"));
								validityCalcObj.put("RuleID", validityCalcObj.getString("RuleID")+object.getString("_id"));
							}
							validityBaseArr.put(validityBaseObj);
							validityCalcArr.put(validityCalcObj);
						}	
					}
					mainJson.put(baseDT,validityBaseArr);
					mainJson.put(calculationDT,validityCalcArr);
					break;
				}
				}
		}
	}
	

	public static void setSaleTravelDateCU(JSONArray array, String validityType, String baseDT, String calculationDT,JSONObject mainJson ) {
		String from = validityType+"From";
		String to =  validityType+"To";
		JSONArray validityBaseArr = new JSONArray();
		JSONArray validityCalcArr = new JSONArray();
		for (int i = 0; i < array.length(); i++) {
			for(int j = 0; j<mainJson.getJSONArray(baseDT).length(); j++){
				JSONObject validityBaseObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(baseDT).getJSONObject(j).toString()));
				JSONObject validityCalcObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(calculationDT).getJSONObject(j).toString()));
				JSONObject object = array.getJSONObject(i);
				JSONArray incArr = new JSONArray();
				JSONArray excArr = new JSONArray();
				JSONObject incObj = new JSONObject();
				JSONObject excObj = new JSONObject();
				if (object.has(from)) {
					if (object.has(to)) {
						incObj.put("operator", "BETWEEN");
						incObj.put("from", object.getString(from).substring(0, 19));
						incObj.put("to", object.getString(to).substring(0, 19));
					} else {
						incObj.put("operator", "GREATERTHANEQUALTO");
						incObj.put("value", object.getString(from).substring(0, 19));
					}
				} else if (object.has(to)) {
					incObj.put("operator", "LESSTHANEQUALTO");
					incObj.put("value", object.getString(to).substring(0, 19));
				}
				if (object.has("blockOutFrom")) {
					if (object.has("blockOutTo")) {
						excObj.put("operator", "BETWEEN");
						excObj.put("from", object.getString("blockOutFrom").substring(0, 19));
						excObj.put("to", object.getString("blockOutTo").substring(0, 19));
					} else {
						excObj.put("operator", "GREATERTHANEQUALTO");
						excObj.put("value", object.getString("blockOutFrom").substring(0, 19));
					}
				} else {
					if (object.has("blockOutTo")) {
						excObj.put("operator", "LESSTHANEQUALTO");
						excObj.put("value", object.getString("blockOutTo").substring(0, 19));
					}
				}
				if (incObj.length()!=0) {
					incArr.put(incObj);
				}
				if (excObj.length()!=0) {
					excArr.put(excObj);
				}		
				JSONArray date = new JSONArray();
				if (incArr.length() > 0) {
					JSONObject inclusion = new JSONObject();
					inclusion.put("inclusion", incArr);
					date.put(inclusion);
				}
				if (excArr.length() > 0) {
					JSONObject exclusion = new JSONObject();
					exclusion.put("exclusion", excArr);
					date.put(exclusion);
				}
				validityBaseObj.put(validityType, date);
				if(object.has("_id") && array.length()>1){
					validityBaseObj.put("RuleID", validityBaseObj.getString("RuleID")+object.getString("_id"));
					validityCalcObj.put("RuleID", validityCalcObj.getString("RuleID")+object.getString("_id"));
				}
				validityBaseArr.put(validityBaseObj);
				validityCalcArr.put(validityCalcObj);
			}	
		}
		mainJson.put(baseDT,validityBaseArr);
		mainJson.put(calculationDT,validityCalcArr);
	}


	public static void setOtherFeeValidityCU(JSONArray otherFeeArr, JSONObject advanceDefinition) {
		if (advanceDefinition.has("validity")) {
			JSONObject validity = advanceDefinition.getJSONObject("validity");
			if(validity.has("validityType"))
				switch (validity.getString("validityType")) {
				case "sale": {
					setSaleTravelDateOFCU(validity.getJSONArray("sale"),"sale", otherFeeArr);
					break;
				}
				case "travel": {
					setSaleTravelDateOFCU(validity.getJSONArray("travel"),"travel", otherFeeArr);
					break;
				}
				case "sale+travel": {

					int length = otherFeeArr.length();
					for (int i = 0; i < validity.getJSONArray("salePlusTravel").length(); i++) {
						for(int j = 0; j<length; j++){
							JSONObject otherFeeObj = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(j).toString()));								
							JSONObject object = validity.getJSONArray("salePlusTravel").getJSONObject(i);

							if(object.has("sales")){
								JSONArray incArr = new JSONArray();
								JSONArray excArr = new JSONArray();
								JSONObject incObj = new JSONObject();
								JSONObject excObj = new JSONObject();
								if (object.getJSONObject("sales").has("saleFrom")) {
									if (object.getJSONObject("sales").has("saleTo")) {
										incObj.put("operator", "BETWEEN");
										incObj.put("from", object.getJSONObject("sales").getString("saleFrom").substring(0, 19));
										incObj.put("to", object.getJSONObject("sales").getString("saleTo").substring(0, 19));
									} else {
										incObj.put("operator", "GREATERTHANEQUALTO");
										incObj.put("value", object.getJSONObject("sales").getString("saleFrom").substring(0, 19));
									}
								} else if (object.getJSONObject("sales").has("saleTo")) {
									incObj.put("operator", "LESSTHANEQUALTO");
									incObj.put("value", object.getJSONObject("sales").getString("saleTo").substring(0, 19));
								}
								if (object.getJSONObject("sales").has("blockOutFrom")) {
									if (object.getJSONObject("sales").has("blockOutTo")) {
										excObj.put("operator", "BETWEEN");
										excObj.put("from", object.getJSONObject("sales").getString("blockOutFrom").substring(0, 19));
										excObj.put("to", object.getJSONObject("sales").getString("blockOutTo").substring(0, 19));
									} else {
										excObj.put("operator", "GREATERTHANEQUALTO");
										excObj.put("value", object.getJSONObject("sales").getString("blockOutFrom").substring(0, 19));
									}
								} else {
									if (object.getJSONObject("sales").has("blockOutTo")) {
										excObj.put("operator", "LESSTHANEQUALTO");
										excObj.put("value", object.getJSONObject("sales").getString("blockOutTo").substring(0, 19));
									}
								}
								if (incObj.length()!=0) {
									incArr.put(incObj);
								}
								if (excObj.length()!=0) {
									excArr.put(excObj);
								}		
								JSONArray date = new JSONArray();
								if (incArr.length() > 0) {
									JSONObject inclusion = new JSONObject();
									inclusion.put("inclusion", incArr);
									date.put(inclusion);
								}
								if (excArr.length() > 0) {
									JSONObject exclusion = new JSONObject();
									exclusion.put("exclusion", excArr);
									date.put(exclusion);
								}
								otherFeeObj.put("sale", date);
							}
							if(object.has("travel")){
								JSONArray incArr = new JSONArray();
								JSONArray excArr = new JSONArray();
								JSONObject incObj = new JSONObject();
								JSONObject excObj = new JSONObject();
								if (object.getJSONObject("travel").has("travelFrom")) {
									if (object.getJSONObject("travel").has("travelTo")) {
										incObj.put("operator", "BETWEEN");
										incObj.put("from", object.getJSONObject("travel").getString("travelFrom").substring(0, 19));
										incObj.put("to", object.getJSONObject("travel").getString("travelTo").substring(0, 19));
									} else {
										incObj.put("operator", "GREATERTHANEQUALTO");
										incObj.put("value", object.getString("travelFrom").substring(0, 19));
									}
								} else if (object.getJSONObject("travel").has("travelTo")) {
									incObj.put("operator", "LESSTHANEQUALTO");
									incObj.put("value", object.getJSONObject("travel").getString("travelTo").substring(0, 19));
								}
								if (object.getJSONObject("travel").has("blockOutFrom")) {
									if (object.getJSONObject("travel").has("blockOutTo")) {
										excObj.put("operator", "BETWEEN");
										excObj.put("from", object.getJSONObject("travel").getString("blockOutFrom").substring(0, 19));
										excObj.put("to", object.getJSONObject("travel").getString("blockOutTo").substring(0, 19));
									} else {
										excObj.put("operator", "GREATERTHANEQUALTO");
										excObj.put("value", object.getJSONObject("travel").getString("blockOutFrom").substring(0, 19));
									}
								} else {
									if (object.getJSONObject("travel").has("blockOutTo")) {
										excObj.put("operator", "LESSTHANEQUALTO");
										excObj.put("value", object.getJSONObject("travel").getString("blockOutTo").substring(0, 19));
									}
								}
								if (incObj.length()!=0) {
									incArr.put(incObj);
								}
								if (excObj.length()!=0) {
									excArr.put(excObj);
								}		
								JSONArray date = new JSONArray();
								if (incArr.length() > 0) {
									JSONObject inclusion = new JSONObject();
									inclusion.put("inclusion", incArr);
									date.put(inclusion);
								}
								if (excArr.length() > 0) {
									JSONObject exclusion = new JSONObject();
									exclusion.put("exclusion", excArr);
									date.put(exclusion);
								}
								otherFeeObj.put("travel", date);
							}
							if(object.has("_id") && validity.getJSONArray("salePlusTravel").length()>1){
								otherFeeObj.put("RuleID", otherFeeObj.getString("RuleID")+object.getString("_id"));
							}
							otherFeeArr.put(otherFeeObj);
						}	
					}
					for(int i=0;i<length;i++){
						otherFeeArr.remove(0);
						System.out.println("sale+trave final "+otherFeeArr.length());
					}
					break;
				}
				}
		}

	}
	

	public static void setSaleTravelDateOFCU(JSONArray array, String validityType, JSONArray otherFeeArr) {
		String from = validityType+"From";
		String to =  validityType+"To";
		int length = otherFeeArr.length();
		for(int  i= 0; i<length; i++){
			for (int j = 0; j < array.length(); j++) {
				JSONObject otherFeeObj = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject object = array.getJSONObject(j);
				JSONArray incArr = new JSONArray();
				JSONArray excArr = new JSONArray();
				JSONObject incObj = new JSONObject();
				JSONObject excObj = new JSONObject();
				if (object.has(from)) {
					if (object.has(to)) {
						incObj.put("operator", "BETWEEN");
						incObj.put("from", object.getString(from).substring(0, 19));
						incObj.put("to", object.getString(to).substring(0, 19));
					} else {
						incObj.put("operator", "GREATERTHANEQUALTO");
						incObj.put("value", object.getString(from).substring(0, 19));
					}
				} else if (object.has(to)) {
					incObj.put("operator", "LESSTHANEQUALTO");
					incObj.put("value", object.getString(to).substring(0, 19));
				}
				if (object.has("blockOutFrom")) {
					if (object.has("blockOutTo")) {
						excObj.put("operator", "BETWEEN");
						excObj.put("from", object.getString("blockOutFrom").substring(0, 19));
						excObj.put("to", object.getString("blockOutTo").substring(0, 19));
					} else {
						excObj.put("operator", "GREATERTHANEQUALTO");
						excObj.put("value", object.getString("blockOutFrom").substring(0, 19));
					}
				} else {
					if (object.has("blockOutTo")) {
						excObj.put("operator", "LESSTHANEQUALTO");
						excObj.put("value", object.getString("blockOutTo").substring(0, 19));
					}
				}
				if (incObj.length()!=0) {
					incArr.put(incObj);
				}
				if (excObj.length()!=0) {
					excArr.put(excObj);
				}		
				JSONArray date = new JSONArray();
				if (incArr.length() > 0) {
					JSONObject inclusion = new JSONObject();
					inclusion.put("inclusion", incArr);
					date.put(inclusion);
				}
				if (excArr.length() > 0) {
					JSONObject exclusion = new JSONObject();
					exclusion.put("exclusion", excArr);
					date.put(exclusion);
				}
				otherFeeObj.put(validityType, date);
				if(object.has("_id") && array.length()>1){
					otherFeeObj.put("RuleID", otherFeeObj.getString("RuleID")+object.getString("_id"));
				}
				otherFeeArr.put(otherFeeObj);
			}	
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
			System.out.println("sales final"+otherFeeArr.length());
		}
	}
	
	
	public static void setOtherFeeDestinationCU(JSONArray otherFeeArr, JSONObject advanceDefinition) {
		if (advanceDefinition.has("travelDestination")) {
			JSONArray destinations = advanceDefinition.getJSONObject("travelDestination").getJSONArray("destinations");
			int length = otherFeeArr.length();
			if (destinations.length() > 0) {
				for (int i = 0; i < destinations.length(); i++) {
					for(int j = 0; j<length; j++){
						String continent = null,country = null,state = null,city = null;
						JSONObject otherFeeObj = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(j).toString()));
						if(destinations.getJSONObject(i).has("continent") && !destinations.getJSONObject(i).getString("continent").equalsIgnoreCase("All"))
							continent = destinations.getJSONObject(i).getString("continent");
						if(destinations.getJSONObject(i).has("country") && !destinations.getJSONObject(i).getString("country").equalsIgnoreCase("All"))
							country = destinations.getJSONObject(i).getString("country");
						if(destinations.getJSONObject(i).has("state") && !destinations.getJSONObject(i).getString("state").equalsIgnoreCase("All"))
							state = destinations.getJSONObject(i).getString("state");
						if(destinations.getJSONObject(i).has("city") && !destinations.getJSONObject(i).getString("city").equalsIgnoreCase("All"))
							city = destinations.getJSONObject(i).getString("city");

						if(destinations.getJSONObject(i).has("_id") && destinations.length()>1){
							otherFeeObj.put("RuleID", otherFeeObj.getString("RuleID")+destinations.getJSONObject(i).getString("_id"));
						}

						if (advanceDefinition.getJSONObject("travelDestination").getBoolean("isInclusion")) {
							otherFeeObj.putOpt("continent", continent);							
							otherFeeObj.putOpt("country", country);							
							otherFeeObj.putOpt("state", state);						
							otherFeeObj.putOpt("city", city);
						}else{							
							otherFeeObj.putOpt("continent_exclusion", continent);						
							otherFeeObj.putOpt("country_exclusion", country);						
							otherFeeObj.putOpt("state_exclusion", state);							
							otherFeeObj.putOpt("city_exclusion", city);
						}
						otherFeeArr.put(otherFeeObj);
					}
				}
				for(int i=0;i<length;i++){
					otherFeeArr.remove(0);
				}
			}
		}
	}
	
	

	
	
	


	
	
	
	
}
