package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;
import cnk.kafkaConsumer.ReceiveMDMRequest;

public class Air {
	public static String commDefnRuleID,overCT,plbCT,segCT,serCT,issCT,mngtCT,destCT,commCT;
	public static boolean overSet,plbSet,destSet,segSet,serSet,issSet,mngtSet,commSet;

	public static String setCommercials(JSONObject mdmDefn, String productName, String productCategory, String productCategorySubType,String supplier, JSONArray supplierMarkets) throws Exception {
		JSONObject mainJson = new JSONObject();
		if(mdmDefn.has("SupplierCommercialData") && mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
			String supplierCommercialDataID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
			JSONArray baseArr = new JSONArray();
			JSONArray calcArr = new JSONArray();
			JSONObject standardCommercial = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
			mainJson.put("CommercialDefinitionDT", CommonFunctions.getStandardCommercialDefiniton(mdmDefn,productCategory,productCategorySubType,supplier,supplierMarkets,"Standard"));

			JSONObject base = new JSONObject();
			JSONObject calculation = new JSONObject();
			base.put("RuleID", "BASE_Standard"+supplierCommercialDataID);
			commDefnRuleID= CommonFunctions.commDefnID;
			base.put("selectedRow", commDefnRuleID);
			base.put("type","base");
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", standardCommercial.getString("contractValidityFrom").substring(0, 19));
			contractValidity.put("to", standardCommercial.getString("contractValidityTo").substring(0, 19));
			base.put("contractValidity", contractValidity);
			calculation.put("type", "calculation");
			calculation.put("RuleID", "CALCULATION_Standard"+supplierCommercialDataID);
			calculation.put("selectedRow", "BASE_Standard"+supplierCommercialDataID);
			baseArr.put(base);
			calcArr.put(calculation);
			
			String stdmdmRuleID = supplierCommercialDataID+"|standardCommercial|null|";
			String fixed = stdmdmRuleID+="fixed";

			int length = baseArr.length();
			for(int i=0;i<length;i++){
				if(standardCommercial.getBoolean("isFixed")){
					calcArr.getJSONObject(i).put("mdmRuleID", fixed);
					CommonFunctions.getFixedDetails(calcArr.getJSONObject(i),standardCommercial.getJSONObject("fixed"));
				}else CommonFunctions.getSlabDetails(baseArr,calcArr,standardCommercial.getJSONArray("slab"),stdmdmRuleID);
			}

			mainJson.put("StandardCommercialBaseDT", baseArr);
			mainJson.put("StandardCommercialCalculationDT", calcArr);

			if(standardCommercial.has("advanceDefinationId")){
				for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
					if(advanceDefinationData.getString("_id").equals(standardCommercial.getString("advanceDefinationId"))){
						JSONObject advanceDefinitionAir = advanceDefinationData.getJSONObject("advanceDefinitionAir");
						setAirAdvancedDefinition(baseArr,calcArr,advanceDefinitionAir,"Standard");
					}
				}
			}

			JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
			setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,supplierCommercialDataID);
		}
		System.out.println("Air Transactional: "+mainJson.toString());
		return mainJson.toString();
	}


	private static void setAdvancedCommercials(JSONObject mdmDefn, JSONArray commercialHead, JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject standardCommercial, String supplier, JSONArray supplierMarkets,String productCategory, String productCategorySubType, String productName, String supplierCommercialDataID) throws Exception {
		Boolean settlement=false;
		JSONObject settlementObject = new JSONObject();
		String advanceCommercialDataID = supplierCommercialDataID+"|advanceCommercialData|";
		String tempAdvCommID = advanceCommercialDataID;
		for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length();i++){
			JSONObject advanceCommercialData = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i);
			JSONObject advanceCommercial = advanceCommercialData.getJSONObject("advanceCommercial");
			advanceCommercialDataID+=advanceCommercialData.getString("_id");
			String displayName = advanceCommercial.getJSONObject("commercialHeadInfo").getString("displayName");
			switch(displayName){
			case "Overriding Commission":{
				JSONObject overRidingCommission = advanceCommercial.getJSONObject("overRidingCommission");
				setContractType("Overriding Commission",overRidingCommission);
				setAdvancedCommercial("OverridingCommercialBaseDT","OverridingCommercialCalculationDT","Overriding",overRidingCommission,mainJson,mdmDefn,commercialHead,overCT,overSet,advanceCommercialDataID);
				break;
			}
			case "Productivity Linked Bonus":{
				JSONObject plb = advanceCommercial.getJSONObject("plb");
				setContractType("Productivity Linked Bonus",plb);
				setAdvancedCommercial("PLBCommercialBaseDT","PLBCommercialCalculationDT","PLB",plb,mainJson,mdmDefn,commercialHead,plbCT,plbSet,advanceCommercialDataID);
				break;
			}
			case "Sector Incentives":{
				JSONObject sectorWiseIncentives = advanceCommercial.getJSONObject("sectorWiseIncentives");
				setContractType("Sector Incentives",sectorWiseIncentives);
				setAdvancedCommercial("SectorWiseIncentiveBaseDT","SectorWiseIncentiveCalculationDT","SectorWiseIncentives",sectorWiseIncentives,mainJson,mdmDefn,commercialHead,destCT,destSet,advanceCommercialDataID);
				break;
			}
			case "Segments Fees":{
				JSONObject segmentFees = advanceCommercial.getJSONObject("segmentFees");
				setContractType("Segment Fees",segmentFees);
				setAdvancedCommercial("SegmentFeeBaseDT","SegmentFeeCalculationDT","SegmentFees",segmentFees,mainJson,mdmDefn,commercialHead,segCT,segSet,advanceCommercialDataID);
				break;
			}
			case "Service Charges":{
				JSONObject serviceCharge = advanceCommercial.getJSONObject("serviceCharge");
				setContractType("Service Charges",serviceCharge);
				setAdvancedCommercial("ServiceChargeBaseDT","ServiceChargeCalculationDT","ServiceCharges",serviceCharge,mainJson,mdmDefn,commercialHead,serCT,serSet,advanceCommercialDataID);
				break;
			}
			case "Issuance Fees":{
				JSONObject issuanceFees = advanceCommercial.getJSONObject("issuanceFees");
				setContractType("Issuance Fees",issuanceFees);
				setAdvancedCommercial("IssuanceFeeBaseDT","IssuanceFeeCalculationDT","IssuanceFees",issuanceFees,mainJson,mdmDefn,commercialHead,issCT,issSet,advanceCommercialDataID);
				break;
			}
			case "Commission":{
				JSONObject commissionFlights = advanceCommercial.getJSONObject("commissionFlights");
				setContractType("Commission",commissionFlights);
				setAdvancedCommercial("CommissionBaseDT","CommissionCalculationDT","Commission",commissionFlights,mainJson,mdmDefn,commercialHead,commCT,commSet,advanceCommercialDataID);
				break;
			}
			case "Management Fee":{
				JSONObject managementFees = advanceCommercial.getJSONObject("managementFees");
				setContractType("Management Fee",managementFees);
				setAdvancedCommercial("ManagementFeesBaseDT","ManagementFeesCalculationDT","ManagementFees",managementFees,mainJson,mdmDefn,commercialHead,mngtCT,mngtSet,advanceCommercialDataID);
				break;
			}
			default:{
				settlement=true;
				String commercialName = CommonFunctions.getCommercialName(displayName);
				String commDefnID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
				String contractType = null;
				if(standardCommercial.getJSONObject("commercialInformation").has("isProvisional")){
					if(standardCommercial.getJSONObject("commercialInformation").getBoolean("isProvisional"))
						contractType="Provisional";
					else contractType="Final";
				}
				settlementObject = SettlementCommercials.settlementCommercials(commercialName,mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i),supplier,supplierMarkets,productCategory,productCategorySubType,productName,contractType,commDefnID,mdmDefn.getJSONArray("advanceDefinationData"));
			}
			}
			advanceCommercialDataID = tempAdvCommID;
		}
		if(settlement){
			System.out.println("Air Settlement: "+settlementObject.toString());
			InvokeRuleConfigurator.invokeSettlementRuleConfigurator(settlementObject.toString(),productName,ReceiveMDMRequest.method);
			SettlementCommercials.main=null;
		}
	}


	private static void setContractType(String displayName, JSONObject jsonObject) {
		String contractType="Final";boolean settlementTransactionWise=false;
		if(jsonObject.getJSONObject("commercialInformation").has("isProvisional")){
			if(jsonObject.getJSONObject("commercialInformation").getBoolean("isProvisional"))
				contractType="Provisional";
			else contractType="Final";
		}
		if(jsonObject.has("isSettlementTransactionWise"))
			settlementTransactionWise= jsonObject.getBoolean("isSettlementTransactionWise");

		switch(displayName){
		case "Overriding Commission":{overCT=contractType;overSet=settlementTransactionWise;break;}
		case "Productivity Linked Bonus":{plbCT=contractType;plbSet=settlementTransactionWise;break;}
		case "Sector Incentives":{destCT=contractType;destSet=settlementTransactionWise;break;}
		case "Segment Fees":{segCT=contractType;segSet=settlementTransactionWise;break;}
		case "Service Charges":{serCT=contractType;serSet=settlementTransactionWise;break;}
		case "Issuance Fees":{issCT=contractType;issSet=settlementTransactionWise;break;}
		case "Management Fee":{mngtCT=contractType;mngtSet=settlementTransactionWise;break;}
		case "Commission":{commCT=contractType;commSet=settlementTransactionWise;break;}
		default:System.out.println("default of Holidays.setContractType");
		}
	}


	public static void setAdvancedCommercial(String baseDT, String calculationDT, String commercialName, JSONObject advanceCommercial, JSONObject mainJson, JSONObject mdmDefn, JSONArray commercialHead, String contractType, boolean settlementTransactionWise, String advanceCommercialDataID) {
		String netOffCommercialHead=null;
		String commercialType = advanceCommercial.getJSONObject("commercialInformation").getString("commercialType");
		if(advanceCommercial.has("calculation")){
			if(advanceCommercial.getJSONObject("calculation").has("netOffCommercialHead"))
				netOffCommercialHead = CommonFunctions.getCommercialName(advanceCommercial.getJSONObject("calculation").getString("netOffCommercialHead"));
		}
		CommonFunctions.setCommercialHead(commercialName,commercialHead,netOffCommercialHead,commercialType,contractType,settlementTransactionWise);

		JSONArray baseArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		JSONObject base = new JSONObject();
		JSONObject calc = new JSONObject();
		base.put("RuleID", "BASE");
		base.put("selectedRow", commDefnRuleID);
		calc.put("RuleID", "CALCULATION");
		calc.put("selectedRow", "BASE");
		base.put("type", "base");
		calc.put("type", "calculation");
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", advanceCommercial.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", advanceCommercial.getString("contractValidityTo").substring(0, 19));
		base.put("contractValidity", contractValidity);

		if(advanceCommercial.getJSONArray("IATANumbers").length()>0)
			base.put("IATANumber", advanceCommercial.getJSONArray("IATANumbers"));
		if(advanceCommercial.has("calculationType")){
			if(advanceCommercial.getString("calculationType").equals("fixed"))
				CommonFunctions.getFixedDetails(calc,advanceCommercial.getJSONObject("fixed"));
		}else if(advanceCommercial.has("fixed"))
			CommonFunctions.getFixedDetails(calc,advanceCommercial.getJSONObject("fixed"));

		baseArr.put(base);
		calcArr.put(calc);
		mainJson.put(baseDT, baseArr);
		mainJson.put(calculationDT, calcArr);

		if(advanceCommercial.getJSONArray("client").length()>0)
			CommonFunctions.getClientDetails(baseArr,calcArr,advanceCommercial.getJSONArray("client"));

		boolean slab=false;
		if((advanceCommercial.has("calculationType") && advanceCommercial.getString("calculationType").equals("slab")) || (!advanceCommercial.has("calculationType") && advanceCommercial.has("slab"))){
			slab=true;
			advanceCommercialDataID+="|";
			CommonFunctions.getSlabDetails(baseArr,calcArr,advanceCommercial.getJSONArray("slab"),advanceCommercialDataID);
		}

		if(!slab){
			int length=calcArr.length();
			advanceCommercialDataID+="|fixed";
			for(int i=0;i<length;i++){
				calcArr.getJSONObject(i).put("mdmRuleID", advanceCommercialDataID);
				CommonFunctions.getFixedDetails(calcArr.getJSONObject(i), advanceCommercial.getJSONObject("fixed"));
			}
		}

		if(advanceCommercial.has("advanceDefinationId")){
			String advDefnID = advanceCommercial.getString("advanceDefinationId");
			for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
				JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
				if(advanceDefinationData.getString("_id").equals(advDefnID)){
					JSONObject advanceDefinitionAir = advanceDefinationData.getJSONObject("advanceDefinitionAir");
					if(!commercialName.equals("PLB"))
						setAirAdvancedDefinition(baseArr,calcArr,advanceDefinitionAir,commercialName);
					else setPLBAdvancedDefinition(baseArr,calcArr,advanceDefinitionAir,commercialName);
				}
			}
		}
	}


	private static void setPLBAdvancedDefinition(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String commercialName) {
		int length = baseArr.length();
		if(length==0){
			length=1;
			JSONObject base = new JSONObject();
			JSONObject calculation = new JSONObject();
			base.put("RuleID", "BASE");
			base.put("selectedRow", commDefnRuleID);
			calculation.put("RuleID","CALCULATION");
			calculation.put("selectedRow","BASE");
			base.put("type", "base");
			calculation.put("type", "calculation");
			//base.put("contractValidity", getContractValidity(commercialName));
			base.put("productName", "Flight");
			baseArr.put(base);
			calcArr.put(calculation);
		}
		for(int i=0;i<length;i++){
			if(advanceDefinitionAir.has("validity")){
				JSONObject validity = advanceDefinitionAir.getJSONObject("validity");
				switch(validity.getString("validityType")){
				case "ticketing":{
					CommonFunctions.getPLBDates(baseArr,calcArr,validity.getJSONArray("ticketing"),"ticketing",true);
					break;
				}
				case "travel":{
					CommonFunctions.getPLBDates(baseArr,calcArr,validity.getJSONArray("travel"),"travel",false);
					break;
				}
				default:{
					JSONArray ticketingPlusTravel = validity.getJSONArray("ticketingPlusTravel");
					CommonFunctions.insertPLBTicketingPlusTravel(ticketingPlusTravel,baseArr,calcArr,true,false);
					break;
				}
				}
			}

			if(advanceDefinitionAir.has("connectivity") && advanceDefinitionAir.getJSONObject("connectivity")!=null)
				CommonFunctions.getAirConnectivity(baseArr,advanceDefinitionAir.getJSONObject("connectivity"));

			if(advanceDefinitionAir.has("credentials") && advanceDefinitionAir.getJSONArray("credentials").length()>0)
				CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAir.getJSONArray("credentials"),"credentials",true);

			if(advanceDefinitionAir.has("others") && advanceDefinitionAir.getJSONObject("others")!=null){
				JSONObject others = advanceDefinitionAir.getJSONObject("others");
				if(others.has("bookingType"))
					CommonFunctions.getBookingTypeTP(baseArr,others,true);
			}

			if(advanceDefinitionAir.has("bookingClass") && advanceDefinitionAir.getJSONObject("bookingClass")!=null){
				JSONObject bookingClass = advanceDefinitionAir.getJSONObject("bookingClass");
				setAirBookingTypeTP(baseArr, calcArr, bookingClass);
			}

			if(advanceDefinitionAir.has("flightTimings"))
				getFlightTimingsNumbersTP(baseArr,calcArr,advanceDefinitionAir.getJSONObject("flightTimings"),"flightTimings","flightTimeFrom","flightTimeTo");

			if(advanceDefinitionAir.has("flightNumbers"))
				getFlightTimingsNumbersTP(baseArr,calcArr,advanceDefinitionAir.getJSONObject("flightNumbers"),"flightRange","flightRangeFrom","flightRangeTo");

			if(advanceDefinitionAir.has("passengerTypes") && advanceDefinitionAir.getJSONArray("passengerTypes").length()>0)
				CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAir.getJSONArray("passengerTypes"),"passengerTypes",false);

			if(advanceDefinitionAir.has("fareClass")){
				if(advanceDefinitionAir.getJSONObject("fareClass").has("fareBasis")){
					JSONObject fareBasis = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("fareBasis");
					JSONArray fare = fareBasis.getJSONArray("fare");
					if(fareBasis.getBoolean("isInclusion"))
						getFareBasisTP(baseArr,calcArr,fare,true);
					else getFareBasisTP(baseArr,calcArr,fare,false);
				}

				if(advanceDefinitionAir.getJSONObject("fareClass").has("dealCodes")){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes");
					if(dealCodes.getBoolean("isInclusion"))
						CommonFunctions.getTriggerPayoutArrayIncExc(baseArr, calcArr, dealCodes.getJSONArray("dealCodes"), "dealCode", true, false);
					else CommonFunctions.getTriggerPayoutArrayIncExc(baseArr, calcArr, dealCodes.getJSONArray("dealCodes"), "dealCode", false, false);
				}
			}

			if(advanceDefinitionAir.has("travelDestination")){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject("travelDestination");
				if(travelDestination.getBoolean("isInclusion")){
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray("triggerOrPayout"),travelDestination.getJSONArray("soldAndTicketingOptions"),"travelType",true);

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray("triggerOrPayout"),travelDestination.getJSONArray("journeyType"),"journeyType",true);

					getCodeSharedFlightIncludedTP(calcArr,travelDestination.getBoolean("codeshareFlightIncluded"),travelDestination.getJSONArray("triggerOrPayout"),true);
					getFlightTypeTP(calcArr,travelDestination.getBoolean("isDirectFlights"),travelDestination.getJSONArray("triggerOrPayout"),true);
					getFlightLineTypeTP(calcArr,travelDestination.getBoolean("isOnline"),travelDestination.getJSONArray("triggerOrPayout"),true);
					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray("productId").length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray("productId").getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						getTravelProductNameTP(calcArr,travelProductNameArr,travelDestination.getJSONArray("triggerOrPayout"),true);
				}else{
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray("triggerOrPayout"),travelDestination.getJSONArray("soldAndTicketingOptions"),"travelType",false);

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray("triggerOrPayout"),travelDestination.getJSONArray("journeyType"),"journeyType",false);

					getCodeSharedFlightIncludedTP(calcArr,travelDestination.getBoolean("codeshareFlightIncluded"),travelDestination.getJSONArray("triggerOrPayout"),false);
					getFlightTypeTP(calcArr,travelDestination.getBoolean("isDirectFlights"),travelDestination.getJSONArray("triggerOrPayout"),false);
					getFlightLineTypeTP(calcArr,travelDestination.getBoolean("isOnline"),travelDestination.getJSONArray("triggerOrPayout"),false);
					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray("productId").length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray("productId").getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						getTravelProductNameTP(calcArr,travelProductNameArr,travelDestination.getJSONArray("triggerOrPayout"),true);
				}
			}
		}
		int lengthCalc = calcArr.length();
		JSONObject travelDestination = advanceDefinitionAir.getJSONObject("travelDestination");
		JSONArray destinations = travelDestination.getJSONArray("destinations");
		for(int d=0;d<lengthCalc;d++){
			JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(d).toString()));
			JSONArray dest = new JSONArray();
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(travelDestination.getJSONArray("triggerOrPayout"));
			dest.put(triggerPayout);
			dest.put(setAirDestination("inclusion",advanceDefinitionAir.getJSONObject("travelDestination").getJSONArray("journeyType"),new JSONObject(),destinations));
			calculation.put("destination", dest);
			calcArr.put(calculation);
		}
		for(int d=0;d<lengthCalc;d++){
			calcArr.remove(0);
		}
	}


	private static void setAirBookingTypeTP(JSONArray baseArr, JSONArray calcArr, JSONObject bookingClass) {
		int length = baseArr.length();
		JSONArray cabin = bookingClass.getJSONArray("cabin");
		for(int i=0;i<length;i++){
			for(int j=0;j<cabin.length();j++){
				JSONObject cabinObject = cabin.getJSONObject(j);
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(cabinObject.getJSONArray("triggerOrPayout"));
				JSONArray cabinArr = new JSONArray();
				JSONObject cabinJson= new JSONObject();
				cabinArr.put(triggerPayout);
				if(cabinObject.has("cabinClass") && !cabinObject.getString("cabinClass").equalsIgnoreCase("All")){
					if(bookingClass.getBoolean("isInclusion"))
						cabinJson.put("cabinClass", cabinObject.getString("cabinClass"));
					else cabinJson.put("cabinClass_exclusion", cabinObject.getString("cabinClass"));
				}
				if(cabinObject.has("rbd") && !cabinObject.getString("rbd").equalsIgnoreCase("All")){
					if(bookingClass.getBoolean("isInclusion"))
						cabinJson.put("RBD", cabinObject.getString("rbd"));
					else cabinJson.put("RBD_exclusion", cabinObject.getString("rbd"));
				}
				cabinArr.put(cabinJson);
				calculation.put("bookingClass", cabinArr);
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, cabinObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void getFareBasisTP(JSONArray baseArr, JSONArray calcArr, JSONArray fare, boolean isInclusion) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<fare.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject fareObject = fare.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(fareObject.getJSONArray("triggerOrPayout"));
				JSONArray fareArr = new JSONArray();
				JSONArray fareBasisArr = new JSONArray();
				fareArr.put(triggerPayout);
				fareBasisArr.put(fareObject.getString("condition"));
				fareBasisArr.put(fareObject.getString("value"));
				JSONObject FareObject = new JSONObject();
				if(isInclusion)
					FareObject.put("fareBasisValue", fareBasisArr);
				else FareObject.put("fareBasisValue_exclusion", fareBasisArr);
				fareArr.put(FareObject);
				calculation.put("fareBasisValue",fareArr);

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, fareObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void getTravelProductNameTP(JSONArray calcArr, JSONArray travelProductNameArr, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isInclusion)
				flightObject.put("travelproductName", travelProductNameArr);
			else flightObject.put("travelproductName_exclusion", travelProductNameArr);
			flightArr.put(flightObject);
			calculation.put("travelproductName", flightArr);
		}
	}


	private static void getFlightLineTypeTP(JSONArray calcArr, boolean isOnline, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isOnline){
				if(isInclusion)
					flightObject.put("flightLineType", "Online");
				else flightObject.put("flightLineType_exclusion", "Online");
			}else{
				if(isInclusion)
					flightObject.put("flightLineType", "Offline");
				else flightObject.put("flightLineType_exclusion", "Offline");
			}
			flightArr.put(flightObject);
			calculation.put("flightLineType", flightArr);
		}
	}


	private static void getFlightTypeTP(JSONArray calcArr, boolean isDirectFlight, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isDirectFlight){
				if(isInclusion)
					flightObject.put("flightType", "Direct");
				else flightObject.put("flightType_exclusion", "Direct");
			}else{
				if(isInclusion)
					flightObject.put("flightType", "Via");
				else flightObject.put("flightType_exclusion", "Via");
			}
			flightArr.put(flightObject);
			calculation.put("flightType", flightArr);
		}
	}


	private static void getCodeSharedFlightIncludedTP(JSONArray calcArr, boolean codeSharedFlightIncluded, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject code = new JSONObject();
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray codeArr = new JSONArray();
			codeArr.put(triggerPayout);
			if(isInclusion)
				code.put("codeSharedFlightIncluded", codeSharedFlightIncluded);
			else code.put("codeSharedFlightIncluded_exclusion", codeSharedFlightIncluded);
			codeArr.put(code);
			calculation.put("codeSharedFlightIncluded", codeArr);
		}
	}


	private static void getFlightTimingsNumbersTP(JSONArray baseArr, JSONArray calcArr, JSONObject flightTiming, String arrayName, String from, String to) {
		int length=baseArr.length();
		JSONArray flighTimeArr = flightTiming.getJSONArray(arrayName);
		for(int i=0;i<length;i++){
			for(int j=0;j<flighTimeArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject timeObject = flighTimeArr.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(timeObject.getJSONArray("triggerOrPayout"));
				JSONArray timeArr = new JSONArray();
				timeArr.put(triggerPayout);
				JSONObject timeObjectMain = new JSONObject();
				if(timeObject.has(from)){
					if(timeObject.has(to)){
						String time = "BETWEEN;"+timeObject.get(from)+";"+timeObject.get(to);
						if(flightTiming.getBoolean("isInclusion"))
							timeObjectMain.put(arrayName, time);
						else timeObjectMain.put(arrayName+"_exclusion", time);
					}else{
						String time = "GREATERTHANEQUALTO;"+timeObject.get(from);
						if(flightTiming.getBoolean("isInclusion"))
							timeObjectMain.put(arrayName, time);
						else timeObjectMain.put(arrayName+"_exclusion", time);
					}
				}else if(timeObject.has(to)){
					String time = "LESSTHANEQUALTO;"+timeObject.get(to);
					if(flightTiming.getBoolean("isInclusion"))
						timeObjectMain.put(arrayName, time);
					else timeObjectMain.put(arrayName+"_exclusion", time);
				}
				timeArr.put(timeObjectMain);
				calculation.put(arrayName, timeArr);
				CommonFunctions.setRuleID(baseArr,calcArr,base,calculation,timeObject.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void setAirAdvancedDefinition(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String commercialName) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
			JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));

			if(advanceDefinitionAir.has("connectivity") && advanceDefinitionAir.getJSONObject("connectivity")!=null){
				JSONObject connectivity = advanceDefinitionAir.getJSONObject("connectivity");
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					base.put("connectivitySupplierType", connectivity.getString("supplierType"));
				if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All"))
					base.put("connectivitySupplier", connectivity.getString("supplierName"));
			}

			if(advanceDefinitionAir.has("credentials") && advanceDefinitionAir.getJSONArray("credentials").length()>0){
				JSONArray credentials = advanceDefinitionAir.getJSONArray("credentials");
				JSONArray crentialsArr = new JSONArray();
				for(int cr=0;cr<credentials.length();cr++){
					crentialsArr.put(credentials.getJSONObject(cr).getString("credentials"));
				}
				base.put("credentialsName", crentialsArr);
			}

			if(advanceDefinitionAir.has("others")){
				if(advanceDefinitionAir.getJSONObject("others")!=null)
					base.put("bookingType", advanceDefinitionAir.getJSONObject("others").getString("bookingType"));
			}

			getAirBookingClass(advanceDefinitionAir, calculation);

			if(advanceDefinitionAir.has("passengerTypes") && advanceDefinitionAir.getJSONArray("passengerTypes").length()>0){
				JSONArray passengerTypes  = advanceDefinitionAir.getJSONArray("passengerTypes");
				JSONArray paxType = new JSONArray();
				for(int pt=0;pt<passengerTypes.length();pt++){
					paxType.put(passengerTypes.getJSONObject(pt).getString("passengerTypes"));
				}
				calculation.put("passengerType", paxType);
			}

			if(advanceDefinitionAir.has("travelDestination")){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject("travelDestination");
				if(travelDestination.getBoolean("isInclusion")){
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						base.put("travelType", travelDestination.get("soldAndTicketingOptions"));

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						base.put("journeyType", travelDestination.get("journeyType"));

					calculation.put("codeShareFlightIncluded", travelDestination.getBoolean("codeshareFlightIncluded"));

					if(travelDestination.getBoolean("isDirectFlights"))
						calculation.put("flightType", "Direct");
					else calculation.put("flightType", "Via");

					if(travelDestination.getBoolean("isOnline"))
						calculation.put("flightLineType", "Online");
					else calculation.put("flightLineType", "Offline");

					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray("productId").length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray("productId").getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						calculation.put("travelProductName", travelProductNameArr);

					setAirDestination("inclusion",advanceDefinitionAir.getJSONObject("travelDestination").getJSONArray("journeyType"),calculation,destinations);
				}else{
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						base.put("travelType_exclusion", travelDestination.get("soldAndTicketingOptions"));

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						base.put("journeyType_exclusion", travelDestination.get("journeyType"));

					calculation.put("codeShareFlightIncluded_exclusion", travelDestination.getBoolean("codeshareFlightIncluded"));

					if(travelDestination.getBoolean("isDirectFlights"))
						calculation.put("flightType_exclusion", "Direct");
					else calculation.put("flightType_exclusion", "Via");

					if(travelDestination.getBoolean("isOnline"))
						calculation.put("flightLineType_exclusion", "Online");
					else calculation.put("flightLineType_exclusion", "Offline");

					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0)
								travelProductNameArr.put(destObj.get("productId"));
						}
					}
					if(travelProductNameArr.length()>0)
						calculation.put("travelProductName_exclusion", travelProductNameArr);

					setAirDestination("exclusion",advanceDefinitionAir.getJSONObject("travelDestination").getJSONArray("journeyType"),calculation,destinations);
				}
			}

			if(advanceDefinitionAir.has("fareClass")){
				if(advanceDefinitionAir.getJSONObject("fareClass").has("fareBasis")){
					JSONArray fare = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("fareBasis").getJSONArray("fare");
					for(int f=0;f<fare.length();f++){
						JSONObject fareObject = fare.getJSONObject(f);
						JSONArray fareArr = new JSONArray();
						if(fareObject.has("condition"))
							fareArr.put(fareObject.getString("condition"));
						if(fareObject.has("value"))
							fareArr.put(fareObject.getString("value"));
						calculation.put("fareBasisValue", fareArr);

						String baseID = base.getString("RuleID");
						String calcID = calculation.getString("RuleID");
						base.put("RuleID", baseID+fareObject.getString("_id"));
						calculation.put("RuleID", calcID+fareObject.getString("_id"));
						calculation.put("selectedRow", baseID+fareObject.getString("_id"));
					}
				}
				if(advanceDefinitionAir.getJSONObject("fareClass").has("dealCodes") && advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes")!=null){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes");
					JSONArray dealCodesArr = dealCodes.getJSONArray("dealCodes");
					JSONArray dealcode= new JSONArray();
					for(int dc=0;dc<dealCodesArr.length();dc++){
						dealcode.put(dealCodesArr.getJSONObject(dc).getString("dealCode"));
					}
					if(dealCodes.getBoolean("isInclusion"))
						calculation.put("dealCode", dealcode);
					else calculation.put("dealCode_exclusion", dealcode);
				}
			}
			baseArr.put(base);
			calcArr.put(calculation);
		}
		for(int w=0;w<length;w++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
		if(advanceDefinitionAir.has("validity")){
			JSONObject validity = advanceDefinitionAir.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "ticketing":{
				CommonFunctions.setDate(baseArr,calcArr,validity.getJSONArray("ticketing"),"ticketing",true);
				break;
			}
			case "travel":{
				CommonFunctions.setDate(baseArr,calcArr,validity.getJSONArray("travel"),"travel",false);
				break;
			}
			default:{
				CommonFunctions.setTravelTicketing(baseArr,calcArr,advanceDefinitionAir.getJSONObject("validity"),true,false);
				break;
			}
			}
		}
		getFlightTimings(baseArr,calcArr,advanceDefinitionAir);
		getFlightNumbers(baseArr,calcArr,advanceDefinitionAir);
	}


	private static void getFlightNumbers(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("flightNumbers")){
			JSONArray flightRange = advanceDefinitionAir.getJSONObject("flightNumbers").getJSONArray("flightRange");
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<flightRange.length();j++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject flightObject  = flightRange.getJSONObject(j);
					String numbers=null;
					if(flightObject.has("flightRangeFrom")){
						if(flightObject.has("flightRangeTo"))
							numbers="BETWEEN"+";"+flightObject.get("flightRangeFrom")+";"+flightObject.get("flightRangeTo");
						else numbers="GREATERTHANEQUALTO"+";"+flightObject.get("flightRangeFrom");
					}else if(flightObject.has("flightRangeTo"))
						numbers="LESSTHANEQUALTO"+";"+flightObject.get("flightRangeTo");

					if(advanceDefinitionAir.getJSONObject("flightNumbers").getBoolean("isInclusion"))
						calculation.put("flightNumber", numbers);
					else calculation.put("flightNumber_exclusion", numbers);

					CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, flightObject.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	private static void getFlightTimings(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("flightTimings")){
			JSONArray flightTimings = advanceDefinitionAir.getJSONObject("flightTimings").getJSONArray("flightTimings");
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				for(int m=0;m<flightTimings.length();m++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject flightTimingObj = flightTimings.getJSONObject(m);
					String timing = null;
					if(flightTimingObj.has("flightTimeFrom")){
						if(flightTimingObj.has("flightTimeTo")){
							timing="BETWEEN";
							timing+=";"+flightTimingObj.getString("flightTimeFrom")+";"+flightTimingObj.getString("flightTimeTo");
						}else{
							timing="GREATERTHANEQUALTO";
							timing+=";"+flightTimingObj.getString("flightTimeFrom");
						}
					}else if(flightTimingObj.has("flightTimeTo")){
						timing="LESSTHANEQUALTO";
						timing+=";"+flightTimingObj.getString("flightTimeTo");
					}
					if(advanceDefinitionAir.getJSONObject("flightTimings").getBoolean("isInclusion"))
						calculation.put("flightTiming", timing);
					else calculation.put("flightTiming_exclusion", timing);	

					CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, flightTimingObj.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	private static JSONObject setAirDestination(String incExc, JSONArray journeyType, JSONObject calculation, JSONArray destinations) {
		String continentMain=null,countryMain=null,cityMain=null,journeyTypeString=null;
		for(int i=0;i<journeyType.length();i++){
			if(i==0)
				journeyTypeString=journeyType.getString(i);
			else journeyTypeString+="&"+journeyType.getString(i);
		}
		for(int i=0;i<destinations.length();i++){
			JSONObject continent = destinations.getJSONObject(i).getJSONObject("continent");
			JSONObject country = destinations.getJSONObject(i).getJSONObject("country");
			JSONObject city = destinations.getJSONObject(i).getJSONObject("city");
			if(i==0){
				if(continent.has("via"))
					continentMain = continent.getString("from")+";"+continent.getString("via")+";"+continent.getString("to");
				else continentMain = continent.getString("from")+";"+null+";"+continent.getString("to");
				if(country.has("via"))
					countryMain = country.getString("from")+";"+country.getString("via")+";"+country.getString("to");
				else countryMain = country.getString("from")+";"+null+";"+country.getString("to");
				if(city.has("via"))
					cityMain = city.getString("from")+";"+city.getString("via")+";"+city.getString("to");
				else cityMain = city.getString("from")+";"+null+";"+city.getString("to");
			}
			else{
				if(continent.has("via"))
					continentMain+="/"+continent.getString("from")+";"+continent.getString("via")+";"+continent.getString("to");
				else continentMain+="/"+continent.getString("from")+";"+null+";"+continent.getString("to");
				if(country.has("via"))
					countryMain+="/"+country.getString("from")+";"+country.getString("via")+";"+country.getString("to");
				else countryMain+="/"+country.getString("from")+";"+null+";"+country.getString("to");
				if(city.has("via"))
					cityMain+="/"+city.getString("from")+";"+city.getString("via")+";"+city.getString("to");
				else cityMain+="/"+city.getString("from")+";"+null+";"+city.getString("to");
			}
		}
		if(incExc=="inclusion"){
			calculation.put("continent", journeyTypeString+";"+continentMain);
			calculation.put("country", journeyTypeString+";"+countryMain);
			calculation.put("city", journeyTypeString+";"+cityMain);
		}else{
			calculation.put("continent_exclusion", journeyTypeString+";"+continentMain);
			calculation.put("country_exclusion", journeyTypeString+";"+countryMain);
			calculation.put("city_exclusion", journeyTypeString+";"+cityMain);
		}
		return calculation;
	}


	public static void getAirBookingClass(JSONObject advanceDefinitionAir, JSONObject calculation) {
		if(advanceDefinitionAir.has("bookingClass")){
			JSONArray cabin = advanceDefinitionAir.getJSONObject("bookingClass").getJSONArray("cabin");
			int cab=0,rbd=0;
			JSONArray cabinArr =new JSONArray();
			JSONArray rbdArr =new JSONArray();
			for(int k=0;k<cabin.length();k++){
				JSONObject cabinObj = cabin.getJSONObject(k);
				if(cabinObj.has("cabinClass")){
					cab=1;cabinArr.put(cabinObj.getString("cabinClass"));
				}
				if(cabinObj.has("rbd")){
					rbd=1;rbdArr.put(cabinObj.getString("rbd"));
				}
			}
			if(advanceDefinitionAir.getJSONObject("bookingClass").getBoolean("isInclusion")){
				if(cab==1)
					calculation.put("cabinClass", cabinArr);
				if(rbd==1)
					calculation.put("RBD", rbdArr);
			}else{
				if(cab==1)
					calculation.put("cabinClass_exclusion", cabinArr);
				if(rbd==1)
					calculation.put("RBD_exclusion", rbdArr);
			}
		}
	}


	private static void getOtherFeesFareBasis(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("fareClass")){
			if(advanceDefinitionAir.getJSONObject("fareClass").has("fareBasis")){
				JSONArray fare = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("fareBasis").getJSONArray("fare");
				int length = otherFeeArr.length();
				for(int i=0;i<length;i++){
					for(int f=0;f<fare.length();f++){
						JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
						JSONObject fareObject = fare.getJSONObject(f);
						JSONArray fareArr = new JSONArray();
						if(fareObject.has("condition"))
							fareArr.put(fareObject.getString("condition"));
						if(fareObject.has("value"))
							fareArr.put(fareObject.getString("value"));
						otherFee.put("fareBasisValue", fareArr);
						String otherFeeID = otherFee.getString("RuleID");
						otherFee.put("RuleID", otherFeeID+fareObject.getString("_id"));
						otherFeeArr.put(otherFee);
					}
				}
				for(int i=0;i<length;i++){
					otherFeeArr.remove(0);
				}
			}
		}
	}


	/*private static void getOtherFeesFlightNumbers(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("flightNumbers")){
			JSONArray flightRange = advanceDefinitionAir.getJSONObject("flightNumbers").getJSONArray("flightRange");
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<flightRange.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject range = flightRange.getJSONObject(j);
					String numbers=null;
					if(range.has("flightRangeFrom")){
						if(range.has("flightRangeTo"))
							numbers="BETWEEN"+";"+range.get("flightRangeFrom")+";"+range.get("flightRangeTo");
						else numbers="GREATERTHANEQUALTO"+";"+range.get("flightRangeFrom");
					}else if(range.has("flightRangeTo"))
						numbers="LESSTHANEQUALTO"+";"+range.get("flightRangeTo");

					if(advanceDefinitionAir.getJSONObject("flightNumbers").getBoolean("isInclusion"))
						otherFee.put("flightNumber", numbers);
					else otherFee.put("flightNumber_exclusion", numbers);

					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, range.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}


	private static void getOtherFeesFlightTiming(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has("flightTimings")){
			JSONArray flightTimings = advanceDefinitionAir.getJSONObject("flightTimings").getJSONArray("flightTimings");
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int m=0;m<flightTimings.length();m++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject timingObject = flightTimings.getJSONObject(m);
					String timing=null;
					if(timingObject.has("flightTimeFrom")){
						if(timingObject.has("flightTimeTo"))
							timing="BETWEEN"+";"+timingObject.get("flightTimeFrom")+";"+timingObject.get("flightTimeTo");
						else timing="GREATERTHANEQUALTO"+";"+timingObject.get("flightTimeFrom");
					}else if(timingObject.has("flightTimeTo"))
						timing="LESSTHANEQUALTO"+";"+timingObject.get("flightTimeTo");

					if(advanceDefinitionAir.getJSONObject("flightTimings").getBoolean("isInclusion"))
						otherFee.put("flightTiming", timing);
					else otherFee.put("flightTiming_exclusion", timing);

					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, timingObject.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}*/


	private static void setAirOtherFeesDestination(JSONArray otherFeeArr, JSONObject advanceDefinitionAir){
		if(advanceDefinitionAir.getJSONObject("travelDestination").has("destinations")){
			JSONArray destinationArray = advanceDefinitionAir.getJSONObject("travelDestination").getJSONArray("destinations");
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<destinationArray.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject destinationObj = destinationArray.getJSONObject(j);
					if(advanceDefinitionAir.getJSONObject("travelDestination").getBoolean("isInclusion")){
						if(destinationObj.has("continent")){
							JSONObject continent = destinationObj.getJSONObject("continent");
							if(continent.has("from") && !continent.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcontinent", continent.getString("from"));
							if(continent.has("via") && !continent.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacontinent", continent.getString("via"));
							if(continent.has("to") && !continent.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocontinent", continent.getString("to"));
						}
						if(destinationObj.has("country")){
							JSONObject country = destinationObj.getJSONObject("country");
							if(country.has("from") && !country.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcountry", country.getString("from"));
							if(country.has("via") && !country.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacountry", country.getString("via"));
							if(country.has("to") && !country.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocountry", country.getString("to"));
						}
						if(destinationObj.has("city")){
							JSONObject city = destinationObj.getJSONObject("city");
							if(city.has("from") && !city.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcity", city.getString("from"));
							if(city.has("via") && !city.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacity", city.getString("via"));
							if(city.has("to") && !city.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocity", city.getString("to"));
						}
					}else{
						if(destinationObj.has("continent")){
							JSONObject continent = destinationObj.getJSONObject("continent");
							if(continent.has("from") && !continent.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcontinent_exclusion", continent.getString("from"));
							if(continent.has("via") && !continent.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacontinentexclusion", continent.getString("via"));
							if(continent.has("to") && !continent.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocontinentexclusion", continent.getString("to"));
						}
						if(destinationObj.has("country")){
							JSONObject country = destinationObj.getJSONObject("country");
							if(country.has("from") && !country.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcountry_exclusion", country.getString("from"));
							if(country.has("via") && !country.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacountry_exclusion", country.getString("via"));
							if(country.has("to") && !country.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocountry_exclusion", country.getString("to"));
						}
						if(destinationObj.has("city")){
							JSONObject city = destinationObj.getJSONObject("city");
							if(city.has("from") && !city.getString("from").equalsIgnoreCase("All"))
								otherFee.put("fromcity_exclusion", city.getString("from"));
							if(city.has("via") && !city.getString("via").equalsIgnoreCase("All"))
								otherFee.put("viacity_exclusion", city.getString("via"));
							if(city.has("to") && !city.getString("to").equalsIgnoreCase("All"))
								otherFee.put("tocity_exclusion", city.getString("to"));
						}
					}
					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, destinationObj.getString("_id"));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}
	
	
	public static void getOtherFeesAdvancedDefinition(JSONArray otherFeeArr, JSONObject advanceDefinitionAir){
		int length =otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee =new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
			if(advanceDefinitionAir.has("connectivity") && advanceDefinitionAir.getJSONObject("connectivity")!=null){
				JSONObject connectivity = advanceDefinitionAir.getJSONObject("connectivity");
				if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplierType", connectivity.getString("supplierType"));
				if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All"))
					otherFee.put("connectivitySupplier", connectivity.getString("supplierName"));
			}
			if(advanceDefinitionAir.has("credentials") && advanceDefinitionAir.getJSONArray("credentials").length()>0){
				JSONArray credentials = advanceDefinitionAir.getJSONArray("credentials");
				JSONArray crentialsArr = new JSONArray();
				for(int cr=0;cr<credentials.length();cr++){
					crentialsArr.put(credentials.getJSONObject(cr).getString("credentials"));
				}
				otherFee.put("credentialsName", crentialsArr);
			}
			if(advanceDefinitionAir.has("others")){
				if(advanceDefinitionAir.getJSONObject("others")!=null)
					otherFee.put("bookingType", advanceDefinitionAir.getJSONObject("others").getString("bookingType"));
			}
			getAirBookingClass(advanceDefinitionAir, otherFee);

			/*
				if(advanceDefinitionAir.has("passengerTypes") && advanceDefinitionAir.getJSONArray("passengerTypes").length()>0){
					JSONArray passengerTypes  = advanceDefinitionAir.getJSONArray("passengerTypes");
					JSONArray paxType = new JSONArray();
					for(int pt=0;pt<passengerTypes.length();pt++){
						paxType.put(passengerTypes.getJSONObject(pt).getString("passengerTypes"));
					}
					otherFee.put("passengerType", paxType);
				}*/
			if(advanceDefinitionAir.has("travelDestination")){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject("travelDestination");
				if(travelDestination.getBoolean("isInclusion")){
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						otherFee.put("travelType", travelDestination.get("soldAndTicketingOptions"));

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						otherFee.put("journeyType", travelDestination.get("journeyType"));

					otherFee.put("codeShareFlightIncluded", travelDestination.getBoolean("codeshareFlightIncluded"));

					if(travelDestination.getBoolean("isDirectFlights"))
						otherFee.put("flightType", "Direct");
					else otherFee.put("flightType", "Via");

					if(travelDestination.getBoolean("isOnline"))
						otherFee.put("flightLineType", "Online");
					else otherFee.put("flightLineType", "Offline");

					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray("productId").length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray("productId").getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						otherFee.put("travelProductName", travelProductNameArr);
				}else{
					if(travelDestination.has("soldAndTicketingOptions") && travelDestination.getJSONArray("soldAndTicketingOptions").length()>0)
						otherFee.put("travelType_exclusion", travelDestination.get("soldAndTicketingOptions"));

					if(travelDestination.has("journeyType") && travelDestination.getJSONArray("journeyType").length()>0)
						otherFee.put("journeyType_exclusion", travelDestination.get("journeyType"));

					otherFee.put("codeShareFlightIncluded_exclusion", travelDestination.getBoolean("codeshareFlightIncluded"));

					if(travelDestination.getBoolean("isDirectFlights"))
						otherFee.put("flightType_exclusion", "Direct");
					else otherFee.put("flightType_exclusion", "Via");

					if(travelDestination.getBoolean("isOnline"))
						otherFee.put("flightLineType_exclusion", "Online");
					else otherFee.put("flightLineType_exclusion", "Offline");

					JSONArray destinations = travelDestination.getJSONArray("destinations");
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has("productId")){
							if(destObj.getJSONArray("productId").length()>0)
								travelProductNameArr.put(destObj.get("productId"));
						}
					}
					if(travelProductNameArr.length()>0)
						otherFee.put("travelProductName_exclusion", travelProductNameArr);


				}
			}
			if(advanceDefinitionAir.has("fareClass")){
				if(advanceDefinitionAir.getJSONObject("fareClass").has("dealCodes") && advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes")!=null){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject("fareClass").getJSONObject("dealCodes");
					JSONArray dealCodesArr = dealCodes.getJSONArray("dealCodes");
					JSONArray dealcode= new JSONArray();
					for(int dc=0;dc<dealCodesArr.length();dc++){
						dealcode.put(dealCodesArr.getJSONObject(dc).getString("dealCode"));
					}
					if(dealCodes.getBoolean("isInclusion"))
						otherFee.put("dealCode", dealcode);
					else otherFee.put("dealCode_exclusion", dealcode);
				}
			}
			otherFeeArr.put(otherFee);
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
		setAirOtherFeesDestination(otherFeeArr,advanceDefinitionAir);
		CommonFunctions.setOtherFeeTicketing(otherFeeArr,advanceDefinitionAir.getJSONObject("validity"));
		getOtherFeesFareBasis(otherFeeArr,advanceDefinitionAir);
		//getOtherFeesFlightTiming(otherFeeArr,advanceDefinitionAir);
		//getOtherFeesFlightNumbers(otherFeeArr,advanceDefinitionAir);
	}
}