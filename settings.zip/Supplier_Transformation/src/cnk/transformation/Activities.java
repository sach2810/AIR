package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;
import cnk.kafkaConsumer.ReceiveMDMRequest;
import java.util.Set;
import java.util.HashSet;

public class Activities {

	public static String setCommercials(JSONObject mdmDefn, String productName, String productCategory,String productCategorySubType, String supplier, JSONArray supplierMarkets) throws Exception {

		JSONObject mainJson = new JSONObject();
		JSONObject commObj;
		JSONObject settlementObject = new JSONObject();
		Boolean settlement=false;
		String commercialName, commercialHeadName,baseDT ,calculationDT,advDefnID = null,RuleID = null,contractType = null;

		//Standard Commercial
		if (mdmDefn.has("SupplierCommercialData") && mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")) {
			RuleID = mdmDefn.getJSONObject("SupplierCommercialData").optString("_id");
			commObj = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
			mainJson.put("CommercialDefinition", CommonFunctions.getStandardCommercialDefinitonCU(commObj, productCategory,productCategorySubType, supplier, supplierMarkets, "Standard"));
			if (mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").has("advanceDefinationId")) {
				advDefnID = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial").getString("advanceDefinationId");
			}
			if(commObj.getJSONObject("commercialInformation").has("isProvisional")){
				if(commObj.getJSONObject("commercialInformation").getBoolean("isProvisional"))
					contractType="Provisional";
				else contractType="Final";
			}
			mainJson = setAdvancedDefinition("StandardCommercialBase", "StandardCommercialCalculation","standardCommercial", mainJson, mdmDefn, commObj, advDefnID, supplier, productCategory,productCategorySubType, productName, RuleID);
		}

		//Other Commercials
		if(mdmDefn.getJSONArray("advanceCommercialData").length()>0) {
			for(int i=0; i<mdmDefn.getJSONArray("advanceCommercialData").length(); i++){
				RuleID = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getString("_id");
				String[] commInfo = getCommercialInfo(mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial"));
				commercialName = commInfo[0];
				commercialHeadName = commInfo[1];
				baseDT = commInfo[2];
				calculationDT = commInfo[3];
				commObj = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i).getJSONObject("advanceCommercial").optJSONObject(commercialName);

				if(commercialName.equals("plb")){
					if(commObj.has("advanceDefinationId")){
						advDefnID = commObj.getString("advanceDefinationId");
					}
					mainJson.getJSONObject("CommercialDefinition").getJSONArray("commercialHead").put(CommonFunctions.getCommercialHead(commObj,commercialHeadName));
					mainJson = setPLBAdvancedDefinition(baseDT, calculationDT,commercialName, mainJson, mdmDefn, commObj, advDefnID, supplier, productCategory,productCategorySubType, productName, RuleID);
				}else if(commercialName.equals("settlement")){
					settlement=true;
					commercialName = CommonFunctions.getCommercialName(commercialHeadName);
					String commDefnID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");				
					settlementObject = SettlementCommercials.settlementCommercials(commercialName,mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i),supplier,supplierMarkets,productCategory,productCategorySubType,productName,contractType,commDefnID,mdmDefn.getJSONArray("advanceDefinationData"));
				}
				else{
					if(commObj.has("advanceDefinationId")){
						advDefnID = commObj.getString("advanceDefinationId");
					}
					mainJson.getJSONObject("CommercialDefinition").getJSONArray("commercialHead").put(CommonFunctions.getCommercialHead(commObj,commercialHeadName));
					mainJson = setAdvancedDefinition(baseDT, calculationDT,commercialName, mainJson, mdmDefn, commObj, advDefnID, supplier, productCategory,productCategorySubType, productName, RuleID);
				}	
			}
			if(settlement){
				System.out.println("Activities Settlement: "+settlementObject.toString());
				InvokeRuleConfigurator.invokeSettlementRuleConfigurator(settlementObject.toString(),productName,ReceiveMDMRequest.method);
				SettlementCommercials.main=null;
			}
		}
		System.out.println("Activities Transactional: "+mainJson);
		return mainJson.toString();
	}

	public static String[] getCommercialInfo(JSONObject advanceCommercial){

		String commInfo[] = new String[4];
		String displayName;
		if(advanceCommercial.has("commercialHeadInfo")){
			if(advanceCommercial.getJSONObject("commercialHeadInfo").has("displayName")){
				displayName =advanceCommercial.getJSONObject("commercialHeadInfo").getString("displayName");	
				switch(displayName){
				case "Overriding Commission":
					commInfo[0] = "overRidingCommission";
					commInfo[1] = "Overriding";
					commInfo[2] = "OverridingCommercialBase";
					commInfo[3] = "OverridingCommercialCalculation";
					break;
				case "Destination Incentives":
					commInfo[0] = "destinationIncentives";
					commInfo[1] = "DestinationIncentive";
					commInfo[2] = "DestinationIncentiveCommercialBase";
					commInfo[3] = "DestinationIncentiveCommercialCalculation";
					break;
				case "Issuance Fees":
					commInfo[0] = "issuanceFees";
					commInfo[1] = "IssuanceFees";
					commInfo[2] = "IssuanceFeesCommercialBase";
					commInfo[3] = "IssuanceFeesCommercialCalculation";
					break;
				case "Service Charges":
					commInfo[0] = "serviceCharge";
					commInfo[1] = "ServiceCharge";
					commInfo[2] = "ServiceChargeCommercialBase";
					commInfo[3] = "ServiceChargeCommercialCalculation";
					break;
				case "Segments Fees":
					commInfo[0] = "segmentFees";
					commInfo[1] = "SegmentFees";
					commInfo[2] = "SegmentFeesCommercialBase";
					commInfo[3] = "SegmentFeesCommercialCalculation";
					break;	
				case "Productivity Linked Bonus":
					commInfo[0] = "plb";
					commInfo[1] = "PLB";
					commInfo[2] = "PLBCommercialBase";
					commInfo[3] = "PLBCommercialCalculation";
					break;
				default:
					commInfo[0] = "settlement";
					commInfo[1] = displayName;
				}
			}
		}
		return commInfo;
	}

	public static JSONObject setAdvancedDefinition(String baseDT, String calculationDT, String commercialName,
			JSONObject mainJson, JSONObject mdmDefn, JSONObject commercialObject, String advancedDefinitionID, String supplier,
			String productCategory, String productCategorySubType, String productName, String RuleID) {

		JSONArray baseArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		JSONObject base = new JSONObject();
		JSONObject calculation = new JSONObject();
		JSONObject advanceDefinitionActivities = new JSONObject();

		base.put("selectedRow", supplier + "_" + productCategory + "_" + productCategorySubType);
		base.put("type", "base");
		base.put("RuleID", RuleID);
		calculation.put("RuleID", RuleID);
		calculation.put("type", "calculation");

		if(mdmDefn.getJSONArray("advanceDefinationData").length()>0){
			for (int i = 0; i < mdmDefn.getJSONArray("advanceDefinationData").length(); i++) {

				JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);

				if (advanceDefinationData.getString("_id").equals(advancedDefinitionID)) {

					advanceDefinitionActivities = advanceDefinationData.getJSONObject("advanceDefinitionActivities");

					//base.put("productName", productName);

					if (advanceDefinitionActivities.has("connectivity")) {
						if (advanceDefinitionActivities.getJSONObject("connectivity").has("supplierType"))
							base.put("connectivitySupplierType", advanceDefinitionActivities.getJSONObject("connectivity").getString("supplierType"));
						if (advanceDefinitionActivities.getJSONObject("connectivity").has("supplierName"))
							base.put("connectivitySupplier", advanceDefinitionActivities.getJSONObject("connectivity").getString("supplierName"));					
					}

					if (advanceDefinitionActivities.has("credentials")) {
						Set<String> credentials = new HashSet<>() ;
						if (advanceDefinitionActivities.getJSONArray("credentials").length() > 0){
							for(int j = 0; j<advanceDefinitionActivities.getJSONArray("credentials").length(); j++){
								if(advanceDefinitionActivities.getJSONArray("credentials").getJSONObject(j).has("credentials"));
								credentials.add(advanceDefinitionActivities.getJSONArray("credentials").getJSONObject(j).getString("credentials"));
							}
							base.put("credentialsName", credentials);
						}
					}

					if (advanceDefinitionActivities.has("others")) {
						if (advanceDefinitionActivities.getJSONObject("others").has("bookingType")) {
							base.put("bookingType",advanceDefinitionActivities.getJSONObject("others").getString("bookingType"));
						}
					}

					if (advanceDefinitionActivities.has("nationality")) {
						Set<String> nationality = new HashSet<>() ;
						if (advanceDefinitionActivities.getJSONArray("nationality").length() > 0) {
							for(int j = 0; j<advanceDefinitionActivities.getJSONArray("nationality").length(); j++){
								if(advanceDefinitionActivities.getJSONArray("nationality").getJSONObject(j).has("clientNationality"));
								nationality.add(advanceDefinitionActivities.getJSONArray("nationality").getJSONObject(j).getString("clientNationality"));
							}
							base.put("nationality", nationality);
						}
					}

					//Pax Type
					if (advanceDefinitionActivities.has("passengerTypes")) {
						Set<String> paxType = new HashSet<>() ;
						if (advanceDefinitionActivities.getJSONArray("passengerTypes").length() > 0){
							for(int j = 0; j<advanceDefinitionActivities.getJSONArray("passengerTypes").length(); j++){
								if(advanceDefinitionActivities.getJSONArray("passengerTypes").getJSONObject(j).has("passengerTypes"));
								paxType.add(advanceDefinitionActivities.getJSONArray("passengerTypes").getJSONObject(j).getString("passengerTypes"));
							}
							calculation.put("participantCategory", paxType);
						}
					}				

					break;
				}
			}
		}
		setCommercialSpecificData(base, calculation, commercialObject, commercialName);
		baseArr.put(base);
		calcArr.put(calculation);
		mainJson.put(baseDT, baseArr);
		mainJson.put(calculationDT, calcArr);
		CommonFunctions.setValidityCU(baseDT,calculationDT,advanceDefinitionActivities,mainJson);
		CommonFunctions.setCLientDetails(baseDT,calculationDT,commercialObject,mainJson);
		setProductDetails(baseDT,calculationDT,commercialObject,mainJson);
		CommonFunctions.setDestinationCU(baseDT,calculationDT,advanceDefinitionActivities,mainJson);
		CommonFunctions.setSlabDetailsCU(baseDT,calculationDT,commercialObject,mainJson);

		for(int i =0; i<mainJson.getJSONArray(baseDT).length();i++){
			mainJson.getJSONArray(baseDT).getJSONObject(i).put("RuleID",mainJson.getJSONArray(baseDT).getJSONObject(i).getString("RuleID")+"base");
			mainJson.getJSONArray(calculationDT).getJSONObject(i).put("RuleID",mainJson.getJSONArray(calculationDT).getJSONObject(i).getString("RuleID")+"calculation");
			mainJson.getJSONArray(calculationDT).getJSONObject(i).put("selectedRow",mainJson.getJSONArray(baseDT).getJSONObject(i).getString("RuleID"));
		}
		return mainJson;
	}

	public static void setCommercialSpecificData(JSONObject base,JSONObject calculation, JSONObject commercial, String commercialName) {

		//Contract Validity
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", commercial.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", commercial.getString("contractValidityTo").substring(0, 19));
		base.put("contractValidity", contractValidity);

		//Segment
		if(commercial.has("slab")){
			if(commercial.getJSONArray("slab").length()>0){
				Set<String> segment = new HashSet<String>();
				for(int i = 0; i<commercial.getJSONArray("slab").length(); i++){
					if(commercial.getJSONArray("slab").getJSONObject(i).has("segments"))
						segment.add(commercial.getJSONArray("slab").getJSONObject(i).getString("segments"));
				}
				if(!segment.isEmpty())
					base.put("segment", segment);
			}			
		}

		JSONObject temp = new JSONObject();
		if(commercial.has("product")){
			if(commercial.optJSONObject("product")!=null){
				if(commercial.getJSONObject("product").has("activities")){
					temp = commercial.getJSONObject("product").getJSONObject("activities");
				}				
			}
			else{
				temp = commercial;
			}
		}
		//IATA Numbers
		if(temp.has("IATANumbers"))
			if(temp.getJSONArray("IATANumbers").length()>0)
				base.put("IATANumber", temp.getJSONArray("IATANumbers"));
		//SupplierRateType And SupplierRateCode
		if(temp.has("supplierRate")){
			if(temp.getJSONArray("supplierRate").length()>0){
				JSONArray suppR = temp.getJSONArray("supplierRate");
				Set<String> supplierRateType = new HashSet<String>();
				Set<String> supplierRateCode = new HashSet<String>();
				//JSONArray supplierRateType = new JSONArray() , supplierRateCode = new JSONArray();
				for(int i = 0; i<suppR.length(); i++){
					if(suppR.getJSONObject(i).has("supplierRatetype"))
						supplierRateType.add(suppR.getJSONObject(i).getString("supplierRatetype"));
					if(suppR.getJSONObject(i).has("supplierRateCode"))
						supplierRateCode.add(suppR.getJSONObject(i).getString("supplierRateCode"));
				}
				if(!supplierRateType.isEmpty())
					base.put("supplierRateType", supplierRateType);
				if(!supplierRateCode.isEmpty())
					base.put("supplierRateCode", supplierRateCode);
			}
		}

		//Calculation
		if(commercial.optBoolean("isFixed") || commercial.optString("calculationType").equalsIgnoreCase("fixed")){
			JSONObject fixed = commercial.getJSONObject("fixed");
			if(fixed.optBoolean("isPercentage")){
				JSONArray perDetails = fixed.getJSONArray("percentageDetails");
				JSONArray fareComp = new JSONArray();
				int j = 0;
				for(int i = 0;i<perDetails.length();i++){
					if(!perDetails.getJSONObject(i).has("farePriceComponents") ||perDetails.getJSONObject(i).getString("farePriceComponents").equalsIgnoreCase("Total")){
						calculation.put("percentageValue", perDetails.getJSONObject(i).get("valuePercentage").toString());
						calculation.put("fareComponent","Total");
						j++;
						break;
					}
					else if(perDetails.getJSONObject(i).getString("farePriceComponents").equalsIgnoreCase("Basic")){
						calculation.put("percentageValue", perDetails.getJSONObject(i).get("valuePercentage").toString());
						fareComp.put("Basic");
					}
					else{
						fareComp.put(perDetails.getJSONObject(i).getString("farePriceComponents").concat("|").concat(perDetails.getJSONObject(i).get("valuePercentage").toString()));
					}
				}
				if(fareComp.length()>0 && j==0){
					calculation.put("fareComponent", CommonFunctions.getFareComponentString(fareComp));
				}
			}
			if(fixed.optBoolean("isAmount")){
				calculation.put("amountValue", fixed.get("valueAmount").toString());
				calculation.put("currency", fixed.getString("currency"));
			}
		}
	}

	private static JSONObject setPLBAdvancedDefinition(String baseDT, String calculationDT, String commercialName,
			JSONObject mainJson, JSONObject mdmDefn, JSONObject commercialObject, String advancedDefinitionID, String supplier,
			String productCategory, String productCategorySubType, String productName, String RuleID) {

		JSONArray baseArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		JSONObject base = new JSONObject();
		JSONObject calculation = new JSONObject();
		JSONObject advanceDefinitionActivities = new JSONObject();

		base.put("selectedRow", supplier + "_" + productCategory + "_" + productCategorySubType);
		base.put("type", "base");
		base.put("RuleID", RuleID);
		calculation.put("RuleID", RuleID);
		calculation.put("type", "calculation");
		setCommercialSpecificData(base, calculation, commercialObject, commercialName);
		baseArr.put(base);
		calcArr.put(calculation);
		if(mdmDefn.getJSONArray("advanceDefinationData").length()>0){
			for (int i = 0; i < mdmDefn.getJSONArray("advanceDefinationData").length(); i++) {

				JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
				if (advanceDefinationData.getString("_id").equals(advancedDefinitionID)) {
					advanceDefinitionActivities = advanceDefinationData.getJSONObject("advanceDefinitionActivities");
					if(advanceDefinitionActivities.has("validity")){
						JSONObject validity = advanceDefinitionActivities.getJSONObject("validity");
						switch(validity.getString("validityType")){
						case "sale":{
							CommonFunctions.getPLBDates(baseArr,calcArr,validity.getJSONArray("sale"),"sale",true);
							break;
						}
						case "travel":{
							CommonFunctions.getPLBDates(baseArr,calcArr,validity.getJSONArray("travel"),"travel",true);
							break;
						}
						default:{
							JSONArray salePlusTravel = validity.getJSONArray("salePlusTravel");
							insertPLBSalePlusTravel(salePlusTravel,baseArr,calcArr);
							break;
						}
						}
					}

					if(advanceDefinitionActivities.has("nationality") && advanceDefinitionActivities.length()>0)
						CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionActivities.getJSONArray("nationality"),"clientNationality",true);

					if(advanceDefinitionActivities.has("passengerTypes") && advanceDefinitionActivities.getJSONArray("passengerTypes").length()>0)
						CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionActivities.getJSONArray("passengerTypes"),"passengerTypes",false);

					if(advanceDefinitionActivities.has("credentials") && advanceDefinitionActivities.getJSONArray("credentials").length()>0)
						CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionActivities.getJSONArray("credentials"),"credentials",true);

					if(advanceDefinitionActivities.has("connectivity") && advanceDefinitionActivities.getJSONObject("connectivity")!=null)
						CommonFunctions.getConnectivityTP(baseArr,advanceDefinitionActivities.getJSONObject("connectivity"));

					if(advanceDefinitionActivities.has("others") && advanceDefinitionActivities.getJSONObject("others")!=null){
						JSONObject others = advanceDefinitionActivities.getJSONObject("others");
						if(others.has("bookingType"))
							//if(others.getBoolean("isInclusion"))
							CommonFunctions.getBookingTypeTP(baseArr,others,true);
						//else CommonFunctions.getBookingType(baseArr,others.getJSONObject("bookingType"),false);
					}

					if(advanceDefinitionActivities.has("travelDestination") && advanceDefinitionActivities.getJSONObject("travelDestination")!=null){
						JSONObject travelDestination = advanceDefinitionActivities.getJSONObject("travelDestination");
						if(travelDestination.getJSONArray("destinations").length()>0){
							if(travelDestination.getBoolean("isInclusion"))
								CommonFunctions.getDestination(baseArr,calcArr,travelDestination.getJSONArray("destinations"),true,false);
							else CommonFunctions.getDestination(baseArr,calcArr,travelDestination.getJSONArray("destinations"),false,false);
						}
					}
				}
			}
		}
		mainJson.put(baseDT, baseArr);
		mainJson.put(calculationDT, calcArr);	
		CommonFunctions.setCLientDetails(baseDT,calculationDT,commercialObject,mainJson);
		CommonFunctions.setSlabDetailsCU(baseDT,calculationDT,commercialObject,mainJson);
		setProductDetails(baseDT,calculationDT,commercialObject,mainJson);

		for(int i =0; i<mainJson.getJSONArray(baseDT).length();i++){
			mainJson.getJSONArray(baseDT).getJSONObject(i).put("RuleID",mainJson.getJSONArray(baseDT).getJSONObject(i).getString("RuleID")+"base");
			mainJson.getJSONArray(calculationDT).getJSONObject(i).put("RuleID",mainJson.getJSONArray(calculationDT).getJSONObject(i).getString("RuleID")+"calculation");
			mainJson.getJSONArray(calculationDT).getJSONObject(i).put("selectedRow",mainJson.getJSONArray(baseDT).getJSONObject(i).getString("RuleID"));
		}
		return mainJson;
	}

	public static void setProductDetails(String baseDT, String calculationDT,JSONObject commercial, JSONObject mainJson) {

		if(commercial.has("product")){
			JSONObject temp = new JSONObject();
			String prodInfo = null;
			if(commercial.optJSONObject("product")!=null){
				if(commercial.getJSONObject("product").has("activities")){
					temp = commercial.getJSONObject("product").getJSONObject("activities");
					prodInfo = "productInformation";
				}				
			}
			else{
				temp = commercial;
				prodInfo = "product";
			}
			JSONArray productBaseArr = new JSONArray();
			JSONArray productCalcArr = new JSONArray();
			JSONArray productInfo = temp.getJSONArray(prodInfo);	
			if(productInfo.length()>0){
				for(int i =0; i<productInfo.length(); i++){
					for(int j =0; j<mainJson.getJSONArray(baseDT).length();j++){
						JSONObject productBaseObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(baseDT).getJSONObject(j).toString()));
						JSONObject productCalcObj = new JSONObject(new JSONTokener(mainJson.getJSONArray(calculationDT).getJSONObject(j).toString()));
						if(productInfo.getJSONObject(i).has("productCategorySubType") && !productInfo.getJSONObject(i).getString("productCategorySubType").equalsIgnoreCase("All"))
							productCalcObj.put("productCategorySubType",productInfo.getJSONObject(i).getString("productCategorySubType"));
						if(productInfo.getJSONObject(i).has("productType") && !productInfo.getJSONObject(i).getString("productType").equalsIgnoreCase("All"))
							productCalcObj.put("productType",productInfo.getJSONObject(i).getString("productType"));
						if(productInfo.getJSONObject(i).has("productName") && !productInfo.getJSONObject(i).getString("productName").equalsIgnoreCase("All"))
							productCalcObj.put("productName",productInfo.getJSONObject(i).getString("productName"));	
						if(productInfo.getJSONObject(i).has("productNameSubType") && !productInfo.getJSONObject(i).getString("productNameSubType").equalsIgnoreCase("All"))
							productCalcObj.put("productNameSubType",productInfo.getJSONObject(i).getString("productNameSubType"));						
						if(productInfo.getJSONObject(i).has("_id") && productInfo.length()>1){
							productBaseObj.put("RuleID", productBaseObj.getString("RuleID")+productInfo.getJSONObject(i).getString("_id"));
							productCalcObj.put("RuleID", productCalcObj.getString("RuleID")+productInfo.getJSONObject(i).getString("_id"));
						}
						productBaseArr.put(productBaseObj);
						productCalcArr.put(productCalcObj);
					}	
				}
				mainJson.put(baseDT,productBaseArr);
				mainJson.put(calculationDT,productCalcArr);	
			}
		}
	}

	private static void insertPLBSalePlusTravel(JSONArray salePlusTravel, JSONArray baseArr, JSONArray calcArr) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(j);
				JSONObject trigPayout = CommonFunctions.getTriggerPayoutObject(salePlusTravelObject.getJSONArray("triggerOrPayout"));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray saleArray = new JSONArray();
				JSONArray travelArray = new JSONArray();
				JSONObject saleinclusion = new JSONObject();
				JSONObject saleexclusion = new JSONObject();
				JSONObject travelinclusion = new JSONObject();
				JSONObject travelexclusion = new JSONObject();
				JSONArray salesDateInclusionArr = new JSONArray();
				JSONArray travelDateInclusionArr = new JSONArray();
				JSONArray salesDateExclusionArr = new JSONArray();
				JSONArray travelDateExclusionArr = new JSONArray();
				JSONObject sale = salePlusTravelObject.getJSONObject("sales");
				JSONObject travel = salePlusTravelObject.getJSONObject("travel");
				JSONObject saleDate = new JSONObject();
				JSONObject travelDate = new JSONObject();
				JSONObject saleExcDate = new JSONObject();
				JSONObject travelExcDate = new JSONObject();
				//sale
				if(sale.has("saleFrom")){
					if(sale.has("saleTo")){
						saleDate.put("operator", "BETWEEN");
						saleDate.put("from", sale.getString("saleFrom"));
						saleDate.put("to", sale.getString("saleTo"));
					}else{
						saleDate.put("operator", "GREATERTHANEQUALTO");
						saleDate.put("value", sale.getString("saleFrom"));
					}
				}else if(sale.has("saleTo")){
					saleDate.put("operator", "LESSTHANEQUALTO");
					saleDate.put("value", sale.getString("saleTo"));
				}
				//travel
				if(travel.has("travelFrom")){
					if(travel.has("travelTo")){
						travelDate.put("operator", "BETWEEN");
						travelDate.put("from", travel.getString("travelFrom"));
						travelDate.put("to", travel.getString("travelTo"));
					}else{
						travelDate.put("operator", "GREATERTHANEQUALTO");
						travelDate.put("value", travel.getString("travelFrom"));
					}
				}else if(travel.has("travelTo")){
					travelDate.put("operator", "LESSTHANEQUALTO");
					travelDate.put("value", travel.getString("travelTo"));
				}
				//blockOut sale
				if(sale.has("blockOutFrom")){
					if(sale.has("blockOutTo")){
						saleExcDate.put("operator", "BETWEEN");
						saleExcDate.put("from", sale.getString("blockOutFrom"));
						saleExcDate.put("to", sale.getString("blockOutTo"));
					}else{
						saleExcDate.put("operator", "GREATERTHANEQUALTO");
						saleExcDate.put("value", sale.getString("blockOutFrom"));
					}
				}else if(sale.has("blockOutTo")){
					saleExcDate.put("operator", "LESSTHANEQUALTO");
					saleExcDate.put("value", sale.getString("blockOutTo"));
				}
				//blockOut travel
				if(travel.has("blockOutFrom")){
					if(travel.has("blockOutTo")){
						travelExcDate.put("operator", "BETWEEN");
						travelExcDate.put("from", travel.getString("blockOutFrom"));
						travelExcDate.put("to", travel.getString("blockOutTo"));
					}else{
						travelExcDate.put("operator", "GREATERTHANEQUALTO");
						travelExcDate.put("value", travel.getString("blockOutFrom"));
					}
				}else if(travel.has("blockOutTo")){
					travelExcDate.put("operator", "LESSTHANEQUALTO");
					travelExcDate.put("value", travel.getString("blockOutTo"));
				}

				saleArray.put(trigPayout);
				travelArray.put(trigPayout);

				if(saleDate.has("operator")){
					salesDateInclusionArr.put(saleDate);
					saleinclusion.put("inclusion", salesDateInclusionArr);
					saleArray.put(saleinclusion);
				}
				if(travelDate.has("operator")){
					travelDateInclusionArr.put(travelDate);
					travelinclusion.put("inclusion", travelDateInclusionArr);
					travelArray.put(travelinclusion);
				}
				if(saleExcDate.has("operator")){
					salesDateExclusionArr.put(saleExcDate);
					saleexclusion.put("exclusion", salesDateExclusionArr);
					saleArray.put(saleexclusion);
				}
				if(travelExcDate.has("operator")){
					travelDateExclusionArr.put(travelExcDate);
					travelexclusion.put("exclusion", travelDateExclusionArr);
					travelArray.put(travelexclusion);
				}

				String baseRuleID = base.getString("RuleID")+salePlusTravelObject.getString("_id");
				String calculationRuleID = calculation.getString("RuleID")+salePlusTravelObject.getString("_id");
				base.put("RuleID", baseRuleID);
				calculation.put("RuleID", calculationRuleID);
				calculation.put("selectedRow", baseRuleID);

				base.put("sale", saleArray);
				base.put("travel", travelArray);

				baseArr.put(base);
				calcArr.put(calculation);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}

	public static void getOtherFeesAdvancedDefinition(JSONArray otherFeeArr, JSONObject advanceDefinition, JSONObject jsonObject, String commDefnID){

		JSONObject otherFee = new JSONObject();
		otherFee.put("RuleID","OtherFee");
		otherFee.put("selectedRow", commDefnID);
		otherFee.put("type", "otherFee");
		JSONObject mdmOtherFees = jsonObject.getJSONObject("advanceCommercial").getJSONObject("otherFees");
		otherFee.put("contractValidity", SettlementCommercials.getContractValidity(mdmOtherFees));
		SettlementCommercials.applyOn(mdmOtherFees,otherFee);
		SettlementCommercials.appliedOnOtherFees(mdmOtherFees,otherFee);
		if(mdmOtherFees.has("fixed")){
			JSONObject fixed = mdmOtherFees.getJSONObject("fixed");
			otherFee.put("commercialAmount", fixed.get("value").toString());
			otherFee.put("commercialCurrency", fixed.getString("currency"));
		}
		if(advanceDefinition.has("connectivity") && advanceDefinition.getJSONObject("connectivity")!=null){
			JSONObject connectivity = advanceDefinition.getJSONObject("connectivity");
			if(connectivity.has("supplierType") && !connectivity.getString("supplierType").equalsIgnoreCase("All"))
				otherFee.put("connectivitySupplierType", connectivity.getString("supplierType"));
			if(connectivity.has("supplierName") && !connectivity.getString("supplierName").equalsIgnoreCase("All"))
				otherFee.put("connectivitySupplier", connectivity.getString("supplierName"));
		}
		if(advanceDefinition.has("credentials") && advanceDefinition.getJSONArray("credentials").length()>0){
			JSONArray credentials = new JSONArray() ;
			for(int i=0;i< advanceDefinition.getJSONArray("credentials").length();i++){
				if( advanceDefinition.getJSONArray("credentials").getJSONObject(i).has("credentials"));
				credentials.put(advanceDefinition.getJSONArray("credentials").getJSONObject(i).getString("credentials"));
			}
			otherFee.put("credentialsName", credentials);
		}
		if(advanceDefinition.has("others")){
			if(advanceDefinition.getJSONObject("others")!=null){
				if (advanceDefinition.getJSONObject("others").has("bookingType")) {
					otherFee.put("bookingType", advanceDefinition.getJSONObject("others").getString("bookingType"));
				}
			}
		}

		/*if(advanceDefinition.has("passengerTypes") && advanceDefinition.getJSONArray("passengerTypes").length()>0){
			JSONArray passengerTypes  = advanceDefinition.getJSONArray("passengerTypes");
			JSONArray paxType = new JSONArray();
			for(int i=0;i<passengerTypes.length();i++){
				paxType.put(passengerTypes.getJSONObject(i).getString("passengerTypes"));
			}
			otherFee.put("participantCategory", paxType);
		}*/

		otherFeeArr.put(otherFee);
		CommonFunctions.setOtherFeeValidityCU(otherFeeArr,advanceDefinition);
		CommonFunctions.setOtherFeeDestinationCU(otherFeeArr,advanceDefinition);
	}


}
