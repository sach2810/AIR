package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;

import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;
import cnk.kafkaConsumer.ReceiveMDMRequest;

public class Cruise {
	public static String overCT,plbCT,destCT,segCT,serCT,issCT,mngtCT,commDefnRuleID;
	public static boolean overSet,plbSet,destSet,segSet,serSet,issSet,mngtSet;
	
	public static String setCommercials(JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		JSONObject mainJson = new JSONObject();
		JSONArray baseArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		if(mdmDefn.has("SupplierCommercialData") && mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
			String supplierCommercialDataID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
			JSONObject standardCommercial = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
			JSONObject commDefn = CommonFunctions.getStandardCommercialDefiniton(mdmDefn,productCategory,productCategorySubType,supplier,supplierMarkets,"Standard");
			mainJson.put("CommercialDefinitionDT", commDefn);
			
			JSONObject base = new JSONObject();
			JSONObject calculation = new JSONObject();
			base.put("RuleID", "BASE"+supplierCommercialDataID);
			base.put("type", "base");
			calculation.put("type", "calculation");
			commDefnRuleID= CommonFunctions.commDefnID;
			base.put("selectedRow", commDefnRuleID);
			calculation.put("RuleID", "CALCULATION"+supplierCommercialDataID);
			calculation.put("selectedRow", "BASE"+supplierCommercialDataID);
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", standardCommercial.getString("contractValidityFrom").substring(0, 19));
			contractValidity.put("to", standardCommercial.getString("contractValidityTo").substring(0, 19));
			base.put("contractValidity", contractValidity);
			baseArr.put(base);
			calcArr.put(calculation);
			mainJson.put("StandardCommercialBaseDT", baseArr);
			mainJson.put("StandardCommercialCalculationDT", calcArr);
			
			if(standardCommercial.has("product")){
				if(standardCommercial.getJSONObject("product").has("transportation")){
					JSONObject transportation = standardCommercial.getJSONObject("product").getJSONObject("transportation");
					if(transportation.has("product")){
						if(transportation.getJSONObject("product").has("genericProduct")){
							for(int i=0;i<baseArr.length();i++){
								JSONObject baseP = baseArr.getJSONObject(i);
								baseP.put("productName", transportation.getJSONObject("product").getJSONObject("genericProduct").getJSONArray("productId"));
							}
						}
					}
				}
			}
			
			if(standardCommercial.has("advanceDefinationId")){
				String advDefnID = standardCommercial.getString("advanceDefinationId");
				for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
					if(advanceDefinationData.getString("_id").equals(advDefnID)){
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject("advanceDefinitionTransportation");
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,false);
					}
				}
			}
			
			String stdmdmRuleID = supplierCommercialDataID+"|standardCommercial|null|";
			String fixed = stdmdmRuleID+="fixed";
			
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				if(standardCommercial.getBoolean("isFixed")){
					calcArr.getJSONObject(i).put("mdmRuleID", fixed);
					CommonFunctions.getFixedDetails(calcArr.getJSONObject(i),standardCommercial.getJSONObject("fixed"));
				}else CommonFunctions.getSlabDetails(baseArr,calcArr,standardCommercial.getJSONArray("slab"),stdmdmRuleID);
			}
			
			JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
			setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,supplierCommercialDataID);
		}
		System.out.println("Cruise Transactional: "+mainJson.toString());
		return mainJson.toString();
	}
	
	
	public static void setAdvancedCommercials(JSONObject mdmDefn, JSONArray commercialHead, JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject standardCommercial, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName, String supplierCommercialDataID) throws Exception {
		Boolean settlement=false;
		JSONObject settlementObject = new JSONObject();
		String advanceCommercialDataID = supplierCommercialDataID+"|advanceCommercialData|";
		String tempAdvCommID = advanceCommercialDataID;
		for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length();i++){
			JSONObject advanceCommercialData = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i);
			JSONObject advanceCommercial = advanceCommercialData.getJSONObject("advanceCommercial");
			advanceCommercialDataID+=advanceCommercialData.getString("_id");
			String displayName = advanceCommercial.getJSONObject("commercialHeadInfo").getString("displayName");
			switch(displayName){
			case "Overriding Commission":{
				JSONObject overRidingCommission = advanceCommercial.getJSONObject("overRidingCommission");
				setContractType("Overriding Commission",overRidingCommission);
				setAdvancedCommercial(mainJson,"OverridingCommercialBaseDT","OverridingCommercialCalculationDT","Overriding",overRidingCommission,mdmDefn,commercialHead,overCT,overSet,advanceCommercialDataID);
				break;
			}
			case "Productivity Linked Bonus":{
				JSONObject plb = advanceCommercial.getJSONObject("plb");
				setContractType("Productivity Linked Bonus",plb);
				setAdvancedCommercial(mainJson,"PLBCommercialBaseDT","PLBCommercialCalculationDT","PLB",plb,mdmDefn,commercialHead,plbCT,plbSet,advanceCommercialDataID);
				break;
			}
			case "Sector Incentives":{
				JSONObject sectorWiseIncentives = advanceCommercial.getJSONObject("sectorWiseIncentives");
				setContractType("Sector Incentives",sectorWiseIncentives);
				setAdvancedCommercial(mainJson,"SectorWiseIncentiveBaseDT","SectorWiseIncentiveCalculationDT","SectorWiseIncentives",sectorWiseIncentives,mdmDefn,commercialHead,destCT,destSet,advanceCommercialDataID);
				break;
			}
			case "Segment Fees":{
				JSONObject segmentFees = advanceCommercial.getJSONObject("segmentFees");
				setContractType("Segment Fees",segmentFees);
				setAdvancedCommercial(mainJson,"SegmentFeeBaseDT","SegmentFeeCalculationDT","SegmentFees",segmentFees,mdmDefn,commercialHead,segCT,segSet,advanceCommercialDataID);
				break;
			}
			case "Service Charges":{
				JSONObject serviceCharge = advanceCommercial.getJSONObject("serviceCharge");
				setContractType("Service Charges",serviceCharge);
				setAdvancedCommercial(mainJson,"ServiceChargeBaseDT","ServiceChargeCalculationDT","ServiceCharges",serviceCharge,mdmDefn,commercialHead,serCT,serSet,advanceCommercialDataID);
				break;
			}
			case "Issuance Fees":{
				JSONObject issuanceFees = advanceCommercial.getJSONObject("issuanceFees");
				setContractType("Issuance Fees",issuanceFees);
				setAdvancedCommercial(mainJson,"IssuanceFeeBaseDT","IssuanceFeeCalculationDT","IssuanceFees",issuanceFees,mdmDefn,commercialHead,issCT,issSet,advanceCommercialDataID);
				break;
			}
			case "Management Fee":{
				JSONObject managementFee = advanceCommercial.getJSONObject("managementFee");
				setContractType("Management Fee",managementFee);
				setAdvancedCommercial(mainJson,"ManagementFeeBaseDT","ManagementFeeCalculationDT","ManagementFee",managementFee,mdmDefn,commercialHead,mngtCT,mngtSet,advanceCommercialDataID);
				break;
			}
			default:{
				settlement=true;
				String commercialName = CommonFunctions.getCommercialName(displayName);
				String commDefnID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
				String contractType = null;
				if(standardCommercial.getJSONObject("commercialInformation").has("isProvisional")){
					if(standardCommercial.getJSONObject("commercialInformation").getBoolean("isProvisional"))
						contractType="Provisional";
					else contractType="Final";
				}
				settlementObject = SettlementCommercials.settlementCommercials(commercialName,mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i),supplier,supplierMarkets,productCategory,productCategorySubType,productName,contractType,commDefnID,mdmDefn.getJSONArray("advanceDefinationData"));
			}
			}
			advanceCommercialDataID = tempAdvCommID;
		}
		if(settlement){
			System.out.println("Cruise Settlement: "+settlementObject.toString());
			InvokeRuleConfigurator.invokeSettlementRuleConfigurator(settlementObject.toString(),productName,ReceiveMDMRequest.method);
			SettlementCommercials.main=null;
		}
	}
	
	
	public static void setAdvancedCommercial(JSONObject mainJson, String baseDT, String calculationDT, String commercialName, JSONObject advanceCommercialNameObject, JSONObject mdmDefn, JSONArray commercialHead, String contractType, boolean settlementTransactionWise, String advanceCommercialDataID) {
		String netOffCommercialHead=null;
		String commercialType = advanceCommercialNameObject.getJSONObject("commercialInformation").getString("commercialType");
		if(advanceCommercialNameObject.has("calculation")){
			if(advanceCommercialNameObject.getJSONObject("calculation").has("netOffCommercialHead"))
				netOffCommercialHead = CommonFunctions.getCommercialName(advanceCommercialNameObject.getJSONObject("calculation").getString("netOffCommercialHead"));
		}
		CommonFunctions.setCommercialHead(commercialName,commercialHead,netOffCommercialHead,commercialType,contractType,settlementTransactionWise);

		JSONArray baseArr =new JSONArray();
		JSONArray calcArr =new JSONArray();
		JSONObject base = new JSONObject();
		JSONObject calculation = new JSONObject();
		base.put("RuleID", "BASE");
		base.put("selectedRow", commDefnRuleID);
		calculation.put("RuleID", "CALCULATION");
		calculation.put("selectedRow", "BASE");
		base.put("type", "base");
		calculation.put("type", "calculation");
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", advanceCommercialNameObject.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", advanceCommercialNameObject.getString("contractValidityTo").substring(0, 19));
		base.put("contractValidity", contractValidity);
		baseArr.put(base);
		calcArr.put(calculation);
		mainJson.put(baseDT, baseArr);
		mainJson.put(calculationDT, calcArr);
		
		/*if(advanceCommercialNameObject.getJSONArray("supplierRate").length()>0)
			CommonFunctions.getSupplierRate(advanceCommercialNameObject.getJSONArray("supplierRate"),calcArr);*/
		
		/*if(advanceCommercialNameObject.getJSONArray("product").length()>0){
			JSONArray product = advanceCommercialNameObject.getJSONArray("product");
			CommonFunctions.getProductDetails(product,baseArr,calcArr);
			baseArr.remove(0);
			calcArr.remove(0);
		}*/
		
		if(advanceCommercialNameObject.getJSONArray("client").length()>0)
			CommonFunctions.getClientDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("client"));
		
		boolean slab=false;
		if((advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.getString("calculationType").equals("slab")) || (!advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.has("slab"))){
			slab=true;
			advanceCommercialDataID+="|";
			CommonFunctions.getSlabDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("slab"),advanceCommercialDataID);
		}
		
		if(!slab){
			int length=calcArr.length();
			advanceCommercialDataID+="|fixed";
			for(int i=0;i<length;i++){
				calcArr.getJSONObject(i).put("mdmRuleID", advanceCommercialDataID);
				CommonFunctions.getFixedDetails(calcArr.getJSONObject(i), advanceCommercialNameObject.getJSONObject("fixed"));
			}
		}
		
		if(advanceCommercialNameObject.has("advanceDefinationId")){
			String advDefnID = advanceCommercialNameObject.getString("advanceDefinationId");
			for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
				JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
				if(advanceDefinationData.getString("_id").equals(advDefnID)){
					JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject("advanceDefinitionTransportation");
					CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,false);
				}
			}
		}
	}
	
	
	private static void setContractType(String displayName, JSONObject jsonObject) {
		String contractType="Final";boolean settlementTransactionWise=false;
		if(jsonObject.getJSONObject("commercialInformation").has("isProvisional")){
			if(jsonObject.getJSONObject("commercialInformation").getBoolean("isProvisional"))
				contractType="Provisional";
			else contractType="Final";
		}
		if(jsonObject.has("isSettlementTransactionWise"))
			settlementTransactionWise= jsonObject.getBoolean("isSettlementTransactionWise");
		
		switch(displayName){
		case "Overriding Commission":{overCT=contractType;overSet=settlementTransactionWise;break;}
		case "Productivity Linked Bonus":{plbCT=contractType;plbSet=settlementTransactionWise;break;}
		case "Sector Incentives":{destCT=contractType;destSet=settlementTransactionWise;break;}
		case "Segment Fees":{segCT=contractType;segSet=settlementTransactionWise;break;}
		case "Service Charges":{serCT=contractType;serSet=settlementTransactionWise;break;}
		case "Issuance Fees":{issCT=contractType;issSet=settlementTransactionWise;break;}
		case "Management Fee":{mngtCT=contractType;mngtSet=settlementTransactionWise;break;}
		default:System.out.println("default of Cruise.setContractType due to displayName: "+displayName);
		}
	}
}
