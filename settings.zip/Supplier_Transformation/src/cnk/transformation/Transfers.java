package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.transformation.CommonFunctions;
import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;
import cnk.kafkaConsumer.ReceiveMDMRequest;

public class Transfers {
	public static String overCT,plbCT,destCT,segCT,serCT,issCT,mngtCT,commDefnRuleID;
	public static boolean overSet,plbSet,destSet,segSet,serSet,issSet,mngtSet;
	
	public static String setCommercials(JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		JSONObject mainJson = new JSONObject();
		JSONArray baseArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		if(mdmDefn.has("SupplierCommercialData") && mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
			String supplierCommercialDataID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
			JSONObject standardCommercial = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
			JSONObject commDefn = CommonFunctions.getStandardCommercialDefiniton(mdmDefn,productCategory,productCategorySubType,supplier,supplierMarkets,"Standard");
			mainJson.put("CommercialDefinitionDT", commDefn);

			JSONObject base = new JSONObject();
			JSONObject calculation = new JSONObject();
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", standardCommercial.getString("contractValidityFrom").substring(0, 19));
			contractValidity.put("to", standardCommercial.getString("contractValidityTo").substring(0, 19));
			base.put("contractValidity", contractValidity);
			base.put("RuleID", "BASE"+supplierCommercialDataID);
			base.put("type", "base");
			calculation.put("type", "calculation");
			commDefnRuleID= CommonFunctions.commDefnID;
			base.put("selectedRow", commDefnRuleID);
			calculation.put("RuleID", "CALCULATION"+supplierCommercialDataID);
			calculation.put("selectedRow", "BASE"+supplierCommercialDataID);
			baseArr.put(base);
			calcArr.put(calculation);
			mainJson.put("StandardCommercialBaseDT", baseArr);
			mainJson.put("StandardCommercialCalculationDT", calcArr);
			
			if(standardCommercial.has("product")){
				if(standardCommercial.getJSONObject("product").has("transportation")){
					JSONObject transportation = standardCommercial.getJSONObject("product").getJSONObject("transportation");
					if(transportation.has("product")){
						if(transportation.getJSONObject("product").has("genericProduct")){
							for(int i=0;i<baseArr.length();i++){
								JSONObject baseP = baseArr.getJSONObject(i);
								baseP.put("productName", transportation.getJSONObject("product").getJSONObject("genericProduct").getJSONArray("productId"));
							}
						}
					}
				}
			}

			/*if(standardCommercial.getJSONArray("clients").length()>0)
				CommonFunctions.getClientDetails(baseArr,calcArr,standardCommercial.getJSONArray("clients"));*/

			if(standardCommercial.has("advanceDefinationId")){
				String advDefnID = standardCommercial.getString("advanceDefinationId");
				for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
					if(advanceDefinationData.getString("_id").equals(advDefnID)){
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject("advanceDefinitionTransportation");
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true);
						appendVehicleDetails(baseArr,calcArr,advanceDefinitionTransportation);
						for(int j=0;j<calcArr.length();j++){
							JSONObject calculationClone = calcArr.getJSONObject(i);
							/*if(advanceDefinitionTransportation.has("rateTypeApplicableFor"))
								calculationClone.put("rateTypeApplicableFor", advanceDefinitionTransportation.getString("rateTypeApplicableFor"));
							if(advanceDefinitionTransportation.has("category"))
								calculationClone.put("rateTypeApplicableForCategory", advanceDefinitionTransportation.getString("category"));*/
							if(advanceDefinitionTransportation.getBoolean("isPrepaid"))
								calculationClone.put("modeOfPayment", "Prepaid");
							else calculationClone.put("modeOfPayment", "Postpaid");
						}
					}
				}
			}
			
			String stdmdmRuleID = supplierCommercialDataID+"|standardCommercial|null|";
			String fixed = stdmdmRuleID+="fixed";

			int length = baseArr.length();
			for(int i=0;i<length;i++){
				if(standardCommercial.getBoolean("isFixed")){
					calcArr.getJSONObject(i).put("mdmRuleID", fixed);
					CommonFunctions.getFixedDetails(calcArr.getJSONObject(i),standardCommercial.getJSONObject("fixed"));
				}else CommonFunctions.getSlabDetails(baseArr,calcArr,standardCommercial.getJSONArray("slab"),stdmdmRuleID);
			}
			
			JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
			setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,supplierCommercialDataID);
		}

		System.out.println("Transfers Transactional: "+mainJson.toString());
		return mainJson.toString();
	}
	
	
	public static void setAdvancedCommercials(JSONObject mdmDefn, JSONArray commercialHead, JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject standardCommercial, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName, String supplierCommercialDataID) throws Exception {
		Boolean settlement=false;
		JSONObject settlementObject = new JSONObject();
		String advanceCommercialDataID = supplierCommercialDataID+"|advanceCommercialData|";
		String tempAdvCommID = advanceCommercialDataID;
		for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length();i++){
			JSONObject advanceCommercialData = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i);
			JSONObject advanceCommercial = advanceCommercialData.getJSONObject("advanceCommercial");
			advanceCommercialDataID+=advanceCommercialData.getString("_id");
			String displayName = advanceCommercial.getJSONObject("commercialHeadInfo").getString("displayName");
			switch(displayName){
			case "Overriding Commission":{
				JSONObject overRidingCommission = advanceCommercial.getJSONObject("overRidingCommission");
				setContractType("Overriding Commission",overRidingCommission);
				setAdvancedCommercial(mainJson,"OverridingCommercialBaseDT","OverridingCommercialCalculationDT","Overriding",overRidingCommission,mdmDefn,commercialHead,overCT,overSet,advanceCommercialDataID);
				break;
			}
			case "Productivity Linked Bonus":{
				JSONObject plb = advanceCommercial.getJSONObject("plb");
				setContractType("Productivity Linked Bonus",plb);
				setAdvancedCommercial(mainJson,"PLBCommercialBaseDT","PLBCommercialCalculationDT","PLB",plb,mdmDefn,commercialHead,plbCT,plbSet,advanceCommercialDataID);
				break;
			}
			case "Destination Incentives":{
				JSONObject destinationIncentives = advanceCommercial.getJSONObject("destinationIncentives");
				setContractType("Destination Incentives",destinationIncentives);
				setAdvancedCommercial(mainJson,"DestinationIncentiveCommercialBaseDT","DestinationIncentiveCommercialCalculationDT","DestinationIncentives",destinationIncentives,mdmDefn,commercialHead,destCT,destSet,advanceCommercialDataID);
				break;
			}
			case "Segment Fees":{
				JSONObject segmentFees = advanceCommercial.getJSONObject("segmentFees");
				setContractType("Segment Fees",segmentFees);
				setAdvancedCommercial(mainJson,"SegmentFeeCommercialBaseDT","SegmentFeeCommercialCalculationDT","SegmentFees",segmentFees,mdmDefn,commercialHead,segCT,segSet,advanceCommercialDataID);
				break;
			}
			case "Service Charges":{
				JSONObject serviceCharge = advanceCommercial.getJSONObject("serviceCharge");
				setContractType("Service Charges",serviceCharge);
				setAdvancedCommercial(mainJson,"ServiceChargeCommercialBaseDT","ServiceChargeCommercialCalculationDT","ServiceCharges",serviceCharge,mdmDefn,commercialHead,serCT,serSet,advanceCommercialDataID);
				break;
			}
			case "Issuance Fees":{
				JSONObject issuanceFees = advanceCommercial.getJSONObject("issuanceFees");
				setContractType("Issuance Fees",issuanceFees);
				setAdvancedCommercial(mainJson,"IssuanceFeesCommercialBaseDT","IssuanceFeesCommercialCalculationDT","IssuanceFees",issuanceFees,mdmDefn,commercialHead,issCT,issSet,advanceCommercialDataID);
				break;
			}
			case "Management Fee":{
				JSONObject managementFee = advanceCommercial.getJSONObject("managementFee");
				setContractType("Management Fee",managementFee);
				setAdvancedCommercial(mainJson,"ManagementFeeCommercialBaseDT","ManagementFeeCommercialCalculationDT","ManagementFee",managementFee,mdmDefn,commercialHead,mngtCT,mngtSet,advanceCommercialDataID);
				break;
			}
			default:{
				settlement=true;
				String commercialName = CommonFunctions.getCommercialName(displayName);
				String commDefnID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
				String contractType = null;
				if(standardCommercial.getJSONObject("commercialInformation").has("isProvisional")){
					if(standardCommercial.getJSONObject("commercialInformation").getBoolean("isProvisional"))
						contractType="Provisional";
					else contractType="Final";
				}
				settlementObject = SettlementCommercials.settlementCommercials(commercialName,mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i),supplier,supplierMarkets,productCategory,productCategorySubType,productName,contractType,commDefnID,mdmDefn.getJSONArray("advanceDefinationData"));
			}
			}
			advanceCommercialDataID = tempAdvCommID;
		}
		if(settlement){
			System.out.println("Transfers Settlement: "+settlementObject.toString());
			InvokeRuleConfigurator.invokeSettlementRuleConfigurator(settlementObject.toString(),productName,ReceiveMDMRequest.method);
			SettlementCommercials.main=null;
		}
	}
	
	
	public static void setAdvancedCommercial(JSONObject mainJson, String baseDT, String calculationDT, String commercialName, JSONObject advanceCommercialNameObject, JSONObject mdmDefn, JSONArray commercialHead, String contractType, boolean settlementTransactionWise, String advanceCommercialDataID) {
		String netOffCommercialHead=null;
		String commercialType = advanceCommercialNameObject.getJSONObject("commercialInformation").getString("commercialType");
		if(advanceCommercialNameObject.has("calculation")){
			if(advanceCommercialNameObject.getJSONObject("calculation").has("netOffCommercialHead"))
				netOffCommercialHead = CommonFunctions.getCommercialName(advanceCommercialNameObject.getJSONObject("calculation").getString("netOffCommercialHead"));
		}
		CommonFunctions.setCommercialHead(commercialName,commercialHead,netOffCommercialHead,commercialType,contractType,settlementTransactionWise);

		JSONArray baseArr =new JSONArray();
		JSONArray calcArr =new JSONArray();
		JSONObject base = new JSONObject();
		JSONObject calculation = new JSONObject();
		base.put("RuleID", "BASE");
		base.put("selectedRow", commDefnRuleID);
		calculation.put("RuleID", "CALCULATION");
		calculation.put("selectedRow", "BASE");
		base.put("type", "base");
		calculation.put("type", "calculation");
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", advanceCommercialNameObject.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", advanceCommercialNameObject.getString("contractValidityTo").substring(0, 19));
		base.put("contractValidity", contractValidity);
		baseArr.put(base);
		calcArr.put(calculation);
		mainJson.put(baseDT, baseArr);
		mainJson.put(calculationDT, calcArr);
		
		/*if(advanceCommercialNameObject.getJSONArray("supplierRate").length()>0)
			CommonFunctions.getSupplierRate(advanceCommercialNameObject.getJSONArray("supplierRate"),calcArr);*/
		
		/*if(advanceCommercialNameObject.getJSONArray("product").length()>0){
			JSONArray product = advanceCommercialNameObject.getJSONArray("product");
			CommonFunctions.getProductDetails(product,baseArr,calcArr);
			baseArr.remove(0);
			calcArr.remove(0);
		}*/
		
		if(advanceCommercialNameObject.getJSONArray("client").length()>0)
			CommonFunctions.getClientDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("client"));
		
		boolean slab=false;
		if((advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.getString("calculationType").equals("slab")) || (!advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.has("slab"))){
			slab=true;
			advanceCommercialDataID+="|";
			CommonFunctions.getSlabDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("slab"),advanceCommercialDataID);
		}
		
		if(!slab){
			int length=calcArr.length();
			advanceCommercialDataID+="|fixed";
			for(int i=0;i<length;i++){
				calcArr.getJSONObject(i).put("mdmRuleID", advanceCommercialDataID);
				CommonFunctions.getFixedDetails(calcArr.getJSONObject(i), advanceCommercialNameObject.getJSONObject("fixed"));
			}
		}
		
		if(advanceCommercialNameObject.has("advanceDefinationId")){
			String advDefnID = advanceCommercialNameObject.getString("advanceDefinationId");
			for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
				JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
				if(advanceDefinationData.getString("_id").equals(advDefnID)){
					JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject("advanceDefinitionTransportation");
					CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true);
					appendVehicleDetails(baseArr,calcArr,advanceDefinitionTransportation);
					for(int j=0;j<calcArr.length();j++){
						JSONObject calculationClone = calcArr.getJSONObject(j);
						/*if(advanceDefinitionTransportation.has("rateTypeApplicableFor"))
							calculationClone.put("rateTypeApplicableFor", advanceDefinitionTransportation.getString("rateTypeApplicableFor"));
						if(advanceDefinitionTransportation.has("category"))
							calculationClone.put("rateTypeApplicableForCategory", advanceDefinitionTransportation.getString("category"));*/
						if(advanceDefinitionTransportation.getBoolean("isPrepaid"))
							calculationClone.put("modeOfPayment", "Prepaid");
						else calculationClone.put("modeOfPayment", "Postpaid");
					}
				}
			}
		}
	}
	
	
	private static void appendVehicleDetails(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionTransportation) {
		if(advanceDefinitionTransportation.has("vehicleDetails")){
			JSONObject vehicleDetails = advanceDefinitionTransportation.getJSONObject("vehicleDetails");
			if(vehicleDetails.has("vehicles") && vehicleDetails.getJSONArray("vehicles").length()>0){
				JSONArray vehicles = vehicleDetails.getJSONArray("vehicles");
				int length= advancedArr.length();
				for(int i=0;i<length;i++){
					for(int j=0;j<vehicles.length();j++){
						JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
						JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
						JSONObject vehicle = vehicles.getJSONObject(j);
						if(vehicleDetails.getBoolean("isInclusion")){
							/*if(vehicle.has("sippOrACRISScode"))
								calculation.put("sippOrACRISScode", vehicle.getString("sippOrACRISScode"));*/
							if(vehicle.has("vehicleCategory"))
								calculation.put("vehicleCategory", vehicle.getString("vehicleCategory"));
							if(vehicle.has("vehicleName"))
								calculation.put("vehicleName", vehicle.getString("vehicleName"));
						}else{
							if(vehicle.has("sippOrACRISScode"))
								calculation.put("sippOrACRISScode_exclusion", vehicle.getString("sippOrACRISScode"));
							if(vehicle.has("vehicleCategory"))
								calculation.put("vehicleCategory_exclusion", vehicle.getString("vehicleCategory"));
							if(vehicle.has("vehicleName"))
								calculation.put("vehicleName_exclusion", vehicle.getString("vehicleName"));
						}
						CommonFunctions.setRuleID(advancedArr, calcArr, base, calculation, vehicle.getString("_id"));
					}
				}
				for(int i=0;i<length;i++){
					advancedArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
	}
	
	
	private static void setContractType(String displayName, JSONObject jsonObject) {
		String contractType="Final";boolean settlementTransactionWise=false;
		if(jsonObject.getJSONObject("commercialInformation").has("isProvisional")){
			if(jsonObject.getJSONObject("commercialInformation").getBoolean("isProvisional"))
				contractType="Provisional";
			else contractType="Final";
		}
		if(jsonObject.has("isSettlementTransactionWise"))
			settlementTransactionWise= jsonObject.getBoolean("isSettlementTransactionWise");
		
		switch(displayName){
		case "Overriding Commission":{overCT=contractType;overSet=settlementTransactionWise;break;}
		case "Productivity Linked Bonus":{plbCT=contractType;plbSet=settlementTransactionWise;break;}
		case "Destination Incentives":{destCT=contractType;destSet=settlementTransactionWise;break;}
		case "Segment Fees":{segCT=contractType;segSet=settlementTransactionWise;break;}
		case "Service Charges":{serCT=contractType;serSet=settlementTransactionWise;break;}
		case "Issuance Fees":{issCT=contractType;issSet=settlementTransactionWise;break;}
		case "Management Fee":{mngtCT=contractType;mngtSet=settlementTransactionWise;break;}
		default:System.out.println("default of Holidays.setContractType");
		}
	}
}
