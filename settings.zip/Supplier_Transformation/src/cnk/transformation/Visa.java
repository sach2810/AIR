package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;

public class Visa {

public static String setCommercials(JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		
		return null;
	}
}
