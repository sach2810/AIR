package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;
import cnk.kafkaConsumer.ReceiveMDMRequest;

public class Accomodation {
	public static String overCT,plbCT,destCT,segCT,serCT,issCT,mngtCT,commDefnRuleID;
	public static boolean overSet,plbSet,destSet,segSet,serSet,issSet,mngtSet;
	
	public static String setCommercials(JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		JSONObject mainJson = new JSONObject();
		if(mdmDefn.has("SupplierCommercialData") && mdmDefn.getJSONObject("SupplierCommercialData").has("standardCommercial")){
			String supplierCommercialDataID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
			JSONArray baseArr = new JSONArray();
			JSONArray calcArr = new JSONArray();
			JSONObject standardCommercial = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("standardCommercial");
			JSONObject commDefn = CommonFunctions.getStandardCommercialDefiniton(mdmDefn,productCategory,productCategorySubType,supplier,supplierMarkets,"Standard");
			commDefn.put("productCategorySubType", productCategorySubType);
			mainJson.put("CommercialDefinitionDT", commDefn);
			JSONObject accommodation = standardCommercial.getJSONObject("product").getJSONObject("accommodation");
			
			JSONObject base = new JSONObject();
			JSONObject calculation = new JSONObject();
			JSONObject contractValidity = new JSONObject();
			contractValidity.put("operator", "BETWEEN");
			contractValidity.put("from", standardCommercial.getString("contractValidityFrom").substring(0, 19));
			contractValidity.put("to", standardCommercial.getString("contractValidityTo").substring(0, 19));
			base.put("contractValidity", contractValidity);
			base.put("RuleID", "BASE"+supplierCommercialDataID);
			base.put("type", "base");
			calculation.put("type", "calculation");
			commDefnRuleID= CommonFunctions.commDefnID;
			base.put("selectedRow", commDefnRuleID);
			calculation.put("RuleID", "CALCULATION"+supplierCommercialDataID);
			calculation.put("selectedRow", "BASE"+supplierCommercialDataID);
			
			if(accommodation.getJSONArray("IATANumbers").length()>0)
				base.put("IATANumber", accommodation.getJSONArray("IATANumbers"));
			
			baseArr.put(base);
			calcArr.put(calculation);
			mainJson.put("StandardCommercialBaseDT", baseArr);
			mainJson.put("StandardCommercialCalculationDT", calcArr);
			
			if(accommodation.getJSONArray("supplierRate").length()>0)
				CommonFunctions.getSupplierRate(accommodation.getJSONArray("supplierRate"),calcArr);
			
			if(accommodation.getJSONArray("productInformation").length()>0){
				JSONArray productInformationArr = accommodation.getJSONArray("productInformation");
				CommonFunctions.getProductDetails(productInformationArr,baseArr,calcArr);
				baseArr.remove(0);
				calcArr.remove(0);
			}
			
			if(standardCommercial.getJSONArray("clients").length()>0)
				CommonFunctions.getClientDetails(baseArr,calcArr,standardCommercial.getJSONArray("clients"));
			
			if(standardCommercial.has("advanceDefinationId")){
				String advDefnID = standardCommercial.getString("advanceDefinationId");
				for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
					if(advanceDefinationData.getString("_id").equals(advDefnID)){
						JSONObject advanceDefinitionAccommodation = advanceDefinationData.getJSONObject("advanceDefinitionAccommodation");
						setAccomodationAdvancedDefinition(advanceDefinitionAccommodation,baseArr,calcArr);
						setDestination(baseArr,calcArr,advanceDefinitionAccommodation);
					}
				}
			}
			
			String stdmdmRuleID = supplierCommercialDataID+"|standardCommercial|null|";
			String fixed = stdmdmRuleID+="fixed";
			
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				if(standardCommercial.getBoolean("isFixed")){
					calcArr.getJSONObject(i).put("mdmRuleID", fixed);
					CommonFunctions.getFixedDetails(calcArr.getJSONObject(i),standardCommercial.getJSONObject("fixed"));
				}else CommonFunctions.getSlabDetails(baseArr,calcArr,standardCommercial.getJSONArray("slab"),stdmdmRuleID);
			}
			JSONArray commercialHead = mainJson.getJSONObject("CommercialDefinitionDT").getJSONArray("commercialHead");
			setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,supplierCommercialDataID);
		}
		
		System.out.println("Accomodation Transactional: "+mainJson.toString());
		return mainJson.toString();
	}
	
	
	public static void setAdvancedCommercials(JSONObject mdmDefn, JSONArray commercialHead, JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject standardCommercial, String supplier, JSONArray supplierMarkets, String productCategory , String productCategorySubType, String productName, String supplierCommercialDataID) throws Exception {
		Boolean settlement=false;
		JSONObject settlementObject = new JSONObject();
		String advanceCommercialDataID = supplierCommercialDataID+"|advanceCommercialData|";
		String tempAdvCommID = advanceCommercialDataID;
		for(int i=0;i<mdmDefn.getJSONArray("advanceCommercialData").length();i++){
			JSONObject advanceCommercialData = mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i);
			JSONObject advanceCommercial = advanceCommercialData.getJSONObject("advanceCommercial");
			advanceCommercialDataID+=advanceCommercialData.getString("_id");
			String displayName = advanceCommercial.getJSONObject("commercialHeadInfo").getString("displayName");
			switch(displayName){
			case "Overriding Commission":{
				JSONObject overRidingCommission = advanceCommercial.getJSONObject("overRidingCommission");
				setContractType("Overriding Commission",overRidingCommission);
				setAdvancedCommercial(mainJson,"OverridingCommercialBaseDT","OverridingCommercialCalculationDT","Overriding",overRidingCommission,mdmDefn,commercialHead,overCT,overSet,advanceCommercialDataID);
				break;
			}
			case "Productivity Linked Bonus":{
				JSONObject plb = advanceCommercial.getJSONObject("plb");
				setContractType("Productivity Linked Bonus",plb);
				setAdvancedCommercial(mainJson,"PLBCommercialBaseDT","PLBCommercialCalculationDT","PLB",plb,mdmDefn,commercialHead,plbCT,plbSet,advanceCommercialDataID);
				break;
			}
			case "Destination Incentives":{
				JSONObject destinationIncentives = advanceCommercial.getJSONObject("destinationIncentives");
				setContractType("Productivity Linked Bonus",destinationIncentives);
				setAdvancedCommercial(mainJson,"DestinationIncentiveBaseDT","DestinationIncentiveCalculationDT","DestinationIncentives",destinationIncentives,mdmDefn,commercialHead,destCT,destSet,advanceCommercialDataID);
				break;
			}
			case "Segment Fees":{
				JSONObject segmentFees = advanceCommercial.getJSONObject("segmentFees");
				setContractType("Productivity Linked Bonus",segmentFees);
				setAdvancedCommercial(mainJson,"SegmentFeeBaseDT","SegmentFeeCalculationDT","SegmentFees",segmentFees,mdmDefn,commercialHead,segCT,segSet,advanceCommercialDataID);
				break;
			}
			case "Service Charges":{
				JSONObject serviceCharge = advanceCommercial.getJSONObject("serviceCharge");
				setContractType("Productivity Linked Bonus",serviceCharge);
				setAdvancedCommercial(mainJson,"ServiceChargeBaseDT","ServiceChargeCalculationDT","ServiceCharges",serviceCharge,mdmDefn,commercialHead,serCT,serSet,advanceCommercialDataID);
				break;
			}
			case "Issuance Fees":{
				JSONObject issuanceFees = advanceCommercial.getJSONObject("issuanceFees");
				setContractType("Productivity Linked Bonus",issuanceFees);
				setAdvancedCommercial(mainJson,"IssuanceFeeBaseDT","IssuanceFeeCalculationDT","IssuanceFees",issuanceFees,mdmDefn,commercialHead,issCT,issSet,advanceCommercialDataID);
				break;
			}
			case "Management Fee":{
				JSONObject managementFee = advanceCommercial.getJSONObject("managementFee");
				setContractType("Productivity Linked Bonus",managementFee);
				setAdvancedCommercial(mainJson,"ManagementFeeBaseDT","ManagementFeeCalculationDT","ManagementFee",managementFee,mdmDefn,commercialHead,mngtCT,mngtSet,advanceCommercialDataID);
				break;
			}
			default:{
				settlement=true;
				String commercialName = CommonFunctions.getCommercialName(displayName);
				String commDefnID = mdmDefn.getJSONObject("SupplierCommercialData").getString("_id");
				String contractType = null;
				if(standardCommercial.getJSONObject("commercialInformation").has("isProvisional")){
					if(standardCommercial.getJSONObject("commercialInformation").getBoolean("isProvisional"))
						contractType="Provisional";
					else contractType="Final";
				}
				settlementObject = SettlementCommercials.settlementCommercials(commercialName,mdmDefn.getJSONArray("advanceCommercialData").getJSONObject(i),supplier,supplierMarkets,productCategory,productCategorySubType,productName,contractType,commDefnID,mdmDefn.getJSONArray("advanceDefinationData"));
			}
			}
			advanceCommercialDataID = tempAdvCommID;
		}
		if(settlement){
			System.out.println("Accomodation Settlement: "+settlementObject.toString());
			InvokeRuleConfigurator.invokeSettlementRuleConfigurator(settlementObject.toString(),productName,ReceiveMDMRequest.method);
			SettlementCommercials.main=null;
		}
	}
	
	
	private static void setContractType(String displayName, JSONObject jsonObject) {
		String contractType="Final";boolean settlementTransactionWise=false;
		if(jsonObject.getJSONObject("commercialInformation").has("isProvisional")){
			if(jsonObject.getJSONObject("commercialInformation").getBoolean("isProvisional"))
				contractType="Provisional";
			else contractType="Final";
		}
		if(jsonObject.has("isSettlementTransactionWise"))
			settlementTransactionWise= jsonObject.getBoolean("isSettlementTransactionWise");

		switch(displayName){
		case "Overriding Commission":{overCT=contractType;overSet=settlementTransactionWise;break;}
		case "Productivity Linked Bonus":{plbCT=contractType;plbSet=settlementTransactionWise;break;}
		case "Destination Incentives":{destCT=contractType;destSet=settlementTransactionWise;break;}
		case "Segment Fees":{segCT=contractType;segSet=settlementTransactionWise;break;}
		case "Service Charges":{serCT=contractType;serSet=settlementTransactionWise;break;}
		case "Issuance Fees":{issCT=contractType;issSet=settlementTransactionWise;break;}
		case "Management Fee":{mngtCT=contractType;mngtSet=settlementTransactionWise;break;}
		default:System.out.println("default of Holidays.setContractType");
		}
	}


	public static void setAdvancedCommercial(JSONObject mainJson, String baseDT, String calculationDT, String commercialName, JSONObject advanceCommercialNameObject, JSONObject mdmDefn, JSONArray commercialHead, String contractType, boolean settlementTransactionWise, String advanceCommercialDataID) {
		String netOffCommercialHead=null;
		String commercialType = advanceCommercialNameObject.getJSONObject("commercialInformation").getString("commercialType");
		if(advanceCommercialNameObject.has("calculation")){
			if(advanceCommercialNameObject.getJSONObject("calculation").has("netOffCommercialHead"))
				netOffCommercialHead = CommonFunctions.getCommercialName(advanceCommercialNameObject.getJSONObject("calculation").getString("netOffCommercialHead"));
		}
		CommonFunctions.setCommercialHead(commercialName,commercialHead,netOffCommercialHead,commercialType,contractType,settlementTransactionWise);
		
		JSONArray baseArr =new JSONArray();
		JSONArray calcArr =new JSONArray();
		JSONObject base = new JSONObject();
		JSONObject calculation = new JSONObject();
		base.put("RuleID", "BASE");
		base.put("selectedRow", commDefnRuleID);
		calculation.put("RuleID", "CALCULATION");
		calculation.put("selectedRow", "BASE");
		base.put("type", "base");
		calculation.put("type", "calculation");
		JSONObject contractValidity = new JSONObject();
		contractValidity.put("operator", "BETWEEN");
		contractValidity.put("from", advanceCommercialNameObject.getString("contractValidityFrom").substring(0, 19));
		contractValidity.put("to", advanceCommercialNameObject.getString("contractValidityTo").substring(0, 19));
		base.put("contractValidity", contractValidity);
		baseArr.put(base);
		calcArr.put(calculation);
		mainJson.put(baseDT, baseArr);
		mainJson.put(calculationDT, calcArr);
		
		if(advanceCommercialNameObject.getJSONArray("supplierRate").length()>0)
			CommonFunctions.getSupplierRate(advanceCommercialNameObject.getJSONArray("supplierRate"),calcArr);
		if(advanceCommercialNameObject.getJSONArray("IATANumbers").length()>0)
			base.put("IATANumber", advanceCommercialNameObject.getJSONArray("IATANumbers"));
		
		if(advanceCommercialNameObject.getJSONArray("product").length()>0){
			JSONArray product = advanceCommercialNameObject.getJSONArray("product");
			CommonFunctions.getProductDetails(product,baseArr,calcArr);
			baseArr.remove(0);
			calcArr.remove(0);
		}
		
		if(advanceCommercialNameObject.getJSONArray("client").length()>0)
			CommonFunctions.getClientDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("client"));
		
		boolean slab=false;
		if((advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.getString("calculationType").equals("slab")) || (!advanceCommercialNameObject.has("calculationType") && advanceCommercialNameObject.has("slab"))){
			slab=true;
			advanceCommercialDataID+="|";
			CommonFunctions.getSlabDetails(baseArr,calcArr,advanceCommercialNameObject.getJSONArray("slab"),advanceCommercialDataID);
		}
		
		if(!slab){
			int length=calcArr.length();
			advanceCommercialDataID+="|fixed";
			for(int i=0;i<length;i++){
				calcArr.getJSONObject(i).put("mdmRuleID", advanceCommercialDataID);
				CommonFunctions.getFixedDetails(calcArr.getJSONObject(i), advanceCommercialNameObject.getJSONObject("fixed"));
			}
		}
		
		if(advanceCommercialNameObject.has("advanceDefinationId")){
			String advDefnID = advanceCommercialNameObject.getString("advanceDefinationId");
			for(int i=0;i<mdmDefn.getJSONArray("advanceDefinationData").length();i++){
				JSONObject advanceDefinationData = mdmDefn.getJSONArray("advanceDefinationData").getJSONObject(i);
				if(advanceDefinationData.getString("_id").equals(advDefnID)){
					if(commercialName.equals("PLB")){
						JSONObject advanceDefinitionAccommodationPLB = advanceDefinationData.getJSONObject("advanceDefinitionAccommodationPLB");
						setPLBAdvancedDefinition(advanceDefinitionAccommodationPLB,baseArr,calcArr);
					}else{
						JSONObject advanceDefinitionAccommodation = advanceDefinationData.getJSONObject("advanceDefinitionAccommodation");
						setAccomodationAdvancedDefinition(advanceDefinitionAccommodation,baseArr,calcArr);
						setDestination(baseArr,calcArr,advanceDefinitionAccommodation);
					}
				}
			}
		}
	}


	private static void setPLBAdvancedDefinition(JSONObject advanceDefinitionAccommodationPLB, JSONArray baseArr, JSONArray calcArr) {
		int length = baseArr.length();
		if(length==0){
			length=1;
			baseArr.put(new JSONObject());
			calcArr.put(new JSONObject());
		}
		if(advanceDefinitionAccommodationPLB.has("validity")){
			JSONObject validity = advanceDefinitionAccommodationPLB.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "sale":{
				CommonFunctions.getPLBDates(baseArr,calcArr,validity.getJSONArray("sale"),"sale",true);
				break;
			}
			case "travel":{
				CommonFunctions.getPLBDates(baseArr,calcArr,validity.getJSONArray("travel"),"travel",true);
				break;
			}
			default:{
				JSONArray salePlusTravel = validity.getJSONArray("salePlusTravel");
				CommonFunctions.insertPLBSalePlusTravel(salePlusTravel,baseArr,calcArr,true,true);
				break;
			}
			}
		}
		
		if(advanceDefinitionAccommodationPLB.has("nationality") && advanceDefinitionAccommodationPLB.length()>0)
			CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray("nationality"),"clientNationality",true);

		if(advanceDefinitionAccommodationPLB.has("passenger") && advanceDefinitionAccommodationPLB.getJSONArray("passenger").length()>0)
			CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray("passenger"),"passengerTypes",false);
		
		if(advanceDefinitionAccommodationPLB.has("credentials") && advanceDefinitionAccommodationPLB.getJSONArray("credentials").length()>0)
			CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray("credentials"),"credentialId",true);
				
		if(advanceDefinitionAccommodationPLB.has("connectivity") && advanceDefinitionAccommodationPLB.getJSONObject("connectivity")!=null)
			CommonFunctions.getConnectivityTP(baseArr,advanceDefinitionAccommodationPLB.getJSONObject("connectivity"));
			
		if(advanceDefinitionAccommodationPLB.has("others") && advanceDefinitionAccommodationPLB.getJSONObject("others")!=null){
			JSONObject others = advanceDefinitionAccommodationPLB.getJSONObject("others");
			if(others.has("bookingType"))
				if(others.getBoolean("isInclusion"))
					CommonFunctions.getBookingTypeTP(baseArr,others.getJSONObject("bookingType"),true);
				else CommonFunctions.getBookingTypeTP(baseArr,others.getJSONObject("bookingType"),false);
			
			if(others.has("roomTypes") && others.getJSONArray("roomTypes").length()>0){
				if(others.getBoolean("isInclusion"))
					CommonFunctions.getTriggerPayoutArrayIncExc(baseArr,calcArr,others.getJSONArray("roomTypes"),"roomTypes",true,false);
				else CommonFunctions.getTriggerPayoutArrayIncExc(baseArr,calcArr,others.getJSONArray("roomTypes"),"roomTypes",false,false);
			}
			
			if(others.has("roomCategories") && others.getJSONArray("roomCategories").length()>0){
				if(others.getBoolean("isInclusion"))
					CommonFunctions.getTriggerPayoutArrayIncExc(baseArr,calcArr,others.getJSONArray("roomCategories"),"roomCategory",true,false);
				else CommonFunctions.getTriggerPayoutArrayIncExc(baseArr,calcArr,others.getJSONArray("roomCategories"),"roomCategory",false,false);
			}
		}
		
		if(advanceDefinitionAccommodationPLB.has("travelDestination") && advanceDefinitionAccommodationPLB.getJSONObject("travelDestination")!=null){
			JSONObject travelDestination = advanceDefinitionAccommodationPLB.getJSONObject("travelDestination");
			if(travelDestination.getJSONArray("travel").length()>0){
				if(travelDestination.getBoolean("isInclusion"))
					CommonFunctions.getDestination(baseArr,calcArr,travelDestination.getJSONArray("travel"),true,true);
				else CommonFunctions.getDestination(baseArr,calcArr,travelDestination.getJSONArray("travel"),false,true);
			}
		}
	}


	public static void setAccomodationAdvancedDefinition(JSONObject advanceDefinitionAccommodation, JSONArray baseArr, JSONArray calcArr) {
		int length = baseArr.length();
		if(length==0){
			length=1;
			baseArr.put(new JSONObject());
			calcArr.put(new JSONObject());
		}
		for(int i=0;i<length;i++){
			JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
			JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
			
			if(advanceDefinitionAccommodation.has("nationality")){
				JSONObject nationality = advanceDefinitionAccommodation.getJSONObject("nationality");
				if(!nationality.getJSONArray("clientNationality").getString(0).equalsIgnoreCase("All"))
					if(nationality.getBoolean("isInclusion"))
						base.put("clientNationality", nationality.get("clientNationality"));
					else base.put("clientNationality_exclusion", nationality.get("clientNationality"));
			}
			if(advanceDefinitionAccommodation.has("passengerTypes") && advanceDefinitionAccommodation.getJSONArray("passengerTypes").length()>0){
				if(!advanceDefinitionAccommodation.getJSONArray("passengerTypes").getString(0).equalsIgnoreCase("All"))
					calculation.put("passengerType", advanceDefinitionAccommodation.getJSONArray("passengerTypes"));
			}
			if(advanceDefinitionAccommodation.has("credentials") && advanceDefinitionAccommodation.getJSONArray("credentials").length()>0){
				if(!advanceDefinitionAccommodation.getJSONArray("credentials").getString(0).equalsIgnoreCase("All"))
					base.put("credentialsName", advanceDefinitionAccommodation.getJSONArray("credentials"));
			}
			if(advanceDefinitionAccommodation.has("connectivity") && advanceDefinitionAccommodation.getJSONObject("connectivity")!=null){
				JSONObject connectivity = advanceDefinitionAccommodation.getJSONObject("connectivity");
				if(!connectivity.getString("supplierType").equalsIgnoreCase("All"))
					base.put("connectivitySupplierType",connectivity.getString("supplierType"));
				if(!connectivity.getString("supplierId").equalsIgnoreCase("All"))
					base.put("connectivitySupplierName",connectivity.getString("supplierId"));
			}
			if(advanceDefinitionAccommodation.has("others") && advanceDefinitionAccommodation.getJSONObject("others")!=null){
				JSONObject others = advanceDefinitionAccommodation.getJSONObject("others");
				if(others.has("bookingType") && !others.getString("bookingType").equalsIgnoreCase("All"))
					base.put("bookingType",others.getString("bookingType"));
				if(others.has("roomTypes") && others.getJSONObject("roomTypes")!=null ){
					if(!others.getJSONObject("roomTypes").getJSONArray("roomTypes").getString(0).equalsIgnoreCase("All"))
						if(others.getJSONObject("roomTypes").getBoolean("isInclusion"))
							calculation.put("roomType", others.getJSONObject("roomTypes").get("roomTypes"));
						else calculation.put("roomType_exclusion", others.getJSONObject("roomTypes").get("roomTypes"));
				}
				if(others.has("roomCategories") && others.getJSONObject("roomCategories")!=null ){
					if(!others.getJSONObject("roomCategories").getJSONArray("roomCategories").getString(0).equalsIgnoreCase("All"))
						if(others.getJSONObject("roomCategories").getBoolean("isInclusion"))
							calculation.put("roomCategory", others.getJSONObject("roomCategories").get("roomCategories"));
						else calculation.put("roomCategory_exclusion", others.getJSONObject("roomCategories").get("roomCategories"));
				}
			}
			baseArr.put(base);
			calcArr.put(calculation);
		}
		for(int j=0;j<length;j++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
		
		if(advanceDefinitionAccommodation.has("validity")){
			JSONObject validity = advanceDefinitionAccommodation.getJSONObject("validity");
			switch(validity.getString("validityType")){
			case "sale":{
				CommonFunctions.setDate(baseArr, calcArr, validity.getJSONArray("sale"), "sale", true);
				break;
			}
			case "travel":{
				CommonFunctions.setDate(baseArr, calcArr, validity.getJSONArray("travel"), "travel", true);
				break;
			}
			default:{
				JSONArray salePlusTravel = validity.getJSONArray("salePlusTravel");
				CommonFunctions.insertSalePlusTravel(baseArr,calcArr,salePlusTravel,true,true);
				break;
			}
			}
		}
	}


	public static void setDestination(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAccommodation) {
		int length = baseArr.length();
		if(advanceDefinitionAccommodation.has("travelDestination")){
			JSONObject travelDestination = advanceDefinitionAccommodation.getJSONObject("travelDestination");
			JSONArray destinations = travelDestination.getJSONArray("destinations");
			for(int i=0;i<length;i++){
				for(int j=0;j<destinations.length();j++){
					JSONObject destinationsObject = destinations.getJSONObject(j);
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					if(travelDestination.getBoolean("isInclusion")){
						if(destinationsObject.has("continent") && !(destinationsObject.getString("continent").equalsIgnoreCase("All")))
							base.put("continent", destinationsObject.getString("continent"));
						if(destinationsObject.has("country") && !(destinationsObject.getString("country").equalsIgnoreCase("All")))
							base.put("country", destinationsObject.getString("country"));
						if(destinationsObject.has("state") && !(destinationsObject.getString("state").equalsIgnoreCase("All")))
							base.put("state", destinationsObject.getString("state"));
						if(destinationsObject.has("city") && !(destinationsObject.getString("city").equalsIgnoreCase("All")))
							base.put("city", destinationsObject.getString("city"));
					}else{
						if(destinationsObject.has("continent") && !(destinationsObject.getString("continent").equalsIgnoreCase("All")))
							base.put("continent_exclusion", destinationsObject.getString("continent"));
						if(destinationsObject.has("country") && !(destinationsObject.getString("country").equalsIgnoreCase("All")))
							base.put("country_exclusion", destinationsObject.getString("country"));
						if(destinationsObject.has("state") && !(destinationsObject.getString("state").equalsIgnoreCase("All")))
							base.put("state_exclusion", destinationsObject.getString("state"));
						if(destinationsObject.has("city") && !(destinationsObject.getString("city").equalsIgnoreCase("All")))
							base.put("city_exclusion", destinationsObject.getString("city"));
					}
					String baseRuleID = base.getString("RuleID")+destinationsObject.getString("_id");
					String calcRuleID = calculation.getString("RuleID")+destinationsObject.getString("_id");
					base.put("RuleID", baseRuleID);
					calculation.put("RuleID", calcRuleID);
					calculation.put("selectedRow", baseRuleID);
					baseArr.put(base);
					calcArr.put(calculation);
				}
			}
			for(int j=0;j<length;j++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}

	
	public static void setAccoOtherFeesAdvancedDefinition(JSONObject advanceDefinitionAccommodation, JSONArray otherFeeArr) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
			if(advanceDefinitionAccommodation.has("nationality") && advanceDefinitionAccommodation.getJSONObject("nationality")!=null)
				if(!advanceDefinitionAccommodation.getJSONObject("nationality").getJSONArray("clientNationality").getString(0).equalsIgnoreCase("All")){
					if(advanceDefinitionAccommodation.getJSONObject("nationality").getBoolean("isInclusion"))
						otherFee.put("clientNationality", advanceDefinitionAccommodation.getJSONObject("nationality").getJSONArray("clientNationality"));
					else otherFee.put("clientNationality_exclusion", advanceDefinitionAccommodation.getJSONObject("nationality").getJSONArray("clientNationality"));
				}
			if(advanceDefinitionAccommodation.has("passengerTypes")){
				if(advanceDefinitionAccommodation.getJSONArray("passengerTypes").length()>0)
					otherFee.put("passengerType", advanceDefinitionAccommodation.getJSONArray("passengerTypes"));
			}
			if(advanceDefinitionAccommodation.has("credentials")){
				if(advanceDefinitionAccommodation.getJSONArray("credentials").length()>0)
					otherFee.put("credentialsName", advanceDefinitionAccommodation.getJSONArray("credentials"));
			}
			if(advanceDefinitionAccommodation.has("connectivity") && advanceDefinitionAccommodation.getJSONObject("connectivity")!=null){
				otherFee.put("connectivitySupplierType",advanceDefinitionAccommodation.getJSONObject("connectivity").getString("supplierType"));
				otherFee.put("connectivitySupplierName",advanceDefinitionAccommodation.getJSONObject("connectivity").getString("supplierId"));
			}
			if(advanceDefinitionAccommodation.has("others") && advanceDefinitionAccommodation.getJSONObject("others")!=null){
				if(advanceDefinitionAccommodation.getJSONObject("others").has("bookingType"))
					otherFee.put("bookingType",advanceDefinitionAccommodation.getJSONObject("others").getString("bookingType"));
				if(advanceDefinitionAccommodation.getJSONObject("others").has("roomTypes") && advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomTypes")!=null ){
					if(advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomTypes").getBoolean("isInclusion"))
						otherFee.put("roomType", advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomTypes").get("roomTypes"));
					else otherFee.put("roomType_exclusion", advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomTypes").get("roomTypes"));
				}
				if(advanceDefinitionAccommodation.getJSONObject("others").has("roomCategories") && advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomCategories")!=null ){
					if(advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomCategories").getBoolean("isInclusion"))
						otherFee.put("roomCategory", advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomCategories").get("roomCategories"));
					else otherFee.put("roomCategory_exclusion", advanceDefinitionAccommodation.getJSONObject("others").getJSONObject("roomCategories").get("roomCategories"));
				}
			}
			otherFeeArr.put(otherFee);
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	public static void setAccomodationOtherFeesDestination(JSONObject advanceDefinitionAccommodation, JSONArray otherFeeArr, JSONObject jsonObject, String commDefnID) {
		if(advanceDefinitionAccommodation.has("travelDestination")){
			JSONArray destinationArray = advanceDefinitionAccommodation.getJSONObject("travelDestination").getJSONArray("destinations");
			int length = otherFeeArr.length();
			for(int j=0;j<length;j++){
				for(int i=0;i<destinationArray.length();i++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(j).toString()));
					JSONObject destinationObj = destinationArray.getJSONObject(i);
					if(advanceDefinitionAccommodation.getJSONObject("travelDestination").getBoolean("isInclusion")){
						if(destinationObj.has("continent") && !destinationObj.getString("continent").equalsIgnoreCase("All"))
							otherFee.put("tocontinent", destinationObj.getString("continent"));
						if(destinationObj.has("country") && !destinationObj.getString("country").equalsIgnoreCase("All"))
							otherFee.put("tocountry",destinationObj.getString("country"));
						if(destinationObj.has("state") && !destinationObj.getString("state").equalsIgnoreCase("All"))
							otherFee.put("tostate",destinationObj.getString("state"));
						if(destinationObj.has("city") && !destinationObj.getString("city").equalsIgnoreCase("All"))
							otherFee.put("tocity",destinationObj.getString("city"));
					}else{
						if(destinationObj.has("continent") && !destinationObj.getString("continent").equalsIgnoreCase("All"))
							otherFee.put("tocontinent_exclusion", destinationObj.getString("continent"));
						if(destinationObj.has("country") && !destinationObj.getString("country").equalsIgnoreCase("All"))
							otherFee.put("tocountry_exclusion",destinationObj.getString("country"));
						if(destinationObj.has("state") && !destinationObj.getString("state").equalsIgnoreCase("All"))
							otherFee.put("tostate_exclusion",destinationObj.getString("state"));
						if(destinationObj.has("city") && !destinationObj.getString("city").equalsIgnoreCase("All"))
							otherFee.put("tocity_exclusion",destinationObj.getString("city"));
					}
					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, destinationObj.getString("_id"));
				}
			}
			for(int j=0;j<length;j++){
				otherFeeArr.remove(0);
			}
		}
	}
	
	
	public static void setAccoValidity(JSONObject advanceDefinitionAccommodation, JSONArray otherFeeArr) {
		if(advanceDefinitionAccommodation.has("validity") && advanceDefinitionAccommodation.getJSONObject("validity")!=null){
			switch(advanceDefinitionAccommodation.getJSONObject("validity").getString("validityType")){
			case "sale":{
				JSONArray sale = advanceDefinitionAccommodation.getJSONObject("validity").getJSONArray("sale");
				getOtherFeesDate(sale,otherFeeArr,"sale");
				break;
			}
			case "travel":{
				JSONArray travel = advanceDefinitionAccommodation.getJSONObject("validity").getJSONArray("travel");
				getOtherFeesDate(travel,otherFeeArr,"travel");
				break;
			}
			default:{
				JSONArray salePlusTravel = advanceDefinitionAccommodation.getJSONObject("validity").getJSONArray("salePlusTravel");
				setSalesPlusTravel(salePlusTravel,otherFeeArr);
			}
			}
		}
	}
	
	
	public static void getOtherFeesDate(JSONArray dateArr,JSONArray otherFeeArr, String date){
		String from=date+"From";
		String to=date+"To";
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArr.length();j++){
				JSONObject inclusionIndiObjMDM =dateArr.getJSONObject(j);
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONArray inclusionArr = new JSONArray();
				JSONArray exclusionArr = new JSONArray();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray saleArr = new JSONArray();
				JSONObject inclusionIndiObj = new JSONObject();
				JSONObject exclusionIndiObj = new JSONObject();
				if(inclusionIndiObjMDM.has(from)){
					if(inclusionIndiObjMDM.has(to)){
						inclusionIndiObj.put("operator", "BETWEEN");
						inclusionIndiObj.put("from", inclusionIndiObjMDM.get(from).toString().substring(0, 19));
						inclusionIndiObj.put("to", inclusionIndiObjMDM.get(to).toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}else{
						inclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						inclusionIndiObj.put("value", inclusionIndiObjMDM.get(from).toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has(to)){
					inclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					inclusionIndiObj.put("value", inclusionIndiObjMDM.get("saleTo").toString().substring(0, 19));
					inclusionArr.put(inclusionIndiObj);
				}

				if(inclusionIndiObjMDM.has("blockOutFrom")){
					if(inclusionIndiObjMDM.has("blockOutTo")){
						exclusionIndiObj.put("operator", "BETWEEN");
						exclusionIndiObj.put("from", inclusionIndiObjMDM.get("blockOutFrom").toString().substring(0, 19));
						exclusionIndiObj.put("to", inclusionIndiObjMDM.get("blockOutTo").toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}else{
						exclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						exclusionIndiObj.put("value", inclusionIndiObjMDM.get("blockOutFrom").toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has("blockOutTo")){
					exclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					exclusionIndiObj.put("value", inclusionIndiObjMDM.get("blockOutTo").toString().substring(0, 19));
					exclusionArr.put(exclusionIndiObj);
				}

				if(inclusionArr.length()>0){
					inclusionObject.put("inclusion",inclusionArr);
					saleArr.put(inclusionObject);
				}
				if(exclusionArr.length()>0){
					exclusionObject.put("exclusion",exclusionArr);
					saleArr.put(exclusionObject);
				}
				
				otherFee.put(date, saleArr);

				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, inclusionIndiObjMDM.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	public static void setSalesPlusTravel(JSONArray salePlusTravel, JSONArray otherFeeArr) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject salePlusTravelObj = salePlusTravel.getJSONObject(j);
				JSONArray saleArr = new JSONArray();
				JSONArray salesinclusionArr = new JSONArray();
				JSONArray salesexclusionArr = new JSONArray();
				JSONObject salesinclusionObject = new JSONObject();
				JSONObject salesexclusionObject = new JSONObject();
				JSONObject saleInclusionIndiObj = new JSONObject();
				JSONObject travelInclusionIndiObj = new JSONObject();
				JSONObject saleExclusionIndiObj = new JSONObject();
				JSONObject travelExclusionIndiObj = new JSONObject();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray travelArr = new JSONArray();
				JSONArray travelinclusionArr = new JSONArray();
				JSONArray travelexclusionArr = new JSONArray();
				JSONObject saleObj = salePlusTravelObj.getJSONObject("sales");
				JSONObject travelObj = salePlusTravelObj.getJSONObject("travel");

				if(saleObj.has("saleFrom")){
					if(saleObj.has("saleTo")){
						saleInclusionIndiObj.put("operator", "BETWEEN");
						saleInclusionIndiObj.put("from", saleObj.get("saleFrom").toString().substring(0, 19));
						saleInclusionIndiObj.put("to", saleObj.get("saleTo").toString().substring(0, 19));
						salesinclusionArr.put(saleInclusionIndiObj);
					}else{
						saleInclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						saleInclusionIndiObj.put("from", saleObj.get("saleFrom").toString().substring(0, 19));
						salesinclusionArr.put(saleInclusionIndiObj);
					}
				}else if(saleObj.has("saleTo")){
					saleInclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					saleInclusionIndiObj.put("to", saleObj.get("saleTo").toString().substring(0, 19));
					salesinclusionArr.put(saleInclusionIndiObj);

				}
				
				if(saleObj.has("blockOutFrom")){
					if(saleObj.has("blockOutTo")){
						saleExclusionIndiObj.put("operator", "BETWEEN");
						saleExclusionIndiObj.put("from", saleObj.get("blockOutFrom").toString().substring(0, 19));
						saleExclusionIndiObj.put("to", saleObj.get("blockOutTo").toString().substring(0, 19));
						salesexclusionArr.put(saleExclusionIndiObj);
					}else{
						saleExclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						saleExclusionIndiObj.put("from", saleObj.get("blockOutFrom").toString().substring(0, 19));
						salesexclusionArr.put(saleExclusionIndiObj);
					}
				}else if(saleObj.has("blockOuto")){
					saleExclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					saleExclusionIndiObj.put("to", saleObj.get("blockOutTo").toString().substring(0, 19));
					salesexclusionArr.put(saleExclusionIndiObj);

				}

				if(salesinclusionArr.length()>0){
					salesinclusionObject.put("inclusion",salesinclusionArr);
					saleArr.put(salesinclusionObject);
				}
				if(salesexclusionArr.length()>0){
					salesexclusionObject.put("exclusion",salesexclusionArr);
					saleArr.put(salesexclusionObject);
				}

				if(travelObj.has("travelFrom")){
					if(travelObj.has("travelTo")){
						travelInclusionIndiObj.put("operator", "BETWEEN");
						travelInclusionIndiObj.put("from", travelObj.get("travelFrom").toString().substring(0, 19));
						travelInclusionIndiObj.put("to", travelObj.get("travelTo").toString().substring(0, 19));
						travelinclusionArr.put(travelInclusionIndiObj);
					}else{
						travelInclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						travelInclusionIndiObj.put("from", travelObj.get("travelFrom").toString().substring(0, 19));
						travelinclusionArr.put(travelInclusionIndiObj);
					}
				}else if(travelObj.has("travelTo")){
					travelInclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					travelInclusionIndiObj.put("to", travelObj.get("travelTo").toString().substring(0, 19));
					travelinclusionArr.put(travelInclusionIndiObj);

				}
				if(travelObj.has("blockOutFrom")){
					if(travelObj.has("blockOutTo")){
						travelExclusionIndiObj.put("operator", "BETWEEN");
						travelExclusionIndiObj.put("from", travelObj.get("blockOutFrom").toString().substring(0, 19));
						travelExclusionIndiObj.put("to", travelObj.get("blockOutTo").toString().substring(0, 19));
						travelinclusionArr.put(travelExclusionIndiObj);
					}else{
						travelExclusionIndiObj.put("operator", "GREATERTHANEQUALTO");
						travelExclusionIndiObj.put("from", travelObj.get("blockOutFrom").toString().substring(0, 19));
						travelinclusionArr.put(travelExclusionIndiObj);
					}
				}else if(travelObj.has("blockOuto")){
					travelExclusionIndiObj.put("operator", "LESSTHANEQUALTO");
					travelExclusionIndiObj.put("to", travelObj.get("blockOutTo").toString().substring(0, 19));
					travelinclusionArr.put(travelExclusionIndiObj);

				}

				if(travelinclusionArr.length()>0){
					inclusionObject.put("inclusion",travelinclusionArr);
					travelArr.put(inclusionObject);
				}
				if(travelexclusionArr.length()>0){
					exclusionObject.put("exclusion",travelexclusionArr);
					travelArr.put(exclusionObject);
				}
				
				otherFee.put("sale", saleArr);
				otherFee.put("travel", travelArr);

				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, salePlusTravelObj.getString("_id"));
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}

	
	
}
