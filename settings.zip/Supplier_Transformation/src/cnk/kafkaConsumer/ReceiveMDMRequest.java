package cnk.kafkaConsumer;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Properties;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import cnk.invokeRuleConfigurator.InvokeRuleConfigurator;
import cnk.transformation.Accomodation;
import cnk.transformation.Activities;
import cnk.transformation.Air;
import cnk.transformation.Bus;
import cnk.transformation.CarRentals;
import cnk.transformation.CommonFunctions;
import cnk.transformation.Cruise;
import cnk.transformation.Holidays;
import cnk.transformation.Insurance;
import cnk.transformation.Rail;
import cnk.transformation.Transfers;
import cnk.transformation.Visa;

public class ReceiveMDMRequest {
	public static String method;
	
	public static void main(String args[]) throws Exception {
		Properties properties = new Properties();
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		String str = "";
		String topic = "MDM.SIT.SUPPLIERCOMMERCIAL.PUB";

		try (InputStream in = classLoader.getResourceAsStream("Configuration.properties")) {
			properties.load(in);

			Enumeration<Object> enuKeys = properties.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = properties.getProperty(key);
				properties.put(key, value);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}


		@SuppressWarnings("resource")
		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(properties);

		consumer.subscribe(Arrays.asList(topic));
		System.out.println("Subscribed to topic " + topic);

		while (true) {
			ConsumerRecords<String, String> records = consumer.poll(100);
			//System.out.println(records);
			for (ConsumerRecord<String, String> record : records) {
				System.out.printf("offset = %d, message = %s\n", record.offset(), record.value());
				str = record.value();
				JSONObject mdmData = new JSONObject(str);
				method = mdmData.getString("method");
				try{
					readJSON(mdmData.getJSONObject("data").toString());
					consumer.commitSync();
				}
				catch(Exception ex){
					ex.printStackTrace();
					consumer.commitSync();
					continue;
				}
			}
		}
	}
	
	
	public static void readJSON(String content) throws Exception {
		JSONObject mdmDefn = new JSONObject(content);
		if(mdmDefn.has("SupplierCommercialData") && mdmDefn.getJSONObject("SupplierCommercialData").has("commercialDefinition")){
			String transform = null;
			String supplier= null,productCategorySubType=null;
			JSONArray supplierMarkets = new JSONArray();
			JSONObject commercialDefinition = mdmDefn.getJSONObject("SupplierCommercialData").getJSONObject("commercialDefinition");
			String productName=CommonFunctions.getProductName(commercialDefinition);
			if(!commercialDefinition.getString("supplierId").equalsIgnoreCase("All"))
				supplier = commercialDefinition.getString("supplierId");
			if(!commercialDefinition.getJSONArray("supplierMarkets").getString(0).equalsIgnoreCase("All"))
				supplierMarkets = commercialDefinition.getJSONArray("supplierMarkets");
			String productCategory = commercialDefinition.getString("productCategory");
			if(commercialDefinition.has("productCategorySubType"))
				productCategorySubType = commercialDefinition.getString("productCategorySubType");
			switch(productName){
			case "accomodation":{
				transform=Accomodation.setCommercials(mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case "air":{
				transform=Air.setCommercials(mdmDefn,productName,productCategory,productCategorySubType,supplier,supplierMarkets);
				break;
			}
			case "activities":{
				transform=Activities.setCommercials(mdmDefn,productName,productCategory,productCategorySubType,supplier,supplierMarkets);
				break;
			}
			case "holidays":{
				transform=Holidays.setCommercials(mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case "bus":{
				transform=Bus.setCommercials(mdmDefn,productName, productCategory,productCategorySubType,supplier,supplierMarkets);
				break;
			}
			case "carrentals":{
				transform=CarRentals.setCommercials(mdmDefn,productName,productCategory,productCategorySubType,supplier,supplierMarkets);
				break;
			}
			case "cruise":{
				transform=Cruise.setCommercials(mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case "rail":{
				transform=Rail.setCommercials(mdmDefn,productName, productCategory,productCategorySubType,supplier,supplierMarkets);
				break;
			}
			case "transfers":{
				transform=Transfers.setCommercials(mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case "insurance":{
				transform=Insurance.setCommercials(mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case "visa":{
				transform=Visa.setCommercials(mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			default:System.out.println("default of readJSON due to productName: "+productName);
			}

			if(transform!=null)
				InvokeRuleConfigurator.invokeRuleConfigurator(transform,productName,ReceiveMDMRequest.method);
		}
	}
}
