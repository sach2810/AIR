package cnk.cce.products;

import cnk.cce.configuration.Constants;

public class Bus implements Constants {
	
}
