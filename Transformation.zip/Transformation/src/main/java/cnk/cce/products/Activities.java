package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.configuration.CommonFunctions;
import cnk.cce.configuration.Constants;

public class Activities implements Constants {

	public static void getOtherFeesAdvancedDefinition(JSONArray otherFeeArr, JSONObject advanceDefinition, String commercialName){
		if(advanceDefinition.has(CONNECTIVITY)){
			JSONObject connectivity = advanceDefinition.getJSONObject(CONNECTIVITY);
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					otherFee.put(CONNECTIVITYSUPPTYPE, connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERNAME) && !connectivity.getString(PROP_SUPPLIERNAME).equalsIgnoreCase("All"))
					otherFee.put(CONNECTIVITYSUPP, connectivity.getString(PROP_SUPPLIERNAME));
			}
		}
		
		if(advanceDefinition.has(PROP_CREDENTIALS) && advanceDefinition.getJSONArray(PROP_CREDENTIALS).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinition.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS,true);
		
		if(advanceDefinition.has(PROP_OTHERS)){
			JSONObject others = advanceDefinition.getJSONObject(PROP_OTHERS);
			if(others.has(BOOKINGTYPE)){
				for(int i=0;i<otherFeeArr.length();i++){
					JSONObject otherFee = otherFeeArr.getJSONObject(i);
					otherFee.put(BOOKINGTYPE, others.getString(BOOKINGTYPE));
				}
			}
		}

		setOtherFeeValidity(otherFeeArr,advanceDefinition,commercialName);
		CommonFunctions.getOtherFeesDestination(otherFeeArr, advanceDefinition, commercialName);
	}
	
	
	private static void setOtherFeeValidity(JSONArray otherFeeArr, JSONObject advanceDefinition, String commercialName) {
		if (advanceDefinition.has(PROP_VALIDITY)) {
			JSONObject validity = advanceDefinition.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE))
				switch (validity.getString(PROP_VALIDITYTYPE)) {
				case PROP_SALE: {
					setSaleTravelDateOF(validity.getJSONArray(PROP_SALE),PROP_SALE, otherFeeArr,commercialName);
					break;
				}
				case PROP_TRAVEL: {
					setSaleTravelDateOF(validity.getJSONArray(PROP_TRAVEL),PROP_TRAVEL, otherFeeArr,commercialName);
					break;
				}
				default: {
					CommonFunctions.setOtherFeesSalePlusTravel(validity.getJSONArray(PROP_SALEPLUSTRAVEL),otherFeeArr,commercialName);
					break;
				}
				}
		}	
	}
	
	
	private static void setSaleTravelDateOF(JSONArray array, String validityType, JSONArray otherFeeArr, String commercialName) {
		String from = validityType+FROM;
		String to =  validityType+TO;
		int length = otherFeeArr.length();
		for(int  i= 0; i<length; i++){
			for (int j = 0; j < array.length(); j++) {
				JSONObject otherFeeObj = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject object = array.getJSONObject(j);
				JSONArray incArr = new JSONArray();
				JSONArray excArr = new JSONArray();
				JSONObject incObj = new JSONObject();
				JSONObject excObj = new JSONObject();
				if (object.has(from)) {
					if (object.has(to)) {
						incObj.put(OPERATOR, BETWEEN);
						incObj.put(PROP_FROM, object.getString(from).substring(0, 19));
						incObj.put(PROP_TO, object.getString(to).substring(0, 19));
					} else {
						incObj.put(OPERATOR, GREATERTHANEQUALTO);
						incObj.put(VALUE, object.getString(from).substring(0, 19));
					}
				} else if (object.has(to)) {
					incObj.put(OPERATOR, LESSTHANEQUALTO);
					incObj.put(VALUE, object.getString(to).substring(0, 19));
				}
				if (object.has(PROP_BLOCKOUT_FROM)) {
					if (object.has(PROP_BLOCKOUT_TO)) {
						excObj.put(OPERATOR, BETWEEN);
						excObj.put(PROP_FROM, object.getString(PROP_BLOCKOUT_FROM).substring(0, 19));
						excObj.put(PROP_TO, object.getString(PROP_BLOCKOUT_TO).substring(0, 19));
					} else {
						excObj.put(OPERATOR, GREATERTHANEQUALTO);
						excObj.put(VALUE, object.getString(PROP_BLOCKOUT_FROM).substring(0, 19));
					}
				} else {
					if (object.has(PROP_BLOCKOUT_TO)) {
						excObj.put(OPERATOR, LESSTHANEQUALTO);
						excObj.put(VALUE, object.getString(PROP_BLOCKOUT_TO).substring(0, 19));
					}
				}
				if (incObj.length()!=0) {
					incArr.put(incObj);
				}
				if (excObj.length()!=0) {
					excArr.put(excObj);
				}		
				JSONArray date = new JSONArray();
				if (incArr.length() > 0) {
					JSONObject inclusion = new JSONObject();
					inclusion.put(INCLUSION, incArr);
					date.put(inclusion);
				}
				if (excArr.length() > 0) {
					JSONObject exclusion = new JSONObject();
					exclusion.put(EXCLUSION, excArr);
					date.put(exclusion);
				}
				otherFeeObj.put(validityType, date);
				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFeeObj, commercialName+"_"+validityType+i+j);
			}	
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
}
