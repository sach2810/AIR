package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.configuration.CommonFunctions;
import cnk.cce.configuration.Constants;

public class Air implements Constants {
	public static JSONArray advancedArr = new JSONArray();
	public static JSONArray calcArr = new JSONArray();

	public static void setPLBAdvancedDefinition(JSONObject base, JSONObject calculation, JSONObject advanceDefinitionAir, String advDefnID, String commercialName) {
		advancedArr.put(base);
		calcArr.put(calculation);
		if(advanceDefinitionAir.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionAir.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				CommonFunctions.setTicketingPlusTravel(advancedArr,calcArr,validity,true,false,commercialName);
			}
		}

		if(advanceDefinitionAir.has(CONNECTIVITY))
			getTriggerPayoutConnectivity(advancedArr,advanceDefinitionAir.getJSONObject(CONNECTIVITY));

		if(advanceDefinitionAir.has(PROP_CREDENTIALS) && advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS).length()>0)
			CommonFunctions.getTriggerPayoutArray(advancedArr,calcArr,advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS),PROP_CREDENTIALSID,true,commercialName);

		if(advanceDefinitionAir.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionAir.getJSONObject(PROP_OTHERS);
			if(others.has(BOOKINGTYPE))
				CommonFunctions.getBookingTypeTP(advancedArr,others,true);
		}

		if(advanceDefinitionAir.has(PROP_BOOKINGCLASS)){
			JSONObject bookingClass = advanceDefinitionAir.getJSONObject(PROP_BOOKINGCLASS);
			setAirBookingTypeTP(advancedArr, calcArr, bookingClass,commercialName);
		}

		if(advanceDefinitionAir.has(PROP_FLIGHT_TIMINGS))
			getFlightTimingsNumbersTP(advancedArr,calcArr,advanceDefinitionAir.getJSONObject(PROP_FLIGHT_TIMINGS),PROP_FLIGHT_TIMINGS,PROP_FLIGHTTIME_FROM,PROP_FLIGHTTIME_TO,commercialName);

		if(advanceDefinitionAir.has(PROP_FLIGHT_NUMBERS))
			getFlightTimingsNumbersTP(advancedArr,calcArr,advanceDefinitionAir.getJSONObject(PROP_FLIGHT_NUMBERS),PROP_FLIGHTRANGE,PROP_FLIGHTRANGE_FROM,PROP_FLIGHTRANGE_TO,commercialName);

		if(advanceDefinitionAir.has(PAXTYPES) && advanceDefinitionAir.getJSONArray(PAXTYPES).length()>0)
			CommonFunctions.getTriggerPayoutArray(advancedArr,calcArr,advanceDefinitionAir.getJSONArray(PAXTYPES),PAXTYPES,false,commercialName);

		if(advanceDefinitionAir.has(PROP_FARECLASS)){
			if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_FAREBASIS)){
				JSONObject fareBasis = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_FAREBASIS);
				JSONArray fare = fareBasis.getJSONArray(PROP_FARE);
				if(fareBasis.has(PROP_BOOLEAN_ISINCLUSION)){
					if(fareBasis.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						getFareBasisTP(advancedArr,calcArr,fare,true,commercialName);
					else getFareBasisTP(advancedArr,calcArr,fare,false,commercialName);
				}
			}

			if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_DEALCODES)){
				JSONObject dealCodes = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_DEALCODES);
				if(dealCodes.has(PROP_BOOLEAN_ISINCLUSION)){
					if(dealCodes.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr, calcArr, dealCodes.getJSONArray(PROP_DEALCODES), DEALCODE, true, false,commercialName);
					else CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr, calcArr, dealCodes.getJSONArray(PROP_DEALCODES), DEALCODE, false, false,commercialName);
				}
			}
		}

		if(advanceDefinitionAir.has(PROP_TRAVELDESTINATION)){
			JSONObject travelDestination = advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION);
			if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
				if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
					if(travelDestination.has(PROP_SOTO) && travelDestination.getJSONArray(PROP_SOTO).length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(advancedArr,travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),travelDestination.getJSONArray(PROP_SOTO),TRAVELTYPE,true);

					if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(advancedArr,travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),travelDestination.getJSONArray(PROP_JOURNEYTYPE),PROP_JOURNEYTYPE,true);

					if(travelDestination.has(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
						getCodeSharedFlightIncludedTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED),travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),true);

					if(travelDestination.has(PROP_BOOLEAN_ISDIRECTFLIGHTS))
						getFlightTypeTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_ISDIRECTFLIGHTS),travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),true);

					if(travelDestination.has(PROP_BOOLEAN_ISONLINE))
						getFlightLineTypeTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE),travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),true);

					if(travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
						JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
						JSONArray travelProductNameArr = new JSONArray();
						for(int d=0;d<destinations.length();d++){
							JSONObject destObj = destinations.getJSONObject(d);
							if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
							}
						}
						if(travelProductNameArr.length()>0)
							getTravelProductNameTP(calcArr,travelProductNameArr,travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),true);
					}
				}else{
					if(travelDestination.has(PROP_SOTO) && travelDestination.getJSONArray(PROP_SOTO).length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(advancedArr,travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),travelDestination.getJSONArray(PROP_SOTO),TRAVELTYPE,false);

					if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
						CommonFunctions.getTriggerPayoutEnumValues(advancedArr,travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),travelDestination.getJSONArray(PROP_JOURNEYTYPE),PROP_JOURNEYTYPE,false);

					if(travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
						getCodeSharedFlightIncludedTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED),travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),false);

					if(travelDestination.has(PROP_BOOLEAN_ISDIRECTFLIGHTS))
						getFlightTypeTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_ISDIRECTFLIGHTS),travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),false);

					if(travelDestination.has(PROP_BOOLEAN_ISONLINE))
						getFlightLineTypeTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE),travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),false);

					if(travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
						JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
						JSONArray travelProductNameArr = new JSONArray();
						for(int d=0;d<destinations.length();d++){
							JSONObject destObj = destinations.getJSONObject(d);
							if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
							}
						}
						if(travelProductNameArr.length()>0)
							getTravelProductNameTP(calcArr,travelProductNameArr,travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT),true);
					}
				}
			}
		}
		int lengthCalc = calcArr.length();
		JSONObject travelDestination = advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION);
		if(CommonFunctions.checkIfPayoutIsPresent(travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT))){
			JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
			for(int d=0;d<lengthCalc;d++){
				JSONObject calculation1 = new JSONObject(new JSONTokener(calcArr.getJSONObject(d).toString()));
				JSONArray dest = new JSONArray();
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(travelDestination.getJSONArray(PROP_TRIGGER_PAYOUT));
				dest.put(triggerPayout);
				dest.put(setAirDestination(INCLUSION,advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION).getJSONArray(PROP_JOURNEYTYPE),new JSONObject(),destinations));
				calculation1.put(PROP_DESTINATION, dest);
				calcArr.put(calculation1);
			}
			for(int d=0;d<lengthCalc;d++){
				calcArr.remove(0);
			}
		}
	}


	private static void setAirBookingTypeTP(JSONArray baseArr, JSONArray calcArr, JSONObject bookingClass, String commercialName) {
		JSONArray cabin = bookingClass.getJSONArray(PROP_CABIN);
		if(cabin.length()>0){
			String cabinString="",rbdString="",triggerString="",payoutString="";
			for(int j=0;j<cabin.length();j++){
				JSONObject cabinObject = cabin.getJSONObject(j);
				JSONArray triggerPayout = cabinObject.getJSONArray(PROP_TRIGGER_PAYOUT);

				if(CommonFunctions.checkIfPayoutIsPresent(cabinObject.getJSONArray(PROP_TRIGGER_PAYOUT))){
					if(cabinObject.has(PROP_CABINCLASS) && !cabinObject.getString(PROP_CABINCLASS).equalsIgnoreCase("All")){
						if(j==0)
							cabinString=cabinObject.getString(PROP_CABINCLASS);
						else cabinString+=";"+cabinObject.getString(PROP_CABINCLASS);
					}else{
						if(j==0)
							cabinString="null";
						else cabinString+=";null";
					}
					if(cabinObject.has(PROP_RBD) && !cabinObject.getString(PROP_RBD).equalsIgnoreCase("All")){
						if(j==0)
							rbdString=cabinObject.getString(PROP_RBD);
						else rbdString+=";"+cabinObject.getString(PROP_RBD);
					}else{
						if(j==0)
							rbdString="null";
						else rbdString+=";null";
					}
					for(int i=0;i<triggerPayout.length();i++){
						if(triggerPayout.getString(i).toLowerCase().equalsIgnoreCase(PROP_PAYOUT)){
							if(j==0){
								payoutString="true";
								triggerString="true";
							}else{
								payoutString+=";true";
								triggerString+=";true";
							}
						}
					}
				}
			}

			JSONObject cabinJson= new JSONObject();
			if(triggerString!="" && payoutString!=""){
				cabinJson.put("trigger", triggerString);
				cabinJson.put("payout", payoutString);
			}

			if(cabinString.length()!=0 || rbdString.length()!=0){
				if(bookingClass.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
					cabinJson.put("cabinClass", cabinString);
					cabinJson.put("rbd", rbdString);
				}else{
					cabinJson.put("cabinClass_exclusion", cabinString);
					cabinJson.put("rbd_exclusion", rbdString);
				}
				for(int i=0;i<calcArr.length();i++){
					JSONObject calc = calcArr.getJSONObject(i);
					calc.put("airCabinClass", cabinJson);
				}
			}
		}
	}
	
	
	public static void getTriggerPayoutConnectivity(JSONArray baseArr, JSONObject connectivity) {
		if(CommonFunctions.checkIfPayoutIsPresent(connectivity.getJSONArray(PROP_TRIGGER_PAYOUT))){
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(connectivity.getJSONArray(PROP_TRIGGER_PAYOUT));
				JSONArray connectivityArr = new JSONArray();
				JSONObject connectivityObject = new JSONObject();
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					connectivityObject.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					connectivityObject.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERID));
				connectivityArr.put(triggerPayout);
				connectivityArr.put(connectivityObject);
				base.put(CONNECTIVITY, connectivityArr);
			}
		}
	}

	
	public static void getAirConnectivity(JSONArray baseArr, JSONObject connectivity) {
		if(CommonFunctions.checkIfPayoutIsPresent(connectivity.getJSONArray(PROP_TRIGGER_PAYOUT))){
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(connectivity.getJSONArray(PROP_TRIGGER_PAYOUT));
				JSONArray connectivityArr = new JSONArray();
				JSONObject connectivityObject = new JSONObject();
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					connectivityObject.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERNAME) && !connectivity.getString(PROP_SUPPLIERNAME).equalsIgnoreCase("All"))
					connectivityObject.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERNAME));
				connectivityArr.put(triggerPayout);
				connectivityArr.put(connectivityObject);
				base.put(CONNECTIVITY, connectivityArr);
			}
		}
	}


	private static void getTravelProductNameTP(JSONArray calcArr, JSONArray travelProductNameArr, JSONArray triggerOrPayout, boolean isInclusion) {
		if(CommonFunctions.checkIfPayoutIsPresent(triggerOrPayout)){
			int length = calcArr.length();
			for(int i=0;i<length;i++){
				JSONObject calculation = calcArr.getJSONObject(i);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
				JSONArray flightArr = new JSONArray();
				flightArr.put(triggerPayout);
				JSONObject flightObject = new JSONObject();
				if(isInclusion)
					flightObject.put(TRAVELPRODUCTNAME, travelProductNameArr);
				else flightObject.put(TRAVELPRODUCTNAME+"_"+EXCLUSION, travelProductNameArr);
				flightArr.put(flightObject);
				calculation.put(TRAVELPRODUCTNAME, flightArr);
			}
		}
	}


	private static void getFlightLineTypeTP(JSONArray calcArr, boolean isOnline, JSONArray triggerOrPayout, boolean isInclusion) {
		if(CommonFunctions.checkIfPayoutIsPresent(triggerOrPayout)){
			int length = calcArr.length();
			for(int i=0;i<length;i++){
				JSONObject calculation = calcArr.getJSONObject(i);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
				JSONArray flightArr = new JSONArray();
				flightArr.put(triggerPayout);
				JSONObject flightObject = new JSONObject();
				if(isOnline){
					if(isInclusion)
						flightObject.put(FLIGHTLINETYPE, ONLINE);
					else flightObject.put(FLIGHTLINETYPE+"_"+EXCLUSION, ONLINE);
				}else{
					if(isInclusion)
						flightObject.put(FLIGHTLINETYPE, OFFLINE);
					else flightObject.put(FLIGHTLINETYPE+"_"+EXCLUSION, OFFLINE);
				}
				flightArr.put(flightObject);
				calculation.put(FLIGHTLINETYPE, flightArr);
			}
		}
	}


	private static void getFlightTypeTP(JSONArray calcArr, boolean isDirectFlight, JSONArray triggerOrPayout, boolean isInclusion) {
		if(CommonFunctions.checkIfPayoutIsPresent(triggerOrPayout)){
			int length = calcArr.length();
			for(int i=0;i<length;i++){
				JSONObject calculation = calcArr.getJSONObject(i);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
				JSONArray flightArr = new JSONArray();
				flightArr.put(triggerPayout);
				JSONObject flightObject = new JSONObject();
				if(isDirectFlight){
					if(isInclusion)
						flightObject.put(FLIGHTTYPE, DIRECT);
					else flightObject.put(FLIGHTTYPE+"_"+EXCLUSION, DIRECT);
				}else{
					if(isInclusion)
						flightObject.put(FLIGHTTYPE, VIA);
					else flightObject.put(FLIGHTTYPE+"_"+EXCLUSION, VIA);
				}
				flightArr.put(flightObject);
				calculation.put(FLIGHTTYPE, flightArr);
			}
		}
	}



	private static void getCodeSharedFlightIncludedTP(JSONArray calcArr, boolean codeSharedFlightIncluded, JSONArray triggerOrPayout, boolean isInclusion) {
		if(CommonFunctions.checkIfPayoutIsPresent(triggerOrPayout)){
			int length = calcArr.length();
			for(int i=0;i<length;i++){
				JSONObject calculation = calcArr.getJSONObject(i);
				JSONObject code = new JSONObject();
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
				JSONArray codeArr = new JSONArray();
				codeArr.put(triggerPayout);
				if(isInclusion)
					code.put(CODESHAREDFLIGHTINCLUDED, codeSharedFlightIncluded);
				else code.put(CODESHAREDFLIGHTINCLUDED+"_"+EXCLUSION, codeSharedFlightIncluded);
				codeArr.put(code);
				calculation.put(CODESHAREDFLIGHTINCLUDED, codeArr);
			}
		}
	}


	private static void getFareBasisTP(JSONArray baseArr, JSONArray calcArr, JSONArray fare, boolean isInclusion, String commercialName) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<fare.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject fareObject = fare.getJSONObject(j);
				if(CommonFunctions.checkIfPayoutIsPresent(fareObject.getJSONArray(PROP_TRIGGER_PAYOUT))){
					JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(fareObject.getJSONArray(PROP_TRIGGER_PAYOUT));
					JSONArray fareArr = new JSONArray();
					JSONArray fareBasisArr = new JSONArray();
					fareArr.put(triggerPayout);
					fareBasisArr.put(fareObject.getString(PROP_CONDITION));
					fareBasisArr.put(fareObject.getString(VALUE));
					JSONObject FareObject = new JSONObject();
					if(isInclusion)
						FareObject.put(FAREBASISVALUE, fareBasisArr);
					else FareObject.put(FAREBASISVALUE+"_"+EXCLUSION, fareBasisArr);
					fareArr.put(FareObject);
					calculation.put(FAREBASISVALUE,fareArr);
					
				}
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+"_"+FAREBASISVALUE+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void getFlightTimingsNumbersTP(JSONArray baseArr, JSONArray calcArr, JSONObject flightTiming, String arrayName, String from, String to, String commercialName) {
		int length=baseArr.length();
		JSONArray flighTimeArr = flightTiming.getJSONArray(arrayName);
		for(int i=0;i<length;i++){
			for(int j=0;j<flighTimeArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject timeObject = flighTimeArr.getJSONObject(j);
				if(CommonFunctions.checkIfPayoutIsPresent(timeObject.getJSONArray(PROP_TRIGGER_PAYOUT))){
					JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(timeObject.getJSONArray(PROP_TRIGGER_PAYOUT));
					JSONArray timeArr = new JSONArray();
					timeArr.put(triggerPayout);
					JSONObject timeObjectMain = new JSONObject();
					if(timeObject.has(from)){
						if(timeObject.has(to)){
							String time = BETWEEN+";"+timeObject.get(from)+";"+timeObject.get(to);
							if(flightTiming.getBoolean(PROP_BOOLEAN_ISINCLUSION))
								timeObjectMain.put(arrayName, time);
							else timeObjectMain.put(arrayName+""+"_"+EXCLUSION, time);
						}else{
							String time = GREATERTHANEQUALTO+";"+timeObject.get(from);
							if(flightTiming.getBoolean(PROP_BOOLEAN_ISINCLUSION))
								timeObjectMain.put(arrayName, time);
							else timeObjectMain.put(arrayName+""+"_"+EXCLUSION, time);
						}
					}else if(timeObject.has(to)){
						String time = LESSTHANEQUALTO+";"+timeObject.get(to);
						if(flightTiming.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							timeObjectMain.put(arrayName, time);
						else timeObjectMain.put(arrayName+"_"+EXCLUSION, time);
					}
					timeArr.put(timeObjectMain);
					calculation.put(arrayName, timeArr);
				}
				CommonFunctions.setRuleID(baseArr,calcArr,base,calculation,commercialName+"_"+arrayName+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setAdvancedDefinition(JSONObject base, JSONObject calculation, JSONObject advanceDefinitionAir, String advDefnID, String commercialName) {
		if(advanceDefinitionAir.has(CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionAir.getJSONObject(CONNECTIVITY);
			if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
				base.put(CONNECTIVITYSUPPTYPE, connectivity.getString(PROP_SUPPLIERTYPE));
			if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
				base.put(CONNECTIVITYSUPPNAME, connectivity.getString(PROP_SUPPLIERID));
		}

		if(advanceDefinitionAir.has(PROP_CREDENTIALS) && advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS).length()>0){
			JSONArray credentials = advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS);
			JSONArray crentialsArr = new JSONArray();
			for(int cr=0;cr<credentials.length();cr++){
				crentialsArr.put(credentials.getJSONObject(cr).getString(PROP_CREDENTIALSID));
			}
			base.put(CREDENTIALSNAME, crentialsArr);
		}

		if(advanceDefinitionAir.has(PROP_OTHERS)){
			if(advanceDefinitionAir.getJSONObject(PROP_OTHERS).has(BOOKINGTYPE))
				base.put(BOOKINGTYPE, advanceDefinitionAir.getJSONObject(PROP_OTHERS).getString(BOOKINGTYPE));
		}

		getAirBookingClass(advanceDefinitionAir, calculation);

		if(advanceDefinitionAir.has(PAXTYPES) && advanceDefinitionAir.getJSONArray(PAXTYPES).length()>0){
			JSONArray passengerTypes  = advanceDefinitionAir.getJSONArray(PAXTYPES);
			JSONArray paxType = new JSONArray();
			for(int pt=0;pt<passengerTypes.length();pt++){
				paxType.put(passengerTypes.getJSONObject(pt).getString(PAXTYPE));
			}
			calculation.put(PAXTYPE, paxType);
		}

		if(advanceDefinitionAir.has(PROP_TRAVELDESTINATION)){
			JSONObject travelDestination = advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION);
			if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
				if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
					if(travelDestination.has(PROP_SOTO) && travelDestination.getJSONArray(PROP_SOTO).length()>0)
						base.put(TRAVELTYPE, travelDestination.getJSONArray(PROP_SOTO));

					if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
						base.put(PROP_JOURNEYTYPE, travelDestination.getJSONArray(PROP_JOURNEYTYPE));

					if(travelDestination.has(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
						calculation.put(CODESHAREDFLIGHTINCLUDED, travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED));

					if(travelDestination.has(PROP_BOOLEAN_ISDIRECTFLIGHTS)){
						if(travelDestination.getBoolean(PROP_BOOLEAN_ISDIRECTFLIGHTS))
							calculation.put(FLIGHTTYPE, DIRECT);
						else calculation.put(FLIGHTTYPE, VIA);
					}

					if(travelDestination.has(PROP_BOOLEAN_ISONLINE)){
						if(travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE))
							calculation.put(FLIGHTLINETYPE, ONLINE);
						else calculation.put(FLIGHTLINETYPE, OFFLINE);
					}

					JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
							for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
								travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
						}
					}
					if(travelProductNameArr.length()>0)
						calculation.put(TRAVELPRODUCTNAME, travelProductNameArr);

					setAirDestination(INCLUSION,advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION).getJSONArray(PROP_JOURNEYTYPE),calculation,destinations);
				}else{
					if(travelDestination.has(PROP_SOTO) && travelDestination.getJSONArray(PROP_SOTO).length()>0)
						base.put(TRAVELTYPE+"_"+EXCLUSION, travelDestination.getJSONArray(PROP_SOTO));

					if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
						base.put(PROP_JOURNEYTYPE+"_"+EXCLUSION, travelDestination.getJSONArray(PROP_JOURNEYTYPE));

					if(travelDestination.has(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
						calculation.put(CODESHAREDFLIGHTINCLUDED+"_"+EXCLUSION, travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED));

					if(travelDestination.has(PROP_BOOLEAN_ISDIRECTFLIGHTS)){
						if(travelDestination.getBoolean(PROP_BOOLEAN_ISDIRECTFLIGHTS))
							calculation.put(FLIGHTTYPE+"_"+EXCLUSION, DIRECT);
						else calculation.put(FLIGHTTYPE+"_"+EXCLUSION, VIA);
					}

					if(travelDestination.has(PROP_BOOLEAN_ISONLINE)){
						if(travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE))
							calculation.put(FLIGHTLINETYPE+"_"+EXCLUSION, ONLINE);
						else calculation.put(FLIGHTLINETYPE+"_"+EXCLUSION, OFFLINE);
					}

					JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
							for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
								travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
						}
					}
					if(travelProductNameArr.length()>0)
						calculation.put(TRAVELPRODUCTNAME+"_"+EXCLUSION, travelProductNameArr);

					setAirDestination(EXCLUSION,advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION).getJSONArray(PROP_JOURNEYTYPE),calculation,destinations);
				}
			}
		}

		if(advanceDefinitionAir.has(PROP_FARECLASS)){
			if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_DEALCODES)){
				JSONObject dealCodes = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_DEALCODES);
				JSONArray dealCodesArr = dealCodes.getJSONArray(PROP_DEALCODES);
				JSONArray dealcode= new JSONArray();
				for(int dc=0;dc<dealCodesArr.length();dc++){
					dealcode.put(dealCodesArr.getJSONObject(dc).getString(PROP_DEALCODES));
				}
				if(dealcode.length()>0){
					if(dealCodes.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						calculation.put(DEALCODE, dealcode);
					else calculation.put(DEALCODE+"_"+EXCLUSION, dealcode);
				}
			}
		}
		
		advancedArr.put(base);
		calcArr.put(calculation);
		
		if(advanceDefinitionAir.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionAir.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				CommonFunctions.setTicketingPlusTravel(advancedArr,calcArr,advanceDefinitionAir.getJSONObject(PROP_VALIDITY),true,false,commercialName);
			}
		}
		getFlightTimings(advancedArr,calcArr,advanceDefinitionAir,commercialName);
		getFlightNumbers(advancedArr,calcArr,advanceDefinitionAir,commercialName);
		setFareBasisValue(advanceDefinitionAir,advancedArr,calcArr,commercialName);
	}


	public static void getAirBookingClass(JSONObject advanceDefinitionAir, JSONObject calculation) {
		if(advanceDefinitionAir.has(PROP_BOOKINGCLASS)){
			JSONObject bookingClass = advanceDefinitionAir.getJSONObject(PROP_BOOKINGCLASS);
			if(bookingClass.has(PROP_CABIN) && bookingClass.getJSONArray(PROP_CABIN).length()>0){
				JSONArray cabin = bookingClass.getJSONArray(PROP_CABIN);
				String cabinString="",rbdString="";
				for(int k=0;k<cabin.length();k++){
					JSONObject cabinObj = cabin.getJSONObject(k);
					if(cabinObj.has(PROP_CABINCLASS) && !cabinObj.getString(PROP_CABINCLASS).equalsIgnoreCase("All")){
						if(k==0)
							cabinString=cabinObj.getString(PROP_CABINCLASS);
						else cabinString+=";"+cabinObj.getString(PROP_CABINCLASS);
					}else{
						if(k==0)
							cabinString="null";
						else cabinString+=";null";
					}
					if(cabinObj.has(PROP_RBD) && !cabinObj.getString(PROP_RBD).equalsIgnoreCase("All")){
						if(k==0)
							rbdString=cabinObj.getString(PROP_RBD);
						else rbdString+=";"+cabinObj.getString(PROP_RBD);
					}else{
						if(k==0)
							rbdString="null";
						else rbdString+=";null";
					}
				}
				
				if(bookingClass.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
					calculation.put(PROP_CABINCLASS, cabinString);
					calculation.put(PROP_RBD, rbdString);
				}else{
					calculation.put(PROP_CABINCLASS+"_"+EXCLUSION, cabinString);
					calculation.put(PROP_RBD+"_"+EXCLUSION, rbdString);
				}
			}
		}
	}


	public static void setFareBasisValue(JSONObject advanceDefinitionAir, JSONArray advancedArr, JSONArray calcArr, String commercialName) {
		int length = advancedArr.length();
		if(advanceDefinitionAir.has(PROP_FARECLASS)){
			JSONObject fareClass = advanceDefinitionAir.getJSONObject(PROP_FARECLASS);
			if(fareClass.has(PROP_FAREBASIS) && fareClass.getJSONObject(PROP_FAREBASIS).getJSONArray(PROP_FARE).length()>0){
				JSONArray fare = fareClass.getJSONObject(PROP_FAREBASIS).getJSONArray(PROP_FARE);
				for(int i=0;i<length;i++){
					for(int f=0;f<fare.length();f++){
						JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
						JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
						JSONObject fareObject = fare.getJSONObject(f);
						JSONArray fareArr = new JSONArray();
						if(fareObject.has(PROP_CONDITION))
							fareArr.put(fareObject.getString(PROP_CONDITION));
						if(fareObject.has(VALUE))
							fareArr.put(fareObject.getString(VALUE));
						if(fareArr.length()%2==0)
							calculation.put(FAREBASISVALUE, fareArr);

						CommonFunctions.setRuleID(advancedArr, calcArr, base, calculation, PROP_FARECLASS+i+f);
					}
				}
				for(int i=0;i<length;i++){
					advancedArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
	}


	private static void getFlightNumbers(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String commercialName) {
		int length = advancedArr.length();
		if(advanceDefinitionAir.has(PROP_FLIGHT_NUMBERS)){
			JSONArray flightRange = advanceDefinitionAir.getJSONObject(PROP_FLIGHT_NUMBERS).getJSONArray(PROP_FLIGHTRANGE);
			if(flightRange.length()>0){
				String numbers=null;
				for(int i=0;i<length;i++){
					for(int j=0;j<flightRange.length();j++){
						JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
						JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
						JSONObject flightObject  = flightRange.getJSONObject(j);
						if(flightObject.has(PROP_FLIGHTRANGE_FROM)){
							if(flightObject.has(PROP_FLIGHTRANGE_TO)){
								if(j==0)
									numbers=BETWEEN;
								numbers+=";"+flightObject.get(PROP_FLIGHTRANGE_FROM)+";"+flightObject.get(PROP_FLIGHTRANGE_TO);
							}else numbers=GREATERTHANEQUALTO+";"+flightObject.get(PROP_FLIGHTRANGE_FROM);
						}else if(flightObject.has(PROP_FLIGHTRANGE_TO))
							numbers=LESSTHANEQUALTO+";"+flightObject.get(PROP_FLIGHTRANGE_TO);

						if(advanceDefinitionAir.getJSONObject(PROP_FLIGHT_NUMBERS).getBoolean(PROP_BOOLEAN_ISINCLUSION))
							calculation.put(FLIGHTNUMBER, numbers);
						else calculation.put(FLIGHTNUMBER+"_"+EXCLUSION, numbers);

						CommonFunctions.setRuleID(advancedArr, calcArr, base, calculation, PROP_FLIGHT_NUMBERS+i+j);
					}
				}
			}
			for(int i=0;i<length;i++){
				advancedArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	private static void getFlightTimings(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String commercialName) {
		int length = advancedArr.length();
		if(advanceDefinitionAir.has(PROP_FLIGHT_TIMINGS)){
			JSONArray flightTimings = advanceDefinitionAir.getJSONObject(PROP_FLIGHT_TIMINGS).getJSONArray(PROP_FLIGHT_TIMINGS);
			if(flightTimings.length()>0){
				String timing = null;
				for(int i=0;i<length;i++){
					for(int m=0;m<flightTimings.length();m++){
						JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
						JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
						JSONObject flightTimingObj = flightTimings.getJSONObject(m);
						if(flightTimingObj.has(PROP_FLIGHTTIME_FROM)){
							if(flightTimingObj.has(PROP_FLIGHTTIME_TO)){
								if(m==0)
									timing=BETWEEN;
								timing+=";"+flightTimingObj.getString(PROP_FLIGHTTIME_FROM)+";"+flightTimingObj.getString(PROP_FLIGHTTIME_TO);

							}else{
								timing=GREATERTHANEQUALTO;
								timing+=";"+flightTimingObj.getString(PROP_FLIGHTTIME_FROM);
							}
						}else if(flightTimingObj.has(PROP_FLIGHTTIME_TO)){
							timing=LESSTHANEQUALTO;
							timing+=";"+flightTimingObj.getString(PROP_FLIGHTTIME_TO);
						}
						if(advanceDefinitionAir.getJSONObject(PROP_FLIGHT_TIMINGS).getBoolean(PROP_BOOLEAN_ISINCLUSION))
							calculation.put(FLIGHTTIMING, timing);
						else calculation.put(FLIGHTTIMING+"_"+EXCLUSION, timing);
						CommonFunctions.setRuleID(advancedArr, calcArr, base, calculation, PROP_FLIGHT_TIMINGS+i+m);
					}
				}
				for(int i=0;i<length;i++){
					advancedArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
	}


	private static JSONObject setAirDestination(String incExc, JSONArray journeyType, JSONObject calculation, JSONArray destinations) {
		String continentMain=null,countryMain=null,cityMain=null,journeyTypeString=null;
		for(int i=0;i<journeyType.length();i++){
			if(i==0)
				journeyTypeString=journeyType.getString(i);
			else journeyTypeString+="&"+journeyType.getString(i);
		}
		for(int i=0;i<destinations.length();i++){
			JSONObject continent = destinations.getJSONObject(i).getJSONObject(PROP_CONTINENT);
			JSONObject country = destinations.getJSONObject(i).getJSONObject(PROP_COUNTRY);
			JSONObject city = destinations.getJSONObject(i).getJSONObject(PROP_CITY);
			if(i==0){
				if(continent.has(PROP_VIA)){
					if(continent.has(FROM)){
						if(continent.has(TO))
							continentMain = continent.getString(FROM)+";"+continent.getString(PROP_VIA)+";"+continent.getString(TO);
						else continentMain = continent.getString(FROM)+";"+continent.getString(PROP_VIA)+";"+null;
					}else{
						if(continent.has(TO))
							continentMain = null+";"+continent.getString(PROP_VIA)+";"+continent.getString(TO);
						else continentMain = null+";"+continent.getString(PROP_VIA)+";"+null;
					}
				}else{
					if(continent.has(FROM)){
						if(continent.has(TO))
							continentMain = continent.getString(FROM)+";"+null+";"+continent.getString(TO);
						else continentMain = continent.getString(FROM)+";"+null+";"+null;
					}else{
						if(continent.has(TO))
							continentMain = null+";"+null+";"+continent.getString(TO);
						else continentMain = null+";"+null+";"+null;
					}
				}
				if(country.has(PROP_VIA)){
					if(country.has(FROM)){
						if(country.has(TO))
							countryMain = country.getString(FROM)+";"+country.getString(PROP_VIA)+";"+country.getString(TO);
						else countryMain = country.getString(FROM)+";"+country.getString(PROP_VIA)+";"+null;
					}else{
						if(country.has(TO))
							countryMain = null+";"+country.getString(PROP_VIA)+";"+country.getString(TO);
						else countryMain = null+";"+country.getString(PROP_VIA)+";"+null;
					}
				}else{
					if(country.has(FROM)){
						if(country.has(TO))
							countryMain = country.getString(FROM)+";"+null+";"+country.getString(TO);
						else countryMain = country.getString(FROM)+";"+null+";"+null;
					}else{
						if(country.has(TO))
							countryMain = null+";"+null+";"+country.getString(TO);
						else countryMain = null+";"+null+";"+null;
					}
				}
				if(city.has(PROP_VIA)){
					if(city.has(FROM)){
						if(city.has(TO))
							cityMain = city.getString(FROM)+";"+city.getString(PROP_VIA)+";"+city.getString(TO);
						else cityMain = city.getString(FROM)+";"+city.getString(PROP_VIA)+";"+null;
					}else{
						if(city.has(TO))
							cityMain = null+";"+city.getString(PROP_VIA)+";"+city.getString(TO);
						else cityMain = null+";"+city.getString(PROP_VIA)+";"+null;
					}
				}else{
					if(city.has(FROM)){
						if(city.has(TO))
							cityMain = city.getString(FROM)+";"+null+";"+city.getString(TO);
						else cityMain = city.getString(FROM)+";"+null+";"+null;
					}else{
						if(city.has(TO))
							cityMain = null+";"+null+";"+city.getString(TO);
						else cityMain = null+";"+null+";"+null;
					}
				}
			}
			else{
				if(continent.has(PROP_VIA)){
					if(continent.has(FROM)){
						if(continent.has(TO))
							continentMain+= "/"+continent.getString(FROM)+";"+continent.getString(PROP_VIA)+";"+continent.getString(TO);
						else continentMain+= "/"+continent.getString(FROM)+";"+continent.getString(PROP_VIA)+";"+null;
					}else{
						if(continent.has(TO))
							continentMain+= "/"+null+";"+continent.getString(PROP_VIA)+";"+continent.getString(TO);
						else continentMain+= "/"+null+";"+continent.getString(PROP_VIA)+";"+null;
					}
				}else{
					if(continent.has(FROM)){
						if(continent.has(TO))
							continentMain+= "/"+continent.getString(FROM)+";"+null+";"+continent.getString(TO);
						else continentMain+= "/"+continent.getString(FROM)+";"+null+";"+null;
					}else{
						if(continent.has(TO))
							continentMain+= "/"+null+";"+null+";"+continent.getString(TO);
						else continentMain+= "/"+null+";"+null+";"+null;
					}
				}
				if(country.has(PROP_VIA)){
					if(country.has(FROM)){
						if(country.has(TO))
							countryMain+= "/"+country.getString(FROM)+";"+country.getString(PROP_VIA)+";"+country.getString(TO);
						else countryMain+= "/"+country.getString(FROM)+";"+country.getString(PROP_VIA)+";"+null;
					}else{
						if(country.has(TO))
							countryMain+= "/"+null+";"+country.getString(PROP_VIA)+";"+country.getString(TO);
						else countryMain+= "/"+null+";"+country.getString(PROP_VIA)+";"+null;
					}
				}else{
					if(country.has(FROM)){
						if(country.has(TO))
							countryMain+= "/"+country.getString(FROM)+";"+null+";"+country.getString(TO);
						else countryMain+= "/"+country.getString(FROM)+";"+null+";"+null;
					}else{
						if(country.has(TO))
							countryMain+= "/"+null+";"+null+";"+country.getString(TO);
						else countryMain+= "/"+null+";"+null+";"+null;
					}
				}
				if(city.has(PROP_VIA)){
					if(city.has(FROM)){
						if(city.has(TO))
							cityMain+= "/"+city.getString(FROM)+";"+city.getString(PROP_VIA)+";"+city.getString(TO);
						else cityMain+= "/"+city.getString(FROM)+";"+city.getString(PROP_VIA)+";"+null;
					}else{
						if(city.has(TO))
							cityMain+= "/"+null+";"+city.getString(PROP_VIA)+";"+city.getString(TO);
						else cityMain+= "/"+null+";"+city.getString(PROP_VIA)+";"+null;
					}
				}else{
					if(city.has(FROM)){
						if(city.has(TO))
							cityMain+= "/"+city.getString(FROM)+";"+null+";"+city.getString(TO);
						else cityMain+= "/"+city.getString(FROM)+";"+null+";"+null;
					}else{
						if(city.has(TO))
							cityMain+= "/"+null+";"+null+";"+city.getString(TO);
						else cityMain+= "/"+null+";"+null+";"+null;
					}
				}
			}
		}
		if(incExc==INCLUSION){
			calculation.put(PROP_CONTINENT, journeyTypeString+";"+continentMain);
			calculation.put(PROP_COUNTRY, journeyTypeString+";"+countryMain);
			calculation.put(PROP_CITY, journeyTypeString+";"+cityMain);
		}else{
			calculation.put(PROP_CONTINENT+"_"+EXCLUSION, journeyTypeString+";"+continentMain);
			calculation.put(PROP_COUNTRY+"_"+EXCLUSION, journeyTypeString+";"+countryMain);
			calculation.put(PROP_CITY+"_"+EXCLUSION, journeyTypeString+";"+cityMain);
		}
		return calculation;
	}


	public static void getOtherFeesAdvancedDefinition(JSONArray otherFeeArr, JSONObject advanceDefinitionAir, String commDefnID, String commercialName){
		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
			if(advanceDefinitionAir.has(CONNECTIVITY)){
				JSONObject connectivity = advanceDefinitionAir.getJSONObject(CONNECTIVITY);
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					otherFee.put(CONNECTIVITYSUPPTYPE, connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERNAME) && !connectivity.getString(PROP_SUPPLIERNAME).equalsIgnoreCase("All"))
					otherFee.put(CONNECTIVITYSUPP, connectivity.getString(PROP_SUPPLIERNAME));
			}
			if(advanceDefinitionAir.has(PROP_CREDENTIALS) && advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS).length()>0){
				JSONArray credentials = advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS);
				JSONArray crentialsArr = new JSONArray();
				for(int cr=0;cr<credentials.length();cr++){
					crentialsArr.put(credentials.getJSONObject(cr).getString(PROP_CREDENTIALS));
				}
				otherFee.put(CREDENTIALSNAME, crentialsArr);
			}
			if(advanceDefinitionAir.has(PROP_OTHERS))
				otherFee.put(BOOKINGTYPE, advanceDefinitionAir.getJSONObject(PROP_OTHERS).getString(BOOKINGTYPE));

			getAirBookingClass(advanceDefinitionAir, otherFee);

			/*	if(advanceDefinitionAir.has(PAXTYPES) && advanceDefinitionAir.getJSONArray(PAXTYPES).length()>0){
				JSONArray passengerTypes  = advanceDefinitionAir.getJSONArray(PAXTYPES);
				JSONArray paxType = new JSONArray();
				for(int pt=0;pt<passengerTypes.length();pt++){
					paxType.put(passengerTypes.getJSONObject(pt).getString(PAXTYPES));
				}
				otherFee.put(PAXTYPE, paxType);
			}*/
			if(advanceDefinitionAir.has(PROP_TRAVELDESTINATION)){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION);
				if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
					if(travelDestination.has(PROP_SOTO) && travelDestination.getJSONArray(PROP_SOTO).length()>0)
						otherFee.put(TRAVELTYPE, travelDestination.get(PROP_SOTO));

					if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
						otherFee.put(PROP_JOURNEYTYPE, travelDestination.get(PROP_JOURNEYTYPE));

					otherFee.put(CODESHAREDFLIGHTINCLUDED, travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED));

					if(travelDestination.getBoolean(PROP_BOOLEAN_ISDIRECTFLIGHTS))
						otherFee.put(FLIGHTTYPE, DIRECT);
					else otherFee.put(FLIGHTTYPE, VIA);

					if(travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE))
						otherFee.put(FLIGHTLINETYPE, ONLINE);
					else otherFee.put(FLIGHTLINETYPE, OFFLINE);

					JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has(PROP_PRODUCTID)){
							if(destObj.getJSONArray(PROP_PRODUCTID).length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTID).length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTID).getString(tpn));
							}
						}
					}
					if(travelProductNameArr.length()>0)
						otherFee.put(TRAVELPRODUCTNAME, travelProductNameArr);
				}else{
					if(travelDestination.has(PROP_SOTO) && travelDestination.getJSONArray(PROP_SOTO).length()>0)
						otherFee.put(TRAVELTYPE+"_"+EXCLUSION, travelDestination.get(PROP_SOTO));

					if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
						otherFee.put(PROP_JOURNEYTYPE+"_"+EXCLUSION, travelDestination.get(PROP_JOURNEYTYPE));

					otherFee.put(CODESHAREDFLIGHTINCLUDED+"_"+EXCLUSION, travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED));

					if(travelDestination.getBoolean(PROP_BOOLEAN_ISDIRECTFLIGHTS))
						otherFee.put(FLIGHTTYPE+"_"+EXCLUSION, DIRECT);
					else otherFee.put(FLIGHTTYPE+"_"+EXCLUSION, VIA);

					if(travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE))
						otherFee.put(FLIGHTLINETYPE+"_"+EXCLUSION, ONLINE);
					else otherFee.put(FLIGHTLINETYPE+"_"+EXCLUSION, OFFLINE);

					JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
					JSONArray travelProductNameArr = new JSONArray();
					for(int d=0;d<destinations.length();d++){
						JSONObject destObj = destinations.getJSONObject(d);
						if(destObj.has(PROP_PRODUCTID)){
							if(destObj.getJSONArray(PROP_PRODUCTID).length()>0)
								travelProductNameArr.put(destObj.get(PROP_PRODUCTID));
						}
					}
					if(travelProductNameArr.length()>0)
						otherFee.put(TRAVELPRODUCTNAME+"_"+EXCLUSION, travelProductNameArr);
				}
			}
			if(advanceDefinitionAir.has(PROP_FARECLASS)){
				if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_DEALCODES)){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_DEALCODES);
					JSONArray dealCodesArr = dealCodes.getJSONArray(PROP_DEALCODES);
					JSONArray dealcode= new JSONArray();
					for(int dc=0;dc<dealCodesArr.length();dc++){
						dealcode.put(dealCodesArr.getJSONObject(dc).getString(DEALCODE));
					}
					if(dealCodes.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						otherFee.put(DEALCODE, dealcode);
					else otherFee.put(DEALCODE+"_"+EXCLUSION, dealcode);
				}
			}
			otherFeeArr.put(otherFee);
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
		setAirOtherFeesDestination(otherFeeArr,advanceDefinitionAir,commercialName);
		CommonFunctions.setOtherFeeTicketingPlusTravel(otherFeeArr,advanceDefinitionAir.getJSONObject(PROP_VALIDITY),commercialName);
		getOtherFeesFareBasis(otherFeeArr,advanceDefinitionAir,commercialName);
		//getOtherFeesFlightTiming(otherFeeArr,advanceDefinitionAir);
		//getOtherFeesFlightNumbers(otherFeeArr,advanceDefinitionAir);
	}


	private static void setAirOtherFeesDestination(JSONArray otherFeeArr, JSONObject advanceDefinitionAir, String commercialName){
		if(advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION).has(PROP_DESTINATIONS)){
			JSONArray destinationArray = advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION).getJSONArray(PROP_DESTINATIONS);
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<destinationArray.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject destinationObj = destinationArray.getJSONObject(j);
					if(advanceDefinitionAir.getJSONObject(PROP_TRAVELDESTINATION).getBoolean(PROP_BOOLEAN_ISINCLUSION)){
						if(destinationObj.has(PROP_CONTINENT)){
							JSONObject continent = destinationArray.getJSONObject(j).getJSONObject(PROP_CONTINENT);
							if(continent.has(PROP_FROM) && !continent.getString(PROP_FROM).equalsIgnoreCase("All"))
								otherFee.put(FROM_CONTINENT, continent.getString(PROP_FROM));
							if(continent.has(PROP_VIA) && !continent.getString(PROP_VIA).equalsIgnoreCase("All"))
								otherFee.put(VIA_CONTINENT, continent.getString(PROP_VIA));
							if(continent.has(PROP_TO) && !continent.getString(PROP_TO).equalsIgnoreCase("All"))
								otherFee.put(TO_CONTINENT, continent.getString(PROP_TO));
						}
						if(destinationObj.has(PROP_COUNTRY)){
							JSONObject country = destinationArray.getJSONObject(j).getJSONObject(PROP_COUNTRY);
							if(country.has(PROP_FROM) && !country.getString(PROP_FROM).equalsIgnoreCase("All"))
								otherFee.put(FROM_COUNTRY, country.getString(PROP_FROM));
							if(country.has(PROP_VIA) && !country.getString(PROP_VIA).equalsIgnoreCase("All"))
								otherFee.put(VIA_COUNTRY, country.getString(PROP_VIA));
							if(country.has(PROP_TO) && !country.getString(PROP_TO).equalsIgnoreCase("All"))
								otherFee.put(TO_COUNTRY, country.getString(PROP_TO));
						}
						if(destinationObj.has(PROP_CITY)){
							JSONObject city = destinationArray.getJSONObject(j).getJSONObject(PROP_CITY);
							if(city.has(PROP_FROM) && !city.getString(PROP_FROM).equalsIgnoreCase("All"))
								otherFee.put(FROM_CITY, city.getString(PROP_FROM));
							if(city.has(PROP_VIA) && !city.getString(PROP_VIA).equalsIgnoreCase("All"))
								otherFee.put(VIA_CITY, city.getString(PROP_VIA));
							if(city.has(PROP_TO) && !city.getString(PROP_TO).equalsIgnoreCase("All"))
								otherFee.put(TO_CITY, city.getString(PROP_TO));
						}
					}else{
						if(destinationObj.has(PROP_CONTINENT)){
							JSONObject continent = destinationArray.getJSONObject(j).getJSONObject(PROP_CONTINENT);
							if(continent.has(PROP_FROM) && !continent.getString(PROP_FROM).equalsIgnoreCase("All"))
								otherFee.put(FROM_CONTINENT+"_"+EXCLUSION, continent.getString(PROP_FROM));
							if(continent.has(PROP_VIA) && !continent.getString(PROP_VIA).equalsIgnoreCase("All"))
								otherFee.put(VIA_CONTINENT+"_"+EXCLUSION, continent.getString(PROP_VIA));
							if(continent.has(PROP_TO) && !continent.getString(PROP_TO).equalsIgnoreCase("All"))
								otherFee.put(TO_CONTINENT+"_"+EXCLUSION, continent.getString(PROP_TO));
						}
						if(destinationObj.has(PROP_COUNTRY)){
							JSONObject country = destinationArray.getJSONObject(j).getJSONObject(PROP_COUNTRY);
							if(country.has(PROP_FROM) && !country.getString(PROP_FROM).equalsIgnoreCase("All"))
								otherFee.put(FROM_COUNTRY+"_"+EXCLUSION, country.getString(PROP_FROM));
							if(country.has(PROP_VIA) && !country.getString(PROP_VIA).equalsIgnoreCase("All"))
								otherFee.put(VIA_COUNTRY+"_"+EXCLUSION, country.getString(PROP_VIA));
							if(country.has(PROP_TO) && !country.getString(PROP_TO).equalsIgnoreCase("All"))
								otherFee.put(TO_COUNTRY+"_"+EXCLUSION, country.getString(PROP_TO));
						}
						if(destinationObj.has(PROP_CITY)){
							JSONObject city = destinationArray.getJSONObject(j).getJSONObject(PROP_CITY);
							if(city.has(PROP_FROM) && !city.getString(PROP_FROM).equalsIgnoreCase("All"))
								otherFee.put(FROM_CITY+"_"+EXCLUSION, city.getString(PROP_FROM));
							if(city.has(PROP_VIA) && !city.getString(PROP_VIA).equalsIgnoreCase("All"))
								otherFee.put(VIA_CITY+"_"+EXCLUSION, city.getString(PROP_VIA));
							if(city.has(PROP_TO) && !city.getString(PROP_TO).equalsIgnoreCase("All"))
								otherFee.put(TO_CITY+"_"+EXCLUSION, city.getString(PROP_TO));
						}
					}
					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+"_"+PROP_DESTINATION+i+j);
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}

		}
	}


	/*private static void getOtherFeesFlightNumbers(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has(PROP_FLIGHT_NUMBERS)){
			JSONArray flightRange = advanceDefinitionAir.getJSONObject(PROP_FLIGHT_NUMBERS).getJSONArray(PROP_FLIGHTRANGE);
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<flightRange.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject range = flightRange.getJSONObject(j);
					String numbers=null;
					if(range.has(PROP_FLIGHTRANGE_FROM)){
						if(range.has(PROP_FLIGHTRANGE_TO))
							numbers=BETWEEN+";"+range.get(PROP_FLIGHTRANGE_FROM)+";"+range.get(PROP_FLIGHTRANGE_TO);
						else numbers=GREATERTHANEQUALTO+";"+range.get(PROP_FLIGHTRANGE_FROM);
					}else if(range.has(PROP_FLIGHTRANGE_TO))
						numbers=LESSTHANEQUALTO+";"+range.get(PROP_FLIGHTRANGE_TO);

					if(advanceDefinitionAir.getJSONObject(PROP_FLIGHT_NUMBERS).getBoolean(PROP_BOOLEAN_ISINCLUSION))
						otherFee.put(FLIGHTNUMBER, numbers);
					else otherFee.put(FLIGHTNUMBER+"_"+EXCLUSION, numbers);

					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, range.getString(_ID));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}


	private static void getOtherFeesFlightTiming(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has(PROP_FLIGHT_TIMINGS)){
			JSONArray flightTimings = advanceDefinitionAir.getJSONObject(PROP_FLIGHT_TIMINGS).getJSONArray(PROP_FLIGHT_TIMINGS);
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int m=0;m<flightTimings.length();m++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject timingObject = flightTimings.getJSONObject(m);
					String timing=null;
					if(timingObject.has(PROP_FLIGHTTIME_FROM)){
						if(timingObject.has(PROP_FLIGHTTIME_TO))
							timing=BETWEEN+";"+timingObject.get(PROP_FLIGHTTIME_FROM)+";"+timingObject.get(PROP_FLIGHTTIME_TO);
						else timing=GREATERTHANEQUALTO+";"+timingObject.get(PROP_FLIGHTTIME_FROM);
					}else if(timingObject.has(PROP_FLIGHTTIME_TO))
						timing=LESSTHANEQUALTO+";"+timingObject.get(PROP_FLIGHTTIME_TO);

					if(advanceDefinitionAir.getJSONObject(PROP_FLIGHT_TIMINGS).getBoolean(PROP_BOOLEAN_ISINCLUSION))
						otherFee.put(FLIGHTTIMING, timing);
					else otherFee.put(FLIGHTTIMING+"_"+EXCLUSION, timing);

					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, timingObject.getString(_ID));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}*/


	private static void getOtherFeesFareBasis(JSONArray otherFeeArr, JSONObject advanceDefinitionAir, String commercialName) {
		if(advanceDefinitionAir.has(PROP_FARECLASS)){
			if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_FAREBASIS)){
				JSONArray fare = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_FAREBASIS).getJSONArray(PROP_FARE);
				int length = otherFeeArr.length();
				if(fare.length()>0){
					for(int i=0;i<length;i++){
						for(int f=0;f<fare.length();f++){
							JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
							JSONObject fareObject = fare.getJSONObject(f);
							JSONArray fareArr = new JSONArray();
							if(fareObject.has(PROP_CONDITION))
								fareArr.put(fareObject.getString(PROP_CONDITION));
							if(fareObject.has(VALUE))
								fareArr.put(fareObject.getString(VALUE));
							otherFee.put(FAREBASISVALUE, fareArr);
							String otherFeeID = otherFee.getString(RULEID);
							otherFee.put(RULEID, otherFeeID+commercialName+"_"+PROP_FARECLASS+i+f);
							otherFeeArr.put(otherFee);
						}
					}
					for(int i=0;i<length;i++){
						otherFeeArr.remove(0);
					}
				}
			}
		}
	}
}
