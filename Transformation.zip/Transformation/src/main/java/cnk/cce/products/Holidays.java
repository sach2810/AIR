package cnk.cce.products;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.cce.configuration.CommonFunctions;
import cnk.cce.configuration.Constants;

public class Holidays implements Constants {
	public static JSONArray baseArr = new JSONArray();
	public static JSONArray calcArr = new JSONArray();
	public static String destination,country,city,brochureName,flavourName,productType,brandName,productName,flavourType;
	
	public static void setHolidaysAdvancedDefinition(JSONObject advanced, JSONObject calculation, JSONObject advanceDefinitionHolidays, String advDefnID, String commercialName, JSONObject mainJson, JSONArray clientCommercialOtherHead) {
		baseArr.put(advanced);
		calcArr.put(calculation);
		if(advanceDefinitionHolidays.has(APPLICABLEON) && advanceDefinitionHolidays.getJSONArray(APPLICABLEON).length()>0){
			setApplicableOnDTName(commercialName,calcArr,mainJson);
			setAdvancedDefinition(advanceDefinitionHolidays,baseArr,calcArr,commercialName);
			setHolidaysApplicableOn(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray(APPLICABLEON),advanceDefinitionHolidays,commercialName);
		}else{
			setAdvancedDefinition(advanceDefinitionHolidays,baseArr,calcArr,commercialName);
			if(advanceDefinitionHolidays.has(PAXTYPE) && advanceDefinitionHolidays.getJSONArray(PAXTYPE).length()>0){
				JSONObject passengerType = advanceDefinitionHolidays.getJSONArray(PAXTYPE).getJSONObject(0);
				if(passengerType.has(PROP_TRIGGER_PAYOUT) && passengerType.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
					CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PAXTYPE), PAXTYPE, true, false,commercialName);
				else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PAXTYPE), PAXTYPE, true, false);
			}
			
			if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
				JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
				if(roomLevel.has(PROP_ROOMCATEGORIES) && roomLevel.getJSONArray(PROP_ROOMCATEGORIES).length()>0){
					JSONObject roomCategories = roomLevel.getJSONArray(PROP_ROOMCATEGORIES).getJSONObject(0);
					if(roomCategories.has(PROP_TRIGGER_PAYOUT) && roomCategories.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
						CommonFunctions.getArray(baseArr, calcArr, roomLevel.getJSONArray(PROP_ROOMCATEGORIES), PROP_ROOMCATEGORIES, true, false,commercialName);
					else CommonFunctions.getArrayNonTP(baseArr, calcArr,roomLevel.getJSONArray(PROP_ROOMCATEGORIES),PROP_ROOMCATEGORIES,true,false);
				}
				
				if(roomLevel.has(PROP_ROOMTYPES) && roomLevel.getJSONArray(PROP_ROOMTYPES).length()>0){
					JSONObject roomTypes = roomLevel.getJSONArray(PROP_ROOMTYPES).getJSONObject(0);
					if(roomTypes.has(PROP_TRIGGER_PAYOUT) && roomTypes.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
						CommonFunctions.getArray(baseArr, calcArr, roomLevel.getJSONArray(PROP_ROOMTYPES), PROP_ROOMTYPES, true, false,commercialName);
					else CommonFunctions.getArrayNonTP(baseArr, calcArr,roomLevel.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES,true,false);
				}
			}
		}
	}
	
	
	private static void setApplicableOnDTName(String commercialName, JSONArray calculationArr, JSONObject mainJson) {
		switch(commercialName){
		case STANDARD:{
			mainJson.remove(DTNAME_STD_CALCULATION);
			mainJson.put(DTNAME_STD_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case OVERRIDING:{
			mainJson.remove(DTNAME_OVER_CALCULATION);
			mainJson.put(DTNAME_OVER_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case PLB:{
			mainJson.remove(DTNAME_PLB_CALCULATION);
			mainJson.put(DTNAME_PLB_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case SEGMENTFEE:{
			mainJson.remove(DTNAME_SEGMENT_CALCULATION);
			mainJson.put(DTNAME_SEGMENT_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case SECTORWISEINCENTIVE:{
			mainJson.remove(DTNAME_SECTOR_CALCULATION);
			mainJson.put(DTNAME_SECTOR_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case DESTINATIONINCENTIVE:{
			mainJson.remove(DTNAME_DESTINATION_CALCULATION);
			mainJson.put(DTNAME_DESTINATION_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case MANAGEMENTFEE:{
			mainJson.remove(DTNAME_MNGT_CALCULATION);
			mainJson.put(DTNAME_MNGT_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case SERVICECHARHGE:{
			mainJson.remove(DTNAME_SERVICE_CALCULATION);
			mainJson.put(DTNAME_SERVICE_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case PROP_DISCOUNT:{
			mainJson.remove(DTNAME_DISCOUNT_CALCULATION);
			mainJson.put(DTNAME_DISCOUNT_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		case MARKUP:{
			mainJson.remove(DTNAME_MARKUP_CALCULATION);
			mainJson.put(DTNAME_MARKUP_APPLICABLEON_CALCULATION, calculationArr);
			break;
		}
		default:System.out.println("default of setApplicableOnDTName due to commercialName: "+commercialName);
		}
	}
	

	private static void setAdvancedDefinition(JSONObject advanceDefinitionHolidays, JSONArray baseArr, JSONArray calcArr, String commercialName) {
		if(advanceDefinitionHolidays.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionHolidays.getJSONObject(PROP_VALIDITY);
			switch(validity.getString(PROP_SALEORTRAVEL)){
			case PROP_SALES:{
				JSONObject sales = validity.getJSONArray(PROP_SALES).getJSONObject(0);
				if(sales.has(PROP_TRIGGER_PAYOUT) && sales.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
					getPLBDates(baseArr, calcArr, validity.getJSONArray(PROP_SALES), PROP_SALES, false, PLB);
				else setDate(baseArr, calcArr, validity.getJSONArray(PROP_SALES), PROP_SALE, false);
				break;
			}
			case PROP_TRAVEL:{
				JSONObject travel = validity.getJSONArray(PROP_TRAVEL).getJSONObject(0);
				if(travel.has(PROP_TRIGGER_PAYOUT) && travel.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
					getPLBDates(baseArr, calcArr, validity.getJSONArray(PROP_TRAVEL), PROP_TRAVEL, false, PLB);
				else setDate(baseArr, calcArr, validity.getJSONArray(PROP_TRAVEL), PROP_TRAVEL, false);
				break;
			}
			default:System.out.println("default of Holidays.setHolidaysAdvancedDefinition");
			}
		}

		if(advanceDefinitionHolidays.has(PROP_TRAVELDESTINATIONS) && advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTINATIONS).length()>0){
			JSONObject travelDestinations = advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTINATIONS).getJSONObject(0);
			if(travelDestinations.has(PROP_TRIGGER_PAYOUT) && travelDestinations.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				setPLBHolidaysDestinations(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTINATIONS),commercialName);
			else setHolidaysDestinations(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTINATIONS),commercialName);
		}
		
		if(advanceDefinitionHolidays.has(PROP_CREDENTIALS) && advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS).length()>0){
			JSONObject credentials = advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS).getJSONObject(0);
			if(credentials.has(PROP_TRIGGER_PAYOUT) && credentials.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true);
		}
		
		if(advanceDefinitionHolidays.has(PROP_NATIONALITY) && advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY).length()>0){
			JSONObject nationality = advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY).getJSONObject(0);
			if(nationality.has(PROP_TRIGGER_PAYOUT) && nationality.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY), CLIENTNATIONALITY, true, true,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY), CLIENTNATIONALITY, true, true);
		}
		
		if(advanceDefinitionHolidays.has(PROP_TOURTYPES) && advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES).length()>0){
			JSONObject tourTypes = advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES).getJSONObject(0);
			if(tourTypes.has(PROP_TRIGGER_PAYOUT) && tourTypes.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES), PROP_TOURTYPES, true, false,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES), PROP_TOURTYPES, true, false);
		}
		
		if(advanceDefinitionHolidays.has(CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionHolidays.getJSONObject(CONNECTIVITY);
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				if(connectivity.has(PROP_TRIGGER_PAYOUT) && connectivity.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0){
					CommonFunctions.getConnectivityTP(baseArr, connectivity);
					break;
				}
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					base.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					base.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERID));
			}
		}
		
		if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
			if(roomLevel.has(BOOKINGTYPE)){
				JSONObject bookingType = roomLevel.getJSONObject(BOOKINGTYPE);
				if(bookingType.has(PROP_TRIGGER_PAYOUT) && bookingType.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0){
					CommonFunctions.getBookingTypeTP(baseArr,bookingType, true);
				}else{
					int length=calcArr.length();
					for(int i=0;i<length;i++){
						JSONObject calculation = calcArr.getJSONObject(i);
						calculation.put(BOOKINGTYPE, bookingType.getString(BOOKINGTYPE));
					}
				}
			}	
		}
	}
	
	
	private static void setHolidaysApplicableOn(JSONArray baseArr, JSONArray calcArr, JSONArray applicableOnArr, JSONObject advanceDefinitionHolidays, String commercialName) {
		if(advanceDefinitionHolidays.has(PAXTYPE) && advanceDefinitionHolidays.getJSONArray(PAXTYPE).length()>0){
			JSONObject passengerType = advanceDefinitionHolidays.getJSONArray(PAXTYPE).getJSONObject(0);
			if(passengerType.has(PROP_TRIGGER_PAYOUT) && passengerType.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				getArrayApplicableOn(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PAXTYPE), PAXTYPE,commercialName);
			else getArrayNonTPApplicableOn(calcArr, advanceDefinitionHolidays.getJSONArray(PAXTYPE), PAXTYPE);
		}
		
		if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
			if(roomLevel.has(PROP_ROOMCATEGORIES) && roomLevel.getJSONArray(PROP_ROOMCATEGORIES).length()>0){
				JSONObject roomCategories = roomLevel.getJSONArray(PROP_ROOMCATEGORIES).getJSONObject(0);
				if(roomCategories.has(PROP_TRIGGER_PAYOUT) && roomCategories.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
					getArrayApplicableOn(baseArr, calcArr, roomLevel.getJSONArray(PROP_ROOMCATEGORIES), PROP_ROOMCATEGORIES,commercialName);
				else getArrayNonTPApplicableOn(calcArr,roomLevel.getJSONArray(PROP_ROOMCATEGORIES),PROP_ROOMCATEGORIES);
			}
			
			if(roomLevel.has(PROP_ROOMTYPES) && roomLevel.getJSONArray(PROP_ROOMTYPES).length()>0){
				JSONObject roomTypes = roomLevel.getJSONArray(PROP_ROOMTYPES).getJSONObject(0);
				if(roomTypes.has(PROP_TRIGGER_PAYOUT) && roomTypes.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
					getArrayApplicableOn(baseArr, calcArr, roomLevel.getJSONArray(PROP_ROOMTYPES), PROP_ROOMTYPES,commercialName);
				else getArrayNonTPApplicableOn(calcArr,roomLevel.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES);
			}
		}
		
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			calculation.put(PRODUCTNAME+"_"+APPLICABLEON, applicableOnArr);
		}
	}
	
	
	private static void getArrayApplicableOn(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, String commercialName) {
		int length=calcArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<jsonArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject jsonObject = jsonArray.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(jsonObject.getJSONArray(PROP_TRIGGER_PAYOUT));
				JSONArray array = new JSONArray();
				array.put(triggerPayout);
				JSONObject object = new JSONObject();
				object.put(name+""+"_"+APPLICABLEON, jsonObject.getString(name));
				array.put(object);
				calculation.put(name, array);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+"_"+name+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	private static void getArrayNonTPApplicableOn(JSONArray calcArr, JSONArray jsonArray, String name) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			calculation.put(name+""+"_"+APPLICABLEON, array);
		}
	}
	
	
	public static void setHolidaysDestinations(JSONArray baseArr, JSONArray calcArr, JSONArray travelDestinationsArr, String commercialName) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				if(travelDestinations.has(PROP_DESTINATION) && !travelDestinations.getString(PROP_DESTINATION).equalsIgnoreCase("All"))
					calculation.put(TOCONTINENT, travelDestinations.getString(PROP_DESTINATION));
				if(travelDestinations.has(PROP_COUNTRY) && !travelDestinations.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
					calculation.put(TOCOUNTRY, travelDestinations.getString(PROP_COUNTRY));
				if(travelDestinations.has(PROP_CITY) && !travelDestinations.getString(PROP_CITY).equalsIgnoreCase("All"))
					calculation.put(TOCITY, travelDestinations.getString(PROP_CITY));
				if(travelDestinations.has(PROP_STATE) && !travelDestinations.getString(PROP_STATE).equalsIgnoreCase("All"))
					calculation.put(TOSTATE, travelDestinations.getString(PROP_STATE));

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+"_"+PROP_DESTINATION+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	private static void setPLBHolidaysDestinations(JSONArray baseArr, JSONArray calcArr, JSONArray travelDestinationsArr, String commercialName) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(travelDestinations.getJSONArray(PROP_TRIGGER_PAYOUT));
				JSONArray destinatn = new JSONArray();
				JSONObject desti = new JSONObject();
				destinatn.put(triggerPayout);
				
				if(travelDestinations.has(PROP_DESTINATION) && !travelDestinations.getString(PROP_DESTINATION).equalsIgnoreCase("All"))
					desti.put(TOCONTINENT, travelDestinations.getString(PROP_DESTINATION));
				if(travelDestinations.has(PROP_COUNTRY) && !travelDestinations.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
					desti.put(TOCOUNTRY, travelDestinations.getString(PROP_COUNTRY));
				if(travelDestinations.has(PROP_CITY) && !travelDestinations.getString(PROP_CITY).equalsIgnoreCase("All"))
					desti.put(TOCITY, travelDestinations.getString(PROP_CITY));
				if(travelDestinations.has(PROP_STATE) && !travelDestinations.getString(PROP_STATE).equalsIgnoreCase("All"))
					desti.put(TOSTATE, travelDestinations.getString(PROP_STATE));

				destinatn.put(desti);
				calculation.put(PROP_TRAVELDESTINATIONS, destinatn);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+"_"+PROP_DESTINATION+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
		
	}
	
	
	public static void setOtherFeesHolidaysAdvancedDefinition(JSONObject advanceDefinitionHolidays, JSONArray otherFeeArr, String commercialName){
		if(advanceDefinitionHolidays.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionHolidays.getJSONObject(PROP_VALIDITY);
			switch(validity.getString(PROP_SALEORTRAVEL)){
			case PROP_SALES:{
				setOtherFeesDate(otherFeeArr,validity.getJSONArray(PROP_SALES),PROP_SALES);
				break;
			}
			case PROP_TRAVEL:{
				setOtherFeesDate(otherFeeArr,validity.getJSONArray(PROP_TRAVEL),PROP_TRAVEL);
				break;
			}
			default:System.out.println("default of Holidays.setHolidaysAdvancedDefinition");
			}
		}

		if(advanceDefinitionHolidays.has(PROP_TRAVELDESTINATIONS) && advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTINATIONS).length()>0)
			setOtherFeeHolidaysDestinations(otherFeeArr,advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTINATIONS),commercialName);

		if(advanceDefinitionHolidays.has(PROP_CREDENTIALS) && advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS,true);

		if(advanceDefinitionHolidays.has(PROP_NATIONALITY) && advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY), CLIENTNATIONALITY,true);

		if(advanceDefinitionHolidays.has(PROP_TOURTYPES) && advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES), PROP_TOURTYPES,true);

		if(advanceDefinitionHolidays.has(CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionHolidays.getJSONObject(CONNECTIVITY);
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					otherFee.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					otherFee.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERID));
			}
		}

		if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
			if(roomLevel.has(BOOKINGTYPE)){
				JSONObject bookingType = roomLevel.getJSONObject(BOOKINGTYPE);
				int length=otherFeeArr.length();
				for(int i=0;i<length;i++){
					JSONObject otherFee = otherFeeArr.getJSONObject(i);
					otherFee.put(BOOKINGTYPE, bookingType.getString(BOOKINGTYPE));
				}
			}	
		}

		if(advanceDefinitionHolidays.has(PAXTYPE) && advanceDefinitionHolidays.getJSONArray(PAXTYPE).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray(PAXTYPE), PAXTYPE,true);

		if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
			if(roomLevel.has(PROP_ROOMCATEGORIES) && roomLevel.getJSONArray(PROP_ROOMCATEGORIES).length()>0)
				CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,roomLevel.getJSONArray(PROP_ROOMCATEGORIES),PROP_ROOMCATEGORIES,true);

			if(roomLevel.has(PROP_ROOMTYPES) && roomLevel.getJSONArray(PROP_ROOMTYPES).length()>0)
				CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,roomLevel.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES,true);
		}
	}
	

	public static void setOtherFeeHolidaysDestinations(JSONArray otherFeeArr, JSONArray travelDestinationsArr, String commercialName) {
		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				if(travelDestinations.has(PROP_DESTINATION) && !travelDestinations.getString(PROP_DESTINATION).equalsIgnoreCase("All"))
					otherFee.put(PROP_CONTINENT, travelDestinations.getString(PROP_DESTINATION));
				if(travelDestinations.has(PROP_COUNTRY) && !travelDestinations.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
					otherFee.put(PROP_COUNTRY, travelDestinations.getString(PROP_COUNTRY));
				if(travelDestinations.has(PROP_CITY) && !travelDestinations.getString(PROP_CITY).equalsIgnoreCase("All"))
					otherFee.put(PROP_CITY, travelDestinations.getString(PROP_CITY));
				if(travelDestinations.has(PROP_STATE) && !travelDestinations.getString(PROP_STATE).equalsIgnoreCase("All"))
					otherFee.put(PROP_STATE, travelDestinations.getString(PROP_STATE));

				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+"_"+PROP_DESTINATION+i+j);
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);

		}
	}
	
	
	public static void setBudgetMarginDetails(JSONObject budgetMarginsObject){
		JSONObject holiday = budgetMarginsObject.getJSONObject(PROP_HOLIDAY);
		if(holiday.getBoolean(PROP_BOOLEAN_ISDESTINATIONLEVEL)){
			JSONObject destinationLevel = holiday.getJSONObject(PROP_DESTINATIONLEVEL);
			if(destinationLevel.has(PROP_DESTINATION) && !destinationLevel.getString(PROP_DESTINATION).equalsIgnoreCase("All"))
				destination = destinationLevel.getString(PROP_DESTINATION);
			if(destinationLevel.has(PROP_COUNTRY) && !destinationLevel.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
				country = destinationLevel.getString(PROP_COUNTRY);
			if(destinationLevel.has(PROP_CITY) && !destinationLevel.getString(PROP_CITY).equalsIgnoreCase("All"))
				city = destinationLevel.getString(PROP_CITY);
		}else{
			JSONObject productLevel = holiday.getJSONObject(PROP_PRODUCTLEVEL);
			if(productLevel.has(PROP_BROCHURENAME) && !productLevel.getString(PROP_BROCHURENAME).equalsIgnoreCase("All"))
				brochureName = productLevel.getString(PROP_BROCHURENAME);
			if(productLevel.has(PROP_FLAVOURNAME) && !productLevel.getString(PROP_FLAVOURNAME).equalsIgnoreCase("All"))
				flavourName = productLevel.getString(PROP_FLAVOURNAME);
			if(productLevel.has(PROP_PRODUCTTYPE) && !productLevel.getString(PROP_PRODUCTTYPE).equalsIgnoreCase("All"))
				productType = productLevel.getString(PROP_PRODUCTTYPE);
			if(productLevel.has(PROP_BRANDNAME) && !productLevel.getString(PROP_BRANDNAME).equalsIgnoreCase("All"))
				brandName = productLevel.getString(PROP_BRANDNAME);
			if(productLevel.has(PRODUCTNAME) && !productLevel.getString(PRODUCTNAME).equalsIgnoreCase("All"))
				productName = productLevel.getString(PRODUCTNAME);
			if(productLevel.has(PROP_FLAVOURTYPE) && !productLevel.getString(PROP_FLAVOURTYPE).equalsIgnoreCase("All"))
				flavourType = productLevel.getString(PROP_FLAVOURTYPE);
		}
	}
	
	
	public static void setBudgetedMarginDetails(JSONObject calculation) {
		calculation.put(TOCONTINENT, destination);
		calculation.put(TOCOUNTRY, country);
		calculation.put(TOCITY, city);
		calculation.put(PRODUCTFLAVORNAME, flavourName);
		calculation.put(PROP_PRODUCTTYPE, productType);
		calculation.put(PROP_BRANDNAME, brandName);
		calculation.put(PRODUCTNAME, productName);
		calculation.put(FLAVORTYPE, flavourType);
	}


	public static void setOtherFeesDate(JSONArray otherFeeArr, JSONArray dateArray, String date) {
		String from = date+FROM;
		String to = date+TO;
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArray.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject dateObject =dateArray.getJSONObject(j);
				JSONArray incArr =new JSONArray();
				JSONArray excArr =new JSONArray();
				JSONArray Date = new JSONArray();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();
				
				CommonFunctions.getDates(dateObject, incArr, from, to,new JSONObject(),Date);
				CommonFunctions.getBlockOutDates(dateObject, excArr,new JSONObject(),Date);

				if(!incArr.isNull(0)){
					inclusion.put(INCLUSION,incArr);
					Date.put(inclusion);
				}
				if(!excArr.isNull(0)){
					exclusion.put(EXCLUSION,excArr);
					Date.put(exclusion);
				}
				otherFee.put(date, Date);
				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, dateObject.getString(PROP_ID));			
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	public static void setDate(JSONArray baseArr, JSONArray calcArr, JSONArray dateArray, String date, boolean inBase) {
		String from = date+FROM;
		String to = date+TO;
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject dateObject =dateArray.getJSONObject(j);
				JSONArray incArr =new JSONArray();
				JSONArray excArr =new JSONArray();
				JSONArray Date = new JSONArray();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();

				CommonFunctions.getDates(dateObject,incArr,from,to,new JSONObject(),Date);
				CommonFunctions.getBlockOutDates(dateObject,excArr,new JSONObject(),Date);

				if(!incArr.isNull(0)){
					inclusion.put(INCLUSION,incArr);
					Date.put(inclusion);
				}
				if(!excArr.isNull(0)){
					exclusion.put(EXCLUSION,excArr);
					Date.put(exclusion);
				}

				if(inBase)
					base.put(date, Date);
				else calculation.put(date, Date);

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, dateObject.getString(PROP_ID));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getPLBDates(JSONArray baseArr, JSONArray calcArr, JSONArray dateArr, String date, boolean inBase, String commercialName) {
		String from = date+FROM;
		String to = date+TO;
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArr.length();j++){
				JSONObject dateObject = dateArr.getJSONObject(j);
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();
				JSONArray DateInclusionArr = new JSONArray();
				JSONArray DateExclusionArr = new JSONArray();
				JSONArray mainDateArray = new JSONArray();
				
				JSONObject trigPayout = CommonFunctions.getTriggerPayoutObject(dateObject.getJSONArray(PROP_TRIGGER_PAYOUT));
				mainDateArray.put(trigPayout);
				
				CommonFunctions.getDates(dateObject, DateInclusionArr, from, to,trigPayout,mainDateArray);
				CommonFunctions.getBlockOutDates(dateObject, DateExclusionArr,trigPayout,mainDateArray);

				if(!DateInclusionArr.isNull(0)){
					inclusion.put(INCLUSION, DateInclusionArr);
					mainDateArray.put(inclusion);
				}
				if(!DateExclusionArr.isNull(0)){
					exclusion.put(EXCLUSION, DateExclusionArr);
					mainDateArray.put(exclusion);
				}

				if(inBase)
					base.put(date, mainDateArray);
				else calculation.put(date, mainDateArray);
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+date+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
}
