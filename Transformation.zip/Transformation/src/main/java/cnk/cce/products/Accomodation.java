package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.configuration.CommonFunctions;
import cnk.cce.configuration.Constants;

public class Accomodation implements Constants {
	public static JSONArray advancedArr = new JSONArray();
	public static JSONArray calcArr = new JSONArray();

	public static void appendPLBAccomodationCommercialsDetails(JSONObject advanced, JSONObject calculation, JSONObject advanceDefinitionAccommodationPLB, String commercialName) {
		advancedArr.put(advanced);
		calcArr.put(calculation);
		if(advanceDefinitionAccommodationPLB.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionAccommodationPLB.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				JSONArray salePlusTravel = validity.getJSONArray(PROP_SALEPLUSTRAVEL);
				CommonFunctions.insertSalePlusTravel(salePlusTravel,advancedArr,calcArr,true,true,commercialName);
			}
		}

		if(advanceDefinitionAccommodationPLB.has(PROP_NATIONALITY) && advanceDefinitionAccommodationPLB.getJSONArray(PROP_NATIONALITY).length()>0)
			CommonFunctions.getTriggerPayoutArray(advancedArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray(PROP_NATIONALITY),CLIENTNATIONALITY,true,commercialName);

		if(advanceDefinitionAccommodationPLB.has(PAXTYPES) && advanceDefinitionAccommodationPLB.getJSONArray(PAXTYPES).length()>0)
			CommonFunctions.getTriggerPayoutArray(advancedArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray(PAXTYPES),PAXTYPES,false,commercialName);

		if(advanceDefinitionAccommodationPLB.has(PROP_CREDENTIALS) && advanceDefinitionAccommodationPLB.getJSONArray(PROP_CREDENTIALS).length()>0)
			CommonFunctions.getTriggerPayoutArray(advancedArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray(PROP_CREDENTIALS),PROP_CREDENTIALSID,true,commercialName);

		if(advanceDefinitionAccommodationPLB.has(CONNECTIVITY))
			CommonFunctions.getConnectivityTP(advancedArr,advanceDefinitionAccommodationPLB.getJSONObject(CONNECTIVITY));

		if(advanceDefinitionAccommodationPLB.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionAccommodationPLB.getJSONObject(PROP_OTHERS);
			if(others.has(BOOKINGTYPE)){
				if(others.getBoolean(PROP_BOOLEAN_ISINCLUSION))
					CommonFunctions.getBookingTypeTP(advancedArr,others.getJSONObject(BOOKINGTYPE),true);
				else CommonFunctions.getBookingTypeTP(advancedArr,others.getJSONObject(BOOKINGTYPE),false);
			}

			if(others.has(PROP_ROOMTYPES) && others.getJSONArray(PROP_ROOMTYPES).length()>0){
				if(others.has(PROP_BOOLEAN_ISINCLUSION)){
					if(others.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr,calcArr,others.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES,true,false,commercialName);
					else CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr,calcArr,others.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES,false,false,commercialName);
				}
			}

			if(others.has(PROP_ROOMCATEGORIES) && others.getJSONArray(PROP_ROOMCATEGORIES).length()>0){
				if(others.has(PROP_BOOLEAN_ISINCLUSION)){
					if(others.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr,calcArr,others.getJSONArray(PROP_ROOMCATEGORIES),ROOMCATEGORY,true,false,commercialName);
					else CommonFunctions.getTriggerPayoutArrayIncExc(advancedArr,calcArr,others.getJSONArray(PROP_ROOMCATEGORIES),ROOMCATEGORY,false,false,commercialName);
				}
			}
		}

		if(advanceDefinitionAccommodationPLB.has(PROP_TRAVELDESTINATION)){
			JSONObject travelDestination = advanceDefinitionAccommodationPLB.getJSONObject(PROP_TRAVELDESTINATION);
			if(travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
				if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
					if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						CommonFunctions.getDestinationTP(advancedArr,calcArr,travelDestination.getJSONArray(PROP_DESTINATIONS),true,true,commercialName);
					else CommonFunctions.getDestinationTP(advancedArr,calcArr,travelDestination.getJSONArray(PROP_DESTINATIONS),false,true,commercialName);
				}
			}
		}
	}


	public static void appendAccomodationAdvancedDefinition(JSONObject base, JSONObject calculation, JSONObject advanceDefinitionAccommodation, String commercialName) {
		if(advanceDefinitionAccommodation.has(PROP_NATIONALITY)){
			JSONObject nationality = advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY);
			if(nationality.getJSONArray(CLIENTNATIONALITY).length()>0 && !nationality.getJSONArray(CLIENTNATIONALITY).getString(0).equalsIgnoreCase("All")){
				if(nationality.getBoolean(PROP_BOOLEAN_ISINCLUSION))
					base.put(CLIENTNATIONALITY, nationality.get(CLIENTNATIONALITY));
				else base.put(CLIENTNATIONALITY+"_"+EXCLUSION, nationality.get(CLIENTNATIONALITY));
			}
		}
		if(advanceDefinitionAccommodation.has(PAXTYPES) && advanceDefinitionAccommodation.getJSONArray(PAXTYPES).length()>0){
			if(!advanceDefinitionAccommodation.getJSONArray(PAXTYPES).getString(0).equalsIgnoreCase("All"))
				calculation.put(PAXTYPE, advanceDefinitionAccommodation.getJSONArray(PAXTYPES));
		}
		if(advanceDefinitionAccommodation.has(PROP_CREDENTIALS) && advanceDefinitionAccommodation.getJSONArray(PROP_CREDENTIALS).length()>0){
			JSONArray credentials = advanceDefinitionAccommodation.getJSONArray(PROP_CREDENTIALS);
			JSONArray credentialName = new JSONArray();
			for(int c=0;c<credentials.length();c++){
				credentialName.put(credentials.getJSONObject(c).getString(PROP_CREDENTIALSID));
			}
			if(credentialName.length()>0)
				base.put(CREDENTIALSNAME, credentialName);
		}
		if(advanceDefinitionAccommodation.has(CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionAccommodation.getJSONObject(CONNECTIVITY);
			if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
				base.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
			if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
				base.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERID));
		}
		if(advanceDefinitionAccommodation.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS);
			if(others.has(BOOKINGTYPE) && !others.getString(BOOKINGTYPE).equalsIgnoreCase("All"))
				base.put(BOOKINGTYPE,others.getString(BOOKINGTYPE));
			if(others.has(PROP_ROOMTYPES)){
				JSONObject roomTypes = others.getJSONObject(PROP_ROOMTYPES);
				if(roomTypes.getJSONArray(PROP_ROOMTYPES).length()>0 && !roomTypes.getJSONArray(PROP_ROOMTYPES).getString(0).equalsIgnoreCase("All"))
					if(roomTypes.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						calculation.put(ROOMTYPE, roomTypes.getJSONArray(PROP_ROOMTYPES));
					else calculation.put(ROOMTYPE+"_"+EXCLUSION, roomTypes.getJSONArray(PROP_ROOMTYPES));
			}
			if(others.has(PROP_ROOMCATEGORIES)){
				JSONObject roomCategories = others.getJSONObject(PROP_ROOMCATEGORIES);
				if(roomCategories.getJSONArray(PROP_ROOMCATEGORIES).length()>0 && !roomCategories.getJSONArray(PROP_ROOMCATEGORIES).getString(0).equalsIgnoreCase("All"))
					if(roomCategories.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						calculation.put(ROOMCATEGORY, roomCategories.getJSONArray(PROP_ROOMCATEGORIES));
					else calculation.put(ROOMCATEGORY+"_"+EXCLUSION, roomCategories.getJSONArray(PROP_ROOMCATEGORIES));
			}
		}

		advancedArr.put(base);
		calcArr.put(calculation);
		if(advanceDefinitionAccommodation.has(PROP_TRAVELDESTINATION)){
			JSONObject travelDestination = advanceDefinitionAccommodation.getJSONObject(PROP_TRAVELDESTINATION);
			JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
			CommonFunctions.getDestination(advancedArr, calcArr, destinations, travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION), true, commercialName);
		}

		if(advanceDefinitionAccommodation.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionAccommodation.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				JSONArray salePlusTravel = validity.getJSONArray(PROP_SALEPLUSTRAVEL);
				CommonFunctions.insertSalePlusTravel(advancedArr,calcArr,salePlusTravel,true,true,commercialName);
			}
		}
	}


	public static void appendAccomodationOtherFeesAdvDefn(JSONObject advanceDefinitionAccommodation, JSONArray otherFeeArr, JSONObject mdmCommDefn, JSONObject jsonObject, String id, int _id, String commercialName){
		for(int g=0;g<mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).length();){
			JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).getJSONObject(g);
			JSONObject otherFees = clientCommercialOtherHead.getJSONObject(PROP_COMMHEADS).getJSONObject(PROP_OTHERFEES);

			if(advanceDefinitionAccommodation.has(PROP_TRAVELDESTINATION)){
				JSONArray destinationArray = advanceDefinitionAccommodation.getJSONObject(PROP_TRAVELDESTINATION).getJSONArray(PROP_DESTINATIONS);
				for(int i=0;i<destinationArray.length();i++){
					JSONObject otherFee = new JSONObject();
					JSONObject destinationObj = destinationArray.getJSONObject(i);
					otherFee.put(RULEID, commercialName+_id+i);
					otherFee.put(SELECTEDROW, id);
					otherFee.put(TYPE, TYPE_OTHERFEE);
					//JSONObject mdmOtherFees = mdmCommDefn.getJSONObject(PROP_OTHERFEES).getJSONObject(PROP_OTHERFEES);
					//otherFee.put(CONTRACTVALIDITY, getContractValidity(jsonObject));
					//applyOn(mdmOtherFees,otherFee);
					//SettlementCommercials.appliedOnOtherFees(otherFees,otherFee);

					if(otherFees.has(PROP_PERCENT) && otherFees.getJSONArray(PROP_PERCENT).length()>0){
						JSONArray percent = otherFees.getJSONArray(PROP_PERCENT);
						JSONArray percentageArr = new JSONArray();
						for(int j=0;j<percent.length();j++){
							JSONObject percentObject = percent.getJSONObject(j);
							JSONObject json = new JSONObject();
							if(percentObject.has(PROP_COMMERCIALHEAD))
								json.put(COMMNAME, percentObject.getString(PROP_COMMERCIALHEAD));
							if(percentObject.has(PROP_PERCENTAGE) && !percentObject.get(PROP_PERCENTAGE).equals(0))
								json.put(COMMPERCENTAGE, percentObject.get(PROP_PERCENTAGE).toString());
							percentageArr.put(json);
						}
						otherFee.put(PROP_PERCENTAGE,percentageArr);
					}

					if(otherFees.has(PROP_FIXED)){
						JSONObject fixed = otherFees.getJSONObject(PROP_FIXED);
						otherFee.put(COMM_AMOUNT, fixed.get(VALUE).toString());
						otherFee.put(COMM_CURRENCY, fixed.getString(PROP_CURRENCY));
					}
					if(advanceDefinitionAccommodation.getJSONObject(PROP_TRAVELDESTINATION).getBoolean(PROP_BOOLEAN_ISINCLUSION)){
						if(destinationObj.has(PROP_CONTINENT) && !destinationObj.getString(PROP_CONTINENT).equalsIgnoreCase("All"))
							otherFee.put(TO_CONTINENT, destinationObj.getString(PROP_CONTINENT));
						if(destinationObj.has(PROP_COUNTRY) && !destinationObj.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
							otherFee.put(TO_COUNTRY,destinationObj.getString(PROP_COUNTRY));
						if(destinationObj.has(PROP_STATE) && !destinationObj.getString(PROP_STATE).equalsIgnoreCase("All"))
							otherFee.put(TO_STATE,destinationObj.getString(PROP_STATE));
						if(destinationObj.has(PROP_CITY) && !destinationObj.getString(PROP_CITY).equalsIgnoreCase("All"))
							otherFee.put(TO_CITY,destinationObj.getString(PROP_CITY));
					}else{
						if(destinationObj.has(PROP_CONTINENT) && !destinationObj.getString(PROP_CONTINENT).equalsIgnoreCase("All"))
							otherFee.put(TO_CONTINENT+"_"+EXCLUSION, destinationObj.getString(PROP_CONTINENT));
						if(destinationObj.has(PROP_COUNTRY) && !destinationObj.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
							otherFee.put(TO_COUNTRY+"_"+EXCLUSION,destinationObj.getString(PROP_COUNTRY));
						if(destinationObj.has(PROP_STATE) && !destinationObj.getString(PROP_STATE).equalsIgnoreCase("All"))
							otherFee.put(TO_STATE+"_"+EXCLUSION,destinationObj.getString(PROP_STATE));
						if(destinationObj.has(PROP_CITY) && !destinationObj.getString(PROP_CITY).equalsIgnoreCase("All"))
							otherFee.put(TO_CITY+"_"+EXCLUSION,destinationObj.getString(PROP_CITY));
					}
					setOtherFeesAccoAdvancedDefinition(advanceDefinitionAccommodation,otherFee);
					otherFeeArr.put(otherFee);
				}
				if(advanceDefinitionAccommodation.has(PROP_VALIDITY))
					switch(advanceDefinitionAccommodation.getJSONObject(PROP_VALIDITY).getString(PROP_VALIDITYTYPE)){
					case PROP_SALE:{
						JSONArray sale = advanceDefinitionAccommodation.getJSONObject(PROP_VALIDITY).getJSONArray(PROP_SALE);
						getTransportationSalesDate(sale,otherFeeArr,commercialName);
						break;
					}
					case PROP_TRAVEL:{
						JSONArray travel = advanceDefinitionAccommodation.getJSONObject(PROP_VALIDITY).getJSONArray(PROP_TRAVEL);
						getTransportationTravelDate(travel,otherFeeArr,commercialName);
						break;
					}
					default:{
						JSONArray salePlusTravel = advanceDefinitionAccommodation.getJSONObject(PROP_VALIDITY).getJSONArray(PROP_SALEPLUSTRAVEL);
						int length = otherFeeArr.length();
						for(int i=0;i<length;i++){
							for(int x=0;x<salePlusTravel.length();x++){
								JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
								JSONObject salePlusTravelObj = salePlusTravel.getJSONObject(x);
								JSONArray saleArr = new JSONArray();
								JSONArray salesinclusionArr = new JSONArray();
								JSONArray salesexclusionArr = new JSONArray();
								JSONObject salesinclusionObject = new JSONObject();
								JSONObject salesexclusionObject = new JSONObject();
								JSONObject saleInclusionIndiObj = new JSONObject();
								JSONObject travelInclusionIndiObj = new JSONObject();
								JSONObject saleExclusionIndiObj = new JSONObject();
								JSONObject travelExclusionIndiObj = new JSONObject();
								JSONObject inclusionObject = new JSONObject();
								JSONObject exclusionObject = new JSONObject();
								JSONArray travelArr = new JSONArray();
								JSONArray travelinclusionArr = new JSONArray();
								JSONArray travelexclusionArr = new JSONArray();
								JSONObject saleObj = salePlusTravelObj.getJSONObject(PROP_SALES);
								JSONObject travelObj = salePlusTravelObj.getJSONObject(PROP_TRAVEL);

								if(saleObj.has(PROP_SALEFROM)){
									if(saleObj.has(PROP_SALETO)){
										saleInclusionIndiObj.put(OPERATOR, BETWEEN);
										saleInclusionIndiObj.put(PROP_FROM, saleObj.get(PROP_SALEFROM).toString().substring(0, 19));
										saleInclusionIndiObj.put(PROP_TO, saleObj.get(PROP_SALETO).toString().substring(0, 19));
										salesinclusionArr.put(saleInclusionIndiObj);
									}else if(saleObj.has(PROP_SALEFROM)){
										saleInclusionIndiObj.put(OPERATOR, GREATERTHANEQUALTO);
										saleInclusionIndiObj.put(PROP_FROM, saleObj.get(PROP_SALEFROM).toString().substring(0, 19));
										salesinclusionArr.put(saleInclusionIndiObj);
									}
								}else if(saleObj.has(PROP_SALETO)){
									saleInclusionIndiObj.put(OPERATOR, LESSTHANEQUALTO);
									saleInclusionIndiObj.put(PROP_TO, saleObj.get(PROP_SALETO).toString().substring(0, 19));
									salesinclusionArr.put(saleInclusionIndiObj);

								}
								if(saleObj.has(PROP_BLOCKOUT_FROM)){
									if(saleObj.has(PROP_BLOCKOUT_TO)){
										saleExclusionIndiObj.put(OPERATOR, BETWEEN);
										saleExclusionIndiObj.put(PROP_FROM, saleObj.get(PROP_BLOCKOUT_FROM).toString().substring(0, 19));
										saleExclusionIndiObj.put(PROP_TO, saleObj.get(PROP_BLOCKOUT_TO).toString().substring(0, 19));
										salesexclusionArr.put(saleExclusionIndiObj);
									}else{
										saleExclusionIndiObj.put(OPERATOR, GREATERTHANEQUALTO);
										saleExclusionIndiObj.put(PROP_FROM, saleObj.get(PROP_BLOCKOUT_FROM).toString().substring(0, 19));
										salesexclusionArr.put(saleExclusionIndiObj);
									}
								}else if(saleObj.has(PROP_BLOCKOUT_TO)){
									saleExclusionIndiObj.put(OPERATOR, LESSTHANEQUALTO);
									saleExclusionIndiObj.put(PROP_TO, saleObj.get(PROP_BLOCKOUT_TO).toString().substring(0, 19));
									salesexclusionArr.put(saleExclusionIndiObj);

								}

								if(salesinclusionArr.length()>0){
									salesinclusionObject.put(INCLUSION,salesinclusionArr);
									saleArr.put(salesinclusionObject);
								}
								if(salesexclusionArr.length()>0){
									salesexclusionObject.put(EXCLUSION,salesexclusionArr);
									saleArr.put(salesexclusionObject);
								}

								if(travelObj.has(PROP_TRAVELFROM)){
									if(travelObj.has(PROP_TRAVELTO)){
										travelInclusionIndiObj.put(OPERATOR, BETWEEN);
										travelInclusionIndiObj.put(PROP_FROM, travelObj.get(PROP_TRAVELFROM).toString().substring(0, 19));
										travelInclusionIndiObj.put(PROP_TO, travelObj.get(PROP_TRAVELTO).toString().substring(0, 19));
										travelinclusionArr.put(travelInclusionIndiObj);
									}else{
										travelInclusionIndiObj.put(OPERATOR, GREATERTHANEQUALTO);
										travelInclusionIndiObj.put(PROP_FROM, travelObj.get(PROP_TRAVELFROM).toString().substring(0, 19));
										travelinclusionArr.put(travelInclusionIndiObj);
									}
								}else if(travelObj.has(PROP_TRAVELTO)){
									travelInclusionIndiObj.put(OPERATOR, LESSTHANEQUALTO);
									travelInclusionIndiObj.put(PROP_TO, travelObj.get(PROP_TRAVELTO).toString().substring(0, 19));
									travelinclusionArr.put(travelInclusionIndiObj);

								}
								if(travelObj.has(PROP_BLOCKOUT_FROM)){
									if(travelObj.has(PROP_BLOCKOUT_TO)){
										travelExclusionIndiObj.put(OPERATOR, BETWEEN);
										travelExclusionIndiObj.put(PROP_FROM, travelObj.get(PROP_BLOCKOUT_FROM).toString().substring(0, 19));
										travelExclusionIndiObj.put(PROP_TO, travelObj.get(PROP_BLOCKOUT_TO).toString().substring(0, 19));
										travelinclusionArr.put(travelExclusionIndiObj);
									}else{
										travelExclusionIndiObj.put(OPERATOR, GREATERTHANEQUALTO);
										travelExclusionIndiObj.put(PROP_FROM, travelObj.get(PROP_BLOCKOUT_FROM).toString().substring(0, 19));
										travelinclusionArr.put(travelExclusionIndiObj);
									}
								}else if(travelObj.has(PROP_BLOCKOUT_TO)){
									travelExclusionIndiObj.put(OPERATOR, LESSTHANEQUALTO);
									travelExclusionIndiObj.put(PROP_TO, travelObj.get(PROP_BLOCKOUT_TO).toString().substring(0, 19));
									travelinclusionArr.put(travelExclusionIndiObj);

								}

								if(travelinclusionArr.length()>0){
									inclusionObject.put(INCLUSION,travelinclusionArr);
									travelArr.put(inclusionObject);
								}
								if(travelexclusionArr.length()>0){
									exclusionObject.put(EXCLUSION,travelexclusionArr);
									travelArr.put(exclusionObject);
								}

								String RuleID = otherFee.getString(RULEID)+commercialName+"_"+PROP_SALEPLUSTRAVEL+i+x;
								otherFee.put(RULEID, RuleID);
								otherFee.put(PROP_SALE, saleArr);
								otherFee.put(PROP_TRAVEL, travelArr);
								otherFeeArr.put(otherFee);
							}
						}
						for(int i=0;i<length;i++){
							otherFeeArr.remove(0);
						}
					}
					}
			}
			break;
		}
	}


	public static void getTransportationTravelDate(JSONArray travel, JSONArray otherFeeArr, String commercialName) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travel.length();j++){
				JSONObject inclusionIndiObjMDM =travel.getJSONObject(j);
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONArray inclusionArr = new JSONArray();
				JSONArray exclusionArr = new JSONArray();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray travelArr = new JSONArray();
				JSONObject inclusionIndiObj = new JSONObject();
				JSONObject exclusionIndiObj = new JSONObject();

				if(inclusionIndiObjMDM.has(PROP_TRAVELFROM)){
					if(inclusionIndiObjMDM.has(PROP_TRAVELTO)){
						inclusionIndiObj.put(OPERATOR, BETWEEN);
						inclusionIndiObj.put(PROP_FROM, inclusionIndiObjMDM.get(PROP_TRAVELFROM).toString().substring(0, 19));
						inclusionIndiObj.put(PROP_TO, inclusionIndiObjMDM.get(PROP_TRAVELTO).toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}else{
						inclusionIndiObj.put(OPERATOR, GREATERTHANEQUALTO);
						inclusionIndiObj.put(VALUE, inclusionIndiObjMDM.get(PROP_TRAVELFROM).toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has(PROP_TRAVELTO)){
					inclusionIndiObj.put(OPERATOR, LESSTHANEQUALTO);
					inclusionIndiObj.put(VALUE, inclusionIndiObjMDM.get(PROP_TRAVELTO).toString().substring(0, 19));
					inclusionArr.put(inclusionIndiObj);
				}

				if(inclusionIndiObjMDM.has(PROP_BLOCKOUT_FROM)){
					if(inclusionIndiObjMDM.has(PROP_BLOCKOUT_TO)){
						exclusionIndiObj.put(OPERATOR, BETWEEN);
						exclusionIndiObj.put(PROP_FROM, inclusionIndiObjMDM.get(PROP_BLOCKOUT_FROM).toString().substring(0, 19));
						exclusionIndiObj.put(PROP_TO, inclusionIndiObjMDM.get(PROP_BLOCKOUT_TO).toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}else{
						exclusionIndiObj.put(OPERATOR, GREATERTHANEQUALTO);
						exclusionIndiObj.put(VALUE, inclusionIndiObjMDM.get(PROP_BLOCKOUT_FROM).toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has(PROP_BLOCKOUT_TO)){
					exclusionIndiObj.put(OPERATOR, LESSTHANEQUALTO);
					exclusionIndiObj.put(VALUE, inclusionIndiObjMDM.get(PROP_BLOCKOUT_TO).toString().substring(0, 19));
					exclusionArr.put(exclusionIndiObj);
				}

				if(inclusionArr.length()>0){
					inclusionObject.put(INCLUSION,inclusionArr);
					travelArr.put(inclusionObject);
				}
				if(exclusionArr.length()>0){
					exclusionObject.put(EXCLUSION,exclusionArr);
					travelArr.put(exclusionObject);
				}

				String RuleID = otherFee.getString(RULEID)+commercialName+"_"+PROP_TRAVEL+i+j;
				otherFee.put(RULEID, RuleID);
				otherFee.put(PROP_TRAVEL, travelArr);
				otherFeeArr.put(otherFee);
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}


	public static void getTransportationSalesDate(JSONArray sale,JSONArray otherFeeArr, String commercialName){
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<sale.length();j++){
				JSONObject inclusionIndiObjMDM =sale.getJSONObject(j);
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONArray inclusionArr = new JSONArray();
				JSONArray exclusionArr = new JSONArray();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray saleArr = new JSONArray();
				JSONObject inclusionIndiObj = new JSONObject();
				JSONObject exclusionIndiObj = new JSONObject();
				if(inclusionIndiObjMDM.has(PROP_SALEFROM)){
					if(inclusionIndiObjMDM.has(PROP_SALETO)){
						inclusionIndiObj.put(OPERATOR, BETWEEN);
						inclusionIndiObj.put(PROP_FROM, inclusionIndiObjMDM.get(PROP_SALEFROM).toString().substring(0, 19));
						inclusionIndiObj.put(PROP_TO, inclusionIndiObjMDM.get(PROP_SALETO).toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}else{
						inclusionIndiObj.put(OPERATOR, GREATERTHANEQUALTO);
						inclusionIndiObj.put(VALUE, inclusionIndiObjMDM.get(PROP_SALEFROM).toString().substring(0, 19));
						inclusionArr.put(inclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has(PROP_SALETO)){
					inclusionIndiObj.put(OPERATOR, LESSTHANEQUALTO);
					inclusionIndiObj.put(VALUE, inclusionIndiObjMDM.get(PROP_SALETO).toString().substring(0, 19));
					inclusionArr.put(inclusionIndiObj);
				}

				if(inclusionIndiObjMDM.has(PROP_BLOCKOUT_FROM)){
					if(inclusionIndiObjMDM.has(PROP_BLOCKOUT_TO)){
						exclusionIndiObj.put(OPERATOR, BETWEEN);
						exclusionIndiObj.put(PROP_FROM, inclusionIndiObjMDM.get(PROP_BLOCKOUT_FROM).toString().substring(0, 19));
						exclusionIndiObj.put(PROP_TO, inclusionIndiObjMDM.get(PROP_BLOCKOUT_TO).toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}else{
						exclusionIndiObj.put(OPERATOR, GREATERTHANEQUALTO);
						exclusionIndiObj.put(VALUE, inclusionIndiObjMDM.get(PROP_BLOCKOUT_FROM).toString().substring(0, 19));
						exclusionArr.put(exclusionIndiObj);
					}
				}else if(inclusionIndiObjMDM.has(PROP_BLOCKOUT_TO)){
					exclusionIndiObj.put(OPERATOR, LESSTHANEQUALTO);
					exclusionIndiObj.put(VALUE, inclusionIndiObjMDM.get(PROP_BLOCKOUT_TO).toString().substring(0, 19));
					exclusionArr.put(exclusionIndiObj);
				}

				if(inclusionArr.length()>0){
					inclusionObject.put(INCLUSION,inclusionArr);
					saleArr.put(inclusionObject);
				}
				if(exclusionArr.length()>0){
					exclusionObject.put(EXCLUSION,exclusionArr);
					saleArr.put(exclusionObject);
				}

				String RuleID = otherFee.getString(RULEID)+commercialName+"_"+PROP_SALE+i+j;
				otherFee.put(RULEID, RuleID);
				otherFee.put(PROP_SALE, saleArr);
				otherFeeArr.put(otherFee);
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}


	private static void setOtherFeesAccoAdvancedDefinition(JSONObject advanceDefinitionAccommodation, JSONObject otherFee) {
		if(advanceDefinitionAccommodation.has(PROP_NATIONALITY)){
			if(advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).getBoolean(PROP_BOOLEAN_ISINCLUSION))
				otherFee.put(CLIENTNATIONALITY, advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).get(CLIENTNATIONALITY));
			else otherFee.put(CLIENTNATIONALITY+"_"+EXCLUSION, advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).get(CLIENTNATIONALITY));
		}
		if(advanceDefinitionAccommodation.has(PAXTYPES) && advanceDefinitionAccommodation.getJSONArray(PAXTYPES).length()>0)
			otherFee.put(PAXTYPE, advanceDefinitionAccommodation.getJSONArray(PAXTYPES));
		if(advanceDefinitionAccommodation.has(PROP_CREDENTIALS) && advanceDefinitionAccommodation.getJSONArray(PROP_CREDENTIALS).length()>0)
			otherFee.put(CREDENTIALSNAME, advanceDefinitionAccommodation.getJSONArray(PROP_CREDENTIALS));
		if(advanceDefinitionAccommodation.has(CONNECTIVITY)){
			otherFee.put(CONNECTIVITYSUPPTYPE,advanceDefinitionAccommodation.getJSONObject(CONNECTIVITY).getString(PROP_SUPPLIERTYPE));
			otherFee.put(CONNECTIVITYSUPPNAME,advanceDefinitionAccommodation.getJSONObject(CONNECTIVITY).getString(PROP_SUPPLIERID));
		}
		if(advanceDefinitionAccommodation.has(PROP_OTHERS)){
			if(advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).has(BOOKINGTYPE))
				otherFee.put(BOOKINGTYPE,advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).getString(BOOKINGTYPE));
			if(advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).has(PROP_ROOMTYPES)){
				if(advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).getJSONObject(PROP_ROOMTYPES).getBoolean(PROP_BOOLEAN_ISINCLUSION))
					otherFee.put(ROOMTYPE, advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).getJSONObject(PROP_ROOMTYPES).get(PROP_ROOMTYPES));
				else otherFee.put(ROOMTYPE+"_"+EXCLUSION, advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).getJSONObject(PROP_ROOMTYPES).get(PROP_ROOMTYPES));
			}
			if(advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).has(PROP_ROOMCATEGORIES)){
				if(advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).getJSONObject(PROP_ROOMCATEGORIES).getBoolean(PROP_BOOLEAN_ISINCLUSION))
					otherFee.put(ROOMCATEGORY, advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).getJSONObject(PROP_ROOMCATEGORIES).get(PROP_ROOMCATEGORIES));
				else otherFee.put(ROOMCATEGORY+"_"+EXCLUSION, advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS).getJSONObject(PROP_ROOMCATEGORIES).get(PROP_ROOMCATEGORIES));
			}
		}
	}


}
