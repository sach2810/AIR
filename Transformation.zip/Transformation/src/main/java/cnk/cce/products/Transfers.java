package cnk.cce.products;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.cce.configuration.CommonFunctions;
import cnk.cce.configuration.Constants;

public class Transfers implements Constants {
	public static JSONArray advancedArr = new JSONArray();
	public static JSONArray calcArr = new JSONArray();
	
	public static void appendTransportationAdvancedDefinition(JSONObject advanced, JSONObject calculation, JSONObject advanceDefinitionTransportation, String advDefnID, String commercialName) {
		CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation, advanced, calculation,commercialName,true,true);
		if(advanceDefinitionTransportation.getBoolean(PROP_BOOLEAN_ISPREPAID))
			calculation.put(MODEOFPAYMENT, MOP_PREPAID);
		else calculation.put(MODEOFPAYMENT, MOP_POSTPAID);
		
		advancedArr.put(advanced);
		calcArr.put(calculation);
		appendVehicleDetails(advancedArr,calcArr,advanceDefinitionTransportation,commercialName);
	}
	
	
	private static void appendVehicleDetails(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionTransportation, String commercialName) {
		if(advanceDefinitionTransportation.has(PROP_VEHICLEDETAILS)){
			JSONObject vehicleDetails = advanceDefinitionTransportation.getJSONObject(PROP_VEHICLEDETAILS);
			if(vehicleDetails.has(PROP_VEHICLES) && vehicleDetails.getJSONArray(PROP_VEHICLES).length()>0){
				JSONArray vehicles = vehicleDetails.getJSONArray(PROP_VEHICLES);
				int length= advancedArr.length();
				for(int i=0;i<length;i++){
					for(int j=0;j<vehicles.length();j++){
						JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
						JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
						JSONObject vehicle = vehicles.getJSONObject(j);
						if(vehicleDetails.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
							/*if(vehicle.has(PROP_SIPPACRISSCODE))
								calculation.put(PROP_SIPPACRISSCODE, vehicle.getString(PROP_SIPPACRISSCODE));*/
							if(vehicle.has(PROP_VEHICLECATEGORY))
								calculation.put(PROP_VEHICLECATEGORY, vehicle.getString(PROP_VEHICLECATEGORY));
							if(vehicle.has(PROP_VEHICLENAME))
								calculation.put(PROP_VEHICLENAME, vehicle.getString(PROP_VEHICLENAME));
						}else{
							/*if(vehicle.has(PROP_SIPPACRISSCODE))
								calculation.put(PROP_SIPPACRISSCODE+"_"+EXCLUSION, vehicle.getString(PROP_SIPPACRISSCODE));*/
							if(vehicle.has(PROP_VEHICLECATEGORY))
								calculation.put(PROP_VEHICLECATEGORY+"_"+EXCLUSION, vehicle.getString(PROP_VEHICLECATEGORY));
							if(vehicle.has(PROP_VEHICLENAME))
								calculation.put(PROP_VEHICLENAME+"_"+EXCLUSION, vehicle.getString(PROP_VEHICLENAME));
						}
						CommonFunctions.setRuleID(advancedArr, calcArr, base, calculation, commercialName+"_"+PROP_VEHICLES+i+j);
					}
				}
				for(int i=0;i<length;i++){
					advancedArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
	}
}
