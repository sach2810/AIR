package cnk.cce.products;

public class Insurance {
	
}
