package cnk.cce.products;

import cnk.cce.configuration.Constants;

public class Cruise implements Constants {
	//cruise details?
}
