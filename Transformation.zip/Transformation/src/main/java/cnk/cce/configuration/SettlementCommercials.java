package cnk.cce.configuration;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.products.Accomodation;
import cnk.cce.products.Activities;
import cnk.cce.products.Air;
import cnk.cce.products.Holidays;

public class SettlementCommercials implements Constants{
	public static JSONObject main = new JSONObject();
	public static String entityType;

	public static String settlementCommercials(String commercialType, String productName, JSONObject mdmCommDefn, JSONObject jsonObject, String entityName, JSONArray entityMarket, String entityType, String supplier, String selectedRow,String productCategory, String productCategorySubType, int index, String mainScreenID) throws Exception {
		String value=SettlementCommercials.entityType;
		String commercialName=CommonFunctions.getCommercialName(jsonObject.get(PROP_COMMERCIALHEAD).toString());
		JSONObject mainJson = new JSONObject();
		if(!main.toString().equals("{}") && !main.isNull(DTNAME_COMMDEFN) && main.has(DTNAME_COMMDEFN)){
			//indicates that values already inserted once in it
			mainJson=new JSONObject(new JSONTokener(main.toString()));
			JSONArray commercialHeadArr = mainJson.getJSONObject(DTNAME_COMMDEFN).getJSONArray(PROP_COMMERCIALHEAD);
			JSONObject comm = new JSONObject();
			comm.put(COMMHEADNAME, commercialName);
			comm.put(COMMTYPE, commercialType);
			comm.put(CONTRACTTYPE, FINAL);		//if in case we get contractType, we can insert here
			comm.put(BOOLEAN_ISAPPLICABLE, true);
			commercialHeadArr.put(comm);
		}else{
			JSONObject commJson = new JSONObject();
			commJson.put(RULEID, selectedRow);
			commJson.put(TYPE, TYPE_DEFN);
			commJson.put(SUPPLIER, supplier);
			commJson.put(COMMERCIAL_ID, mainScreenID+"_"+TYPE_OTHERFEE+"_");
			commJson.put(KEY, mainScreenID);
			appendProductCategoryAndSubType(commJson, productName, productCategory, productCategorySubType);
			commJson.put(ENTITYNAME, entityName);
			if(entityMarket.length()>0)
				commJson.put(PROP_ENTITYMARKET, entityMarket);
			JSONArray commercialHeadArr = new JSONArray();
			JSONObject comm = new JSONObject();
			comm.put(COMMHEADNAME, commercialName);
			comm.put(COMMTYPE, commercialType);
			comm.put(CONTRACTTYPE, FINAL);		//if in case we get contractType, we can insert here
			comm.put(BOOLEAN_ISAPPLICABLE, true);
			commercialHeadArr.put(comm);
			commJson.put(PROP_COMMERCIALHEAD, commercialHeadArr);

			mainJson.put(DTNAME_COMMDEFN, commJson);
		}

		switch(jsonObject.get(PROP_COMMERCIALHEAD).toString()){
		case PROP_MAINTENANCEFEES:{
			otherFees(DTNAME_MAINTENANCEFEE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_INTEGRATIONFEES:{
			otherFees(DTNAME_INTEGRATIONFEE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_LICENCEFEES:{
			otherFees(DTNAME_LICENCEFFE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_WEBSERVICEFEES:{
			otherFees(DTNAME_WEBSERVICEFEE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_LOYALTYBONUS:{
			otherFees(DTNAME_LOYALTYBONUS,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_TRAININGFEES:{
			otherFees(DTNAME_TRANINGFEE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_PREFERENCEBENEFIT:{
			otherFees(DTNAME_PREFERENCEBENEFIT,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_RETAINERFEE:{
			otherFees(DTNAME_RETAINERFEE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_LISTINGFEE:{
			otherFees(DTNAME_LISTINGFEE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_CONTENTACCESSFEE:{
			otherFees(DTNAME_CONTENTACCESSFEE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_SIGNUPFEES:{
			otherFees(DTNAME_SIGNUPFEE,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_SIGNUPBONUS:{
			setSignUpBonus(jsonObject,mainJson,mdmCommDefn, commercialName,selectedRow,commercialType,value,entityName,entityMarket,entityType,supplier,productName,mainScreenID,index);
			break;
		}
		case PROP_LOOKTOBOOK:{
			setLookToBookDetails(mdmCommDefn,jsonObject,mainJson,selectedRow,commercialName,value,entityName,entityType,index,mainScreenID);
			break;
		}	
		case PROP_MSFFEES:{
			//no schema for msffee in client
		}
		case PROP_INCENTIVEONTOPUP:{
			setIncentiveOnTopUp(mdmCommDefn,jsonObject,mainJson,selectedRow,commercialName,value,entityName,entityType,index,mainScreenID);
			break;
		}
		case PROP_TERMINATIONFEES:{
			setTerminationFeeDetails(jsonObject,mdmCommDefn,mainJson,value,selectedRow,commercialName,entityName,entityType,index,mainScreenID);
			break;
		}
		case PROP_PENALTYFEE:{
			setPenaltyFeeDetails(mdmCommDefn,jsonObject,mainJson,selectedRow,commercialName,value,entityName,entityType,index,mainScreenID);
			break;
		}
		case PROP_FOC:{
			break;
		}
		case PROP_LOSTTICKET:{
			otherFees(DTNAME_LOSTTICKET,mainJson,mdmCommDefn,jsonObject,value,selectedRow,commercialName,supplier,entityName,entityMarket,entityType,commercialType,productName,index,mainScreenID);
			break;
		}
		case PROP_REMITTANCEFEES:{
			//no schema for remittance in client
		}
		default:System.out.println("default of settlementCommercials bcoz of commercialName: "+jsonObject.get(PROP_COMMERCIALHEAD).toString());
		}
		main=new JSONObject(new JSONTokener(mainJson.toString()));
		return main.toString();
	}


	private static void setPenaltyFeeDetails(JSONObject mdmCommDefn, JSONObject mainUseCaseJsonObject, JSONObject mainJson, String selectedRow, String commercialName, String value, String entityName, String entityType, int index, String mainScreenID) {
		if(mainUseCaseJsonObject.has(PROP_APPLICABLEON_ID) && mainUseCaseJsonObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
			JSONArray penaltyFeeArr = new JSONArray();
			for(int k=0;k<mainUseCaseJsonObject.getJSONArray(PROP_APPLICABLEON_ID).length();k++){
				for(int i=0;i<mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).length();i++){
					JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).getJSONObject(i);
					if(clientCommercialOtherHead.getString(PROP_ID).equals(mainUseCaseJsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(k))){
						JSONArray penaltyCriteria =  clientCommercialOtherHead.getJSONObject(PROP_COMMHEADS).getJSONArray(PROP_PENALTYCRITERIA);
						for(int j=0;j<penaltyCriteria.length();j++){
							JSONObject penaltyCriteriaObject = penaltyCriteria.getJSONObject(j);
							JSONObject penaltyFee = new JSONObject();
							JSONObject slabDetails = new JSONObject(); 
							JSONObject slabTypeVal = new JSONObject();
							penaltyFee.put(RULEID, mainScreenID+"_"+clientCommercialOtherHead.getString(PROP_ID)+"_"+k+j);
							setInitialRequirements(mainUseCaseJsonObject,penaltyFee,selectedRow,commercialName,mainScreenID);

							if(penaltyCriteriaObject.has(PROP_MINTOACHIEVE_FROM) && penaltyCriteriaObject.has(PROP_MINTOACHIEVE_TO)){
								String minToAchieve = penaltyCriteriaObject.get(PROP_MINTOACHIEVE_FROM).toString();
								String maxToAchieve = penaltyCriteriaObject.get(PROP_MINTOACHIEVE_TO).toString();
								String targetto = penaltyCriteriaObject.get(PROP_TARGET_TO).toString();
								slabDetails.put(SLABTYPE, penaltyCriteriaObject.getString(SLABTYPE));
								slabTypeVal.put(MINTOACHIEVE,minToAchieve+"*"+targetto);
								slabTypeVal.put(MAXTOACHIEVE,maxToAchieve+"*"+targetto);
								slabDetails.put(SLABTYPEVALUE, slabTypeVal);
								penaltyFee.put(PROP_SLABDETAILS, slabDetails);
							}else{
								slabDetails.put(SLABTYPE, penaltyCriteriaObject.getString(SLABTYPE));
								if(penaltyCriteriaObject.get(PROP_TARGET_TO).equals(0)){
									slabTypeVal.put(OPERATOR, GREATERTHANEQUALTO);
									slabTypeVal.put(VALUE, penaltyCriteriaObject.get(PROP_TARGET_FROM).toString());
								}else{
									slabTypeVal.put(OPERATOR,BETWEEN);
									slabTypeVal.put(PROP_FROM, penaltyCriteriaObject.get(PROP_TARGET_FROM).toString());
									slabTypeVal.put(PROP_TO, penaltyCriteriaObject.get(PROP_TARGET_TO).toString());
								}
								slabDetails.put(SLABTYPEVALUE, slabTypeVal);
								penaltyFee.put(PROP_SLABDETAILS, slabDetails);
							}
							JSONObject penalty = penaltyCriteriaObject.getJSONObject(PROP_PENALTY);
							if(penalty.getBoolean(PROP_BOOLEAN_ISPERCENTAGE)){
								if(penalty.getJSONObject(PROP_PERCENTAGE).has(SLABTYPE))
									penaltyFee.put(MATCHING_SLABTYPE, penalty.getJSONObject(PROP_PERCENTAGE).getString(SLABTYPE));
								if(penalty.getJSONObject(PROP_PERCENTAGE).has(VALUE) && !penalty.getJSONObject(PROP_PERCENTAGE).get(VALUE).equals(0))
									penaltyFee.put(PROP_PERCENTAGE, penalty.getJSONObject(PROP_PERCENTAGE).get(VALUE).toString());
							}else{
								if(penalty.getJSONObject(PROP_AMOUNT).has(PROP_CURRENCY))
									penaltyFee.put(COMM_AMOUNT, penalty.getJSONObject(PROP_AMOUNT).getString(PROP_CURRENCY));
								if(penalty.getJSONObject(PROP_AMOUNT).has(VALUE) && !penalty.getJSONObject(PROP_AMOUNT).get(VALUE).equals(0))
									penaltyFee.put(COMM_CURRENCY, penalty.getJSONObject(PROP_AMOUNT).get(VALUE).toString());
							}
							penaltyFeeArr.put(penaltyFee);
						}
					}
				}
			}
			mainJson.put(DTNAME_PENALTYFEE, penaltyFeeArr);
		}else{
			JSONObject penaltyFee = new JSONObject();
			String ruleID = mainScreenID+"_"+commercialName+"_"+entityName+"_"+entityType+index;
			penaltyFee.put(RULEID, ruleID);
			setInitialRequirements(mainUseCaseJsonObject,penaltyFee,selectedRow,commercialName,mainScreenID);
			if(mainUseCaseJsonObject.getJSONObject(value).has(PROP_AMOUNT) && !mainUseCaseJsonObject.getJSONObject(value).get(PROP_AMOUNT).equals(0))
				penaltyFee.put(COMM_AMOUNT, mainUseCaseJsonObject.getJSONObject(value).get(PROP_AMOUNT).toString());
			if(mainUseCaseJsonObject.getJSONObject(value).has(PROP_CURRENCY))
				penaltyFee.put(COMM_CURRENCY, mainUseCaseJsonObject.getJSONObject(value).getString(PROP_CURRENCY));
			mainJson.put(DTNAME_PENALTYFEE, penaltyFee);
		}
	}


	private static void setLookToBookDetails(JSONObject mdmCommDefn, JSONObject jsonObject, JSONObject mainJson, String selectedRow, String commercialName, String value, String entityName, String entityType, int index, String mainScreenID) {
		JSONArray lookToBookArr = new JSONArray();
		if(jsonObject.has(PROP_APPLICABLEON_ID) && jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
			for(int k=0;k<jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length();k++){
				for(int i=0;i<mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).length();i++){
					JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).getJSONObject(i);
					if(clientCommercialOtherHead.getString(PROP_ID).equals(jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(k))){
						JSONObject lookToBook =  clientCommercialOtherHead.getJSONObject(PROP_COMMHEADS).getJSONObject(PROP_LOOKTOBOOK_OBJECT);
						JSONObject l2b = new JSONObject();
						setInitialRequirements(jsonObject,l2b,selectedRow,commercialName,mainScreenID);

						if(lookToBook.getString(PROP_BY_RATIO_OR_RATE).equals(PROP_RATIO)){
							for(int m=0;m<lookToBook.getJSONArray(PROP_BYRATIO).length();m++){
								JSONObject lookRatio = lookToBook.getJSONArray(PROP_BYRATIO).getJSONObject(m);
								l2b.put(RULEID, mainScreenID+"_"+commercialName+PROP_BYRATIO+k+m);
								JSONObject lookToBookObject = new JSONObject();
								lookToBookObject.put(PROP_FROM,lookRatio.getJSONObject(PROP_LOOKRATIO).get(PROP_FROM).toString());
								lookToBookObject.put(PROP_TO,lookRatio.getJSONObject(PROP_LOOKRATIO).get(PROP_TO).toString());
								lookToBookObject.put(PROP_BOOKRATIO, lookRatio.get(PROP_BOOKRATIO).toString());
								lookToBookObject.put(AMOUNTPERACCESSLOOK, lookRatio.get(PROP_AMOUNTPERACCESSLOOK).toString());
								if(lookRatio.has(PROP_CURRENCY))
									lookToBookObject.put(PROP_CURRENCY, lookRatio.getString(PROP_CURRENCY));
								l2b.put(PROP_LOOKTOBOOK_OBJECT, lookToBookObject);
								lookToBookArr.put(l2b);
							}
						}else{
							JSONObject lookToBookRate = new JSONObject();
							JSONObject l2bByRate = lookToBook.getJSONObject(PROP_BYRATE);
							l2b.put(RULEID, mainScreenID+"_"+clientCommercialOtherHead.getString(PROP_ID)+k+i);
							JSONObject ratePerLook = new JSONObject();
							JSONObject ratePerBook = new JSONObject();
							JSONObject ratePerLookJsonObject = l2bByRate.getJSONObject(PROP_RATEPERLOOK);
							JSONObject ratePerBookJsonObject = l2bByRate.getJSONObject(PROP_RATEPERBOOK);
							if(ratePerLookJsonObject.has(PROP_CURRENCY))
								ratePerLook.put(PROP_CURRENCY, ratePerLookJsonObject.getString(PROP_CURRENCY));
							if(ratePerLookJsonObject.has(PROP_AMOUNT) && !ratePerLookJsonObject.get(PROP_AMOUNT).equals(0))
								ratePerLook.put(PROP_AMOUNT, ratePerLookJsonObject.get(PROP_AMOUNT).toString());
							if(ratePerBookJsonObject.has(PROP_CURRENCY))
								ratePerBook.put(PROP_CURRENCY, ratePerBookJsonObject.getString(PROP_CURRENCY));
							if(ratePerBookJsonObject.has(PROP_AMOUNT) && !ratePerBookJsonObject.get(PROP_AMOUNT).equals(0))
								ratePerBook.put(PROP_AMOUNT, ratePerBookJsonObject.get(PROP_AMOUNT).toString());
							lookToBookRate.put(LOOKRATE, ratePerLook);
							lookToBookRate.put(BOOKRATE, ratePerBook);
							l2b.put(PROP_LOOKTOBOOK_OBJECT, lookToBookRate);
							lookToBookArr.put(l2b);
						}
					}
				}
			}
			mainJson.put(DTNAME_LOOKTOBOOK, lookToBookArr);
		}else{
			JSONObject lookToBook = new JSONObject();
			String ruleID = mainScreenID+"_"+commercialName+"_"+entityName+"_"+entityType+index;
			lookToBook.put(RULEID, ruleID);
			setInitialRequirements(jsonObject,lookToBook,selectedRow,commercialName,mainScreenID);
			if(jsonObject.getJSONObject(value).has(PROP_AMOUNT) && !jsonObject.getJSONObject(value).get(PROP_AMOUNT).equals(0))
				lookToBook.put(COMM_AMOUNT, jsonObject.getJSONObject(value).get(PROP_AMOUNT).toString());
			if(jsonObject.getJSONObject(value).has(PROP_CURRENCY))
				lookToBook.put(COMM_CURRENCY, jsonObject.getJSONObject(value).getString(PROP_CURRENCY));
			mainJson.put(DTNAME_LOOKTOBOOK, lookToBook);
		}
	}


	private static void setInitialRequirements(JSONObject jsonObject, JSONObject l2b, String selectedRow, String commercialName, String mainScreenID) {
		l2b.put(SELECTEDROW, selectedRow);
		l2b.put(TYPE, commercialName);
		l2b.put(CONTRACTVALIDITY, getContractValidity(jsonObject));
		l2b.put(COMMERCIAL_ID, mainScreenID+"_"+commercialName+"_");
		l2b.put(KEY, mainScreenID);
	}


	private static void setIncentiveOnTopUp(JSONObject mdmCommDefn, JSONObject jsonObject, JSONObject mainJson, String selectedRow, String commercialName, String value, String entityName, String entityType, int index, String mainScreenID) {
		JSONArray iotpArray = new JSONArray();
		if(jsonObject.has(PROP_APPLICABLEON_ID) && jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
			for(int k=0;k<jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length();k++){
				for(int i=0;i<mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).length();i++){
					JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).getJSONObject(i);
					if(clientCommercialOtherHead.getString(PROP_ID).equals(jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(k))){
						JSONObject incentiveOnTopUp =  clientCommercialOtherHead.getJSONObject(PROP_COMMHEADS).getJSONObject(PROP_IOTP);
						switch(incentiveOnTopUp.getString(PROP_PERIODFORTOPUP)){
						case PROP_DAILY:{
							for(int j=0;j<incentiveOnTopUp.getJSONArray(PROP_DAILY).length();j++){
								JSONObject iotp = new JSONObject();
								JSONObject iotpDaily =incentiveOnTopUp.getJSONArray(PROP_DAILY).getJSONObject(j);
								JSONObject daily = new JSONObject();
								JSONObject periodForTopUp = new JSONObject();
								setInitialRequirements(jsonObject,iotp,selectedRow,commercialName,mainScreenID);
								iotp.put(RULEID, mainScreenID+"_"+clientCommercialOtherHead.getString(PROP_ID)+PROP_DAILY+k+j);
								if(incentiveOnTopUp.has(PROP_MODEOFPAYMENT))
									iotp.put(PROP_MODEOFPAYMENT, incentiveOnTopUp.getString(PROP_MODEOFPAYMENT));
								if(incentiveOnTopUp.has(PROP_BANKID))
									iotp.put(BANKNAME, incentiveOnTopUp.getString(PROP_BANKID));
								if(incentiveOnTopUp.has(PROP_CURRENCY))
									iotp.put(INCENTIVECURRENCY, incentiveOnTopUp.getString(PROP_CURRENCY));
								if(incentiveOnTopUp.has(PROP_AMOUNT) && !incentiveOnTopUp.get(PROP_AMOUNT).equals(0))
									iotp.put(INCENTIVEAMOUNT, incentiveOnTopUp.get(PROP_AMOUNT).toString());
								if(iotpDaily.has(PROP_TIMEOFTHEDAY_HOURS))
									daily.put(HOURS, iotpDaily.get(PROP_TIMEOFTHEDAY_HOURS).toString());
								if(iotpDaily.has(PROP_TIMEOFTHEDAY_MINS))
									daily.put(MINUTES, iotpDaily.get(PROP_TIMEOFTHEDAY_MINS).toString());
								periodForTopUp.put(PROP_DAILY, daily);
								iotp.put(PERIODFORTOPUP, periodForTopUp);
								iotpArray.put(iotp);
							}
							break;
						}
						case PROP_WEEKLY:{
							JSONObject weekly = new JSONObject();
							JSONObject iotp = new JSONObject();
							JSONObject periodForTopUp = new JSONObject();
							JSONArray iotpWeekly =incentiveOnTopUp.getJSONArray(PROP_WEEKLY);
							setInitialRequirements(jsonObject,iotp,selectedRow,commercialName,mainScreenID);
							iotp.put(RULEID, mainScreenID+"_"+clientCommercialOtherHead.getString(PROP_ID)+"_"+PROP_WEEKLY+k+i);
							if(incentiveOnTopUp.has(PROP_MODEOFPAYMENT))
								iotp.put(PROP_MODEOFPAYMENT, incentiveOnTopUp.getString(PROP_MODEOFPAYMENT));
							if(incentiveOnTopUp.has(PROP_BANKID))
								iotp.put(BANKNAME, incentiveOnTopUp.getString(PROP_BANKID));
							if(incentiveOnTopUp.has(PROP_CURRENCY))
								iotp.put(INCENTIVECURRENCY, incentiveOnTopUp.getString(PROP_CURRENCY));
							if(incentiveOnTopUp.has(PROP_AMOUNT) && !incentiveOnTopUp.get(PROP_AMOUNT).equals(0))
								iotp.put(INCENTIVEAMOUNT, incentiveOnTopUp.get(PROP_AMOUNT).toString());
							Set<String> tempo = new HashSet<String>();
							for(int j=0;j<iotpWeekly.length();j++){
								JSONObject temp = iotpWeekly.getJSONObject(j);
								if(temp.has(PROP_DAYSOFTHEWEEK)){
									tempo.add(temp.getString(PROP_DAYSOFTHEWEEK));
									weekly.put(DAYOFWEEK, tempo);
								}
							}

							periodForTopUp.put(PROP_WEEKLY, weekly);
							iotp.put(PERIODFORTOPUP, periodForTopUp);
							iotpArray.put(iotp);
							break;
						}
						case PROP_FORTNIGHTLY:{
							for(int j=0;j<incentiveOnTopUp.getJSONArray(PROP_FORTNIGHTLY).length();j++){
								JSONObject iotpFortnightly =incentiveOnTopUp.getJSONArray(PROP_FORTNIGHTLY).getJSONObject(j);
								JSONObject iotp = new JSONObject();
								JSONObject fortnighly = new JSONObject();
								JSONObject periodForTopUp = new JSONObject();
								JSONArray dayOfWeekInMonth = new JSONArray();
								JSONArray monthFortnightly = new JSONArray();
								setInitialRequirements(jsonObject,iotp,selectedRow,commercialName,mainScreenID);
								iotp.put(RULEID, mainScreenID+"_"+clientCommercialOtherHead.getString(PROP_ID)+"_"+PROP_FORTNIGHTLY+k+j);
								if(incentiveOnTopUp.has(PROP_MODEOFPAYMENT))
									iotp.put(PROP_MODEOFPAYMENT, incentiveOnTopUp.getString(PROP_MODEOFPAYMENT));
								if(incentiveOnTopUp.has(PROP_BANKID))
									iotp.put(BANKNAME, incentiveOnTopUp.getString(PROP_BANKID));
								if(incentiveOnTopUp.has(PROP_CURRENCY))
									iotp.put(INCENTIVECURRENCY, incentiveOnTopUp.getString(PROP_CURRENCY));
								if(incentiveOnTopUp.has(PROP_AMOUNT) && !incentiveOnTopUp.get(PROP_AMOUNT).equals(0))
									iotp.put(INCENTIVEAMOUNT, incentiveOnTopUp.get(PROP_AMOUNT).toString());
								if(iotpFortnightly.has(PROP_DAY1))
									dayOfWeekInMonth.put(iotpFortnightly.get(PROP_DAY1).toString());
								if(iotpFortnightly.has(PROP_DAY2))
									dayOfWeekInMonth.put(iotpFortnightly.get(PROP_DAY2).toString());
								fortnighly.put(DAYOFWEEK_INMONTH, dayOfWeekInMonth);
								int f = iotpFortnightly.getInt(PROP_REPEATEVERY);
								for(int bc=1;bc<=12;bc++){
									if(bc%f==0){
										monthFortnightly.put(""+bc);
									}
								}
								fortnighly.put(MONTH,monthFortnightly);
								periodForTopUp.put(FORTNIGHTLY, fortnighly);
								iotp.put(PERIODFORTOPUP, periodForTopUp);
								iotpArray.put(iotp);
							}
							break;
						}
						default:{
							System.out.println("default of periodOfTopUp");
						}
						}
					}
				}
			}
			mainJson.put(DTNAME_INCENTIVEONTOPUP, iotpArray);
		}else{
			JSONObject iotp = new JSONObject();
			String ruleID = mainScreenID+"_"+commercialName+"_"+entityName+"_"+entityType+"_"+index;
			iotp.put(RULEID, ruleID);
			setInitialRequirements(jsonObject,iotp,selectedRow,commercialName,mainScreenID);
			if(jsonObject.getJSONObject(value).has(PROP_PERCENTAGE) && !jsonObject.getJSONObject(value).get(PROP_PERCENTAGE).equals(0))
				iotp.put(INCENTIVEPERCENTAGE, jsonObject.getJSONObject(value).get(PROP_PERCENTAGE).toString());
			mainJson.put(DTNAME_INCENTIVEONTOPUP, iotp);
		}
	}


	private static void setTerminationFeeDetails(JSONObject jsonObject, JSONObject mdmCommDefn, JSONObject mainJson, String value, String selectedRow, String commercialName, String entityName, String entityType, int index, String mainScreenID) {
		if(jsonObject.has(PROP_APPLICABLEON_ID) && jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
			JSONObject terminationFeeP = new JSONObject();
			for(int i=0;i<jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length();i++){
				for(int j=0;j<mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).length();j++){
					JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).getJSONObject(j);
					if(clientCommercialOtherHead.getString(PROP_ID).equals(jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(i))){
						JSONArray terminationArray = clientCommercialOtherHead.getJSONObject(PROP_COMMHEADS).getJSONArray(PROP_TERMINATIONFEE);
						for(int k=0;k<terminationArray.length();k++){
							JSONObject terminationFee =  terminationArray.getJSONObject(k);
							terminationFeeP.put(RULEID, mainScreenID+"_"+jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(i)+commercialName);
							setInitialRequirements(terminationFee,terminationFeeP,selectedRow,commercialName,mainScreenID);
							if(terminationFee.getJSONObject(PROP_PAYABLE).getBoolean(PROP_FIXED)){
								if(terminationFee.getJSONObject(PROP_FIXED).has(PROP_CURRENCY))
									terminationFeeP.put(COMM_CURRENCY,terminationFee.getJSONObject(PROP_FIXED).getString(PROP_CURRENCY));
								if(terminationFee.getJSONObject(PROP_FIXED).has(VALUE) && !terminationFee.getJSONObject(PROP_FIXED).get(VALUE).equals(0))
									terminationFeeP.put(COMM_AMOUNT,terminationFee.getJSONObject(PROP_FIXED).get(VALUE).toString());
							}else{
								JSONArray returnableCommHeadArr =new JSONArray();
								for(int n=0;n<terminationFee.getJSONArray(PROP_RETURNOFPAYABLE).length();n++){
									JSONObject returnableCommHead =new JSONObject();
									if(terminationFee.getJSONArray(PROP_RETURNOFPAYABLE).getJSONObject(n).has(PROP_COMMERCIALHEAD))
										returnableCommHead.put(COMMNAME, terminationFee.getJSONArray(PROP_RETURNOFPAYABLE).getJSONObject(n).getString(PROP_COMMERCIALHEAD));
									if(terminationFee.getJSONArray(PROP_RETURNOFPAYABLE).getJSONObject(n).has(PROP_INTERESTONAMOUNT) && !terminationFee.getJSONArray(PROP_RETURNOFPAYABLE).getJSONObject(n).get(PROP_INTERESTONAMOUNT).equals(0))
										returnableCommHead.put(COMMPERCENTAGE, terminationFee.getJSONArray(PROP_RETURNOFPAYABLE).getJSONObject(n).get(PROP_INTERESTONAMOUNT).toString());
									returnableCommHeadArr.put(returnableCommHead);
								}
								terminationFeeP.put(RETURNABLE_COMMHEAD,returnableCommHeadArr);
							}
						}
					}
				}
			}
			mainJson.put(DTNAME_TERMINATIONFEE, terminationFeeP);
		}else{
			JSONObject terminationFee = new JSONObject();
			String ruleID = mainScreenID+"_"+commercialName+"_"+entityName+"_"+entityType+index;
			terminationFee.put(RULEID, ruleID);
			setInitialRequirements(jsonObject,terminationFee,selectedRow,commercialName,mainScreenID);
			if(jsonObject.getJSONObject(value).has(PROP_AMOUNT) && !jsonObject.getJSONObject(value).get(PROP_AMOUNT).equals(0))
				terminationFee.put(COMM_AMOUNT, jsonObject.getJSONObject(value).get(PROP_AMOUNT).toString());
			if(jsonObject.getJSONObject(value).has(PROP_CURRENCY))
				terminationFee.put(COMM_CURRENCY, jsonObject.getJSONObject(value).getString(PROP_CURRENCY));
			mainJson.put(DTNAME_TERMINATIONFEE, terminationFee);
		}
	}


	private static void setSignUpBonus(JSONObject jsonObject, JSONObject mainJson, JSONObject mdmCommDefn, String commercialName,String selectedRow,String commercialType, String value, String entityName, JSONArray entityMarket, String entityType,String supplier,String productName, String mainScreenID, int index) {
		if(jsonObject.has(PROP_APPLICABLEON_ID) && jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
			JSONArray signUpBonusArr = new JSONArray();
			for(int i=0;i<jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length();i++){
				JSONObject signUpBonus = new JSONObject();
				signUpBonus.put(RULEID, mainScreenID+"_"+jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(i));
				setInitialRequirements(jsonObject,signUpBonus,selectedRow,commercialName,mainScreenID);
				//CommonFunctions.signUpBonusApplicableOnID = jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(i);
				getClientOtherHeads(PROP_SIGNUPBONUS_OBJECT,commercialType,mdmCommDefn,entityName,entityMarket,entityType,supplier,commercialName,productName,mainJson,signUpBonus,jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(i));
				if(jsonObject.getJSONObject(value).has(PROP_AMOUNT) && !jsonObject.getJSONObject(value).get(PROP_AMOUNT).equals(0))
					signUpBonus.put(COMM_AMOUNT, jsonObject.getJSONObject(value).get(PROP_AMOUNT).toString());
				if(jsonObject.getJSONObject(value).has(PROP_CURRENCY))
					signUpBonus.put(COMM_CURRENCY, jsonObject.getJSONObject(value).getString(PROP_CURRENCY));
				signUpBonusArr.put(signUpBonus);
			}
			mainJson.put(DTNAME_SIGNUPBONUS, signUpBonusArr);
		}else{
			JSONObject signUpBonus = new JSONObject();
			String ruleID = mainScreenID+"_"+commercialName+"_"+entityName+"_"+entityType+index;
			signUpBonus.put(RULEID, ruleID);
			setInitialRequirements(jsonObject,signUpBonus,selectedRow,commercialName,mainScreenID);
			if(jsonObject.getJSONObject(value).has(PROP_AMOUNT) && !jsonObject.getJSONObject(value).get(PROP_AMOUNT).equals(0))
				signUpBonus.put(COMM_AMOUNT, jsonObject.getJSONObject(value).get(PROP_AMOUNT).toString());
			if(jsonObject.getJSONObject(value).has(PROP_CURRENCY))
				signUpBonus.put(COMM_CURRENCY, jsonObject.getJSONObject(value).getString(PROP_CURRENCY));
			mainJson.put(DTNAME_SIGNUPBONUS, signUpBonus);
		}
	}


	public static void otherFees(String DTname, JSONObject mainJson, JSONObject mdmCommDefn, JSONObject jsonObject, String value, String selectedRow, String commercialName, String supplier, String entityName, JSONArray entityMarket, String entityType, String commercialType, String productName, int index, String mainScreenID){
		JSONArray otherFeeArr = new JSONArray();
		String ruleID = commercialName+"_"+entityName+"_"+entityType+index;
		if(jsonObject.has(PROP_APPLICABLEON_ID) && jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
			for(int i=0;i<jsonObject.getJSONArray(PROP_APPLICABLEON_ID).length();i++){
				JSONObject otherFee = new JSONObject();
				otherFee.put(RULEID, mainScreenID+"_"+jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(i));
				setInitialRequirements(jsonObject,otherFee,selectedRow,commercialName,mainScreenID);
				//CommonFunctions.otherFeeApplicableOnID = jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(i);
				getClientOtherHeads(PROP_OTHERFEES,commercialType,mdmCommDefn,entityName,entityMarket,entityType,supplier,commercialName,productName,mainJson,otherFee,jsonObject.getJSONArray(PROP_APPLICABLEON_ID).getString(i));
				otherFeeArr.put(otherFee);
			}
			mainJson.put(DTname, otherFeeArr);
		}else{
			JSONObject otherFee = new JSONObject();
			otherFee.put(RULEID, mainScreenID+"_"+ruleID);
			setInitialRequirements(jsonObject,otherFee,selectedRow,commercialName,mainScreenID);
			if(jsonObject.getJSONObject(value).has(PROP_AMOUNT) && !jsonObject.getJSONObject(value).get(PROP_AMOUNT).equals(0))
				otherFee.put(COMM_AMOUNT, jsonObject.getJSONObject(value).get(PROP_AMOUNT).toString());
			if(jsonObject.getJSONObject(value).has(PROP_CURRENCY))
				otherFee.put(COMM_CURRENCY, jsonObject.getJSONObject(value).getString(PROP_CURRENCY));
			otherFeeArr.put(otherFee);
			mainJson.put(DTname, otherFeeArr);
		}

		if(jsonObject.has(PROP_ADVDEFN_ID) && jsonObject.getString(PROP_ADVDEFN_ID).length()!=0){
			for(int j=0;j<mdmCommDefn.getJSONArray(PROP_ADVDEFN_DATA).length();j++){
				JSONObject advDefData = mdmCommDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(j);
				if(jsonObject.getString(PROP_ADVDEFN_ID).equals(advDefData.getString(PROP_ID))){
					switch(productName){
					case PRODUCTNAME_ACCOMODATION:{
						JSONObject advanceDefinitionAccommodation = advDefData.getJSONObject(PROP_ADVDEFN_ACCO);
						Accomodation.appendAccomodationOtherFeesAdvDefn(advanceDefinitionAccommodation,otherFeeArr,mdmCommDefn,jsonObject,selectedRow,index,commercialName);
						break;
					}
					case PRODUCTNAME_HOLIDAYS:{
						JSONObject advanceDefinitionHolidays = advDefData.getJSONObject(PROP_ADVDEFN_HOLIDAYS);
						Holidays.setOtherFeesHolidaysAdvancedDefinition(advanceDefinitionHolidays, otherFeeArr,commercialName);
						break;
					}
					case PRODUCTNAME_ACTIVITIES:{
						JSONObject advanceDefinitionActivities = advDefData.getJSONObject(PROP_ADVDEFN_ACTIVITIES);
						Activities.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionActivities,commercialName);
						break;
					}
					case PRODUCTNAME_BUS:{
						JSONObject advanceDefinitionTransportation = advDefData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setOtherFeesTransportationAdvancedDefinition(advanceDefinitionTransportation, otherFeeArr,commercialName);
						break;
					}
					case PRODUCTNAME_CARRENTALS:{
						JSONObject advanceDefinitionTransportation = advDefData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setOtherFeesTransportationAdvancedDefinition(advanceDefinitionTransportation, otherFeeArr,commercialName);
						break;
					}
					case PRODUCTNAME_CRUISE:{
						JSONObject advanceDefinitionTransportation = advDefData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setOtherFeesTransportationAdvancedDefinition(advanceDefinitionTransportation, otherFeeArr,commercialName);
						break;
					}
					case PRODUCTNAME_RAIL:{
						break;
					}
					case PRODUCTNAME_AIR:{
						JSONObject advanceDefinitionAir = advDefData.getJSONObject(PROP_ADVDEFN_AIR);
						Air.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionAir, selectedRow,commercialName);
						break;
					}
					case PRODUCTNAME_TRANSFERS:{
						JSONObject advanceDefinitionTransportation = advDefData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setOtherFeesTransportationAdvancedDefinition(advanceDefinitionTransportation, otherFeeArr,commercialName);
						break;
					}
					}
				}
			}
		}
	}


	private static JSONObject getContractValidity(JSONObject jsonObject) {
		JSONObject contractValidity = new JSONObject();
		contractValidity.put(PROP_FROM, jsonObject.getJSONObject(PROP_EFFECTIVE_DATES).getString(PROP_FROM).substring(0, 19));
		if(jsonObject.getJSONObject(PROP_EFFECTIVE_DATES).has(PROP_TO)){
			contractValidity.put(PROP_TO, jsonObject.getJSONObject(PROP_EFFECTIVE_DATES).getString(PROP_TO).substring(0, 19));
			contractValidity.put(OPERATOR, BETWEEN);
		}else contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
		return contractValidity;
	}


	public static void appendProductCategoryAndSubType(JSONObject commJson, String productName, String productCategory, String productCategorySubType) {
		switch(productName){
		/*case PRODUCTNAME_ACCOMODATION:{
			commJson.put(PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}*/
		case PRODUCTNAME_HOLIDAYS:{
			commJson.put(PROP_PRODUCTCATEGORY, productCategory);
			commJson.put(PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		/*case PRODUCTNAME_ACTIVITIES:{
			commJson.put(PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}*/
		}
	}


	private static JSONObject getClientOtherHeads(String otherHead, String commercialType, JSONObject mdmCommDefn, String entityName,JSONArray entityMarket, String entityType, String supplier, String commercialName, String productName, JSONObject mainJson, JSONObject object, String advDefnID){
		switch(otherHead){
		case PROP_OTHERFEES:{
			for(int i=0;i<mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).length();i++){
				JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).getJSONObject(i);
				if(clientCommercialOtherHead.getString(PROP_ID).equals(advDefnID)){
					JSONObject otherFees = clientCommercialOtherHead.getJSONObject(PROP_COMMHEADS).getJSONObject(PROP_OTHERFEES);
					JSONArray commercialHead = mainJson.getJSONObject(DTNAME_COMMDEFN).getJSONArray(PROP_COMMERCIALHEAD);
					for(int c=0;c<commercialHead.length();c++){
						JSONObject commHeadObj = commercialHead.getJSONObject(c);
						if(commHeadObj.getString(COMMHEADNAME).equals(commercialName)){
							if(otherFees.has(PROP_REFUNDABLE))
								commHeadObj.put(PROP_REFUNDABLE, true);
							else commHeadObj.put(PROP_REFUNDABLE, false);
							if(otherFees.has(PROP_RECURRING))
								commHeadObj.put(PROP_RECURRING, true);
							else commHeadObj.put(PROP_RECURRING, false);
						}
					}
					if(otherFees.has(PROP_PERCENT) && otherFees.getJSONArray(PROP_PERCENT).length()>0){
						JSONArray percent = otherFees.getJSONArray(PROP_PERCENT);
						JSONArray percentageArr = new JSONArray();
						for(int j=0;j<percent.length();j++){
							JSONObject percentObject = percent.getJSONObject(j);
							JSONObject json = new JSONObject();
							if(percentObject.has(PROP_COMMERCIALHEAD))
								json.put(COMMNAME, percentObject.getString(PROP_COMMERCIALHEAD));
							if(percentObject.has(PROP_PERCENTAGE) && !percentObject.get(PROP_PERCENTAGE).equals(0))
								json.put(COMMPERCENTAGE, percentObject.get(PROP_PERCENTAGE).toString());
							percentageArr.put(json);
						}
						object.put(PROP_PERCENTAGE,percentageArr);
					}else{
						if(otherFees.getJSONObject(PROP_FIXED).has(VALUE) && !otherFees.getJSONObject(PROP_FIXED).get(VALUE).equals(0))
							object.put(COMM_AMOUNT, otherFees.getJSONObject(PROP_FIXED).get(VALUE).toString());
						if(otherFees.getJSONObject(PROP_FIXED).has(PROP_CURRENCY))
							object.put(COMM_CURRENCY, otherFees.getJSONObject(PROP_FIXED).getString(PROP_CURRENCY));
					}
				}
			}break;
		}
		case PROP_SIGNUPBONUS_OBJECT:{
			for(int i=0;i<mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).length();i++){
				JSONObject clientCommercialOtherHead = mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD).getJSONObject(i);
				if(advDefnID.equals(clientCommercialOtherHead.getString(PROP_ID))){
					JSONObject signupbonus = clientCommercialOtherHead.getJSONObject(PROP_COMMHEADS).getJSONObject(PROP_SIGNUPBONUS_OBJECT);
					JSONObject slabDetails = new JSONObject();
					slabDetails.put(SLABTYPE, signupbonus.getString(PROP_SLABTYPE));
					JSONObject slabTypeValueObj = new JSONObject();
					slabTypeValueObj.put(OPERATOR, BETWEEN);
					slabTypeValueObj.put(PROP_FROM, signupbonus.get(PROP_TARGET_FROM).toString());
					slabTypeValueObj.put(PROP_TO, signupbonus.get(PROP_TARGET_TO).toString());
					slabDetails.put(SLABTYPEVALUE, slabTypeValueObj);
					object.put(PROP_SLABDETAILS, slabDetails);
				}
			}
			break;
		}
		default:System.out.println("default of getClientSettlementHead");
		}
		return object;
	}
}
