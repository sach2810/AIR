package cnk.cce.configuration;

import java.io.InputStream;
import java.util.Map;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.products.Holidays;
import cnk.cce.configuration.SettlementCommercials;
import org.json.JSONArray;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Properties;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.Logger;
/*import java.io.File;
import org.apache.commons.io.FileUtils;*/

public class Configuration implements Constants{
	private static String mUserID;
	private transient static String mPassword;
	private transient static String mHttpBasicAuth;
	static JSONObject mdmReq;
	static String method = "";
	static String requestUrl = "";
	static boolean settlement = false;
	static String settlementString = null;
	public final static Logger LOGGER = Logger.getLogger(Configuration.class);

	public static void main(String args[]){
		while(true){
			KafkaConsumer<String, String> consumer = null;
			try{
				Properties properties = new Properties();
				ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
				String str = "";
				String topic = TOPICNAME;
				String msfTopic = MSF_TOPICNAME;

				Properties properties1 = new Properties();
				ClassLoader classLoader1 = Thread.currentThread().getContextClassLoader();
				try(InputStream in1 = classLoader1.getResourceAsStream("resources/log4j.properties")){
					properties1.load(in1);
					PropertyConfigurator.configure(properties1);
				}catch(Exception e){
					e.printStackTrace();
					LOGGER.error("Error while loading log4j properties: "+e);
				}

				try(InputStream in = classLoader.getResourceAsStream(KAFKA_PROPERTIES)){
					properties.load(in);
					Enumeration<Object> enuKeys = properties.keys();
					while (enuKeys.hasMoreElements()) {
						String key = (String) enuKeys.nextElement();
						String value = properties.getProperty(key);
						properties.put(key, value);
					}
				}catch(Exception e){
					LOGGER.error(e);
					e.printStackTrace();
				}

				/*String content = FileUtils.readFileToString(new File("D:\\AVAMAR BACKUP\\Milan Tank\\Desktop\\MSF_Test_Client.json"), "utf-8");
			JSONObject mdmCommDefn = new JSONObject(content);
			method = mdmCommDefn.getString("method");
			System.out.println(mdmCommDefn);
			readJSON(mdmCommDefn.getJSONObject("data"),method);*/

				try {
					consumer = new KafkaConsumer<String, String>(properties);
					consumer.subscribe(Arrays.asList(topic,msfTopic));
					System.out.println("Subscribed to topic " + topic+" & "+msfTopic);

					while (true) {
						ConsumerRecords<String, String> records = consumer.poll(100);
						for (ConsumerRecord<String, String> record : records) {
							System.out.printf("offset = %d, message = %s\n", record.offset(), record.value());
							str = record.value();
							LOGGER.info(record.offset()+" , "+str);
							JSONObject mdmData = new JSONObject(str);
							method = mdmData.getString("method");
							try{
								readJSON(mdmData.getJSONObject("data"),method);
								consumer.commitSync();
							}
							catch(Exception ex){
								LOGGER.error(ex);
								ex.printStackTrace();
								consumer.commitSync();
								continue;
							}
						}
						continue;
					}
				}catch(Exception e){
					LOGGER.error(e);
					e.printStackTrace();
					consumer.commitSync();
					consumer.close();
					continue;
				}
			}catch(Exception e){
				LOGGER.error(e);
				e.printStackTrace();
				consumer.commitSync();
				consumer.close();
				continue;
			}
		}
	}


	private static void readJSON(JSONObject mdmCommDefn, String kafkaMethod) throws Exception {
		if(mdmCommDefn.has(PROP_BUDGETMARGINDETAILS) && mdmCommDefn.getJSONObject(PROP_BUDGETMARGINDETAILS).has(PROP_BUDGETMARGINS) && mdmCommDefn.getJSONObject(PROP_BUDGETMARGINDETAILS).getJSONArray(PROP_BUDGETMARGINS).length()>0){
			JSONArray budgetMargins = mdmCommDefn.getJSONObject(PROP_BUDGETMARGINDETAILS).getJSONArray(PROP_BUDGETMARGINS);
			for(int i=0;i<budgetMargins.length();i++){
				for(int j=0;j<mdmCommDefn.getJSONArray(PROP_CLIENTCOMMDATA).length();j++){
					JSONObject clientCommercialData = mdmCommDefn.getJSONArray(PROP_CLIENTCOMMDATA).getJSONObject(j);
					String budgetedMarginDetailId = clientCommercialData.getString(PROP_BUDGETMARGINID);
					if(budgetMargins.getJSONObject(i).has(PROP_ID) && budgetMargins.getJSONObject(i).getString(PROP_ID).equals(budgetedMarginDetailId)){
						String supplier = null,entityName=null,entityType=null, productCategorySubType = null;
						String productName=CommonFunctions.getProductName(budgetMargins.getJSONObject(i));
						String productCategory = budgetMargins.getJSONObject(i).getString(PROP_PRODUCTCATEGORY);
						if(budgetMargins.getJSONObject(i).has(PROP_SUBTYPE) && !budgetMargins.getJSONObject(i).getString(PROP_SUBTYPE).equalsIgnoreCase("All"))
							productCategorySubType = budgetMargins.getJSONObject(i).getString(PROP_SUBTYPE);
						if(productName.equals(PRODUCTNAME_HOLIDAYS))
							Holidays.setBudgetMarginDetails(budgetMargins.getJSONObject(i));
						JSONObject budgetMarginAttachedTo = mdmCommDefn.getJSONObject(PROP_BUDGETMARGINDETAILS).getJSONObject(PROP_BUDGETMARGINATTACHEDTO);
						if(budgetMarginAttachedTo.has(PROP_BOOKINGID))
							CommonFunctions.setAmmendRequest(budgetMarginAttachedTo,mdmCommDefn,productName,kafkaMethod);
						else{
							if(mdmCommDefn.getJSONObject(PROP_BUDGETMARGINDETAILS).has(PROP_ENTITYID))
								entityName = mdmCommDefn.getJSONObject(PROP_BUDGETMARGINDETAILS).getString(PROP_ENTITYID);
							if(budgetMarginAttachedTo.has(PROP_ENTITYTYPE))
								entityType = budgetMarginAttachedTo.getString(PROP_ENTITYTYPE);
							String selectedRow = clientCommercialData.getString(PROP_ID)+"_"+entityName+"_"+entityType;
							JSONObject flightsAndNonAir = clientCommercialData.getJSONObject(PROP_COMMDETAILS).getJSONObject(PROP_FLIGHTSANDNONAIR);
							JSONArray entityMarket = new JSONArray();
							if(flightsAndNonAir.has(PROP_SUPPLIERID) && !flightsAndNonAir.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
								supplier = flightsAndNonAir.getString(PROP_SUPPLIERID);
							JSONObject commDefn = new JSONObject();
							JSONObject commDefnPreProcess = new JSONObject();
							commDefn.put(TYPE,TYPE_DEFN);
							commDefn.put(SUPPLIER,supplier);
							commDefn.put(PROP_ENTITYTYPE,entityType);
							commDefn.put(ENTITYNAME,entityName);
							if(budgetMarginAttachedTo.has(PROP_ENTITYMARKET) && !budgetMarginAttachedTo.getJSONArray(PROP_ENTITYMARKET).getString(0).equalsIgnoreCase("All")){
								if(!entityMarket.isNull(0)){
									entityMarket=budgetMarginAttachedTo.getJSONArray(PROP_ENTITYMARKET);
									commDefn.put(PROP_ENTITYMARKET,entityMarket);
									commDefnPreProcess.put(PROP_ENTITYMARKET,entityMarket);
								}
							}

							String mainScreenID = clientCommercialData.getString(PROP_ID);
							String clientCommercialDataID = clientCommercialData.get(PROP__V)+"|"+mainScreenID;
							JSONArray commHead = new JSONArray();
							
							boolean isCommissionable = false;
							if(flightsAndNonAir.has(ISCOMMISIONABLE))
								isCommissionable = flightsAndNonAir.getBoolean(ISCOMMISIONABLE);
							
							JSONObject mainJson = new JSONObject();

							JSONObject additionalCommercials = flightsAndNonAir.getJSONObject(PROP_ADDITIONALCOMMS);
							if(additionalCommercials.has(PROP_PAYABLETOCLIENT) && additionalCommercials.getJSONArray(PROP_PAYABLETOCLIENT).length()>0)
								CommonFunctions.appendCommercialHead(additionalCommercials.getJSONArray(PROP_PAYABLETOCLIENT),clientCommercialDataID,productName,PAYABLE,ADDITIONAL,ADDITIONAL_PAYABLE,commHead,mdmCommDefn,supplier,entityName,entityMarket,selectedRow,productCategory,productCategorySubType,mainScreenID,isCommissionable,mainJson,commDefn);
							if(additionalCommercials.has(PROP_RECEIVABLETOCOMPANY) && additionalCommercials.getJSONArray(PROP_RECEIVABLETOCOMPANY).length()>0)
								CommonFunctions.appendCommercialHead(additionalCommercials.getJSONArray(PROP_RECEIVABLETOCOMPANY),clientCommercialDataID,productName,RECEIVABLE,ADDITIONAL,ADDITIONAL_RECEIVABLE,commHead,mdmCommDefn,supplier,entityName,entityMarket,selectedRow,productCategory,productCategorySubType,mainScreenID,isCommissionable,mainJson,commDefn);

							JSONObject retentionCommercials = flightsAndNonAir.getJSONObject(PROP_RETENTIONCOMMS);
							if(retentionCommercials.has(PROP_PAYABLETOCLIENT) && retentionCommercials.getJSONArray(PROP_PAYABLETOCLIENT).length()>0)
								CommonFunctions.appendCommercialHead(retentionCommercials.getJSONArray(PROP_PAYABLETOCLIENT),clientCommercialDataID,productName,PAYABLE,RETENTION,RETENTION_PAYABLE,commHead,mdmCommDefn,supplier,entityName,entityMarket,selectedRow,productCategory,productCategorySubType,mainScreenID,isCommissionable,mainJson,commDefn);
							if(retentionCommercials.has(PROP_RECEIVABLETOCOMPANY) && retentionCommercials.getJSONArray(PROP_RECEIVABLETOCOMPANY).length()>0)
								CommonFunctions.appendCommercialHead(retentionCommercials.getJSONArray(PROP_RECEIVABLETOCOMPANY),clientCommercialDataID,productName,RECEIVABLE,RETENTION,RENTENTION_RECEIVABLE,commHead,mdmCommDefn,supplier,entityName,entityMarket,selectedRow,productCategory,productCategorySubType,mainScreenID,isCommissionable,mainJson,commDefn);

							if(flightsAndNonAir.has(PROP_markup) && flightsAndNonAir.getJSONArray(PROP_markup).length()>0){
								JSONObject markUp = flightsAndNonAir.getJSONArray(PROP_markup).getJSONObject(0);
								if(markUp.has(PROP_EFFECTIVE_DATES))
									CommonFunctions.appendCommercialHead(MARKUP, RECEIVABLE, MARKUP, true,commDefn,commHead,mainJson);
							}

							if(flightsAndNonAir.has(COMMTYPE) && flightsAndNonAir.getString(COMMTYPE).equals(PROP_BYPRODUCT)){
								commDefn.put(PRIORITY,"-1");
								commDefn.put(PROP_BYPRODUCT,true);
								commDefn.put(PROP_ENTITY_PRECONDITION,BYPRODUCT);
								commDefn.put(POSTPROCESSING,BYPRODUCT);
								commDefn.put(AGENDAGROUP,BYPRODUCT);
								commDefnPreProcess.put(PREPROCESS_BYPRODUCT,true);
								commDefnPreProcess.put(PROP_ENTITY_PRECONDITION, PREPROCESS_BYPRODUCT_COMPLETED);
								commDefnPreProcess.put(POSTPROCESSING, PREPROCESS_BYPRODUCT_COMPLETED);
								for(int ch=0;ch<commHead.length();ch++){
									JSONObject commHeadObject = commHead.getJSONObject(ch);
									switch(commHeadObject.getString(COMMHEADNAME)){
									case STANDARD:{commDefn.put(STD_BYPRODUCT, true);commDefnPreProcess.put(STD_BYPRODUCT, true);break;}
									case OVERRIDING:{commDefn.put(OVERRIDING_BYPRODUCT, true);break;}
									case PLB:{commDefn.put(PLB_BYPRODUCT, true);break;}
									case SECTORWISEINCENTIVE:{commDefn.put(SECTOR_BYPRODUCT, true);break;}
									case SEGMENTFEE:{commDefn.put(SEGMENTFEE_BYPRODUCT, true);break;}
									case PROP_DISCOUNT:{commDefn.put(DISCOUNT_BYPRODUCT, true);break;}
									case MANAGEMENTFEE:{commDefn.put(MNGT_BYPRODUCT, true);break;}
									case ISSUANCEFEE:{commDefn.put(ISSUANCEFEE_BYPRODUCT, true);break;}
									case SERVICECHARHGE:{commDefn.put(SERVICE_BYPRODUCT, true);break;}
									case MARKUP:{commDefn.put(MARKUP_BYPRODUCT, true);commDefnPreProcess.put(MARKUP_BYPRODUCT, true);break;}
									case DEST_BYPRODUCT:{commDefn.put(DEST_BYPRODUCT, true);break;}
									
									}
								}
							}else{
								commDefn.put(PROP_BYPRODUCT,false);
								commDefn.put(PROP_ENTITY_PRECONDITION,DEFN_COMPLETED);
								commDefn.put(POSTPROCESSING,DEFN_COMPLETED);
								commDefn.put(AGENDAGROUP,COMMDEFN);
								commDefnPreProcess.put(PREPROCESS_BYPRODUCT,false);
								commDefnPreProcess.put(PROP_ENTITY_PRECONDITION, PREPROCESS_COMPLETED);
								commDefnPreProcess.put(POSTPROCESSING, PREPROCESS_COMPLETED);
								for(int ch=0;ch<commHead.length();ch++){
									JSONObject commHeadObject = commHead.getJSONObject(ch);
									switch(commHeadObject.getString(COMMHEADNAME)){
									case STANDARD:{commDefn.put(STD_BYSUPPLIER, true);break;}
									}
								}
							}
							
							commDefn.put(RULEID, selectedRow);
							commDefn.put(COMMERCIAL_ID, mainScreenID);
							commDefn.put(KEY, mainScreenID);
							commDefnPreProcess.put(KEY, mainScreenID);
							commDefnPreProcess.put(TYPE,TYPE_DEFN);
							commDefnPreProcess.put(SUPPLIER,supplier);
							commDefnPreProcess.put(PROP_ENTITYTYPE,entityType);
							commDefnPreProcess.put(ENTITYNAME,entityName);
							commDefnPreProcess.put(RULEID, selectedRow);
							commDefnPreProcess.put(COMMERCIAL_ID, "PreProcess_"+mainScreenID);
							CommonFunctions.appendProductCategoryAndSubType(commDefn,productName,productCategory,productCategorySubType);
							CommonFunctions.appendProductCategoryAndSubType(commDefnPreProcess,productName,productCategory,productCategorySubType);
							//mainJson.put(DTNAME_COMMDEFN,commDefn);
							mainJson.put(DTNAME_COMMDEFN_PREPROCESS,commDefnPreProcess);
							
							CommonFunctions.addCommercialDetails(supplier,entityName,entityMarket,entityType,commHead,mdmCommDefn,mainJson,productName,selectedRow,flightsAndNonAir,clientCommercialDataID,mainScreenID);
							CommonFunctions.setDefaultAdvDefnID(productName);

							LOGGER.info(productName.toUpperCase()+" Transactional: "+mainJson.toString());
							//System.out.println(productName.toUpperCase()+" Transactional: "+mainJson.toString());
							hitJSONService(mainJson,productName,kafkaMethod);
							
							if(settlement && settlementString!=null){
								LOGGER.info(productName.toUpperCase()+" Settlement: "+settlementString);
								//System.out.println(productName.toUpperCase()+" Settlement: "+settlementString);
								SettlementCommercials.main.keySet().clear();
								hitSettlementJSONService(settlementString, productName, method);
								settlement = false;	settlementString=null;
							}
						}
					}
				}
			}
		}else CommonFunctions.setMsfFeeDetails(mdmCommDefn);
	}


	public static void hitJSONService(JSONObject mainJson, String productName, String kafkaMethod) throws Exception {
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = "kieserver";      
		mPassword = "kieserver1!";
		mHttpBasicAuth = HTTP_AUTH_BASIC_PREFIX.concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(kafkaMethod){
		case POST:{
			URL = SERVER_URL+productName+URL_TRANS_CREATE;
			break;
		}
		case PUT:{
			URL = SERVER_URL+productName+URL_TRANS_UPDATE;
			break;
		}
		case DELETE:{
			URL = SERVER_URL+productName+URL_TRANS_DELETE;
			break;
		}
		}
		if(URL!=null){
			URL productURL = new URL(URL);
			String outputString = null;
			JSONObject outputS = consumeJSONService(SERVER_PORT,productURL,mHttpHeaders,mainJson.toString());
			if(outputS!=null)
				outputString=outputS.toString();
			else outputString="null";
			LOGGER.info(outputString);
			System.out.println(outputS);
		}else System.out.println("Method name is other than POST,PUT or DELETE");
	}


	public static void hitSettlementJSONService(String mainJson, String productName, String kafkaMethod) throws Exception {
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = "kieserver";      
		mPassword = "kieserver1!";
		mHttpBasicAuth = HTTP_AUTH_BASIC_PREFIX.concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(kafkaMethod){
		case POST:{
			URL = SERVER_URL+productName+URL_SETT_CREATE;
			break;
		}
		case PUT:{
			URL = SERVER_URL+productName+URL_SETT_UPDATE;
			break;
		}
		case DELETE:{
			URL = SERVER_URL+productName+URL_SETT_DELETE;
			break;
		}
		}
		if(URL!=null){
			URL productURL = new URL(URL);
			String outputString = null;
			JSONObject outputS = consumeJSONService(SERVER_PORT,productURL,mHttpHeaders,mainJson.toString());
			if(outputS!=null)
				outputString=outputS.toString();
			else outputString="null";
			LOGGER.info(outputString);
			System.out.println(outputS);
		}else System.out.println("Method name is other than POST,PUT or DELETE");
	}


	private static JSONObject consumeJSONService(String tgtSysId, URL tgtSysURL, Map<String, String> httpHdrs, String reqJsonStr) throws Exception {
		HttpURLConnection svcConn = null;
		try {
			svcConn = (HttpURLConnection) tgtSysURL.openConnection();
			InputStream httpResStream = consumeService(tgtSysId, svcConn, httpHdrs, reqJsonStr.getBytes());
			if (httpResStream != null) {
				JSONObject resJson = new JSONObject(new JSONTokener(httpResStream));
				return resJson;
			}
		}
		catch (Exception x) {}
		finally {
			if (svcConn != null) {
				svcConn.disconnect();
			}
		}
		return null;
	}


	private static InputStream consumeService(String tgtSysId, HttpURLConnection svcConn, Map<String, String> httpHdrs, byte[] payload) throws Exception {
		svcConn.setDoOutput(true);
		svcConn.setRequestMethod(POST);
		Set<Entry<String,String>> httpHeaders = httpHdrs.entrySet();
		if(httpHeaders != null && httpHeaders.size() > 0){
			Iterator<Entry<String,String>> httpHeadersIter = httpHeaders.iterator();
			while(httpHeadersIter.hasNext()){
				Entry<String,String> httpHeader = httpHeadersIter.next();
				svcConn.setRequestProperty(httpHeader.getKey(), httpHeader.getValue());
			}
		}
		OutputStream httpOut = svcConn.getOutputStream();
		httpOut.write(payload);
		httpOut.flush();
		httpOut.close();

		int resCode = svcConn.getResponseCode();
		if(resCode == HttpURLConnection.HTTP_OK)
			return svcConn.getInputStream();

		return null;
	}
}