package cnk.cce.configuration;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.products.Accomodation;
import cnk.cce.products.Air;
import cnk.cce.products.CarRentals;
import cnk.cce.products.Holidays;
import cnk.cce.products.Transfers;

public class CommonFunctions implements Constants {
	public static JSONArray baseArr = new JSONArray();
	public static JSONArray calcArr = new JSONArray();
	public static String stdPercentage,stdAmount,overPercentage,overAmount,plbPercentage,plbAmount,servicePercentage,serviceAmount,stdFareComponent,overFareComponent,plbFareComponent,serviceFareComponent,mngtclientCommercialDataID,markupclientCommercialDataID;
	public static String sectorCurrency,segmentCurrency,mngtCurrency,discountCurrency,sectorFareComponent,discountFareComponent,mngtFareComponent,segmentFareComponent,mngtPercentage,mngtAmount,discountPercentage,discountAmount,segmentPercentage;
	public static String segmentAmount,sectorPercentage,sectorAmount,commissionPercentage,commissionAmount,issuancePercentage,issuanceAmount,stdCurrency,destinationAmount,serviceCurrency,serviceclientCommercialDataID,discountclientCommercialDataID;
	public static String markUpContractValidityFrom,markUpContractValidityTo,minSellingPriceAmount,markUpRateType,issuanceFareComponent,issuanceCurrency,commissionFareComponent,commissionCurrency,overCurrency,plbCurrency,destinationPercentage,plbOH;
	public static String stdclientCommercialDataID,overclientCommercialDataID,plbclientCommercialDataID,segmentclientCommercialDataID,sectorclientCommercialDataID,destinationclientCommercialDataID,commissionclientCommercialDataID,issuanceclientCommercialDataID;
	public static String serviceContractValidityTo,sectorContractValidityFrom,serviceContractValidityFrom,sectorContractValidityTo,segmentContractValidityTo,segmentContractValidityFrom,stdContractValidityFrom,stdContractValidityTo,overContractValidityFrom;
	public static String overContractValidityTo,plbContractValidityFrom,plbContractValidityTo,issuanceContractValidityFrom,issuanceContractValidityTo,commissionContractValidityFrom,commissionContractValidityTo,destinationFareComponent,destinationCurrency;
	public static String managementContractValidityFrom,managementContractValidityTo,discountContractValidityFrom,discountContractValidityTo,markupContractValidityFrom,markupContractValidityTo,destinationContractValidityFrom,destinationContractValidityTo;
	public static JSONArray plbapplicableOnArray,segmentapplicableOnArray,serviceapplicableOnArray;

	public static void setContractValidity(JSONObject jsonObject, String commercialName, String productName){
		String from=null,to=null;
		if(jsonObject.getJSONObject(PROP_EFFECTIVE_DATES).has(PROP_FROM))
			from = jsonObject.getJSONObject(PROP_EFFECTIVE_DATES).get(PROP_FROM).toString().substring(0, 11)+"00:00:00";
		if(jsonObject.getJSONObject(PROP_EFFECTIVE_DATES).has(PROP_TO))
			to = jsonObject.getJSONObject(PROP_EFFECTIVE_DATES).get(PROP_TO).toString().substring(0, 11)+"23:59:59";
		switch(commercialName){
		case PROP_STD_COMM:{stdContractValidityFrom=from;stdContractValidityTo=to;break;}
		case PROP_OVER_COMM:{overContractValidityFrom=from;overContractValidityTo=to;break;}
		case PROP_PLB:{plbContractValidityFrom=from;plbContractValidityTo=to;break;}
		case PROP_SECTORINCENTIVES:{sectorContractValidityFrom=from;sectorContractValidityTo=to;break;}
		case PROP_SEGMENTFEES:{segmentContractValidityFrom=from;segmentContractValidityTo=to;break;}
		case PROP_SEGMENTSFEES:{segmentContractValidityFrom=from;segmentContractValidityTo=to;break;}
		case PROP_MANAGEMENTFEE:{managementContractValidityFrom=from;managementContractValidityTo=to;break;}
		case PROP_SERVICECHARGES:{serviceContractValidityFrom=from;serviceContractValidityTo=to;break;}
		case PROP_DISCOUNT:{discountContractValidityFrom=from;discountContractValidityTo=to;break;}
		case PROP_DESTINATIONINCENTIVES:{destinationContractValidityFrom=from;destinationContractValidityTo=to;break;}
		case PROP_ISSUANCEFEES:{issuanceContractValidityFrom=from;issuanceContractValidityTo=to;break;}
		case PROP_MARKUP:{markUpContractValidityFrom=from;markUpContractValidityTo=to;break;}
		case PROP_COMMISSION:{commissionContractValidityFrom=from;commissionContractValidityTo=to;break;}
		default:System.out.println("default of setContractValidity due to commercialName: "+commercialName);
		}
	}


	public static void getOtherFeesArrayNonTP(JSONArray otherFeeArr, JSONArray jsonArray, String name, boolean isInclusion) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = otherFeeArr.getJSONObject(i);
			if(isInclusion)
				otherFee.put(name, array);
			else otherFee.put(name+_EXCLUSION, array);
		}
	}


	public static void getArrayNonTP(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, boolean isInclusion, boolean inBase) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject calculation = calcArr.getJSONObject(i);
			if(isInclusion){
				if(inBase)
					base.put(name, array);
				else calculation.put(name, array);
			}else{
				if(inBase)
					base.put(name+_EXCLUSION, array);
				else calculation.put(name+_EXCLUSION, array);
			}
		}
	}


	public static void getArray(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, boolean isInclusion,boolean inBase, String commercialName) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<jsonArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject jsonObject = jsonArray.getJSONObject(j);
				if(checkIfPayoutIsPresent(jsonObject.getJSONArray(PROP_TRIGGER_PAYOUT))){
					JSONObject triggerPayout = getTriggerPayoutObject(jsonObject.getJSONArray(PROP_TRIGGER_PAYOUT));
					JSONArray array = new JSONArray();
					JSONObject object = new JSONObject();
					array.put(triggerPayout);
					object.put(name, jsonObject.getString(name));
					array.put(object);

					if(isInclusion){
						if(inBase)
							base.put(name, array);
						else calculation.put(name, array);
					}else{
						if(inBase)
							base.put(name+_EXCLUSION, array);
						else calculation.put(name+_EXCLUSION, array);
					}
				}
				setRuleID(baseArr, calcArr, base, calculation, commercialName+"_"+name+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getConnectivityTP(JSONArray baseArr, JSONObject connectivity) {
		if(checkIfPayoutIsPresent(connectivity.getJSONArray(PROP_TRIGGER_PAYOUT))){
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray(PROP_TRIGGER_PAYOUT));
				JSONArray connectivityArr = new JSONArray();
				JSONObject connectivityObject = new JSONObject();
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					connectivityObject.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					connectivityObject.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERID));
				connectivityArr.put(triggerPayout);
				connectivityArr.put(connectivityObject);
				base.put(CONNECTIVITY, connectivityArr);
			}
		}
	}


	public static void getBookingTypeTP(JSONArray baseArr, JSONObject bookingType, boolean isInclusion) {
		if(checkIfPayoutIsPresent(bookingType.getJSONArray(PROP_TRIGGER_PAYOUT))){
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = getTriggerPayoutObject(bookingType.getJSONArray(PROP_TRIGGER_PAYOUT));
				JSONArray bookingTypeArr = new JSONArray();
				JSONObject bookingTypeObject = new JSONObject();
				if(isInclusion)
					bookingTypeObject.put(BOOKINGTYPE,bookingType.getString(BOOKINGTYPE));
				else bookingTypeObject.put(BOOKINGTYPE+"_"+EXCLUSION,bookingType.getString(BOOKINGTYPE));
				bookingTypeArr.put(triggerPayout);
				bookingTypeArr.put(bookingTypeObject);
				base.put(BOOKINGTYPE, bookingTypeArr);
			}
		}
	}


	public static void appendCommercialHead(String commercialName,String commercialType,String commercialProperty, boolean isCommissionable, JSONObject commDefn, JSONArray commHead, JSONObject mainJson) {
		JSONObject commercialHead = new JSONObject();
		commercialHead.put(COMMHEADNAME, commercialName);
		commercialHead.put(COMMTYPE, commercialType);
		commercialHead.put(COMMPROPERTY, commercialProperty);
		commercialHead.put(ISCOMMISIONABLE, isCommissionable);
		commHead.put(commercialHead);
		commDefn.put(PROP_COMMERCIALHEAD,commHead);
		mainJson.put(DTNAME_COMMDEFN,commDefn);
	}


	public static String getFareComponent(JSONArray fareComponents) {
		String fareComponent=null;int flag=0;
		for(int i=0;i<fareComponents.length();i++){
			if(fareComponents.getString(i).equals(BASIC) || fareComponents.getString(i).equals(PROP_BASEFARE)){
				flag=1;
			}
			if(fareComponents.getString(i).equals(TOTAL)){
				flag=2;
				break;
			}
		}
		if(flag==1){
			fareComponent=BASIC;
			for(int i=0;i<fareComponents.length();i++){
				if(!(fareComponents.getString(i).equals(BASIC) || fareComponents.getString(i).equals(PROP_BASEFARE))){
					fareComponent+=","+fareComponents.getString(i);
				}
			}
		}else if(flag==2){
			fareComponent=TOTAL;
		}else{
			for(int i=0;i<fareComponents.length();i++){
				if(i==0)
					fareComponent=fareComponents.getString(i);
				else fareComponent+=","+fareComponents.getString(i);
			}
		}
		return fareComponent;
	}


	public static String getCommercialName(String commercialName) {
		switch(commercialName){
		case PROP_STD_COMM: return STANDARD;
		case PROP_OVER_COMM: return OVERRIDING;
		case PROP_PLB: return PLB;
		case PROP_SECTORINCENTIVES: return SECTORWISEINCENTIVE;
		case PROP_SEGMENTFEES: return SEGMENTFEE;
		case PROP_SEGMENTSFEES: return SEGMENTFEE;
		case PROP_MANAGEMENTFEE: return MANAGEMENTFEE;
		case PROP_SERVICECHARGES: return SERVICECHARHGE;
		case PROP_DISCOUNT: return PROP_DISCOUNT;
		case MARKUP: return MARKUP;
		case PROP_DESTINATIONINCENTIVES: return DESTINATIONINCENTIVE;
		case PROP_ISSUANCEFEES: return ISSUANCEFEE;
		case PROP_COMMISSION: return PROP_COMMISSION;
		case PROP_MAINTENANCEFEES: return MAINTENANCEFEES;
		case PROP_INTEGRATIONFEES: return INTEGRATIONFEES;
		case PROP_LICENCEFEES: return LICENCEFEES;
		case PROP_WEBSERVICEFEES: return WEBSERVICEFEES;
		case PROP_LOYALTYBONUS: return LOYALTYBONUS;
		case PROP_PREFERENCEBENEFIT: return PREFERENCEBENEFIT;
		case PROP_RETAINERFEE: return RETAINERFEE;
		case PROP_LISTINGFEE: return LISTINGFEE;
		case PROP_CONTENTACCESSFEE: return CONTENTACCESSFEE;
		case PROP_SIGNUPFEES: return SIGNUPFEES;
		case PROP_SIGNUPBONUS: return SIGNUPBONUS;
		case PROP_LOOKTOBOOK: return LOOKTOBOOK;
		case PROP_MSFFEES: return MSFFEES;
		case PROP_INCENTIVEONTOPUP: return INCENTIVEONTOPUP;
		case PROP_TERMINATIONFEES: return TERMINATIONFEES;
		case PROP_PENALTYFEE: return PENALTYFEE;
		case PROP_FOC: return FREEOFCOST;
		case PROP_LOSTTICKET: return LOSTTICKET;
		case PROP_REMITTANCEFEES: return REMITTANCEFEES;
		case PROP_TRAININGFEES: return TRANINGFEES;
		default:System.out.println("deafult of getCommercialName");
		}
		return null;
	}


	public static JSONObject addCommercialDetails(String supplier,String entityName,JSONArray entityMarket,String entityType,JSONArray commHead,JSONObject mdmCommDefn,JSONObject mainJson,String productName, String selectedRow, JSONObject flightsAndNonAir, String clientCommercialDataID, String mainScreenID) throws Exception{
		for(int i=0;i<commHead.length();i++){
			switch(commHead.getJSONObject(i).getString(COMMHEADNAME)){
			case STANDARD:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_STD_ADVANCE),mainJson.getJSONArray(DTNAME_STD_CALCULATION),STANDARD,mainScreenID);break;}
			case OVERRIDING:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_OVER_ADVANCE),mainJson.getJSONArray(DTNAME_OVER_CALCULATION),OVERRIDING,mainScreenID);break;}
			case PLB:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_PLB_ADVANCE),mainJson.getJSONArray(DTNAME_PLB_CALCULATION),PLB,mainScreenID);break;}
			case SEGMENTFEE:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_SEGMENT_ADVANCE),mainJson.getJSONArray(DTNAME_SEGMENT_CALCULATION),SEGMENTFEE,mainScreenID);break;}
			case SECTORWISEINCENTIVE:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_SECTOR_ADVANCE),mainJson.getJSONArray(DTNAME_SECTOR_CALCULATION),SECTORWISEINCENTIVE,mainScreenID);break;}
			case DESTINATIONINCENTIVE:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_DESTINATION_ADVANCE),mainJson.getJSONArray(DTNAME_DESTINATION_CALCULATION),DESTINATIONINCENTIVE,mainScreenID);break;}
			case MANAGEMENTFEE:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_MNGT_ADVANCE),mainJson.getJSONArray(DTNAME_MNGT_CALCULATION),MANAGEMENTFEE,mainScreenID);break;}
			case SERVICECHARHGE:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_SERVICE_ADVANCE),mainJson.getJSONArray(DTNAME_SERVICE_CALCULATION),SERVICECHARHGE,mainScreenID);break;}
			case PROP_DISCOUNT:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_DISCOUNT_ADVANCE),mainJson.getJSONArray(DTNAME_DISCOUNT_CALCULATION),PROP_DISCOUNT,mainScreenID);break;}
			case PROP_ISSUANCEFEES:{createRuleId_commercialId(mainJson.getJSONArray(DTNAME_ISSUANCE_ADVANCE),mainJson.getJSONArray(DTNAME_ISSUANCE_CALCULATION),PROP_ISSUANCEFEES,mainScreenID);break;}
			case MARKUP:{setMarkUpCommercialDetails(mainJson,productName,selectedRow,flightsAndNonAir,mdmCommDefn,clientCommercialDataID,mainScreenID);break;}
			}
		}
		return mainJson;
	}


	private static void setMarkUpCommercialDetails(JSONObject mainJson, String productName, String selectedRow, JSONObject flightsAndNonAir, JSONObject mdmCommDefn, String clientCommercialDataID, String mainScreenID) {
		JSONArray markUpArr = flightsAndNonAir.getJSONArray(PROP_markup);
		JSONArray advancedArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		for(int e=0;e<markUpArr.length();e++){
			JSONObject markUpObject = markUpArr.getJSONObject(e);
			String entityTypeString = PROP_CLIENT;
			JSONObject client = markUpObject.getJSONObject(PROP_CLIENT);
			if(client.get(PROP_PERCENTAGE).equals(0) && client.get(PROP_AMOUNT).equals(0))
				entityTypeString=PROP_COMPANY;
			
			clientCommercialDataID=clientCommercialDataID+"|markup|"+e+"|"+entityTypeString;
			setContractValidity(markUpObject, PROP_MARKUP,productName);
			JSONObject entityType = markUpObject.getJSONObject(entityTypeString);
			
			//minimum selling price
			if(entityTypeString.equals(PROP_COMPANY)){
				JSONObject markupToMinSellingPriceCompany = markUpObject.getJSONObject(PROP_MARKUP_MIN_SP_COMPANY);
				if(markupToMinSellingPriceCompany.has(PROP_AMOUNT) && !markupToMinSellingPriceCompany.get(PROP_AMOUNT).equals(0))
					minSellingPriceAmount = markupToMinSellingPriceCompany.get(PROP_AMOUNT).toString();
			}else{
				JSONObject markupToMinSellingPriceClient = markUpObject.getJSONObject(PROP_MARKUP_MIN_SP_CLIENT);
				if(markupToMinSellingPriceClient.has(PROP_AMOUNT) && !markupToMinSellingPriceClient.get(PROP_AMOUNT).equals(0))
					minSellingPriceAmount = markupToMinSellingPriceClient.get(PROP_AMOUNT).toString();
			}
			
			JSONObject markUpBase = new JSONObject();
			JSONObject markUpCalc = new JSONObject();
			markUpBase.put(TYPE, TYPE_ADVANCED);
			markUpBase.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+e);
			markUpBase.put(SELECTEDROW, selectedRow);
			markUpBase.put(COMMERCIAL_ID, mainScreenID+"_"+TYPE_ADVANCED+"_");
			markUpCalc.put(COMMERCIAL_ID, mainScreenID+"_"+TYPE_CALCULATION+"_");
			markUpBase.put(KEY, mainScreenID);
			markUpCalc.put(KEY, mainScreenID);
			markUpBase.put(AGENDAGROUP, selectedRow+"_"+MARKUP);
			markUpCalc.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+e);
			markUpCalc.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+e);
			markUpCalc.put(AGENDAGROUP, selectedRow+"_"+MARKUP);
			markUpCalc.put(TYPE, TYPE_CALCULATION);
			markUpCalc.put(MDMRULEID,clientCommercialDataID);
			JSONObject contractValidity = new JSONObject();
			if(markUpContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, markUpContractValidityFrom);
				contractValidity.put(PROP_TO, markUpContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, markUpContractValidityFrom);
			}
			markUpBase.put(CONTRACTVALIDITY, contractValidity);
			markUpCalc.put(MINIMUM_SELLING_PRICE, minSellingPriceAmount);
			if(entityType.has(PROP_CURRENCY))
				markUpCalc.put(PROP_CURRENCY, entityType.getString(PROP_CURRENCY));
			if(entityType.has(PROP_PERCENTAGE))
				markUpCalc.put(MARKUP_PERCENTAGE, entityType.get(PROP_PERCENTAGE).toString());
			if(entityType.has(PROP_AMOUNT))
				markUpCalc.put(MARKUP_AMOUNT, entityType.get(PROP_AMOUNT).toString());
			if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
				markUpCalc.put(FARECOMPONENT, getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS)));

			advancedArr.put(markUpBase);
			calcArr.put(markUpCalc);

			if(markUpObject.has(PROP_ADVDEFN_ID)){
				JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray(PROP_ADVDEFN_DATA);
				for(int k=0;k<advancedDefinitionData.length();k++){
					JSONObject advancedDefinitionObject = advancedDefinitionData.getJSONObject(k);
					if(markUpObject.getString(PROP_ADVDEFN_ID).equals(advancedDefinitionObject.getString(PROP_ID))){
						switch(productName){
						case PRODUCTNAME_AIR:{
							JSONObject advanceDefinitionAir = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_AIR);
							Air.setAdvancedDefinition(markUpBase,markUpCalc,advanceDefinitionAir,markUpObject.getString(PROP_ADVDEFN_ID),MARKUP);
							break;
						}
						case PRODUCTNAME_ACCOMODATION:{
							JSONObject advanceDefinitionAccommodation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_ACCO);
							Accomodation.appendAccomodationAdvancedDefinition(markUpBase,markUpCalc,advanceDefinitionAccommodation,MARKUP);
							break;
						}
						case PRODUCTNAME_ACTIVITIES:{
							JSONObject advanceDefinitionActivities = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_ACTIVITIES);
							setTransportationAdvancedDefinition(advanceDefinitionActivities, markUpBase, markUpCalc,MARKUP,true,true);
							break;
						}
						case PRODUCTNAME_CARRENTALS:{
							JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
							CarRentals.appendTransportationAdvancedDefinition(markUpBase,markUpCalc,advanceDefinitionTransportation,markUpObject.getString(PROP_ADVDEFN_ID),MARKUP);
							break;
						}
						case PRODUCTNAME_BUS:{
							JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
							setTransportationAdvancedDefinition(advanceDefinitionTransportation, markUpBase, markUpCalc,MARKUP,true,true);
							break;
						}
						case PRODUCTNAME_CRUISE:{
							JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
							CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation, markUpBase, markUpCalc,MARKUP,true,false);
							break;
						}
						case PRODUCTNAME_HOLIDAYS:{
							JSONObject advanceDefinitionHolidays = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN).getJSONObject(PROP_ADVDEFN_HOLIDAYS);
							Holidays.setHolidaysAdvancedDefinition(markUpBase,markUpCalc,advanceDefinitionHolidays,markUpObject.getString(PROP_ADVDEFN_ID), MARKUP, mainJson,mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD));
							break;
						}
						case PRODUCTNAME_TRANSFERS:{
							JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
							Transfers.appendTransportationAdvancedDefinition(markUpBase,markUpCalc,advanceDefinitionTransportation,markUpObject.getString(PROP_ADVDEFN_ID),MARKUP);
							break;
						}
						case PRODUCTNAME_RAIL:{}
						case PRODUCTNAME_INSURANCE:{}
						case PRODUCTNAME_VISA:{}
						default:System.out.println("Default of MarkUp Adv Defn coz of productName: "+productName);
						}
					}
				}
			}

			/*if(markUp.has("rateType"))
				markUpRateType = markUp.getString("rateType");*/
		}
		
		for(int i=0;i<calcArr.length();i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			String ruleId = calculation.getString(MDMRULEID)+"|"+calculation.getString(SELECTEDROW)+"|"+calculation.getString(AGENDAGROUP);
			calculation.put(MDMRULEID, ruleId);
		}
		
		mainJson.put(DTNAME_MARKUP_ADVANCE, advancedArr);
		mainJson.put(DTNAME_MARKUP_CALCULATION, calcArr);

	}


	public static void getOtherFeesDestination(JSONArray otherFeeArr, JSONObject advanceDefinitionTransportation, String commercialName){
		if(advanceDefinitionTransportation.getJSONObject(PROP_TRAVELDESTINATION).has(PROP_DESTINATIONS)){
			JSONArray destinationArray = advanceDefinitionTransportation.getJSONObject(PROP_TRAVELDESTINATION).getJSONArray(PROP_DESTINATIONS);
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<destinationArray.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject destinationObj = destinationArray.getJSONObject(j);
					if(advanceDefinitionTransportation.getJSONObject(PROP_TRAVELDESTINATION).getBoolean(PROP_BOOLEAN_ISINCLUSION)){
						if(destinationObj.has(PROP_CONTINENT) && !destinationObj.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destinationObj.getString(PROP_CONTINENT).length()!=0)
							otherFee.put(PROP_CONTINENT, destinationObj.getString(PROP_CONTINENT));
						if(destinationObj.has(PROP_COUNTRY) && !destinationObj.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destinationObj.getString(PROP_COUNTRY).length()!=0)
							otherFee.put(PROP_COUNTRY, destinationObj.getString(PROP_COUNTRY));
						if(destinationObj.has(PROP_STATE) && !destinationObj.getString(PROP_STATE).equalsIgnoreCase("All") && destinationObj.getString(PROP_STATE).length()!=0)
							otherFee.put(PROP_STATE, destinationObj.getString(PROP_STATE));
						if(destinationObj.has(PROP_CITY) && !destinationObj.getString(PROP_CITY).equalsIgnoreCase("All") && destinationObj.getString(PROP_CITY).length()!=0)
							otherFee.put(PROP_CITY, destinationObj.getString(PROP_CITY));
					}else{
						if(destinationObj.has(PROP_CONTINENT) && !destinationObj.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destinationObj.getString(PROP_CONTINENT).length()!=0)
							otherFee.put(PROP_CONTINENT+_EXCLUSION, destinationObj.getString(PROP_CONTINENT));
						if(destinationObj.has(PROP_COUNTRY) && !destinationObj.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destinationObj.getString(PROP_COUNTRY).length()!=0)
							otherFee.put(PROP_COUNTRY+_EXCLUSION, destinationObj.getString(PROP_COUNTRY));
						if(destinationObj.has(PROP_STATE) && !destinationObj.getString(PROP_STATE).equalsIgnoreCase("All") && destinationObj.getString(PROP_STATE).length()!=0)
							otherFee.put(PROP_STATE+_EXCLUSION, destinationObj.getString(PROP_STATE));
						if(destinationObj.has(PROP_CITY) && !destinationObj.getString(PROP_CITY).equalsIgnoreCase("All") && destinationObj.getString(PROP_CITY).length()!=0)
							otherFee.put(PROP_CITY+_EXCLUSION, destinationObj.getString(PROP_CITY));
					}
					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+"_"+PROP_DESTINATION+i+j);
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}


	public static void setOtherFeesTransportationAdvancedDefinition(JSONObject advanceDefinitionTransportation, JSONArray otherFeeArr, String commercialName) {
		//ancillary name, ancillary type, applicable on : not in schema
		if(advanceDefinitionTransportation.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionTransportation.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				setOtherFeesSalePlusTravel(validity.getJSONArray(PROP_SALEPLUSTRAVEL),otherFeeArr,commercialName);
			}
		}

		if(advanceDefinitionTransportation.has(PROP_TRAVELDESTINATION))
			getOtherFeesDestination(otherFeeArr, advanceDefinitionTransportation,commercialName);

		if(advanceDefinitionTransportation.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionTransportation.getJSONObject(PROP_OTHERS);
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				otherFee.put(BOOKINGTYPE, others.getString(BOOKINGTYPE));
			}
		}

		if(advanceDefinitionTransportation.has(CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionTransportation.getJSONObject(CONNECTIVITY);
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					otherFee.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					otherFee.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERID));
			}
		}

		if(advanceDefinitionTransportation.has(PROP_CREDENTIALS) && advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS).length()>0)
			getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS,true);

		if(advanceDefinitionTransportation.has(PROP_NATIONALITY) && advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY).length()>0)
			getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY), CLIENTNATIONALITY,true);

		if(advanceDefinitionTransportation.has(PAXTYPES) && advanceDefinitionTransportation.getJSONArray(PAXTYPES).length()>0)
			getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray(PAXTYPES), PAXTYPES,true);
	}


	public static void setDefaultAdvDefnID(String productName) {
		stdclientCommercialDataID=null;overclientCommercialDataID=null;plbclientCommercialDataID=null;segmentclientCommercialDataID=null;
		sectorclientCommercialDataID=null;destinationclientCommercialDataID=null;commissionclientCommercialDataID=null;issuanceclientCommercialDataID=null;
		serviceclientCommercialDataID=null;discountclientCommercialDataID=null;mngtclientCommercialDataID=null;markupclientCommercialDataID=null;
	}


	/*public static JSONArray getAncillaryDetails(String attribute, JSONArray ancillary) {
		JSONArray ancillaryName = new JSONArray();
		JSONArray ancillaryType = new JSONArray();
		for(int i=0;i<ancillary.length();i++){
			if(ancillary.getJSONObject(i).has(PROP_ANCILLARYNAME))
				ancillaryName.put(ancillary.getJSONObject(i).getString(PROP_ANCILLARYNAME));
			if(ancillary.getJSONObject(i).has(PROP_ANCILLARYTYPE))
				ancillaryType.put(ancillary.getJSONObject(i).getString(PROP_ANCILLARYTYPE));
		}
		if(attribute.equals(NAME))
			return ancillaryName;
		else return ancillaryType;
	}*/


	public static String getProductName(JSONObject mdmCommDefn) {
		String productCategory = mdmCommDefn.get(PROP_PRODUCTCATEGORY).toString();
		switch(productCategory){
		case MDM_PRODUCTNAME_ACCO:return PRODUCTNAME_ACCOMODATION;
		case MDM_PRODUCTNAME_ACTIVITIES: return PRODUCTNAME_ACTIVITIES;
		case MDM_PRODUCTNAME_HOLIDAYS: return PRODUCTNAME_HOLIDAYS;
		case MDM_PRODUCTNAME_OTHERS: {
			String subCategory = mdmCommDefn.get(PROP_SUBTYPE).toString();
			switch(subCategory){
			case MDM_PRODUCTNAME_INSURANCE: return PRODUCTNAME_INSURANCE;
			case MDM_PRODUCTNAME_VISA: return PRODUCTNAME_VISA;
			}
		}
		case MDM_PRODUCTNAME_TRANSPORTATION:{
			String subCategory = mdmCommDefn.get(PROP_SUBTYPE).toString();
			switch(subCategory){
			case MDM_PRODUCTNAME_BUS: return PRODUCTNAME_BUS;
			case MDM_PRODUCTNAME_CAR: return PRODUCTNAME_CARRENTALS;
			case MDM_PRODUCTNAME_CRUISE: return PRODUCTNAME_CRUISE;
			case MDM_PRODUCTNAME_EURORAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_FLIGHT: return PRODUCTNAME_AIR;
			case MDM_PRODUCTNAME_INDAINRAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_RAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_TRANSFER: return PRODUCTNAME_TRANSFERS;
			}
		}
		}
		return null;
	}


	public static boolean isTransactional(String commName) {
		switch(commName){
		case PROP_STD_COMM:{return true;}
		case PROP_OVER_COMM:{return true;}
		case PROP_PLB:{return true;}
		case PROP_SEGMENTFEES:{return true;}
		case PROP_SEGMENTSFEES:{return true;}
		case PROP_SECTORINCENTIVES:{return true;}
		case PROP_MANAGEMENTFEE:{return true;}
		case PROP_SERVICECHARGES:{return true;}
		case PROP_DISCOUNT:{return true;}
		case PROP_DESTINATIONINCENTIVES:{return true;}
		case PROP_ISSUANCEFEES:{return true;}
		case PROP_COMMISSION:{return true;}
		}
		return false;
	}


	public static void setRuleID(JSONArray advancedArr, JSONArray calculationArr, JSONObject base,JSONObject calculation, String ID) {
		/*String baseID = base.getString(RULEID);
		String calcID = calculation.getString(RULEID);
		base.put(RULEID, baseID+ID);
		calculation.put(RULEID, calcID+ID);
		calculation.put(SELECTEDROW, baseID+ID);*/
		advancedArr.put(base);
		calculationArr.put(calculation);
	}


	public static void getCalculationDetails(JSONArray commHead, String commercialName, String percentage, String amount, String fareComponent, String currency, JSONObject calculation){
		for(int j=0;j<commHead.length();j++){
			if(commHead.getJSONObject(j).get(COMMHEADNAME).toString().equals(commercialName)){
				switch(commHead.getJSONObject(j).getString(COMMPROPERTY)){
				case RETENTION:{
					calculation.put(RETENTION_PERCENTAGE, percentage);
					calculation.put(PROP_RETENTION_AMOUNT, amount);
					break;
				}
				case "Fixed":{
					calculation.put(RETENTION_PERCENTAGE, percentage);
					calculation.put(PROP_RETENTION_AMOUNT, amount);
					break;
				}
				case ADDITIONAL:{
					calculation.put(ADDITIONAL_PERCENTAGE, percentage);
					calculation.put(ADDITIONAL_AMOUNT, amount);
					calculation.put(FARECOMPONENT, fareComponent);
					calculation.put(PROP_CURRENCY, currency);
					break;
				}
				}
			}
		}
	}


	public static JSONObject getTriggerPayoutObject(JSONArray triggerOrPayout) {
		JSONObject triggerPayout = new JSONObject();
		boolean trigger=false,payout=false;
		for(int i=0;i<triggerOrPayout.length();i++){
			String value = triggerOrPayout.getString(i);
			if(value.equalsIgnoreCase(PROP_TRIGGER))
				trigger=true;

			if(value.equalsIgnoreCase(PROP_PAYOUT))
				payout=true;
		}
		triggerPayout.put(PROP_TRIGGER, trigger);
		triggerPayout.put(PROP_PAYOUT, payout);

		return triggerPayout;
	}


	public static void getTriggerPayoutArray(JSONArray baseArr, JSONArray calcArr, JSONArray array, String name, boolean inBase, String commercialName){
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<array.length();j++){
				JSONObject object = array.getJSONObject(j);
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				if(checkIfPayoutIsPresent(object.getJSONArray(PROP_TRIGGER_PAYOUT))){
					JSONArray requestArr = new JSONArray();
					JSONObject requestObject = new JSONObject();
					JSONObject triggerPayout = getTriggerPayoutObject(object.getJSONArray(PROP_TRIGGER_PAYOUT));
					requestArr.put(triggerPayout);
					requestObject.put(name, object.getString(name));
					requestArr.put(requestObject);
					if(inBase)
						base.put(name, requestArr);
					else calculation.put(name, requestArr);
				}
				setRuleID(baseArr,calcArr,base,calculation,commercialName+"_"+name+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getTriggerPayoutArrayIncExc(JSONArray baseArr, JSONArray calcArr, JSONArray roomTypes, String name, boolean isInclusion, boolean inBase, String commercialName) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<roomTypes.length();j++){
				JSONObject roomTypesObject = roomTypes.getJSONObject(j);
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				if(checkIfPayoutIsPresent(roomTypesObject.getJSONArray(PROP_TRIGGER_PAYOUT))){
					JSONObject triggerPayout = getTriggerPayoutObject(roomTypesObject.getJSONArray(PROP_TRIGGER_PAYOUT));
					JSONArray roomTypesArr = new JSONArray();
					JSONObject roomTypesInnerObject = new JSONObject();
					if(isInclusion)
						roomTypesInnerObject.put(name, roomTypesObject.getString(name));
					else roomTypesInnerObject.put(name+_EXCLUSION, roomTypesObject.getString(name));
					roomTypesArr.put(triggerPayout);
					roomTypesArr.put(roomTypesInnerObject);
					if(inBase)
						base.put(name, roomTypesArr);
					else calculation.put(name, roomTypesArr);
				}
				setRuleID(baseArr,calcArr,base,calculation,commercialName+"_"+name+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}

	}


	public static void getConnectivity(JSONArray baseArr, JSONObject connectivity) {
		if(checkIfPayoutIsPresent(connectivity.getJSONArray(PROP_TRIGGER_PAYOUT))){
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray(PROP_TRIGGER_PAYOUT));
				JSONArray connectivityArr = new JSONArray();
				JSONObject connectivityObject = new JSONObject();
				if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
					connectivityObject.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					connectivityObject.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERID));
				connectivityArr.put(triggerPayout);
				connectivityArr.put(connectivityObject);
				base.put(CONNECTIVITY, connectivityArr);
			}
		}
	}


	public static void getBookingType(JSONArray baseArr, JSONObject bookingType, boolean isInclusion) {
		if(checkIfPayoutIsPresent(bookingType.getJSONArray(PROP_TRIGGER_PAYOUT))){
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = getTriggerPayoutObject(bookingType.getJSONArray(PROP_TRIGGER_PAYOUT));
				JSONArray bookingTypeArr = new JSONArray();
				JSONObject bookingTypeObject = new JSONObject();
				if(isInclusion)
					bookingTypeObject.put(BOOKINGTYPE,bookingType.getString(BOOKINGTYPE));
				else bookingTypeObject.put(BOOKINGTYPE+_EXCLUSION,bookingType.getString(BOOKINGTYPE));
				bookingTypeArr.put(triggerPayout);
				bookingTypeArr.put(bookingTypeObject);
				base.put(BOOKINGTYPE, bookingTypeArr);
			}
		}
	}


	public static void getTriggerPayoutEnumValues(JSONArray baseArr, JSONArray triggerOrPayout, JSONArray jsonArray, String name, boolean isInclusion) {
		if(checkIfPayoutIsPresent(triggerOrPayout)){
			int length =baseArr.length();
			for(int i=0;i<length;i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = getTriggerPayoutObject(triggerOrPayout);
				JSONArray array = new JSONArray();
				array.put(triggerPayout);
				JSONObject object = new JSONObject();
				if(isInclusion)
					object.put(name, jsonArray);
				else object.put(name+_EXCLUSION, jsonArray);
				array.put(object);
				base.put(name, array);
			}
		}
	}


	public static void setOtherFeesRuleID(JSONArray otherFeeArr, JSONObject otherFee, String ID) {
		String otherFeeRuleID = otherFee.getString(RULEID)+ID;
		otherFee.put(RULEID, otherFeeRuleID);
		otherFeeArr.put(otherFee);
	}


	public static void setCalculationParameters(String commercialName, JSONObject calculation, JSONObject mainJson) {
		JSONArray commHead = new JSONArray(); 
		commHead = mainJson.getJSONObject(DTNAME_COMMDEFN).getJSONArray(PROP_COMMERCIALHEAD);
		switch(commercialName){
		case STANDARD:{getCalculationDetails(commHead,commercialName,stdPercentage,stdAmount,stdFareComponent,stdCurrency,calculation);break;}
		case OVERRIDING:{getCalculationDetails(commHead,commercialName,overPercentage,overAmount,overFareComponent,overCurrency,calculation);break;}
		case PLB:{getCalculationDetails(commHead,commercialName,plbPercentage,plbAmount,plbFareComponent,plbCurrency,calculation);break;}
		case SECTORWISEINCENTIVE:{getCalculationDetails(commHead,commercialName,sectorPercentage,sectorAmount,sectorFareComponent,sectorCurrency,calculation);break;}
		case DESTINATIONINCENTIVE:{getCalculationDetails(commHead,commercialName,destinationPercentage,destinationAmount,destinationFareComponent,destinationCurrency,calculation);break;}
		case SEGMENTFEE:{getCalculationDetails(commHead,commercialName,segmentPercentage,segmentAmount,segmentFareComponent,segmentCurrency,calculation);break;}
		case SERVICECHARHGE:{getCalculationDetails(commHead,commercialName,servicePercentage,serviceAmount,serviceFareComponent,serviceCurrency,calculation);break;}
		case MANAGEMENTFEE:{getCalculationDetails(commHead,commercialName,mngtPercentage,mngtAmount,mngtFareComponent,mngtCurrency,calculation);break;}
		case PROP_DISCOUNT:{getCalculationDetails(commHead,commercialName,discountPercentage,discountAmount,discountFareComponent,discountCurrency,calculation);break;}
		default:System.out.println("default of CommonFunctions.setCalculationParameters due to: "+commercialName);
		}
	}


	public static void setTransportationAdvancedDefinition(JSONObject advanceDefinitionTransportation, JSONObject advanced, JSONObject calculation, String commercialName, boolean isSalesInBase, boolean isTravelInBase) {
		//ancillary name, ancillary type, applicable on : not in schema
		baseArr.put(advanced);
		calcArr.put(calculation);
		if(advanceDefinitionTransportation.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionTransportation.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				insertSalePlusTravel(baseArr,calcArr,validity.getJSONArray(PROP_SALEPLUSTRAVEL),isSalesInBase,isTravelInBase,commercialName);
			}
		}
		if(advanceDefinitionTransportation.has(PROP_TRAVELDESTINATION)){
			JSONObject travelDestination = advanceDefinitionTransportation.getJSONObject(PROP_TRAVELDESTINATION);
			JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
			JSONObject destObject = destinations.getJSONObject(0);
			if(destObject.has(PROP_TRIGGER_PAYOUT) && destObject.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0){
				if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION))
					getDestinationTP(baseArr,calcArr,destinations,true,false,commercialName);//isBase : false
				else getDestinationTP(baseArr,calcArr,destinations,false,false,commercialName);//isBase : false
			}else{
				if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION))
					getDestination(baseArr,calcArr,destinations,true,false,commercialName);//isBase : false
				else getDestination(baseArr,calcArr,destinations,false,false,commercialName);//isBase : false
			}
		}

		if(advanceDefinitionTransportation.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionTransportation.getJSONObject(PROP_OTHERS);
			if(others.has(PROP_TRIGGER_PAYOUT) && others.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				getBookingTypeTP(baseArr, others.getJSONObject(BOOKINGTYPE), true);//isInclusion : true
			else{
				for(int i=0;i<baseArr.length();i++){
					JSONObject base = baseArr.getJSONObject(i);
					base.put(BOOKINGTYPE, others.getString(BOOKINGTYPE));//inBase
				}
			}
		}

		if(advanceDefinitionTransportation.has(CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionTransportation.getJSONObject(CONNECTIVITY);
			if(connectivity.has(PROP_TRIGGER_PAYOUT) && connectivity.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				getConnectivityTP(baseArr,connectivity);
			else{
				for(int i=0;i<baseArr.length();i++){
					JSONObject base = baseArr.getJSONObject(i);
					if(connectivity.has(PROP_SUPPLIERTYPE) && !connectivity.getString(PROP_SUPPLIERTYPE).equalsIgnoreCase("All"))
						base.put(CONNECTIVITYSUPPTYPE,connectivity.getString(PROP_SUPPLIERTYPE));
					if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
						base.put(CONNECTIVITYSUPPNAME,connectivity.getString(PROP_SUPPLIERID));
				}
			}
		}

		if(advanceDefinitionTransportation.has(PROP_CREDENTIALS) && advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS).length()>0){
			JSONObject credentials = advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS).getJSONObject(0);
			if(credentials.has(PROP_TRIGGER_PAYOUT) && credentials.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true,commercialName);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true);
		}

		if(advanceDefinitionTransportation.has(PROP_NATIONALITY) && advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY).length()>0){
			JSONObject nationality = advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY).getJSONObject(0);
			if(nationality.has(PROP_TRIGGER_PAYOUT) && nationality.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY), CLIENTNATIONALITY, true, true,commercialName);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY), CLIENTNATIONALITY, true, true);
		}

		if(advanceDefinitionTransportation.has(PAXTYPES) && advanceDefinitionTransportation.getJSONArray(PAXTYPES).length()>0){
			JSONObject passengerTypes = advanceDefinitionTransportation.getJSONArray(PAXTYPES).getJSONObject(0);
			if(passengerTypes.has(PROP_TRIGGER_PAYOUT) && passengerTypes.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PAXTYPES), PAXTYPES, true, false,commercialName);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PAXTYPES), PAXTYPES, true, false);
		}
	}


	public static void appendProductCategoryAndSubType(JSONObject ipJson, String productName, String productCategory, String productCategorySubType) {
		switch(productName){
		case PRODUCTNAME_ACCOMODATION:{
			ipJson.put(PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		case PRODUCTNAME_HOLIDAYS:{
			ipJson.put(PROP_PRODUCTCATEGORY, productCategory);
			ipJson.put(PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		}
	}


	public static void getDestination(JSONArray advancedArr, JSONArray calcArr, JSONArray destinations, boolean isInclusion, boolean inAdvanced, String commercialName) {
		if(destinations.length()>0){
			int length= calcArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<destinations.length();j++){
					JSONObject advanced = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject destination = destinations.getJSONObject(j);
					if(inAdvanced){
						if(isInclusion){
							if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
								advanced.put(PROP_CONTINENT, destination.getString(PROP_CONTINENT));
							if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
								advanced.put(PROP_COUNTRY, destination.getString(PROP_COUNTRY));
							if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
								advanced.put(PROP_STATE, destination.getString(PROP_STATE));
							if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
								advanced.put(PROP_CITY, destination.getString(PROP_CITY));
						}else{
							if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
								advanced.put(PROP_CONTINENT+_EXCLUSION, destination.getString(PROP_CONTINENT));
							if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
								advanced.put(PROP_COUNTRY+_EXCLUSION, destination.getString(PROP_COUNTRY));
							if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
								advanced.put(PROP_STATE+_EXCLUSION, destination.getString(PROP_STATE));
							if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
								advanced.put(PROP_CITY+_EXCLUSION, destination.getString(PROP_CITY));
						}
					}else{
						if(isInclusion){
							if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
								calculation.put(PROP_CONTINENT, destination.getString(PROP_CONTINENT));
							if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
								calculation.put(PROP_COUNTRY, destination.getString(PROP_COUNTRY));
							if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
								calculation.put(PROP_STATE, destination.getString(PROP_STATE));
							if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
								calculation.put(PROP_CITY, destination.getString(PROP_CITY));
						}else{
							if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
								calculation.put(PROP_CONTINENT+_EXCLUSION, destination.getString(PROP_CONTINENT));
							if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
								calculation.put(PROP_COUNTRY+_EXCLUSION, destination.getString(PROP_COUNTRY));
							if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
								calculation.put(PROP_STATE+_EXCLUSION, destination.getString(PROP_STATE));
							if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
								calculation.put(PROP_CITY+_EXCLUSION, destination.getString(PROP_CITY));
						}
					}
					setRuleID(advancedArr, calcArr, advanced, calculation, commercialName+"_"+PROP_DESTINATION+i+j);
				}
			}
			for(int i=0;i<length;i++){
				advancedArr.remove(0);
				calcArr.remove(0);
			}
		}
	}

	
	public static void getDestinationTP(JSONArray baseArr, JSONArray calcArr, JSONArray travel, boolean isInclusion, boolean inBase, String commercialName) {
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travel.length();j++){
				JSONObject object = travel.getJSONObject(j);
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				if(checkIfPayoutIsPresent(object.getJSONArray(PROP_TRIGGER_PAYOUT))){
					JSONObject triggerPayout = getTriggerPayoutObject(object.getJSONArray(PROP_TRIGGER_PAYOUT));
					JSONArray requestArr = new JSONArray();
					JSONObject requestObject = new JSONObject();
					requestArr.put(triggerPayout);
					if(isInclusion){
						if(object.has(PROP_CONTINENT) && !object.getString(PROP_CONTINENT).equalsIgnoreCase("All") && object.getString(PROP_CONTINENT).length()!=0)
							requestObject.put(PROP_CONTINENT, object.getString(PROP_CONTINENT));
						if(object.has(PROP_COUNTRY) && !object.getString(PROP_COUNTRY).equalsIgnoreCase("All") && object.getString(PROP_COUNTRY).length()!=0)
							requestObject.put(PROP_COUNTRY, object.getString(PROP_COUNTRY));
						if(object.has(PROP_STATE) && !object.getString(PROP_STATE).equalsIgnoreCase("All") && object.getString(PROP_STATE).length()!=0)
							requestObject.put(PROP_STATE, object.getString(PROP_STATE));
						if(object.has(PROP_CITY) && !object.getString(PROP_CITY).equalsIgnoreCase("All") && object.getString(PROP_CITY).length()!=0)
							requestObject.put(PROP_CITY, object.getString(PROP_CITY));
					}else{
						if(object.has(PROP_CONTINENT) && !object.getString(PROP_CONTINENT).equalsIgnoreCase("All") && object.getString(PROP_CONTINENT).length()!=0)
							requestObject.put(PROP_CONTINENT+_EXCLUSION, object.getString(PROP_CONTINENT));
						if(object.has(PROP_COUNTRY) && !object.getString(PROP_COUNTRY).equalsIgnoreCase("All") && object.getString(PROP_COUNTRY).length()!=0)
							requestObject.put(PROP_COUNTRY+_EXCLUSION, object.getString(PROP_COUNTRY));
						if(object.has(PROP_STATE) && !object.getString(PROP_STATE).equalsIgnoreCase("All") && object.getString(PROP_STATE).length()!=0)
							requestObject.put(PROP_STATE+_EXCLUSION, object.getString(PROP_STATE));
						if(object.has(PROP_CITY) && !object.getString(PROP_CITY).equalsIgnoreCase("All") && object.getString(PROP_CITY).length()!=0)
							requestObject.put(PROP_CITY+_EXCLUSION, object.getString(PROP_CITY));
					}
					requestArr.put(requestObject);
					if(inBase)
						base.put(PROP_TRAVELDESTINATION, requestArr);
					else calculation.put(PROP_TRAVELDESTINATION, requestArr);
					
				}
				setRuleID(baseArr,calcArr,base,calculation,commercialName+"_"+PROP_DESTINATION+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void setAmmendRequest(JSONObject budgetMarginAttachedTo, JSONObject mdmCommDefn, String productName, String kafkaMethod) throws Exception{
		String bookingId = budgetMarginAttachedTo.getString(PROP_BOOKINGID);
		JSONArray opsAmendments = budgetMarginAttachedTo.getJSONArray("opsAmendments");
		JSONObject mainJson = new JSONObject();
		for(int ops=0;ops<opsAmendments.length();ops++){
			JSONObject opsObject = opsAmendments.getJSONObject(ops);
			String commercialName = opsObject.getString("commercialName");
			String mdmRuleID = opsObject.getString(MDMRULEID);
			String[] values = mdmRuleID.split("\\|");
			for(int i=0;i<mdmCommDefn.getJSONArray(PROP_CLIENTCOMMDATA).length();i++){
				JSONObject clientCommercialData = mdmCommDefn.getJSONArray(PROP_CLIENTCOMMDATA).getJSONObject(i);
				if(clientCommercialData.getString(PROP_ID).equals(values[1])){
					JSONObject flightsAndNonAir = clientCommercialData.getJSONObject(PROP_COMMDETAILS).getJSONObject(PROP_FLIGHTSANDNONAIR);
					if(values[2].equals(PROP_markup)){
						JSONArray markup = flightsAndNonAir.getJSONArray(PROP_markup);
						for(int j=0;j<markup.length();j++){
							JSONObject markUp = markup.getJSONObject(Integer.parseInt(values[3]));
							JSONObject object = markUp.getJSONObject(values[4]);
							JSONObject calculation = new JSONObject();
							calculation.put(RULEID, mdmRuleID);
							calculation.put(COMMERCIAL_ID, values[1]+"_"+i);
							calculation.put(SELECTEDROW, values[5]);
							calculation.put(TYPE, TYPE_CALCULATION);
							calculation.put(AGENDAGROUP, values[6]);
							calculation.put(PROP_BOOKINGID, bookingId);
							if(object.has(PROP_PERCENTAGE) && !object.get(PROP_PERCENTAGE).equals(0))
								calculation.put(MARKUP_PERCENTAGE, object.get(PROP_PERCENTAGE).toString());
							if(object.has(PROP_AMOUNT) && !object.get(PROP_AMOUNT).equals(0))
								calculation.put(MARKUP_AMOUNT, object.get(PROP_AMOUNT).toString());
							if(object.has(PROP_CURRENCY))
								calculation.put(PROP_CURRENCY, object.getString(PROP_CURRENCY));
							if(object.has(PROP_FARECOMPONENTS) && object.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								calculation.put(FARECOMPONENT, getFareComponent(object.getJSONArray(PROP_FARECOMPONENTS)));
							calculation.put(MDMRULEID, mdmRuleID);
							calculation.put(PRIORITY, "1");
							mainJson.put(DTNAME_MARKUP_CALCULATION, calculation);
							if(productName.equals(PRODUCTNAME_HOLIDAYS)){
								mainJson.put(DTNAME_MARKUP_APPLICABLEON_CALCULATION, calculation);
							}
						}
					}else{
						String[] val = values[2].split("\\_");
						JSONArray array = flightsAndNonAir.getJSONObject(val[0]).getJSONArray(val[1]);
						for(int j=0;j<array.length();j++){
							JSONObject object = array.getJSONObject(Integer.parseInt(values[3]));
							JSONObject calcObject = object.getJSONObject(values[4]);
							JSONObject calculation = new JSONObject();
							calculation.put(RULEID, mdmRuleID);
							calculation.put(COMMERCIAL_ID, values[1]+"_"+i);
							calculation.put(SELECTEDROW, values[5]);
							calculation.put(PROP_BOOKINGID, bookingId);
							calculation.put(AGENDAGROUP, values[6]);
							calculation.put(TYPE, TYPE_CALCULATION);
							switch(val[0]){
							case PROP_ADDITIONALCOMMS:{
								if(calcObject.has(PROP_PERCENTAGE) && !calcObject.get(PROP_PERCENTAGE).equals(0))
									calculation.put(ADDITIONAL_PERCENTAGE, calcObject.get(PROP_PERCENTAGE).toString());
								if(calcObject.has(PROP_AMOUNT) && !calcObject.get(PROP_AMOUNT).equals(0))
									calculation.put(ADDITIONAL_AMOUNT, calcObject.get(PROP_AMOUNT).toString());
								if(calcObject.has(PROP_CURRENCY))
									calculation.put(PROP_CURRENCY, calcObject.getString(PROP_CURRENCY));
								if(calcObject.has(PROP_FARECOMPONENTS) && calcObject.getJSONArray(PROP_FARECOMPONENTS).length()>0)
									calculation.put(FARECOMPONENT, getFareComponent(calcObject.getJSONArray(PROP_FARECOMPONENTS)));
								break;
							}
							case PROP_RETENTIONCOMMERCIALS:{
								if(calcObject.has(PROP_PERCENTAGE) && !calcObject.get(PROP_PERCENTAGE).equals(0))
									calculation.put(RETENTION_PERCENTAGE, calcObject.get(PROP_PERCENTAGE).toString());
								if(calcObject.has(PROP_AMOUNT) && !calcObject.get(PROP_AMOUNT).equals(0))
									calculation.put(PROP_RETENTION_AMOUNT, calcObject.get(PROP_AMOUNT).toString());
								break;
							}
							}
							calculation.put(MDMRULEID, mdmRuleID);
							calculation.put(PRIORITY, "1");
							mainJson.put(getDecisionTableName(commercialName), calculation);
							if(productName.equals(PRODUCTNAME_HOLIDAYS))
								mainJson.put(getHolidaysDecisionTableName(commercialName), calculation);
						}
					}
				}
			}
		}
		Configuration.LOGGER.info(productName.toUpperCase()+" Transactional (bookingId): "+mainJson.toString());
		//System.out.println(productName.toUpperCase()+" Transactional (bookingId): "+mainJson.toString());
		Configuration.hitJSONService(mainJson,productName,kafkaMethod);
	}


	private static String getDecisionTableName(String commercialName) {
		switch(commercialName){
		case STANDARD: return DTNAME_STD_CALCULATION;
		case OVERRIDING: return DTNAME_OVER_CALCULATION;
		case PLB: return DTNAME_PLB_CALCULATION;
		case SECTORWISEINCENTIVE: return DTNAME_SECTOR_CALCULATION;
		case SEGMENTFEE: return DTNAME_SEGMENT_CALCULATION;
		case MANAGEMENTFEE: return DTNAME_MNGT_CALCULATION;
		case SERVICECHARHGE: return DTNAME_SERVICE_CALCULATION;
		case PROP_DISCOUNT: return DTNAME_DISCOUNT_CALCULATION;
		case DESTINATIONINCENTIVE: return DTNAME_DESTINATION_CALCULATION;
		/*case ISSUANCEFEE: return "IssuanceFeeClientCommercialCalculationDT";
		case PROP_COMMISSION: return "CommissionClientCommercialCalculationDT";*/
		default:System.out.println("default of getDecisionTableName due to: "+commercialName);
		}
		return null;
	}


	private static String getHolidaysDecisionTableName(String commercialName) {
		switch(commercialName){
		case STANDARD: return DTNAME_STD_APPLICABLEON_CALCULATION;
		case OVERRIDING: return DTNAME_OVER_APPLICABLEON_CALCULATION;
		case PLB: return DTNAME_PLB_APPLICABLEON_CALCULATION;
		case SECTORWISEINCENTIVE: return DTNAME_SECTOR_APPLICABLEON_CALCULATION;
		case SEGMENTFEE: return DTNAME_SEGMENT_APPLICABLEON_CALCULATION;
		case MANAGEMENTFEE: return DTNAME_MNGT_APPLICABLEON_CALCULATION;
		case SERVICECHARHGE: return DTNAME_SERVICE_APPLICABLEON_CALCULATION;
		case PROP_DISCOUNT: return DTNAME_DISCOUNT_APPLICABLEON_CALCULATION;
		case DESTINATIONINCENTIVE: return DTNAME_DESTINATION_APPLICABLEON_CALCULATION;
		/*case ISSUANCEFEE: return "IssuanceFeeClientCommercialCalculationDT";
		case PROP_COMMISSION: return "CommissionClientCommercialCalculationDT";*/
		default:System.out.println("default of getDecisionTableName due to: "+commercialName);
		}
		return null;
	}


	public static void appendCommercialHead(JSONArray jsonArray, String clientCommDataId_1, String productName, String commercialType, String commercialProperty, String clientCommDataId_2, JSONArray commHead, JSONObject mdmCommDefn, String supplier, String entityName, JSONArray entityMarket, String selectedRow, String productCategory, String productCategorySubType, String mainScreenID, boolean isCommissionable, JSONObject mainJson, JSONObject commDefn) throws Exception {
		for(int i=0;i<jsonArray.length();i++){
			JSONObject payableObject = jsonArray.getJSONObject(i);
			if(payableObject.has(PROP_COMMERCIALHEAD)){
				if(isTransactional(payableObject.getString(PROP_COMMERCIALHEAD))){
					if(payableObject.has(PROP_EFFECTIVE_DATES) && payableObject.getJSONObject(PROP_EFFECTIVE_DATES).has(PROP_FROM)){
						String entityTypeString = PROP_CLIENT;
						SettlementCommercials.entityType = PROP_CLIENT;
						JSONObject client = payableObject.getJSONObject(PROP_CLIENT);
						if(client.get(PROP_PERCENTAGE).equals(0) && client.get(PROP_AMOUNT).equals(0)){
							entityTypeString=PROP_COMPANY;
							SettlementCommercials.entityType = PROP_COMPANY;
						}

						String mdmRuleID = clientCommDataId_1+"|"+clientCommDataId_2+"|"+i+"|"+entityTypeString;
						String commercialHead = payableObject.getString(PROP_COMMERCIALHEAD);
						boolean otherHeads = false;
						setContractValidity(payableObject, commercialHead, productName);
						String commName = getCommercialName(commercialHead);

						JSONObject entityType = payableObject.getJSONObject(entityTypeString);
						if(entityType.has("type") && entityType.getString("type").equalsIgnoreCase("Fixed")){
							commercialProperty = "Fixed";
						}
						switch(commercialHead){
						case PROP_STD_COMM:{
							stdclientCommercialDataID = mdmRuleID;
							if(entityType.has(PROP_PERCENTAGE))
								stdPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								stdFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								stdCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								stdAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_OVER_COMM:{
							overclientCommercialDataID = mdmRuleID;
							if(entityType.has(PROP_PERCENTAGE))
								overPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								overFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								overCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								overAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_PLB:{
							plbclientCommercialDataID = mdmRuleID;
							if(payableObject.has(PROP_APPLICABLEON_ID) && payableObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
								otherHeads = true;
								plbapplicableOnArray=payableObject.getJSONArray(PROP_APPLICABLEON_ID);
							}
							if(entityType.has(PROP_PERCENTAGE))
								plbPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								plbFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								plbCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								plbAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_SEGMENTFEES:{
							segmentclientCommercialDataID = mdmRuleID;
							if(payableObject.has(PROP_APPLICABLEON_ID) && payableObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
								otherHeads = true;
								segmentapplicableOnArray=payableObject.getJSONArray(PROP_APPLICABLEON_ID);
							}
							if(entityType.has(PROP_PERCENTAGE))
								segmentPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								segmentFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								segmentCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								segmentAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_SEGMENTSFEES:{
							segmentclientCommercialDataID = mdmRuleID;
							if(payableObject.has(PROP_APPLICABLEON_ID) && payableObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0){
								otherHeads = true;
								segmentapplicableOnArray=payableObject.getJSONArray(PROP_APPLICABLEON_ID);
							}
							if(entityType.has(PROP_PERCENTAGE))
								segmentPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								segmentFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								segmentCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								segmentAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_SECTORINCENTIVES:{
							sectorclientCommercialDataID = mdmRuleID;
							if(entityType.has(PROP_PERCENTAGE))
								sectorPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								sectorFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								sectorCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								sectorAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_MANAGEMENTFEE:{
							mngtclientCommercialDataID = mdmRuleID;
							if(entityType.has(PROP_PERCENTAGE))
								mngtPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								mngtFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								mngtCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								mngtAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_SERVICECHARGES:{
							serviceclientCommercialDataID = mdmRuleID;
							if(payableObject.has(PROP_APPLICABLEON_ID) && payableObject.getJSONArray(PROP_APPLICABLEON_ID).length()>0)
								serviceapplicableOnArray = payableObject.getJSONArray(PROP_APPLICABLEON_ID);
							if(entityType.has(PROP_PERCENTAGE))
								servicePercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								serviceFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								serviceCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								serviceAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_DISCOUNT:{
							discountclientCommercialDataID = mdmRuleID;
							if(entityType.has(PROP_PERCENTAGE))
								discountPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								discountFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								discountCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								discountAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_COMMISSION:{
							commissionclientCommercialDataID = mdmRuleID;
							if(entityType.has(PROP_PERCENTAGE))
								commissionPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								commissionFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								commissionCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								commissionAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_ISSUANCEFEES:{
							issuanceclientCommercialDataID = mdmRuleID;
							if(entityType.has(PROP_PERCENTAGE))
								issuancePercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								issuanceFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								issuanceCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								issuanceAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						case PROP_DESTINATIONINCENTIVES:{
							destinationclientCommercialDataID = mdmRuleID;
							if(entityType.has(PROP_PERCENTAGE))
								destinationPercentage = entityType.get(PROP_PERCENTAGE).toString();
							if(entityType.has(PROP_FARECOMPONENTS) && entityType.getJSONArray(PROP_FARECOMPONENTS).length()>0)
								destinationFareComponent = getFareComponent(entityType.getJSONArray(PROP_FARECOMPONENTS));
							if(entityType.has(PROP_CURRENCY) && entityType.getString(PROP_CURRENCY).length()!=0)
								destinationCurrency = entityType.getString(PROP_CURRENCY);
							if(entityType.has(PROP_AMOUNT))
								destinationAmount = entityType.get(PROP_AMOUNT).toString();
							break;
						}
						default:System.out.println("default of appendCommercialHead > entityType due to commHead: "+commercialHead);
						}
						if(checkIfCommercialNameExist(commHead,commName,commercialProperty,mdmRuleID))
							appendCommercialHead(commName,commercialType,commercialProperty,isCommissionable,commDefn,commHead,mainJson);
						
						
						CommonFunctions.setInitialRequirements(mainJson,commName,selectedRow,mainScreenID,getAdvancedDTName(commName),getCalculationDTName(commName),mdmCommDefn,mdmRuleID,i,commercialType,commercialProperty,payableObject,productName);
						if(otherHeads)
							CommonFunctions.appendApplicableOnDetails(mainJson,commName,mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD));
						otherHeads = false;
					}
				}else{
					SettlementCommercials.entityType = PROP_CLIENT;
					JSONObject client = payableObject.getJSONObject(PROP_CLIENT);
					if(client.get(PROP_PERCENTAGE).equals(0) && client.get(PROP_AMOUNT).equals(0))
						SettlementCommercials.entityType = PROP_COMPANY;
					
					//Settlement Commercials
					if(payableObject.has(PROP_EFFECTIVE_DATES) && payableObject.getJSONObject(PROP_EFFECTIVE_DATES).has(PROP_FROM)){
						Configuration.settlement = true;
						Configuration.settlementString = SettlementCommercials.settlementCommercials(commercialType, productName, mdmCommDefn, payableObject, entityName, entityMarket, clientCommDataId_2, supplier, selectedRow, productCategory, productCategorySubType, i, mainScreenID);
					}
				}
			}
		}
	}


	private static boolean checkIfCommercialNameExist(JSONArray commHead, String commName, String commercialProperty, String commercialPath) {
		for(int i=0;i<commHead.length();i++){
			JSONObject commHeadObject = commHead.getJSONObject(i);
			if(commHeadObject.getString(COMMHEADNAME).equals(commName) && commHeadObject.getString(COMMPROPERTY).equals(commercialProperty)){
				return false;
			}
		}
		return true;
	}


	public static void setInitialRequirements(JSONObject mainJson, String commercialName, String selectedRow, String mainScreenID, String advancedDT, String calculationDT, JSONObject mdmCommDefn, String mdmRuleID, int i, String commercialType, String commercialProperty, JSONObject payableObject, String productName) {
		JSONObject advanced = new JSONObject();
		JSONObject calculation = new JSONObject();
		advanced.put(TYPE, TYPE_ADVANCED);
		calculation.put(TYPE, TYPE_CALCULATION);
		advanced.put(SELECTEDROW, selectedRow);
		advanced.put(CONTRACTVALIDITY, getContractValidity(commercialName));
		setRuleID(commercialName,advanced,calculation,selectedRow,mainScreenID,i,commercialType,commercialProperty);
		setCalculationParameters(commercialName,calculation,mainJson);
		mdmRuleID = mdmRuleID+"|"+calculation.getString(SELECTEDROW)+"|"+calculation.getString(AGENDAGROUP);
		calculation.put(MDMRULEID, mdmRuleID);
		if(commercialName.equals(SERVICECHARHGE))
			addOtherHeadDetails(advanced,mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD));
		serviceapplicableOnArray=null;
		
		if(mainJson.has(advancedDT)){
			mainJson.getJSONArray(advancedDT).put(advanced);
			mainJson.getJSONArray(calculationDT).put(calculation);
		}else{
			JSONArray advancedArr = new JSONArray();
			JSONArray calcArr = new JSONArray();
			advancedArr.put(advanced);
			calcArr.put(calculation);
			mainJson.put(advancedDT, advancedArr);
			mainJson.put(calculationDT, calcArr);
		}
		
		if(payableObject.has(PROP_ADVDEFN_ID)){
			mainJson.getJSONArray(advancedDT).remove(mainJson.getJSONArray(advancedDT).length()-1);
			mainJson.getJSONArray(calculationDT).remove(mainJson.getJSONArray(calculationDT).length()-1);
			setAdvancedDefiniton(commercialName, payableObject.getString(PROP_ADVDEFN_ID),productName,mdmCommDefn,advanced,calculation,mainJson);
			switch(productName){
			case PRODUCTNAME_AIR:{
				appendAdvancedDefinitionObjects(mainJson,commercialName,Air.advancedArr,Air.calcArr);
				Air.advancedArr = new JSONArray();
				Air.calcArr = new JSONArray();
				break;
			}
			case PRODUCTNAME_ACCOMODATION:{
				appendAdvancedDefinitionObjects(mainJson,commercialName,Accomodation.advancedArr,Accomodation.calcArr);
				Accomodation.advancedArr = new JSONArray();
				Accomodation.calcArr = new JSONArray();
				break;
			}
			case PRODUCTNAME_CARRENTALS:{
				appendAdvancedDefinitionObjects(mainJson,commercialName,CarRentals.advancedArr,CarRentals.calcArr);
				CarRentals.advancedArr = new JSONArray();
				CarRentals.calcArr = new JSONArray();
				break;
			}
			case PRODUCTNAME_TRANSFERS:{
				appendAdvancedDefinitionObjects(mainJson,commercialName,Transfers.advancedArr,Transfers.calcArr);
				Transfers.advancedArr = new JSONArray();
				Transfers.calcArr = new JSONArray();
				break;
			}
			case PRODUCTNAME_HOLIDAYS:{
				appendAdvancedDefinitionObjects(mainJson,commercialName,Holidays.baseArr,Holidays.calcArr);
				Holidays.baseArr = new JSONArray();
				Holidays.calcArr = new JSONArray();
				break;
			}
			case PRODUCTNAME_INSURANCE:{}
			case PRODUCTNAME_ACTIVITIES:{}
			case PRODUCTNAME_RAIL:{}
			case PRODUCTNAME_VISA:{}
			case PRODUCTNAME_CRUISE:{}
			case PRODUCTNAME_BUS:{}
			}
		}
	}


	public static void setAdvancedDefiniton(String commercialName, String advanceDefinitionId, String productName, JSONObject mdmCommDefn, JSONObject advanced, JSONObject calculation, JSONObject mainJson) {
		JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray(PROP_ADVDEFN_DATA);
		for(int i=0;i<advancedDefinitionData.length();i++){
			if(advanceDefinitionId.equals(advancedDefinitionData.getJSONObject(i).getString(PROP_ID))){
				JSONObject advancedDefinitionObject = advancedDefinitionData.getJSONObject(i).getJSONObject(PROP_ADVDEFN);
				switch(productName){
				case PRODUCTNAME_AIR:{
					JSONObject flights = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_AIR);
					if(!commercialName.equals(PLB))
						Air.setAdvancedDefinition(advanced,calculation,flights,advanceDefinitionId,commercialName);
					else Air.setPLBAdvancedDefinition(advanced,calculation,flights,advanceDefinitionId,commercialName);
					break;
				}
				case PRODUCTNAME_ACTIVITIES:{
					JSONObject advanceDefinitionActivities = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_ACTIVITIES);
					setTransportationAdvancedDefinition(advanceDefinitionActivities, advanced, calculation,commercialName,true,true);
					break;
				}
				case PRODUCTNAME_ACCOMODATION:{
					if(!commercialName.equals(PLB)){
						JSONObject advanceDefinitionAccommodation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_ACCO);
						Accomodation.appendAccomodationAdvancedDefinition(advanced,calculation,advanceDefinitionAccommodation,commercialName);
					}else{
						JSONObject advanceDefinitionAccommodationPLB = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_ACCO_PLB);
						Accomodation.appendPLBAccomodationCommercialsDetails(advanced,calculation,advanceDefinitionAccommodationPLB,commercialName);
					}
					break;
				}
				case PRODUCTNAME_CARRENTALS:{
					JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
					CarRentals.appendTransportationAdvancedDefinition(advanced,calculation,advanceDefinitionTransportation,advanceDefinitionId,commercialName);
					break;
				}
				case PRODUCTNAME_CRUISE:{
					JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
					setTransportationAdvancedDefinition(advanceDefinitionTransportation, advanced, calculation,commercialName,true,false);
					break;
				}
				case PRODUCTNAME_BUS:{
					JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
					setTransportationAdvancedDefinition(advanceDefinitionTransportation, advanced, calculation,commercialName,true,true);
					break;
				}
				case PRODUCTNAME_TRANSFERS:{
					JSONObject advanceDefinitionTransportation = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
					Transfers.appendTransportationAdvancedDefinition(advanced,calculation,advanceDefinitionTransportation,advanceDefinitionId,commercialName);
					break;
				}
				case PRODUCTNAME_HOLIDAYS:{
					Holidays.setBudgetedMarginDetails(calcArr.getJSONObject(calcArr.length()-1));
					JSONObject advanceDefinitionHolidays = advancedDefinitionObject.getJSONObject(PROP_ADVDEFN_HOLIDAYS);
					Holidays.setHolidaysAdvancedDefinition(advanced,calculation,advanceDefinitionHolidays,advanceDefinitionId,commercialName,mainJson,mdmCommDefn.getJSONArray(PROP_CLIENTCOMM_OTHERHEAD));
					break;
				}
				case PRODUCTNAME_INSURANCE:{}
				case PRODUCTNAME_RAIL:{}
				case PRODUCTNAME_VISA:{}
				}
			}
		}
	}


	private static void appendAdvancedDefinitionObjects(JSONObject mainJson, String commercialName, JSONArray advArr, JSONArray calArr) {
		String advancedDT = getAdvancedDTName(commercialName);
		String calculationDT = getCalculationDTName(commercialName);
		for(int j=0;j<advArr.length();j++){
			JSONArray advancedArr = mainJson.getJSONArray(advancedDT);
			JSONArray calcArr = mainJson.getJSONArray(calculationDT);
			advancedArr.put(advArr.getJSONObject(j));
			calcArr.put(calArr.getJSONObject(j));
		}
	}


	private static String getCalculationDTName(String commName) {
		switch(commName){
		case STANDARD: return DTNAME_STD_CALCULATION;
		case OVERRIDING: return DTNAME_OVER_CALCULATION;
		case PLB: return DTNAME_PLB_CALCULATION;
		case SEGMENTFEE: return DTNAME_SEGMENT_CALCULATION;
		case SECTORWISEINCENTIVE: return DTNAME_SECTOR_CALCULATION;
		case DESTINATIONINCENTIVE: return DTNAME_DESTINATION_CALCULATION;
		case MANAGEMENTFEE: return DTNAME_MNGT_CALCULATION;
		case SERVICECHARHGE: return DTNAME_SERVICE_CALCULATION;
		case PROP_DISCOUNT: return DTNAME_DISCOUNT_CALCULATION;
		case ISSUANCEFEE: return DTNAME_ISSUANCE_CALCULATION;
		//case PROP_COMMISSION: return DTNAME_COMMISSION_ADVANCE;
		}
		return null;
	}


	private static String getAdvancedDTName(String commName) {
		switch(commName){
		case STANDARD: return DTNAME_STD_ADVANCE;
		case OVERRIDING: return DTNAME_OVER_ADVANCE;
		case PLB: return DTNAME_PLB_ADVANCE;
		case SEGMENTFEE: return DTNAME_SEGMENT_ADVANCE;
		case SECTORWISEINCENTIVE: return DTNAME_SECTOR_ADVANCE;
		case DESTINATIONINCENTIVE: return DTNAME_DESTINATION_ADVANCE;
		case MANAGEMENTFEE: return DTNAME_MNGT_ADVANCE;
		case SERVICECHARHGE: return DTNAME_SERVICE_ADVANCE;
		case PROP_DISCOUNT: return DTNAME_DISCOUNT_ADVANCE;
		case ISSUANCEFEE: return DTNAME_ISSUANCE_ADVANCE;
		//case PROP_COMMISSION: return DTNAME_COMMISSION_ADVANCE;
		}
		return null;
	}


	private static void addOtherHeadDetails(JSONObject advanced, JSONArray clientCommercialOtherHead) {
		if(serviceapplicableOnArray!=null && serviceapplicableOnArray.length()>0){
			for(int i=0;i<serviceapplicableOnArray.length();i++){
				String applicableOnID = serviceapplicableOnArray.getString(i);
				for(int j=0;j<clientCommercialOtherHead.length();j++){
					JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
					if(applicableOnID.equals(clientCommercialOtherHeadObject.getString(PROP_ID))){
						if(clientCommercialOtherHeadObject.getJSONObject(PROP_COMMHEADS).getJSONArray(PROP_SERVICECHARGE_APPLICABLEON).length()>0)
							advanced.put(APPLICABLEON, clientCommercialOtherHeadObject.getJSONObject(PROP_COMMHEADS).getJSONArray(PROP_SERVICECHARGE_APPLICABLEON));
						else{
							JSONArray applicableOn = new JSONArray();
							applicableOn.put(PROP_OPNAME_BOOK);
							applicableOn.put(PROP_OPNAME_AMENDMENT);
							applicableOn.put(PROP_OPNAME_CANCELLATION);
							advanced.put(APPLICABLEON,applicableOn);
						}
					}
				}
			}
		}else{
			JSONArray applicableOn = new JSONArray();
			applicableOn.put(PROP_OPNAME_BOOK);
			applicableOn.put(PROP_OPNAME_AMENDMENT);
			applicableOn.put(PROP_OPNAME_CANCELLATION);
			advanced.put(APPLICABLEON,applicableOn);
		}
	}


	public static JSONObject getContractValidity(String commercialName) {
		JSONObject contractValidity = new JSONObject();
		switch(commercialName){
		case STANDARD:{
			if(stdContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, stdContractValidityFrom);
				contractValidity.put(PROP_TO, stdContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, stdContractValidityFrom);
			}
			break;
		}
		case OVERRIDING:{
			if(overContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, overContractValidityFrom);
				contractValidity.put(PROP_TO, overContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, overContractValidityFrom);
			}
			break;
		}
		case PLB:{
			if(plbContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, plbContractValidityFrom);
				contractValidity.put(PROP_TO, plbContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, plbContractValidityFrom);
			}
			break;
		}
		case SECTORWISEINCENTIVE:{
			if(sectorContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, sectorContractValidityFrom);
				contractValidity.put(PROP_TO, sectorContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, sectorContractValidityFrom);
			}
			break;
		}
		case DESTINATIONINCENTIVE:{
			if(destinationContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, destinationContractValidityFrom);
				contractValidity.put(PROP_TO, destinationContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, destinationContractValidityFrom);
			}
			break;
		}
		case SEGMENTFEE:{
			if(segmentContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, segmentContractValidityFrom);
				contractValidity.put(PROP_TO, segmentContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, segmentContractValidityFrom);
			}
			break;
		}
		case ISSUANCEFEE:{
			if(issuanceContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, issuanceContractValidityFrom);
				contractValidity.put(PROP_TO, issuanceContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, issuanceContractValidityFrom);
			}
			break;
		}
		case SERVICECHARHGE:{
			if(serviceContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, serviceContractValidityFrom);
				contractValidity.put(PROP_TO, serviceContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, serviceContractValidityFrom);
			}
			break;
		}
		case MANAGEMENTFEE:{
			if(managementContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, managementContractValidityFrom);
				contractValidity.put(PROP_TO, managementContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, managementContractValidityFrom);
			}
			break;
		}
		case PROP_DISCOUNT:{
			if(discountContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, discountContractValidityFrom);
				contractValidity.put(PROP_TO, discountContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, discountContractValidityFrom);
			}
			break;
		}
		case PROP_COMMISSION:{
			if(commissionContractValidityTo!=null){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(PROP_FROM, commissionContractValidityFrom);
				contractValidity.put(PROP_TO, commissionContractValidityTo);
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, commissionContractValidityFrom);
			}
			break;
		}
		default:System.out.println("default of getContractValidity due to: "+commercialName);
		}
		return contractValidity;
	}


	private static void setRuleID(String commercialName, JSONObject advanced, JSONObject calculation, String id, String mainScreenID, int i, String commercialType, String commercialProperty) {
		switch(commercialName){
		case STANDARD:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id+"_"+STANDARD);
			calculation.put(AGENDAGROUP, id+"_"+STANDARD);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case OVERRIDING:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id);
			calculation.put(AGENDAGROUP, id);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case PLB:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id);
			calculation.put(AGENDAGROUP, id);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case SECTORWISEINCENTIVE:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id);
			calculation.put(AGENDAGROUP, id);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case DESTINATIONINCENTIVE:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id);
			calculation.put(AGENDAGROUP, id);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case SEGMENTFEE:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id);
			calculation.put(AGENDAGROUP, id);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case SERVICECHARHGE:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id);
			calculation.put(AGENDAGROUP, id);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case MANAGEMENTFEE:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id);
			calculation.put(AGENDAGROUP, id);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case PROP_DISCOUNT:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id);
			calculation.put(AGENDAGROUP, id);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		case MARKUP:{
			advanced.put(RULEID, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			calculation.put(RULEID, TYPE_CALCULATION+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
			advanced.put(AGENDAGROUP, id+"_"+MARKUP);
			calculation.put(AGENDAGROUP, id+"_"+MARKUP);
			calculation.put(SELECTEDROW, TYPE_ADVANCED+"_"+mainScreenID+"_"+commercialName+"_"+commercialProperty+"_"+commercialType+"_"+i);
		}break;
		default:System.out.println("default of Accomodation.setRuleID due to: "+commercialName);
		}
	}


	public static void createRuleId_commercialId(JSONArray advancedArr, JSONArray calcArr, String commercialName, String mainScreenID) {
		for(int i=0;i<advancedArr.length();i++){
			JSONObject advanced = advancedArr.getJSONObject(i);
			JSONObject calculation = calcArr.getJSONObject(i);
			advanced.put(COMMERCIAL_ID, mainScreenID+"_"+commercialName+"_"+TYPE_ADVANCED+"_"+i);
			advanced.put(KEY, mainScreenID);
			calculation.put(COMMERCIAL_ID, mainScreenID+"_"+commercialName+"_"+TYPE_CALCULATION+"_"+i);
			calculation.put(KEY, mainScreenID);
		}
	}
	
	
	public static void setOtherFeesSalePlusTravel(JSONArray salePlusTravel, JSONArray otherFeeArr, String commercialName) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				boolean trigger = false, payout = false;
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject salePlusTravelObj = salePlusTravel.getJSONObject(j);
				JSONObject trigPayout = new JSONObject();
				if(salePlusTravelObj.has(PROP_TRIGGER_PAYOUT) && salePlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0){
					trigger = true;
					if(CommonFunctions.checkIfPayoutIsPresent(salePlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT))){
						payout = true;
						trigPayout = getTriggerPayoutObject(salePlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT));
					}
				}
				JSONArray saleArr = new JSONArray();
				JSONArray salesinclusionArr = new JSONArray();
				JSONArray salesexclusionArr = new JSONArray();
				JSONObject salesinclusionObject = new JSONObject();
				JSONObject salesexclusionObject = new JSONObject();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray travelArr = new JSONArray();
				JSONArray travelinclusionArr = new JSONArray();
				JSONArray travelexclusionArr = new JSONArray();
				JSONObject saleObj = salePlusTravelObj.getJSONObject(PROP_SALES);
				JSONObject travelObj = salePlusTravelObj.getJSONObject(PROP_TRAVEL);
				
				if((trigger && payout) || (!trigger && !payout)){
					switch(salePlusTravelObj.getString(PROP_VALIDITYTYPE).toLowerCase()){
					case PROP_SALES:{
						CommonFunctions.getDates(saleObj, salesinclusionArr, PROP_SALEFROM, PROP_SALETO,trigPayout,saleArr);
						CommonFunctions.getBlockOutDates(saleObj, salesexclusionArr,trigPayout,saleArr);
						break;
					}
					case PROP_SALE:{
						CommonFunctions.getDates(saleObj, salesinclusionArr, PROP_SALEFROM, PROP_SALETO,trigPayout,saleArr);
						CommonFunctions.getBlockOutDates(saleObj, salesexclusionArr,trigPayout,saleArr);
						break;
					}
					case PROP_TRAVEL:{
						CommonFunctions.getDates(travelObj, travelinclusionArr, PROP_TRAVELFROM, PROP_TRAVELTO,trigPayout,travelArr);
						CommonFunctions.getBlockOutDates(travelObj, travelinclusionArr,trigPayout,travelArr);
						break;
					}
					default:{
						CommonFunctions.getDates(saleObj, salesinclusionArr, PROP_SALEFROM, PROP_SALETO,trigPayout,saleArr);
						CommonFunctions.getBlockOutDates(saleObj, salesexclusionArr,trigPayout,saleArr);
						CommonFunctions.getDates(travelObj, travelinclusionArr, PROP_TRAVELFROM, PROP_TRAVELTO,trigPayout,travelArr);
						CommonFunctions.getBlockOutDates(travelObj, travelinclusionArr,trigPayout,travelArr);
					}
					}
				}
				
				if(salesinclusionArr.length()>0){
					salesinclusionObject.put(INCLUSION,salesinclusionArr);
					saleArr.put(salesinclusionObject);
				}
				if(salesexclusionArr.length()>0){
					salesexclusionObject.put(EXCLUSION,salesexclusionArr);
					saleArr.put(salesexclusionObject);
				}

				if(travelinclusionArr.length()>0){
					inclusionObject.put(INCLUSION,travelinclusionArr);
					travelArr.put(inclusionObject);
				}
				if(travelexclusionArr.length()>0){
					exclusionObject.put(EXCLUSION,travelexclusionArr);
					travelArr.put(exclusionObject);
				}
				
				if(saleArr.length()>0)
					otherFee.put(PROP_SALE, saleArr);
				if(travelArr.length()>0)
					otherFee.put(PROP_TRAVEL, travelArr);

				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+PROP_SALES+PROP_TRAVEL+i+j);
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}


	public static void insertSalePlusTravel(JSONArray baseArr, JSONArray calcArr, JSONArray salePlusTravel, boolean isSalesInBase, boolean isTravelInBase, String commercialName) {
		int length=baseArr.length();
		for(int j=0;j<length;j++){
			for(int i=0;i<salePlusTravel.length();i++){
				boolean trigger = false, payout = false;
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(j).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(j).toString()));
				JSONArray saleArray = new JSONArray();
				JSONObject trigPayout = new JSONObject();
				JSONArray travelArray = new JSONArray();
				JSONObject saleinclusion = new JSONObject();
				JSONObject saleexclusion = new JSONObject();
				JSONObject travelinclusion = new JSONObject();
				JSONObject travelexclusion = new JSONObject();
				JSONArray salesDateInclusionArr = new JSONArray();
				JSONArray travelDateInclusionArr = new JSONArray();
				JSONArray salesDateExclusionArr = new JSONArray();
				JSONArray travelDateExclusionArr = new JSONArray();
				
				JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(i);
				if(salePlusTravelObject.has(PROP_TRIGGER_PAYOUT) && salePlusTravelObject.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0){
					trigger = true;
					if(CommonFunctions.checkIfPayoutIsPresent(salePlusTravelObject.getJSONArray(PROP_TRIGGER_PAYOUT))){
						payout = true;
						trigPayout = getTriggerPayoutObject(salePlusTravelObject.getJSONArray(PROP_TRIGGER_PAYOUT));
					}
				}
				JSONObject sale = salePlusTravelObject.getJSONObject(PROP_SALES);
				JSONObject travel = salePlusTravelObject.getJSONObject(PROP_TRAVEL);
				if((trigger && payout) || (!trigger && !payout)){
					switch(salePlusTravelObject.getString(PROP_VALIDITYTYPE).toLowerCase()){
					case PROP_SALES:{
						getDates(sale,salesDateInclusionArr,PROP_SALEFROM,PROP_SALETO,trigPayout,saleArray);
						getBlockOutDates(sale, salesDateExclusionArr,trigPayout,saleArray);
						break;
					}
					case PROP_SALE:{
						getDates(sale,salesDateInclusionArr,PROP_SALEFROM,PROP_SALETO,trigPayout,saleArray);
						getBlockOutDates(sale, salesDateExclusionArr,trigPayout,saleArray);
						break;
					}
					case PROP_TRAVEL:{
						getDates(travel,travelDateInclusionArr,PROP_TRAVELFROM,PROP_TRAVELTO,trigPayout,travelArray);
						getBlockOutDates(travel, travelDateExclusionArr,trigPayout,travelArray);
						break;
					}
					default:{
						getDates(sale,salesDateInclusionArr,PROP_SALEFROM,PROP_SALETO,trigPayout,saleArray);
						getBlockOutDates(sale, salesDateExclusionArr,trigPayout,saleArray);
						getDates(travel,travelDateInclusionArr,PROP_TRAVELFROM,PROP_TRAVELTO,trigPayout,travelArray);
						getBlockOutDates(travel, travelDateExclusionArr,trigPayout,travelArray);
					}
					}
				}
				
				if(!salesDateInclusionArr.isNull(0)){
					saleinclusion.put(INCLUSION, salesDateInclusionArr);
					saleArray.put(saleinclusion);
				}
				if(!travelDateInclusionArr.isNull(0)){
					travelinclusion.put(INCLUSION, travelDateInclusionArr);
					travelArray.put(travelinclusion);
				}
				if(!salesDateExclusionArr.isNull(0)){
					saleexclusion.put(EXCLUSION, salesDateExclusionArr);
					saleArray.put(saleexclusion);
				}
				if(!travelDateExclusionArr.isNull(0)){
					travelexclusion.put(EXCLUSION, travelDateExclusionArr);
					travelArray.put(travelexclusion);
				}

				if(saleArray.length()>0){
					if(isSalesInBase)
						base.put(PROP_SALE, saleArray);
					else calculation.put(PROP_SALE, saleArray);
				}

				if(travelArray.length()>0){
					if(isTravelInBase)
						base.put(PROP_TRAVEL, travelArray);
					else calculation.put(PROP_TRAVEL, travelArray);
				}

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_SALES+PROP_TRAVEL+i+j);
			}
		}
		for(int j=0;j<length;j++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setOtherFeeTicketingPlusTravel(JSONArray otherFeeArr, JSONObject validity, String commercialName){
		if(validity.has(PROP_VALIDITYTYPE)){
			int length = otherFeeArr.length();
			JSONArray ticketingPlusTravel = validity.getJSONArray(PROP_TICKETINGPLUSTRAVEL);
			if(ticketingPlusTravel.length()>0){
				for(int i=0;i<length;i++){
					for(int j=0;j<ticketingPlusTravel.length();j++){
						boolean trigger = false, payout = false;
						JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
						JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(j);
						JSONArray tickincArr =new JSONArray();
						JSONArray tickexcArr =new JSONArray();
						JSONArray travelincArr =new JSONArray();
						JSONArray travelexcArr =new JSONArray();
						JSONArray ticketingDate = new JSONArray();
						JSONArray travelDate = new JSONArray();
						JSONObject inclusionTkt = new JSONObject();
						JSONObject exclusionTkt = new JSONObject();
						JSONObject inclusionTra = new JSONObject();
						JSONObject exclusionTra = new JSONObject();
						JSONObject trigPayout = new JSONObject();
						if(ticketPlusTravelObj.has(PROP_TRIGGER_PAYOUT) && ticketPlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0){
							trigger = true;
							if(CommonFunctions.checkIfPayoutIsPresent(ticketPlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT))){
								payout = true;
								trigPayout = getTriggerPayoutObject(ticketPlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT));
							}
						}

						JSONObject ticketingObject = ticketPlusTravelObj.getJSONObject(PROP_TICKET);
						JSONObject travelObject = ticketPlusTravelObj.getJSONObject(PROP_TRAVEL);
						if((trigger && payout) || (!trigger && !payout)){
							switch(ticketPlusTravelObj.getString(PROP_VALIDITYTYPE).toLowerCase()){
							case PROP_TICKETING:{
								getDates(ticketingObject, tickincArr, PROP_TICKETINGFROM, PROP_TICKETINGTO,trigPayout,ticketingDate);
								getBlockOutDates(ticketingObject, tickexcArr,trigPayout,ticketingDate);
								break;
							}
							case PROP_TRAVEL:{
								getDates(travelObject, travelincArr, PROP_TRAVELFROM, PROP_TRAVELTO,trigPayout,ticketingDate);
								getBlockOutDates(travelObject, travelexcArr,trigPayout,ticketingDate);
								break;
							}
							default:{
								getDates(ticketingObject, tickincArr, PROP_TICKETINGFROM, PROP_TICKETINGTO,trigPayout,ticketingDate);
								getBlockOutDates(ticketingObject, tickexcArr,trigPayout,ticketingDate);
								getDates(travelObject, travelincArr, PROP_TRAVELFROM, PROP_TRAVELTO,trigPayout,ticketingDate);
								getBlockOutDates(travelObject, travelexcArr,trigPayout,ticketingDate);
							}
							}
						}

						if(!tickincArr.isNull(0)){
							inclusionTkt.put(INCLUSION,tickincArr);
							ticketingDate.put(inclusionTkt);
						}
						if(!tickexcArr.isNull(0)){
							exclusionTkt.put(EXCLUSION,tickexcArr);
							ticketingDate.put(exclusionTkt);
						}
						if(!travelincArr.isNull(0)){
							inclusionTra.put(INCLUSION,travelincArr);
							travelDate.put(inclusionTra);
						}
						if(!travelexcArr.isNull(0)){
							exclusionTra.put(EXCLUSION,travelexcArr);
							travelDate.put(exclusionTra);
						}
						if(ticketingDate.length()>0)
							otherFee.put(PROP_TICKETING, ticketingDate);
						if(travelDate.length()>0)
							otherFee.put(PROP_TRAVEL, travelDate);

						setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+PROP_TICKETING+PROP_TRAVEL+i+j);
					}
				}
				for(int i=0;i<length;i++){
					otherFeeArr.remove(0);
				}
			}
		}
	}


	public static void setTicketingPlusTravel(JSONArray advancedArr, JSONArray calcArr, JSONObject validity, boolean isTicketingInBase, boolean isTravelInBase, String commercialName) {
		int length = advancedArr.length();
		JSONArray ticketingPlusTravel = validity.getJSONArray(PROP_TICKETINGPLUSTRAVEL);
		if(ticketingPlusTravel.length()>0){
			for(int i=0;i<length;i++){
				for(int j=0;j<ticketingPlusTravel.length();j++){
					boolean trigger = false, payout = false;
					JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(j);
					JSONObject trigPayout = new JSONObject();
					if(ticketPlusTravelObj.has(PROP_TRIGGER_PAYOUT) && ticketPlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT).length()>0){
						trigger = true;
						if(CommonFunctions.checkIfPayoutIsPresent(ticketPlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT))){
							payout = true;
							trigPayout = getTriggerPayoutObject(ticketPlusTravelObj.getJSONArray(PROP_TRIGGER_PAYOUT));
						}
					}
					JSONArray tickincArr =new JSONArray();
					JSONArray tickexcArr =new JSONArray();
					JSONArray travelincArr =new JSONArray();
					JSONArray travelexcArr =new JSONArray();
					JSONArray ticketingDate = new JSONArray();
					JSONArray travelDate = new JSONArray();
					JSONObject inclusionTkt = new JSONObject();
					JSONObject exclusionTkt = new JSONObject();
					JSONObject inclusionTra = new JSONObject();
					JSONObject exclusionTra = new JSONObject();

					JSONObject ticketingObject = ticketPlusTravelObj.getJSONObject(PROP_TICKET);
					JSONObject travelObject = ticketPlusTravelObj.getJSONObject(PROP_TRAVEL);
					if((trigger && payout) || (!trigger && !payout)){
						switch(ticketPlusTravelObj.getString(PROP_VALIDITYTYPE).toLowerCase()){
						case PROP_TICKETING:{
							getDates(ticketingObject,tickincArr,PROP_TICKETINGFROM,PROP_TICKETINGTO,trigPayout,ticketingDate);
							getBlockOutDates(ticketingObject, tickexcArr,trigPayout,ticketingDate);
							break;
						}
						case PROP_TRAVEL:{
							getDates(travelObject,travelincArr,PROP_TRAVELFROM,PROP_TRAVELTO,trigPayout,travelDate);
							getBlockOutDates(travelObject, travelexcArr,trigPayout,travelDate);
							break;
						}
						default:{
							getDates(ticketingObject,tickincArr,PROP_TICKETINGFROM,PROP_TICKETINGTO,trigPayout,ticketingDate);
							getBlockOutDates(ticketingObject, tickexcArr,trigPayout,ticketingDate);
							getDates(travelObject,travelincArr,PROP_TRAVELFROM,PROP_TRAVELTO,trigPayout,travelDate);
							getBlockOutDates(travelObject, travelexcArr,trigPayout,travelDate);
						}
						}
					}

					if(!tickincArr.isNull(0)){
						inclusionTkt.put(INCLUSION,tickincArr);
						ticketingDate.put(inclusionTkt);
					}
					if(!tickexcArr.isNull(0)){
						exclusionTkt.put(EXCLUSION,tickexcArr);
						ticketingDate.put(exclusionTkt);
					}
					if(!travelincArr.isNull(0)){
						inclusionTra.put(INCLUSION,travelincArr);
						travelDate.put(inclusionTra);
					}
					if(!travelexcArr.isNull(0)){
						exclusionTra.put(EXCLUSION,travelexcArr);
						travelDate.put(exclusionTra);
					}

					if(ticketingDate.length()>0){
						if(isTicketingInBase)
							base.put(PROP_TICKETING, ticketingDate);
						else calculation.put(PROP_TICKETING, ticketingDate);
					}

					if(travelDate.length()>0){
						if(isTravelInBase)
							base.put(PROP_TRAVEL, travelDate);
						else calculation.put(PROP_TRAVEL, travelDate);
					}
					setRuleID(advancedArr, calcArr, base, calculation, PROP_TICKETINGPLUSTRAVEL+i+j);
				}
			}
			for(int i=0;i<length;i++){
				advancedArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void getDates(JSONObject dateObject, JSONArray inclusionArray, String from, String to, JSONObject trigPayout, JSONArray mainDateArray) {
		JSONObject indiObj = new JSONObject();
		if(dateObject.has(from)){
			if(dateObject.has(to)){
				indiObj.put(OPERATOR,BETWEEN);
				indiObj.put(FROM, dateObject.getString(from).substring(0, 11)+"00:00:00");
				indiObj.put(TO, dateObject.getString(to).substring(0, 11)+"23:59:59");
			}else{
				indiObj.put(OPERATOR,GREATERTHANEQUALTO);
				indiObj.put(VALUE, dateObject.getString(from).substring(0, 11)+"00:00:00");
			}
		}else if(dateObject.has(to)){
			indiObj.put(OPERATOR,LESSTHANEQUALTO);
			indiObj.put(VALUE, dateObject.getString(to).substring(0, 11)+"23:59:59");
		}
		if(trigPayout.length()!=0 && trigPayout!=null && !trigPayout.toString().equals("{}"))
			mainDateArray.put(trigPayout);
		inclusionArray.put(indiObj);
	}


	public static void getBlockOutDates(JSONObject dateObject, JSONArray exclusionArray, JSONObject trigPayout, JSONArray mainDateArray) {
		if(dateObject.has(PROP_BLOCKOUT_FROM) && dateObject.getJSONArray(PROP_BLOCKOUT_FROM).length()>0){
			if(dateObject.has(PROP_BLOCKOUT_TO) && dateObject.getJSONArray(PROP_BLOCKOUT_TO).length()>0){
				JSONArray blockOutFrom = dateObject.getJSONArray(PROP_BLOCKOUT_FROM);
				JSONArray blockOutTo = dateObject.getJSONArray(PROP_BLOCKOUT_TO);
				if(trigPayout.length()!=0 && trigPayout!=null && !trigPayout.toString().equals("{}"))
					mainDateArray.put(trigPayout);
				for(int a=0;a<blockOutFrom.length();a++){
					JSONObject indiBlockObj = new JSONObject();
					indiBlockObj.put(OPERATOR, BETWEEN);
					indiBlockObj.put(FROM, blockOutFrom.getString(a).substring(0, 11)+"00:00:00");
					indiBlockObj.put(TO, blockOutTo.getString(a).substring(0, 11)+"23:59:59");
					exclusionArray.put(indiBlockObj);
				}
			}
		}
	}


	public static void appendApplicableOnDetails(JSONObject mainJson, String commercialName, JSONArray clientCommercialOtherHead) {
		JSONArray advancedArr = mainJson.getJSONArray(getAdvancedDTName(commercialName));
		JSONArray calculationArr = mainJson.getJSONArray(getCalculationDTName(commercialName));
		switch(commercialName){
		case PLB:{
			if(plbapplicableOnArray!=null && plbapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<plbapplicableOnArray.length();i++){
					String applicableOnID = plbapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString(PROP_ID))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								JSONObject plb = clientCommercialOtherHeadObject.getJSONObject(PROP_COMMHEADS).getJSONObject(PROP_PLB_OBJECT);
								if(CommonFunctions.plbOH.equals(SLAB)){
									JSONObject slab = plb.getJSONObject(SLAB);
									if(slab.has(SLABTYPE))
										calculation.put(SLABTYPE, slab.getString(SLABTYPE));
									calculation.put(SLABTYPEVALUE, BETWEEN+";"+slab.get(PROP_FROMVALUE)+";"+slab.get(PROP_TOVALUE));
								}else if(plb.has(PROP_RETENTION)){
									JSONObject retention = plb.getJSONObject(PROP_RETENTION);
									if(retention.has(SLABTYPE))
										calculation.put(SLABTYPE, retention.getString(SLABTYPE));
									String slabTypeValue=BETWEEN+";";
									JSONArray currencyDetails = retention.getJSONObject(PROP_DETAILS).getJSONArray(PROP_CURRENCYDETAILS);
									for(int k=0;k<currencyDetails.length();k++){
										JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
										slabTypeValue+=currencyDetailsObject.get(PROP_FROMVALUE)+";"+currencyDetailsObject.get(PROP_TOVALUE);
									}
									calculation.put(SLABTYPEVALUE, slabTypeValue);
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, PLB+"_"+SLABTYPE+i+j);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}
			plbapplicableOnArray = null;
			break;
		}
		case SEGMENTFEE:{
			if(segmentapplicableOnArray!=null && segmentapplicableOnArray.length()>0){
				int length = advancedArr.length();
				for(int i=0;i<segmentapplicableOnArray.length();i++){
					String applicableOnID = segmentapplicableOnArray.getString(i);
					for(int j=0;j<clientCommercialOtherHead.length();j++){
						JSONObject clientCommercialOtherHeadObject = clientCommercialOtherHead.getJSONObject(j);
						if(applicableOnID.equals(clientCommercialOtherHeadObject.getString(PROP_ID))){
							for(int m=0;m<length;m++){
								JSONObject calculation = new JSONObject(new JSONTokener(calculationArr.getJSONObject(m).toString()));
								JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(m).toString()));
								if(clientCommercialOtherHeadObject.has(PROP_COMMHEADS) && clientCommercialOtherHeadObject.getJSONObject(PROP_COMMHEADS).has(PROP_SEGEMNTFEES_OBJECT)){
									JSONObject segmentFees = clientCommercialOtherHeadObject.getJSONObject(PROP_COMMHEADS).getJSONObject(PROP_SEGEMNTFEES_OBJECT);
									calculation.put(SLABTYPE, segmentFees.getString(SLABTYPE));
									calculation.put(SLABTYPEVALUE, BETWEEN+";"+segmentFees.getString(PROP_FROMVALUE)+";"+segmentFees.getString(PROP_TOVALUE));
								}

								CommonFunctions.setRuleID(advancedArr, calculationArr, base, calculation, SEGMENTFEE+"_"+SLABTYPE+i+j);
							}
						}
					}
				}
				for(int m=0;m<length;m++){
					advancedArr.remove(0);
					calculationArr.remove(0);
				}
			}
			segmentapplicableOnArray = null;
		}
		}
	}


	public static void setMsfFeeDetails(JSONObject mdmCommDefn) throws Exception {
		JSONObject paymentOptionDetails = mdmCommDefn.getJSONObject(PROP_PAYMENTOPTION_DETAILS);
		JSONObject mainJson = new JSONObject();
		JSONObject commJson = new JSONObject();
		String commDefnID = paymentOptionDetails.getString(PROP_ID);
		commJson.put(RULEID, commDefnID);
		commJson.put(TYPE, TYPE_DEFN);
		commJson.put(COMMERCIAL_ID, commDefnID+"_"+MSFFEES+"_");
		commJson.put(KEY, commDefnID);
		commJson.put(ENTITYNAME, paymentOptionDetails.getString(PROP_ENTITYID));
		if(paymentOptionDetails.has(PROP_ENTITYMARKET) && !paymentOptionDetails.getString(PROP_ENTITYMARKET).equalsIgnoreCase("All"))
			commJson.put(PROP_ENTITYMARKET, paymentOptionDetails.getString(PROP_ENTITYMARKET));
		JSONArray commercialHeadArr = new JSONArray();
		JSONObject comm = new JSONObject();
		comm.put(COMMHEADNAME, MSFFEES);
		comm.put(COMMTYPE, RECEIVABLE);	//kya aap sure hai?
		comm.put(CONTRACTTYPE, FINAL);
		comm.put(BOOLEAN_ISAPPLICABLE, true);
		commercialHeadArr.put(comm);
		commJson.put(PROP_COMMERCIALHEAD, commercialHeadArr);
		mainJson.put(DTNAME_COMMDEFN, commJson);

		JSONArray msfArray = new JSONArray();
		String commID = commDefnID+"_"+MSFFEES+"_";
		JSONArray manageOfAquirers = paymentOptionDetails.getJSONArray(PROP_MANAGE_ACQUIRERS);
		boolean allProduct = false;
		for(int i=0;i<manageOfAquirers.length();i++){
			JSONObject msfFee = new JSONObject();
			msfFee.put(SELECTEDROW, commDefnID);
			msfFee.put(TYPE, MSFFEES);
			JSONObject manageOfAquirersObject = manageOfAquirers.getJSONObject(i);
			msfFee.put("mid", manageOfAquirersObject.getString("mid"));
			msfFee.put(KEY, commDefnID);
			msfFee.put(RULEID, manageOfAquirersObject.getString("mid")+"_"+commDefnID+"_"+manageOfAquirersObject.getString(PROP_ID)+"_"+i);
			msfFee.put(COMMERCIAL_ID, commID+i);
			JSONObject clientMSFFees = manageOfAquirersObject.getJSONObject(PROP_CLIENT_MSFFEES);
			if(clientMSFFees.has(PROP_AMOUNT) && !clientMSFFees.get(PROP_AMOUNT).equals(0))
				msfFee.put(PROP_AMOUNT, clientMSFFees.get(PROP_AMOUNT).toString());
			if(clientMSFFees.has(PROP_PERCENTAGE))
				msfFee.put(PROP_PERCENTAGE, clientMSFFees.get(PROP_PERCENTAGE).toString());
			if(manageOfAquirersObject.has(PROP_MODEOFPAYMENT))
				msfFee.put(PROP_MODEOFPAYMENT, manageOfAquirersObject.getString(PROP_MODEOFPAYMENT));
			if(msfFee.has(PROP_AMOUNT)){
				if(manageOfAquirersObject.has(PROP_CURRENCY))
					msfFee.put(PROP_CURRENCY, manageOfAquirersObject.getString(PROP_CURRENCY));
			}
			if(manageOfAquirersObject.has(PROP_CARDTYPE) && manageOfAquirersObject.getJSONArray(PROP_CARDTYPE).length()>0)
				msfFee.put(PROP_CARDTYPE, manageOfAquirersObject.getJSONArray(PROP_CARDTYPE));
			msfArray.put(msfFee);
			//mainJson.put(DTNAME_MSFFEE, msfFee);

			if(manageOfAquirersObject.has(PROP_ADV_APPLICABILITY) && manageOfAquirersObject.getJSONObject(PROP_ADV_APPLICABILITY).has(PROP_ADV_DEFN_ID)){
				String advanceDefinationId = manageOfAquirersObject.getJSONObject(PROP_ADV_APPLICABILITY).getString(PROP_ADV_DEFN_ID);
				JSONArray advancedDefinitionData = mdmCommDefn.getJSONArray(PROP_ADVDEFN_DATA);
				for(int j=0;j<advancedDefinitionData.length();j++){
					JSONObject advancedDefinitionDataObject = advancedDefinitionData.getJSONObject(j);
					if(advanceDefinationId.equals(advancedDefinitionDataObject.getString(PROP_ID))){
						JSONObject advanceApplicablity = advancedDefinitionDataObject.getJSONObject(PROP_ADV_APPLICABLITY);
						if(advanceApplicablity.has(PROP_PRODUCTDETAILS) && advanceApplicablity.getJSONArray(PROP_PRODUCTDETAILS).length()>0){
							if(msfArray.length()>0 && mainJson.has(DTNAME_MSFFEE)){
								msfArray.remove(msfArray.length()-1);
								for(int p=0;p<PRODUCTNAMES.length;p++){
									Configuration.LOGGER.info(PRODUCTNAMES[p].toUpperCase()+" Settlement (MSFFee): "+mainJson.toString());
									//System.out.println(PRODUCTNAMES[p].toUpperCase()+" Settlement (MSFFee): "+mainJson);
									Configuration.hitSettlementJSONService(mainJson.toString(), PRODUCTNAMES[p], Configuration.method);
								}
								allProduct = false;
								msfArray = new JSONArray();
							}
							JSONArray productDetails = advanceApplicablity.getJSONArray(PROP_PRODUCTDETAILS);
							for(int k=0;k<productDetails.length();k++){
								JSONObject productDetailsObject = productDetails.getJSONObject(k);
								String productName = getProductNameMsfFee(productDetailsObject);
								if(msfArray.length()<1)
									msfArray.put(msfFee);
								mainJson.put(DTNAME_MSFFEE, msfArray);
								Configuration.LOGGER.info(productName.toUpperCase()+" Settlement (MSFFee): "+mainJson.toString());
								//System.out.println(productName.toUpperCase()+" Settlement (MSFFee): "+mainJson);
								Configuration.hitSettlementJSONService(mainJson.toString(), productName, Configuration.method);
							}
							msfArray = new JSONArray();
						}
					}
				}
			}else{
				allProduct = true;
				mainJson.put(DTNAME_MSFFEE, msfArray);
			}
		}
		if(allProduct){
			for(int p=0;p<PRODUCTNAMES.length;p++){
				Configuration.LOGGER.info(PRODUCTNAMES[p].toUpperCase()+" Settlement (MSFFee): "+mainJson.toString());
				//System.out.println(PRODUCTNAMES[p].toUpperCase()+" Settlement (MSFFee): "+mainJson);
				Configuration.hitSettlementJSONService(mainJson.toString(), PRODUCTNAMES[p], Configuration.method);
			}
		}
	}


	public static String getProductNameMsfFee(JSONObject mdmCommDefn) {
		String productCategory = mdmCommDefn.getString(PROP_PRODUCTCATEGORY);
		switch(productCategory){
		case MDM_PRODUCTNAME_ACCO:return PRODUCTNAME_ACCOMODATION;
		case MDM_PRODUCTNAME_ACTIVITIES: return PRODUCTNAME_ACTIVITIES;
		case MDM_PRODUCTNAME_HOLIDAYS: return PRODUCTNAME_HOLIDAYS;
		case MDM_PRODUCTNAME_OTHERS: {
			String subCategory = mdmCommDefn.getString(PROP_PRODUCTCATEGORYSUBTYPE);
			switch(subCategory){
			case MDM_PRODUCTNAME_INSURANCE: return PRODUCTNAME_INSURANCE;
			case MDM_PRODUCTNAME_VISA: return PRODUCTNAME_VISA;
			}
		}
		case MDM_PRODUCTNAME_TRANSPORTATION:{
			String subCategory = mdmCommDefn.getString(PROP_PRODUCTCATEGORYSUBTYPE);
			switch(subCategory){
			case MDM_PRODUCTNAME_BUS: return PRODUCTNAME_BUS;
			case MDM_PRODUCTNAME_CAR: return PRODUCTNAME_CARRENTALS;
			case MDM_PRODUCTNAME_CRUISE: return PRODUCTNAME_CRUISE;
			case MDM_PRODUCTNAME_EURORAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_FLIGHT: return PRODUCTNAME_AIR;
			case MDM_PRODUCTNAME_INDAINRAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_RAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_TRANSFER: return PRODUCTNAME_TRANSFERS;
			}
		}
		}
		return null;
	}


	public static boolean checkIfPayoutIsPresent(JSONArray triggerOrPayout) {
		for(int i=0;i<triggerOrPayout.length();i++){
			if(triggerOrPayout.getString(i).toLowerCase().equals(PROP_PAYOUT))
				return true;
		}
		return false;
	}
}
