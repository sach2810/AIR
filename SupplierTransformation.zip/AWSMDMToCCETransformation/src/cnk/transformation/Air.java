package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Air implements Constants {
	
	public static String setCommercials(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception {
		if(baseArr.length()>0){
			JSONObject standardCommercial = CommonFunctions.stdComm;
			if(standardCommercial.has(PROP_PRODUCT)){
				JSONObject product = standardCommercial.getJSONObject(PROP_PRODUCT);
				if(product.has(PROP_TRANSPORTATION)){
					JSONObject transportation = product.getJSONObject(PROP_TRANSPORTATION);
					if(transportation.has(PROP_PRODUCT)){
						JSONObject product1 = transportation.getJSONObject(PROP_PRODUCT);
						if(product1.has(PROP_FLIGHT)){
							JSONObject flight = product1.getJSONObject(PROP_FLIGHT);
							if(flight.has(PROP_IATANOS) && flight.getJSONArray(PROP_IATANOS).length()>0)
								baseArr.getJSONObject(0).put(IATANO, flight.getJSONArray(PROP_IATANOS));
							if(flight.has(PROP_PRODUCTID) && flight.getJSONArray(PROP_PRODUCTID).length()>0){
								if(!flight.getJSONArray(PROP_PRODUCTID).getString(0).equalsIgnoreCase("All"))
									baseArr.getJSONObject(0).put(PROP_PRODUCTID, flight.getJSONArray(PROP_PRODUCTID));
							}
						}
					}
				}
			}

			if(standardCommercial.has(PROP_ADVDEFN_ID)){
				for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(i);
					if(advanceDefinationData.getString(PROP_ID).equals(standardCommercial.getString(PROP_ADVDEFN_ID))){
						JSONObject advanceDefinitionAir = advanceDefinationData.getJSONObject(PROP_ADVDEFN_AIR);
						setAirAdvancedDefinition(baseArr,calcArr,advanceDefinitionAir,STANDARD);
					}
				}
			}

			JSONArray commercialHead = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
			CommonFunctions.setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,CommonFunctions.mdmRuleID,CommonFunctions.suppCommDataId);
			CommonFunctions.setCommercialId(mainJson,CommonFunctions.suppCommDataId);
		}
		//System.out.println("Air Transactional: "+mainJson.toString());
		return mainJson.toString();
	}


	public static void setPLBAdvancedDefinition(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String commercialName, String id) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			if(advanceDefinitionAir.has(PROP_VALIDITY)){
				JSONObject validity = advanceDefinitionAir.getJSONObject(PROP_VALIDITY);
				if(validity.has(PROP_VALIDITYTYPE)){
					CommonFunctions.setTicketingPlusTravel(baseArr,calcArr,validity,true,false,commercialName);
				}
			}

			if(advanceDefinitionAir.has(PROP_CONNECTIVITY))
				getTriggerPayoutConnectivity(baseArr,advanceDefinitionAir.getJSONObject(PROP_CONNECTIVITY));

			if(advanceDefinitionAir.has(PROP_CREDENTIALS) && advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS).length()>0)
				CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS),PROP_CREDENTIALID,true,commercialName);

			if(advanceDefinitionAir.has(PROP_OTHERS)){
				JSONObject others = advanceDefinitionAir.getJSONObject(PROP_OTHERS);
				if(others.has(PROP_BOOKINGTYPE))
					CommonFunctions.getBookingTypeTP(baseArr,others,true);
			}

			if(advanceDefinitionAir.has(PROP_BOOKINGCLASS)){
				JSONObject bookingClass = advanceDefinitionAir.getJSONObject(PROP_BOOKINGCLASS);
				setAirBookingTypeTP(baseArr, calcArr, bookingClass,commercialName);
			}

			if(advanceDefinitionAir.has(PROP_FLIGHTTIMINGS))
				getFlightTimingsNumbersTP(baseArr,calcArr,advanceDefinitionAir.getJSONObject(PROP_FLIGHTTIMINGS),PROP_FLIGHTTIMINGS,PROP_FLIGHTTIME_FROM,PROP_FLIGHTTIME_TO,commercialName);

			if(advanceDefinitionAir.has(PROP_FLIGHTNUMBERS))
				getFlightTimingsNumbersTP(baseArr,calcArr,advanceDefinitionAir.getJSONObject(PROP_FLIGHTNUMBERS),PROP_FLIGHTRANGE,PROP_FLIGHTRANGE_FROM,PROP_FLIGHTRANGE_TO,commercialName);

			if(advanceDefinitionAir.has(PROP_PASSENGERTYPES) && advanceDefinitionAir.getJSONArray(PROP_PASSENGERTYPES).length()>0)
				CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAir.getJSONArray(PROP_PASSENGERTYPES),PROP_PASSENGERTYPES,false,commercialName);
			
			if(advanceDefinitionAir.has(PROP_FARECLASS)){
				if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_FAREBASIS)){
					JSONObject fareBasis = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_FAREBASIS);
					JSONArray fare = fareBasis.getJSONArray(PROP_FARE);
					if(fareBasis.has(PROP_BOOLEAN_ISINCLUSION)){
						if(fareBasis.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							getFareBasisTP(baseArr,calcArr,fare,true,commercialName);
						else getFareBasisTP(baseArr,calcArr,fare,false,commercialName);
					}
				}

				if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_DEALCODES)){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_DEALCODES);
					if(dealCodes.has(PROP_BOOLEAN_ISINCLUSION)){
						if(dealCodes.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							CommonFunctions.getTriggerPayoutArrayIncExc(baseArr, calcArr, dealCodes.getJSONArray(PROP_DEALCODES), DEALCODE, true, false,commercialName);
						else CommonFunctions.getTriggerPayoutArrayIncExc(baseArr, calcArr, dealCodes.getJSONArray(PROP_DEALCODES), DEALCODE, false, false,commercialName);
					}
				}
			}

			if(advanceDefinitionAir.has(PROP_TRAVELDEST)){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST);
				if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
					if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
						if(travelDestination.has(PROP_SOLDANDTICKETINGOPTIONS) && travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS).length()>0)
							CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS),TRAVELTYPE,true);

						if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
							CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),travelDestination.getJSONArray(PROP_JOURNEYTYPE),PROP_JOURNEYTYPE,true);

						if(travelDestination.has(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
							getCodeSharedFlightIncludedTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED),travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),true);
						
						if(travelDestination.has(PROP_BOOLEAN_ISDIRCTFLIGHTS))
							getFlightTypeTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_ISDIRCTFLIGHTS),travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),true);
						
						if(travelDestination.has(PROP_BOOLEAN_ISONLINE))
							getFlightLineTypeTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE),travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),true);
						
						if(travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
							JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
							JSONArray travelProductNameArr = new JSONArray();
							for(int d=0;d<destinations.length();d++){
								JSONObject destObj = destinations.getJSONObject(d);
								if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
									for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
										travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
								}
							}
							if(travelProductNameArr.length()>0)
								getTravelProductNameTP(calcArr,travelProductNameArr,travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),true);
						}
					}else{
						if(travelDestination.has(PROP_SOLDANDTICKETINGOPTIONS) && travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS).length()>0)
							CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS),TRAVELTYPE,false);

						if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
							CommonFunctions.getTriggerPayoutEnumValues(baseArr,travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),travelDestination.getJSONArray(PROP_JOURNEYTYPE),PROP_JOURNEYTYPE,false);

						if(travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
							getCodeSharedFlightIncludedTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED),travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),false);

						if(travelDestination.has(PROP_BOOLEAN_ISDIRCTFLIGHTS))
							getFlightTypeTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_ISDIRCTFLIGHTS),travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),false);

						if(travelDestination.has(PROP_BOOLEAN_ISONLINE))
							getFlightLineTypeTP(calcArr,travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE),travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),false);

						if(travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
							JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
							JSONArray travelProductNameArr = new JSONArray();
							for(int d=0;d<destinations.length();d++){
								JSONObject destObj = destinations.getJSONObject(d);
								if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
									for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
										travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
								}
							}
							if(travelProductNameArr.length()>0)
								getTravelProductNameTP(calcArr,travelProductNameArr,travelDestination.getJSONArray(PROP_TRIGGERPAYOUT),true);
						}
					}
				}
			}
		}
		
		int lengthCalc = calcArr.length();
		JSONObject travelDestination = advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST);
		JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
		if(destinations.length()>0){
			for(int d=0;d<lengthCalc;d++){
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(d).toString()));
				JSONArray dest = new JSONArray();
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(travelDestination.getJSONArray(PROP_TRIGGERPAYOUT));
				dest.put(triggerPayout);
				dest.put(setAirDestination(INCLUSION,advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST).getJSONArray(PROP_JOURNEYTYPE),new JSONObject(),destinations));
				calculation.put(DESTINATION, dest);
				calcArr.put(calculation);
			}
			for(int d=0;d<lengthCalc;d++){
				calcArr.remove(0);
			}
		}
	}


	private static void setAirBookingTypeTP(JSONArray baseArr, JSONArray calcArr, JSONObject bookingClass, String commercialName) {
		JSONArray cabin = bookingClass.getJSONArray(PROP_CABIN);
		if(cabin.length()>0){
			String cabinString="",rbdString="",triggerString="",payoutString="";
			for(int j=0;j<cabin.length();j++){
				boolean insert = false;
				JSONObject cabinObject = cabin.getJSONObject(j);
				JSONArray triggerPayout = cabinObject.getJSONArray(PROP_TRIGGERPAYOUT);
				for(int i=0;i<triggerPayout.length();i++){
					if(triggerPayout.getString(i).equalsIgnoreCase(PAYOUT))
						insert = true;
				}
				
				if(insert){
					if(cabinObject.has(PROP_CABINCLASS) && !cabinObject.getString(PROP_CABINCLASS).equalsIgnoreCase("All")){
						if(j==0)
							cabinString=cabinObject.getString(PROP_CABINCLASS);
						else cabinString+=";"+cabinObject.getString(PROP_CABINCLASS);
					}else{
						if(j==0)
							cabinString="null";
						else cabinString+=";null";
					}
					if(cabinObject.has(PROP_RBD) && !cabinObject.getString(PROP_RBD).equalsIgnoreCase("All")){
						if(j==0)
							rbdString=cabinObject.getString(PROP_RBD);
						else rbdString+=";"+cabinObject.getString(PROP_RBD);
					}else{
						if(j==0)
							rbdString="null";
						else rbdString+=";null";
					}
					
					for(int i=0;i<triggerPayout.length();i++){
						if(triggerPayout.getString(i).toLowerCase().equalsIgnoreCase(PAYOUT)){
							if(j==0){
								payoutString="true";
								triggerString="true";
							}else{
								payoutString+=";true";
								triggerString+=";true";
							}
						}
					}
				}
			}
			
			JSONObject cabinJson= new JSONObject();
			if(triggerString!="" && payoutString!=""){
				cabinJson.put("trigger", triggerString);
				cabinJson.put("payout", payoutString);
			}
			
			if(bookingClass.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
				cabinJson.put("cabinClass", cabinString);
				cabinJson.put("rbd", rbdString);
			}else{
				cabinJson.put("cabinClass_exclusion", cabinString);
				cabinJson.put("rbd_exclusion", rbdString);
			}
			
			for(int i=0;i<calcArr.length();i++){
				JSONObject calc = calcArr.getJSONObject(i);
				calc.put("airCabinClass", cabinJson);
			}
		}
	}


	public static void getAirBookingClass(JSONObject advanceDefinitionAir, JSONObject calculation) {
		if(advanceDefinitionAir.has(PROP_BOOKINGCLASS)){
			JSONObject bookingClass = advanceDefinitionAir.getJSONObject(PROP_BOOKINGCLASS);
			if(bookingClass.has(PROP_CABIN) && bookingClass.getJSONArray(PROP_CABIN).length()>0){
				JSONArray cabin = bookingClass.getJSONArray(PROP_CABIN);
				String cabinString="",rbdString="";
				for(int k=0;k<cabin.length();k++){
					JSONObject cabinObj = cabin.getJSONObject(k);
					if(cabinObj.has(PROP_CABINCLASS) && !cabinObj.getString(PROP_CABINCLASS).equalsIgnoreCase("All")){
						if(k==0)
							cabinString=cabinObj.getString(PROP_CABINCLASS);
						else cabinString+=";"+cabinObj.getString(PROP_CABINCLASS);
					}else{
						if(k==0)
							cabinString="null";
						else cabinString+=";null";
					}
					if(cabinObj.has(PROP_RBD) && !cabinObj.getString(PROP_RBD).equalsIgnoreCase("All")){
						if(k==0)
							rbdString=cabinObj.getString(PROP_RBD);
						else rbdString+=";"+cabinObj.getString(PROP_RBD);
					}else{
						if(k==0)
							rbdString="null";
						else rbdString+=";null";
					}
				}
				
				if(bookingClass.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
					calculation.put(PROP_CABINCLASS, cabinString);
					calculation.put(PROP_RBD, rbdString);
				}else{
					calculation.put(PROP_CABINCLASS+"_"+EXCLUSION, cabinString);
					calculation.put(PROP_RBD+"_"+EXCLUSION, rbdString);
				}
			}
		}
	}


	private static void getFareBasisTP(JSONArray baseArr, JSONArray calcArr, JSONArray fare, boolean isInclusion, String commercialName) {
		if(fare.length()>0){
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<fare.length();j++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject fareObject = fare.getJSONObject(j);
					JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(fareObject.getJSONArray(PROP_TRIGGERPAYOUT));
					JSONArray fareArr = new JSONArray();
					JSONArray fareBasisArr = new JSONArray();
					fareArr.put(triggerPayout);
					fareBasisArr.put(fareObject.getString(PROP_CONDITION));
					fareBasisArr.put(fareObject.getString(VALUE));
					JSONObject FareObject = new JSONObject();
					if(isInclusion)
						FareObject.put(PROP_FAREBASISVALUE, fareBasisArr);
					else FareObject.put(PROP_FAREBASISVALUE+"_"+EXCLUSION, fareBasisArr);
					fareArr.put(FareObject);
					calculation.put(PROP_FAREBASISVALUE,fareArr);

					CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_FAREBASISVALUE+i+j);
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	private static void getTravelProductNameTP(JSONArray calcArr, JSONArray travelProductNameArr, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isInclusion)
				flightObject.put(TRAVELPRODUCTNAME, travelProductNameArr);
			else flightObject.put(TRAVELPRODUCTNAME+"_"+EXCLUSION, travelProductNameArr);
			flightArr.put(flightObject);
			calculation.put(TRAVELPRODUCTNAME, flightArr);
		}
	}


	private static void getFlightLineTypeTP(JSONArray calcArr, boolean isOnline, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isOnline){
				if(isInclusion)
					flightObject.put(FLIGHTLINETYPE, ONLINE);
				else flightObject.put(FLIGHTLINETYPE+"_"+EXCLUSION, ONLINE);
			}else{
				if(isInclusion)
					flightObject.put(FLIGHTLINETYPE, OFFLINE);
				else flightObject.put(FLIGHTLINETYPE+"_"+EXCLUSION, OFFLINE);
			}
			flightArr.put(flightObject);
			calculation.put(FLIGHTLINETYPE, flightArr);
		}
	}


	private static void getFlightTypeTP(JSONArray calcArr, boolean isDirectFlight, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray flightArr = new JSONArray();
			flightArr.put(triggerPayout);
			JSONObject flightObject = new JSONObject();
			if(isDirectFlight){
				if(isInclusion)
					flightObject.put(FLIGHTTYPE, DIRECT);
				else flightObject.put(FLIGHTTYPE+"_"+EXCLUSION, DIRECT);
			}else{
				if(isInclusion)
					flightObject.put(FLIGHTTYPE, VIA);
				else flightObject.put(FLIGHTTYPE+"_"+EXCLUSION, VIA);
			}
			flightArr.put(flightObject);
			calculation.put(FLIGHTTYPE, flightArr);
		}
	}


	private static void getCodeSharedFlightIncludedTP(JSONArray calcArr, boolean codeSharedFlightIncluded, JSONArray triggerOrPayout, boolean isInclusion) {
		int length = calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			JSONObject code = new JSONObject();
			JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(triggerOrPayout);
			JSONArray codeArr = new JSONArray();
			codeArr.put(triggerPayout);
			if(isInclusion)
				code.put(CODESHAREDFLIGHTINCLUDED, codeSharedFlightIncluded);
			else code.put(CODESHAREDFLIGHTINCLUDED+"_"+EXCLUSION, codeSharedFlightIncluded);
			codeArr.put(code);
			calculation.put(CODESHAREDFLIGHTINCLUDED, codeArr);
		}
	}


	private static void getFlightTimingsNumbersTP(JSONArray baseArr, JSONArray calcArr, JSONObject flightTiming, String arrayName, String from, String to, String commercialName) {
		int length=baseArr.length();
		JSONArray flighTimeArr = flightTiming.getJSONArray(arrayName);
		if(flighTimeArr.length()>0){
			for(int i=0;i<length;i++){
				for(int j=0;j<flighTimeArr.length();j++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject timeObject = flighTimeArr.getJSONObject(j);
					JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(timeObject.getJSONArray(PROP_TRIGGERPAYOUT));
					JSONArray timeArr = new JSONArray();
					timeArr.put(triggerPayout);
					JSONObject timeObjectMain = new JSONObject();
					if(timeObject.has(from)){
						if(timeObject.has(to)){
							String time = BETWEEN+";"+timeObject.get(from)+";"+timeObject.get(to);
							if(flightTiming.getBoolean(PROP_BOOLEAN_ISINCLUSION))
								timeObjectMain.put(arrayName, time);
							else timeObjectMain.put(arrayName+"_"+EXCLUSION, time);
						}else{
							String time = GREATERTHANEQUALTO+";"+timeObject.get(from);
							if(flightTiming.getBoolean(PROP_BOOLEAN_ISINCLUSION))
								timeObjectMain.put(arrayName, time);
							else timeObjectMain.put(arrayName+"_"+EXCLUSION, time);
						}
					}else if(timeObject.has(to)){
						String time = LESSTHANEQUALTO+";"+timeObject.get(to);
						if(flightTiming.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							timeObjectMain.put(arrayName, time);
						else timeObjectMain.put(arrayName+"_"+EXCLUSION, time);
					}
					timeArr.put(timeObjectMain);
					calculation.put(arrayName, timeArr);
					CommonFunctions.setRuleID(baseArr,calcArr,base,calculation,commercialName+PROP_FLIGHTTIMINGS+i+j);
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void setAirAdvancedDefinition(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String commercialName) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
			JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));

			if(advanceDefinitionAir.has(PROP_CONNECTIVITY)){
				JSONObject connectivity = advanceDefinitionAir.getJSONObject(PROP_CONNECTIVITY);
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					base.put(CONN_SUPPTYPE, connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPID) && !connectivity.getString(PROP_SUPPID).equalsIgnoreCase("All"))
					base.put(CONN_SUPPNAME, connectivity.getString(PROP_SUPPID));
			}

			if(advanceDefinitionAir.has(PROP_CREDENTIALS) && advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS).length()>0){
				JSONArray credentials = advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS);
				JSONArray crentialsArr = new JSONArray();
				for(int cr=0;cr<credentials.length();cr++){
					crentialsArr.put(credentials.getJSONObject(cr).getString(PROP_CREDENTIALID));
				}
				base.put(CREDENTIALSNAME, crentialsArr);
			}

			if(advanceDefinitionAir.has(PROP_OTHERS)){
				if(advanceDefinitionAir.getJSONObject(PROP_OTHERS).has(PROP_BOOKINGTYPE))
					base.put(PROP_BOOKINGTYPE, advanceDefinitionAir.getJSONObject(PROP_OTHERS).getString(PROP_BOOKINGTYPE));
			}

			getAirBookingClass(advanceDefinitionAir, calculation);

			if(advanceDefinitionAir.has(PROP_PASSENGERTYPES) && advanceDefinitionAir.getJSONArray(PROP_PASSENGERTYPES).length()>0){
				JSONArray passengerTypes  = advanceDefinitionAir.getJSONArray(PROP_PASSENGERTYPES);
				JSONArray paxType = new JSONArray();
				for(int pt=0;pt<passengerTypes.length();pt++){
					paxType.put(passengerTypes.getJSONObject(pt).getString(PASSENGERTYPE));
				}
				calculation.put(PASSENGERTYPE, paxType);
			}

			if(advanceDefinitionAir.has(PROP_TRAVELDEST)){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST);
				if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
					if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
						if(travelDestination.has(PROP_SOLDANDTICKETINGOPTIONS) && travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS).length()>0)
							base.put(TRAVELTYPE, travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS));

						if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
							base.put(PROP_JOURNEYTYPE, travelDestination.getJSONArray(PROP_JOURNEYTYPE));

						if(travelDestination.has(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
							calculation.put(CODESHAREFLIGHTINCLUDED, travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED));

						if(travelDestination.has(PROP_BOOLEAN_ISDIRCTFLIGHTS)){
							if(travelDestination.getBoolean(PROP_BOOLEAN_ISDIRCTFLIGHTS))
								calculation.put(FLIGHTTYPE, DIRECT);
							else calculation.put(FLIGHTTYPE, VIA);
						}

						if(travelDestination.has(PROP_BOOLEAN_ISONLINE)){
							if(travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE))
								calculation.put(FLIGHTLINETYPE, ONLINE);
							else calculation.put(FLIGHTLINETYPE, OFFLINE);
						}

						JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
						JSONArray travelProductNameArr = new JSONArray();
						for(int d=0;d<destinations.length();d++){
							JSONObject destObj = destinations.getJSONObject(d);
							if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
							}
						}
						if(travelProductNameArr.length()>0)
							calculation.put(TRAVELPRODUCTNAME, travelProductNameArr);

						setAirDestination(INCLUSION,advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST).getJSONArray(PROP_JOURNEYTYPE),calculation,destinations);
					}else{
						if(travelDestination.has(PROP_SOLDANDTICKETINGOPTIONS) && travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS).length()>0)
							base.put(TRAVELTYPE+"_"+EXCLUSION, travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS));

						if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
							base.put(PROP_JOURNEYTYPE+"_"+EXCLUSION, travelDestination.getJSONArray(PROP_JOURNEYTYPE));

						if(travelDestination.has(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
							calculation.put(CODESHAREFLIGHTINCLUDED+"_"+EXCLUSION, travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED));

						if(travelDestination.has(PROP_BOOLEAN_ISDIRCTFLIGHTS)){
							if(travelDestination.getBoolean(PROP_BOOLEAN_ISDIRCTFLIGHTS))
								calculation.put(FLIGHTTYPE+"_"+EXCLUSION, DIRECT);
							else calculation.put(FLIGHTTYPE+"_"+EXCLUSION, VIA);
						}

						if(travelDestination.has(PROP_BOOLEAN_ISONLINE)){
							if(travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE))
								calculation.put(FLIGHTLINETYPE+"_"+EXCLUSION, ONLINE);
							else calculation.put(FLIGHTLINETYPE+"_"+EXCLUSION, OFFLINE);
						}

						JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
						JSONArray travelProductNameArr = new JSONArray();
						for(int d=0;d<destinations.length();d++){
							JSONObject destObj = destinations.getJSONObject(d);
							if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
								for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
									travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
							}
						}
						if(travelProductNameArr.length()>0)
							calculation.put(TRAVELPRODUCTNAME+"_"+EXCLUSION, travelProductNameArr);

						setAirDestination(EXCLUSION,advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST).getJSONArray(PROP_JOURNEYTYPE),calculation,destinations);
					}
				}
			}

			if(advanceDefinitionAir.has(PROP_FARECLASS)){
				if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_DEALCODES)){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_DEALCODES);
					JSONArray dealCodesArr = dealCodes.getJSONArray(PROP_DEALCODES);
					JSONArray dealcode= new JSONArray();
					for(int dc=0;dc<dealCodesArr.length();dc++){
						dealcode.put(dealCodesArr.getJSONObject(dc).getString(PROP_DEALCODES));
					}
					if(dealcode.length()>0){
						if(dealCodes.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							calculation.put(DEALCODE, dealcode);
						else calculation.put(DEALCODE+"_"+EXCLUSION, dealcode);
					}
				}
			}
			baseArr.put(base);
			calcArr.put(calculation);
		}
		for(int w=0;w<length;w++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
		if(advanceDefinitionAir.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionAir.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				CommonFunctions.setTicketingPlusTravel(baseArr,calcArr,advanceDefinitionAir.getJSONObject(PROP_VALIDITY),true,false,commercialName);
			}
		}
		getFlightTimings(baseArr,calcArr,advanceDefinitionAir,commercialName);
		getFlightNumbers(baseArr,calcArr,advanceDefinitionAir,commercialName);
		setFareBasisValue(advanceDefinitionAir,calcArr,baseArr,commercialName);
	}


	private static void setFareBasisValue(JSONObject advanceDefinitionAir, JSONArray calcArr, JSONArray baseArr, String commercialName) {
		if(advanceDefinitionAir.has(PROP_FARECLASS)){
			if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_FAREBASIS) && advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_FAREBASIS).getJSONArray(PROP_FARE).length()>0){
				int length =calcArr.length();
				for(int i=0;i<length;i++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONArray fare = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_FAREBASIS).getJSONArray(PROP_FARE);
					for(int f=0;f<fare.length();f++){
						JSONObject fareObject = fare.getJSONObject(f);
						JSONArray fareArr = new JSONArray();
						if(fareObject.has(PROP_CONDITION))
							fareArr.put(fareObject.getString(PROP_CONDITION));
						if(fareObject.has(VALUE))
							fareArr.put(fareObject.getString(VALUE));
						calculation.put(PROP_FAREBASISVALUE, fareArr);

						CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+"_"+PROP_FARECLASS+i+f);
					}
				}
				for(int i=0;i<length;i++){
					baseArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
	}


	private static void getFlightNumbers(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String commercialName) {
		if(advanceDefinitionAir.has(PROP_FLIGHTNUMBERS)){
			if(advanceDefinitionAir.getJSONObject(PROP_FLIGHTNUMBERS).getJSONArray(PROP_FLIGHTRANGE).length()>0){
				JSONArray flightRange = advanceDefinitionAir.getJSONObject(PROP_FLIGHTNUMBERS).getJSONArray(PROP_FLIGHTRANGE);
				if(flightRange.length()>0){
					int length = baseArr.length();
					for(int i=0;i<length;i++){
						for(int j=0;j<flightRange.length();j++){
							JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
							JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
							JSONObject flightObject  = flightRange.getJSONObject(j);
							String numbers=null;
							if(flightObject.has(PROP_FLIGHTRANGE_FROM)){
								if(flightObject.has(PROP_FLIGHTRANGE_TO))
									numbers=BETWEEN+";"+flightObject.get(PROP_FLIGHTRANGE_FROM)+";"+flightObject.get(PROP_FLIGHTRANGE_TO);
								else numbers=GREATERTHANEQUALTO+";"+flightObject.get(PROP_FLIGHTRANGE_FROM);
							}else if(flightObject.has(PROP_FLIGHTRANGE_TO))
								numbers=LESSTHANEQUALTO+";"+flightObject.get(PROP_FLIGHTRANGE_TO);

							if(advanceDefinitionAir.getJSONObject(PROP_FLIGHTNUMBERS).getBoolean(PROP_BOOLEAN_ISINCLUSION))
								calculation.put(FLIGHTNUMBER, numbers);
							else calculation.put(FLIGHTNUMBER+"_"+EXCLUSION, numbers);

							CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_FLIGHTNUMBERS+i+j);
						}
					}
					for(int i=0;i<length;i++){
						baseArr.remove(0);
						calcArr.remove(0);
					}
				}
			}
		}
	}


	private static void getFlightTimings(JSONArray baseArr, JSONArray calcArr, JSONObject advanceDefinitionAir, String commercialName) {
		if(advanceDefinitionAir.has(PROP_FLIGHTTIMINGS)){
			if(advanceDefinitionAir.getJSONObject(PROP_FLIGHTTIMINGS).getJSONArray(PROP_FLIGHTTIMINGS).length()>0){
				JSONArray flightTimings = advanceDefinitionAir.getJSONObject(PROP_FLIGHTTIMINGS).getJSONArray(PROP_FLIGHTTIMINGS);
				int length = baseArr.length();
				for(int i=0;i<length;i++){
					for(int m=0;m<flightTimings.length();m++){
						JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
						JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
						JSONObject flightTimingObj = flightTimings.getJSONObject(m);
						String timing = null;
						if(flightTimingObj.has(PROP_FLIGHTTIME_FROM)){
							JSONObject flightTimeFrom = flightTimingObj.getJSONObject(PROP_FLIGHTTIME_FROM);
							String from = flightTimeFrom.get(PROP_HOUR)+":"+flightTimeFrom.get(PROP_MINUTES)+":"+flightTimeFrom.get(PROP_SECOND);
							if(flightTimingObj.has(PROP_FLIGHTTIME_TO)){
								JSONObject flightTimeTo = flightTimingObj.getJSONObject(PROP_FLIGHTTIME_TO);
								String to = flightTimeTo.get(PROP_HOUR)+":"+flightTimeTo.get(PROP_MINUTES)+":"+flightTimeTo.get(PROP_SECOND);
								timing=BETWEEN+";"+from+";"+to;
							}else timing=GREATERTHANEQUALTO+";"+from;
						}else if(flightTimingObj.has(PROP_FLIGHTTIME_TO)){
							JSONObject flightTimeTo = flightTimingObj.getJSONObject(PROP_FLIGHTTIME_TO);
							String to = flightTimeTo.get(PROP_HOUR)+":"+flightTimeTo.get(PROP_MINUTES)+":"+flightTimeTo.get(PROP_SECOND);
							timing=LESSTHANEQUALTO+";"+to;
						}
						if(advanceDefinitionAir.getJSONObject(PROP_FLIGHTTIMINGS).getBoolean(PROP_BOOLEAN_ISINCLUSION))
							calculation.put(FLIGHTTIMING, timing);
						else calculation.put(FLIGHTTIMING+"_"+EXCLUSION, timing);	

						CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_FLIGHTTIMINGS+i+m);
					}
				}
				for(int i=0;i<length;i++){
					baseArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
	}


	private static JSONObject setAirDestination(String incExc, JSONArray journeyType, JSONObject calculation, JSONArray destinations) {
		if(destinations.length()>0){
			String continentMain=null,countryMain=null,cityMain=null,journeyTypeString=null;
			for(int i=0;i<journeyType.length();i++){
				if(i==0)
					journeyTypeString=journeyType.getString(i);
				else journeyTypeString+="&"+journeyType.getString(i);
			}
			for(int i=0;i<destinations.length();i++){
				JSONObject continent = new JSONObject();
				if(destinations.getJSONObject(i).has(PROP_CONTINENT))
					continent = destinations.getJSONObject(i).getJSONObject(PROP_CONTINENT);
				JSONObject country = new JSONObject();
				if(destinations.getJSONObject(i).has(PROP_COUNTRY))
					country = destinations.getJSONObject(i).getJSONObject(PROP_COUNTRY);
				JSONObject city = new JSONObject();
				if(destinations.getJSONObject(i).has(PROP_CITY))
					city = destinations.getJSONObject(i).getJSONObject(PROP_CITY);
				if(i==0){
					if(continent.length()>0){
						if(continent.has(PROP_VIA) && continent.getString(PROP_VIA).length()!=0){
							if(continent.has(FROM) && continent.getString(FROM).length()!=0){
								if(continent.has(TO) && continent.getString(TO).length()!=0)
									continentMain = continent.getString(FROM)+";"+continent.getString(PROP_VIA)+";"+continent.getString(TO);
								else continentMain = continent.getString(FROM)+";"+continent.getString(PROP_VIA)+";"+null;
							}else{
								if(continent.has(TO) && continent.getString(TO).length()!=0)
									continentMain = null+";"+continent.getString(PROP_VIA)+";"+continent.getString(TO);
								else continentMain = null+";"+continent.getString(PROP_VIA)+";"+null;
							}
						}else{
							if(continent.has(FROM) && continent.getString(FROM).length()!=0){
								if(continent.has(TO) && continent.getString(TO).length()!=0)
									continentMain = continent.getString(FROM)+";"+null+";"+continent.getString(TO);
								else continentMain = continent.getString(FROM)+";"+null+";"+null;
							}else{
								if(continent.has(TO) && continent.getString(TO).length()!=0)
									continentMain = null+";"+null+";"+continent.getString(TO);
							}
						}
					}
					if(country.length()>0){
						if(country.has(PROP_VIA) && country.getString(PROP_VIA).length()!=0){
							if(country.has(FROM) && country.getString(FROM).length()!=0){
								if(country.has(TO) && country.getString(TO).length()!=0)
									countryMain = country.getString(FROM)+";"+country.getString(PROP_VIA)+";"+country.getString(TO);
								else countryMain = country.getString(FROM)+";"+country.getString(PROP_VIA)+";"+null;
							}else{
								if(country.has(TO) && country.getString(TO).length()!=0)
									countryMain = null+";"+country.getString(PROP_VIA)+";"+country.getString(TO);
								else countryMain = null+";"+country.getString(PROP_VIA)+";"+null;
							}
						}else{
							if(country.has(FROM) && country.getString(FROM).length()!=0){
								if(country.has(TO) && country.getString(TO).length()!=0)
									countryMain = country.getString(FROM)+";"+null+";"+country.getString(TO);
								else countryMain = country.getString(FROM)+";"+null+";"+null;
							}else{
								if(country.has(TO) && country.getString(TO).length()!=0)
									countryMain = null+";"+null+";"+country.getString(TO);
							}
						}
					}
					if(city.length()>0){
						if(city.has(PROP_VIA) && city.getString(PROP_VIA).length()!=0){
							if(city.has(FROM) && city.getString(FROM).length()!=0){
								if(city.has(TO) && city.getString(TO).length()!=0)
									cityMain = city.getString(FROM)+";"+city.getString(PROP_VIA)+";"+city.getString(TO);
								else cityMain = city.getString(FROM)+";"+city.getString(PROP_VIA)+";"+null;
							}else{
								if(city.has(TO) && city.getString(TO).length()!=0)
									cityMain = null+";"+city.getString(PROP_VIA)+";"+city.getString(TO);
								else cityMain = null+";"+city.getString(PROP_VIA)+";"+null;
							}
						}else{
							if(city.has(FROM) && city.getString(FROM).length()!=0){
								if(city.has(TO) && city.getString(TO).length()!=0)
									cityMain = city.getString(FROM)+";"+null+";"+city.getString(TO);
								else cityMain = city.getString(FROM)+";"+null+";"+null;
							}else{
								if(city.has(TO) && city.getString(TO).length()!=0)
									cityMain = null+";"+null+";"+city.getString(TO);
							}
						}
					}
				}
				else{
					if(continent.length()>0){
						if(continent.has(PROP_VIA) && continent.getString(PROP_VIA).length()!=0){
							if(continent.has(FROM) && continent.getString(FROM).length()!=0){
								if(continent.has(TO) && continent.getString(TO).length()!=0)
									continentMain+= "/"+continent.getString(FROM)+";"+continent.getString(PROP_VIA)+";"+continent.getString(TO);
								else continentMain+= "/"+continent.getString(FROM)+";"+continent.getString(PROP_VIA)+";"+null;
							}else{
								if(continent.has(TO) && continent.getString(TO).length()!=0)
									continentMain+= "/"+null+";"+continent.getString(PROP_VIA)+";"+continent.getString(TO);
								else continentMain+= "/"+null+";"+continent.getString(PROP_VIA)+";"+null;
							}
						}else{
							if(continent.has(FROM) && continent.getString(FROM).length()!=0){
								if(continent.has(TO) && continent.getString(TO).length()!=0)
									continentMain+= "/"+continent.getString(FROM)+";"+null+";"+continent.getString(TO);
								else continentMain+= "/"+continent.getString(FROM)+";"+null+";"+null;
							}else{
								if(continent.has(TO) && continent.getString(TO).length()!=0)
									continentMain+= "/"+null+";"+null+";"+continent.getString(TO);
								else continentMain+= "/"+null+";"+null+";"+null;
							}
						}
					}
					if(country.length()>0){
						if(country.has(PROP_VIA) && country.getString(PROP_VIA).length()!=0){
							if(country.has(FROM) && country.getString(FROM).length()!=0){
								if(country.has(TO) && country.getString(TO).length()!=0)
									countryMain+= "/"+country.getString(FROM)+";"+country.getString(PROP_VIA)+";"+country.getString(TO);
								else countryMain+= "/"+country.getString(FROM)+";"+country.getString(PROP_VIA)+";"+null;
							}else{
								if(country.has(TO) && country.getString(TO).length()!=0)
									countryMain+= "/"+null+";"+country.getString(PROP_VIA)+";"+country.getString(TO);
								else countryMain+= "/"+null+";"+country.getString(PROP_VIA)+";"+null;
							}
						}else{
							if(country.has(FROM) && country.getString(FROM).length()!=0){
								if(country.has(TO) && country.getString(TO).length()!=0)
									countryMain+= "/"+country.getString(FROM)+";"+null+";"+country.getString(TO);
								else countryMain+= "/"+country.getString(FROM)+";"+null+";"+null;
							}else{
								if(country.has(TO) && country.getString(TO).length()!=0)
									countryMain+= "/"+null+";"+null+";"+country.getString(TO);
								else countryMain+= "/"+null+";"+null+";"+null;
							}
						}
					}
					if(city.length()>0){
						if(city.has(PROP_VIA) && city.getString(PROP_VIA).length()!=0){
							if(city.has(FROM) && city.getString(FROM).length()!=0){
								if(city.has(TO) && city.getString(TO).length()!=0)
									cityMain+= "/"+city.getString(FROM)+";"+city.getString(PROP_VIA)+";"+city.getString(TO);
								else cityMain+= "/"+city.getString(FROM)+";"+city.getString(PROP_VIA)+";"+null;
							}else{
								if(city.has(TO) && city.getString(TO).length()!=0)
									cityMain+= "/"+null+";"+city.getString(PROP_VIA)+";"+city.getString(TO);
								else cityMain+= "/"+null+";"+city.getString(PROP_VIA)+";"+null;
							}
						}else{
							if(city.has(FROM) && city.getString(FROM).length()!=0){
								if(city.has(TO) && city.getString(TO).length()!=0)
									cityMain+= "/"+city.getString(FROM)+";"+null+";"+city.getString(TO);
								else cityMain+= "/"+city.getString(FROM)+";"+null+";"+null;
							}else{
								if(city.has(TO) && city.getString(TO).length()!=0)
									cityMain+= "/"+null+";"+null+";"+city.getString(TO);
								else cityMain+= "/"+null+";"+null+";"+null;
							}
						}
					}
				}
			}
			if(incExc==INCLUSION){
				if(continentMain!=null)
					calculation.put(PROP_CONTINENT, journeyTypeString+";"+continentMain);
				if(countryMain!=null)
					calculation.put(PROP_COUNTRY, journeyTypeString+";"+countryMain);
				if(cityMain!=null)
					calculation.put(PROP_CITY, journeyTypeString+";"+cityMain);
			}else{
				if(continentMain!=null)
					calculation.put(PROP_CONTINENT+"_"+EXCLUSION, journeyTypeString+";"+continentMain);
				if(countryMain!=null)
					calculation.put(PROP_COUNTRY+"_"+EXCLUSION, journeyTypeString+";"+countryMain);
				if(cityMain!=null)
					calculation.put(PROP_CITY+"_"+EXCLUSION, journeyTypeString+";"+cityMain);
			}
		}
		return calculation;
	}


	private static void getOtherFeesFareBasis(JSONArray otherFeeArr, JSONObject advanceDefinitionAir, String commercialName) {
		if(advanceDefinitionAir.has(PROP_FARECLASS)){
			if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_FAREBASIS)){
				if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_FAREBASIS).getJSONArray(PROP_FARE).length()>0){
					JSONArray fare = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_FAREBASIS).getJSONArray(PROP_FARE);
					int length = otherFeeArr.length();
					for(int i=0;i<length;i++){
						for(int f=0;f<fare.length();f++){
							JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
							JSONObject fareObject = fare.getJSONObject(f);
							JSONArray fareArr = new JSONArray();
							if(fareObject.has(PROP_CONDITION))
								fareArr.put(fareObject.getString(PROP_CONDITION));
							if(fareObject.has(VALUE))
								fareArr.put(fareObject.getString(VALUE));
							otherFee.put(PROP_FAREBASISVALUE, fareArr);
							String otherFeeID = otherFee.getString(RULEID);
							otherFee.put(RULEID, otherFeeID+commercialName+PROP_FARECLASS+i+f);
							otherFeeArr.put(otherFee);
						}
					}
					for(int i=0;i<length;i++){
						otherFeeArr.remove(0);
					}
				}
			}
		}
	}


	/*private static void getOtherFeesFlightNumbers(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has(PROP_FLIGHTNUMBERS)){
			JSONArray flightRange = advanceDefinitionAir.getJSONObject(PROP_FLIGHTNUMBERS).getJSONArray(PROP_FLIGHTRANGE);
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<flightRange.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject range = flightRange.getJSONObject(j);
					String numbers=null;
					if(range.has(PROP_FLIGHTRANGE_FROM)){
						if(range.has(PROP_FLIGHTRANGE_TO))
							numbers=BETWEEN+";"+range.get(PROP_FLIGHTRANGE_FROM)+";"+range.get(PROP_FLIGHTRANGE_TO);
						else numbers=GREATERTHANEQUALTO+";"+range.get(PROP_FLIGHTRANGE_FROM);
					}else if(range.has(PROP_FLIGHTRANGE_TO))
						numbers=LESSTHANEQUALTO+";"+range.get(PROP_FLIGHTRANGE_TO);

					if(advanceDefinitionAir.getJSONObject(PROP_FLIGHTNUMBERS).getBoolean(PROP_BOOLEAN_ISINCLUSION))
						otherFee.put(FLIGHTNUMBER, numbers);
					else otherFee.put(FLIGHTNUMBER_"+exclusion", numbers);

					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, range.getString(PROP_ID));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}


	private static void getOtherFeesFlightTiming(JSONArray otherFeeArr, JSONObject advanceDefinitionAir) {
		if(advanceDefinitionAir.has(PROP_FLIGHTTIMINGS)){
			JSONArray flightTimings = advanceDefinitionAir.getJSONObject(PROP_FLIGHTTIMINGS).getJSONArray(PROP_FLIGHTTIMINGS);
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int m=0;m<flightTimings.length();m++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject timingObject = flightTimings.getJSONObject(m);
					String timing=null;
					if(timingObject.has(PROP_FLIGHTTIME_FROM)){
						if(timingObject.has(PROP_FLIGHTTIME_TO))
							timing=BETWEEN+";"+timingObject.get(PROP_FLIGHTTIME_FROM)+";"+timingObject.get(PROP_FLIGHTTIME_TO);
						else timing=GREATERTHANEQUALTO+";"+timingObject.get(PROP_FLIGHTTIME_FROM);
					}else if(timingObject.has(PROP_FLIGHTTIME_TO))
						timing=LESSTHANEQUALTO+";"+timingObject.get(PROP_FLIGHTTIME_TO);

					if(advanceDefinitionAir.getJSONObject(PROP_FLIGHTTIMINGS).getBoolean(PROP_BOOLEAN_ISINCLUSION))
						otherFee.put(FLIGHTTIMING, timing);
					else otherFee.put(FLIGHTTIMING_"+exclusion", timing);

					CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, timingObject.getString(PROP_ID));
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}*/


	private static void setAirOtherFeesDestination(JSONArray otherFeeArr, JSONObject advanceDefinitionAir, String commercialName){
		if(advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST).has(PROP_DESTINATIONS)){
			JSONArray destinationArray = advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST).getJSONArray(PROP_DESTINATIONS);
			if(destinationArray.length()>0){
				int length = otherFeeArr.length();
				for(int i=0;i<length;i++){
					for(int j=0;j<destinationArray.length();j++){
						JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
						JSONObject destinationObj = destinationArray.getJSONObject(j);
						if(advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST).getBoolean(PROP_BOOLEAN_ISINCLUSION)){
							if(destinationObj.has(PROP_CONTINENT)){
								JSONObject continent = destinationObj.getJSONObject(PROP_CONTINENT);
								if(continent.has(FROM) && !continent.getString(FROM).equalsIgnoreCase("All"))
									otherFee.put(FROMCONTINENT, continent.getString(FROM));
								if(continent.has(PROP_VIA) && !continent.getString(PROP_VIA).equalsIgnoreCase("All"))
									otherFee.put(VIACONTINENT, continent.getString(PROP_VIA));
								if(continent.has(TO) && !continent.getString(TO).equalsIgnoreCase("All"))
									otherFee.put(TOCONTINENT, continent.getString(TO));
							}
							if(destinationObj.has(PROP_COUNTRY)){
								JSONObject country = destinationObj.getJSONObject(PROP_COUNTRY);
								if(country.has(FROM) && !country.getString(FROM).equalsIgnoreCase("All"))
									otherFee.put(FROMCOUNTRY, country.getString(FROM));
								if(country.has(PROP_VIA) && !country.getString(PROP_VIA).equalsIgnoreCase("All"))
									otherFee.put(VIACOUNTRY, country.getString(PROP_VIA));
								if(country.has(TO) && !country.getString(TO).equalsIgnoreCase("All"))
									otherFee.put(TOCOUNTRY, country.getString(TO));
							}
							if(destinationObj.has(PROP_CITY)){
								JSONObject city = destinationObj.getJSONObject(PROP_CITY);
								if(city.has(FROM) && !city.getString(FROM).equalsIgnoreCase("All"))
									otherFee.put(FROMCITY, city.getString(FROM));
								if(city.has(PROP_VIA) && !city.getString(PROP_VIA).equalsIgnoreCase("All"))
									otherFee.put(VIACITY, city.getString(PROP_VIA));
								if(city.has(TO) && !city.getString(TO).equalsIgnoreCase("All"))
									otherFee.put(TOCITY, city.getString(TO));
							}
						}else{
							if(destinationObj.has(PROP_CONTINENT)){
								JSONObject continent = destinationObj.getJSONObject(PROP_CONTINENT);
								if(continent.has(FROM) && !continent.getString(FROM).equalsIgnoreCase("All"))
									otherFee.put(FROMCONTINENT+"_"+EXCLUSION, continent.getString(FROM));
								if(continent.has(PROP_VIA) && !continent.getString(PROP_VIA).equalsIgnoreCase("All"))
									otherFee.put(VIACONTINENT+"_"+EXCLUSION, continent.getString(PROP_VIA));
								if(continent.has(TO) && !continent.getString(TO).equalsIgnoreCase("All"))
									otherFee.put(TOCONTINENT+"_"+EXCLUSION, continent.getString(TO));
							}
							if(destinationObj.has(PROP_COUNTRY)){
								JSONObject country = destinationObj.getJSONObject(PROP_COUNTRY);
								if(country.has(FROM) && !country.getString(FROM).equalsIgnoreCase("All"))
									otherFee.put(FROMCOUNTRY+"_"+EXCLUSION, country.getString(FROM));
								if(country.has(PROP_VIA) && !country.getString(PROP_VIA).equalsIgnoreCase("All"))
									otherFee.put(VIACOUNTRY+"_"+EXCLUSION, country.getString(PROP_VIA));
								if(country.has(TO) && !country.getString(TO).equalsIgnoreCase("All"))
									otherFee.put(TOCOUNTRY+"_"+EXCLUSION, country.getString(TO));
							}
							if(destinationObj.has(PROP_CITY)){
								JSONObject city = destinationObj.getJSONObject(PROP_CITY);
								if(city.has(FROM) && !city.getString(FROM).equalsIgnoreCase("All"))
									otherFee.put(FROMCITY+"_"+EXCLUSION, city.getString(FROM));
								if(city.has(PROP_VIA) && !city.getString(PROP_VIA).equalsIgnoreCase("All"))
									otherFee.put(VIACITY+"_"+EXCLUSION, city.getString(PROP_VIA));
								if(city.has(TO) && !city.getString(TO).equalsIgnoreCase("All"))
									otherFee.put(TOCITY+"_"+EXCLUSION, city.getString(TO));
							}
						}
						CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+PROP_DESTINATIONS+i+j);
					}
				}
				for(int i=0;i<length;i++){
					otherFeeArr.remove(0);
				}
			}
		}
	}
	
	
	public static void getOtherFeesAdvancedDefinition(JSONArray otherFeeArr, JSONObject advanceDefinitionAir, String commercialName){
		int length =otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee =new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
			if(advanceDefinitionAir.has(PROP_CONNECTIVITY)){
				JSONObject connectivity = advanceDefinitionAir.getJSONObject(PROP_CONNECTIVITY);
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					otherFee.put(CONN_SUPPTYPE, connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPID) && !connectivity.getString(PROP_SUPPID).equalsIgnoreCase("All"))
					otherFee.put(CONN_SUPPNAME, connectivity.getString(PROP_SUPPID));
			}
			if(advanceDefinitionAir.has(PROP_CREDENTIALS) && advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS).length()>0){
				JSONArray credentials = advanceDefinitionAir.getJSONArray(PROP_CREDENTIALS);
				JSONArray crentialsArr = new JSONArray();
				for(int cr=0;cr<credentials.length();cr++){
					crentialsArr.put(credentials.getJSONObject(cr).getString(PROP_CREDENTIALID));
				}
				otherFee.put(CREDENTIALSNAME, crentialsArr);
			}
			if(advanceDefinitionAir.has(PROP_OTHERS)){
				if(advanceDefinitionAir.getJSONObject(PROP_OTHERS).has(PROP_BOOKINGTYPE))
					otherFee.put(PROP_BOOKINGTYPE, advanceDefinitionAir.getJSONObject(PROP_OTHERS).getString(PROP_BOOKINGTYPE));
			}
			//getAirBookingClass(advanceDefinitionAir, otherFee);

			/*
				if(advanceDefinitionAir.has(PROP_PASSENGERTYPES) && advanceDefinitionAir.getJSONArray(PROP_PASSENGERTYPES).length()>0){
					JSONArray passengerTypes  = advanceDefinitionAir.getJSONArray(PROP_PASSENGERTYPES);
					JSONArray paxType = new JSONArray();
					for(int pt=0;pt<passengerTypes.length();pt++){
						paxType.put(passengerTypes.getJSONObject(pt).getString(PROP_PASSENGERTYPES));
					}
					otherFee.put(PASSENGERTYPE, paxType);
				}*/
			if(advanceDefinitionAir.has(PROP_TRAVELDEST)){
				JSONObject travelDestination = advanceDefinitionAir.getJSONObject(PROP_TRAVELDEST);
				if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
					if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
						if(travelDestination.has(PROP_SOLDANDTICKETINGOPTIONS) && travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS).length()>0)
							otherFee.put(TRAVELTYPE, travelDestination.get(PROP_SOLDANDTICKETINGOPTIONS));

						if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
							otherFee.put(PROP_JOURNEYTYPE, travelDestination.get(PROP_JOURNEYTYPE));

						if(travelDestination.has(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
							otherFee.put(CODESHAREFLIGHTINCLUDED, travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED));

						if(travelDestination.has(PROP_BOOLEAN_ISDIRCTFLIGHTS)){
							if(travelDestination.getBoolean(PROP_BOOLEAN_ISDIRCTFLIGHTS))
								otherFee.put(FLIGHTTYPE, DIRECT);
							else otherFee.put(FLIGHTTYPE, VIA);
						}

						if(travelDestination.has(PROP_BOOLEAN_ISONLINE)){
							if(travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE))
								otherFee.put(FLIGHTLINETYPE, ONLINE);
							else otherFee.put(FLIGHTLINETYPE, OFFLINE);
						}

						if(travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
							JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
							JSONArray travelProductNameArr = new JSONArray();
							for(int d=0;d<destinations.length();d++){
								JSONObject destObj = destinations.getJSONObject(d);
								if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
									for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
										travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
								}
							}
							if(travelProductNameArr.length()>0)
								otherFee.put(TRAVELPRODUCTNAME, travelProductNameArr);
						}
					}else{
						if(travelDestination.has(PROP_SOLDANDTICKETINGOPTIONS) && travelDestination.getJSONArray(PROP_SOLDANDTICKETINGOPTIONS).length()>0)
							otherFee.put(TRAVELTYPE+"_"+EXCLUSION, travelDestination.get(PROP_SOLDANDTICKETINGOPTIONS));

						if(travelDestination.has(PROP_JOURNEYTYPE) && travelDestination.getJSONArray(PROP_JOURNEYTYPE).length()>0)
							otherFee.put(PROP_JOURNEYTYPE+"_"+EXCLUSION, travelDestination.get(PROP_JOURNEYTYPE));

						if(travelDestination.has(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED))
							otherFee.put(CODESHAREFLIGHTINCLUDED+"_"+EXCLUSION, travelDestination.getBoolean(PROP_BOOLEAN_CODESHAREDFLIGHTINCLUDED));

						if(travelDestination.has(PROP_BOOLEAN_ISDIRCTFLIGHTS)){
							if(travelDestination.getBoolean(PROP_BOOLEAN_ISDIRCTFLIGHTS))
								otherFee.put(FLIGHTTYPE+"_"+EXCLUSION, DIRECT);
							else otherFee.put(FLIGHTTYPE+"_"+EXCLUSION, VIA);
						}

						if(travelDestination.has(PROP_BOOLEAN_ISONLINE)){
							if(travelDestination.getBoolean(PROP_BOOLEAN_ISONLINE))
								otherFee.put(FLIGHTLINETYPE+"_"+EXCLUSION, ONLINE);
							else otherFee.put(FLIGHTLINETYPE+"_"+EXCLUSION, OFFLINE);
						}

						if(travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
							JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
							JSONArray travelProductNameArr = new JSONArray();
							for(int d=0;d<destinations.length();d++){
								JSONObject destObj = destinations.getJSONObject(d);
								if(destObj.has(PROP_PRODUCTS) && destObj.getJSONArray(PROP_PRODUCTS).length()>0){
									for(int tpn=0;tpn<destObj.getJSONArray(PROP_PRODUCTS).length();tpn++)
										travelProductNameArr.put(destObj.getJSONArray(PROP_PRODUCTS).getJSONObject(tpn).getString(PROP_PRODUCTID));
								}
							}
							if(travelProductNameArr.length()>0)
								otherFee.put(TRAVELPRODUCTNAME+"_"+EXCLUSION, travelProductNameArr);
						}
					}
				}
			}
			if(advanceDefinitionAir.has(PROP_FARECLASS)){
				if(advanceDefinitionAir.getJSONObject(PROP_FARECLASS).has(PROP_DEALCODES)){
					JSONObject dealCodes = advanceDefinitionAir.getJSONObject(PROP_FARECLASS).getJSONObject(PROP_DEALCODES);
					if(dealCodes.has(PROP_DEALCODES) && dealCodes.getJSONArray(PROP_DEALCODES).length()>0){
						JSONArray dealCodesArr = dealCodes.getJSONArray(PROP_DEALCODES);
						JSONArray dealcode= new JSONArray();
						for(int dc=0;dc<dealCodesArr.length();dc++){
							dealcode.put(dealCodesArr.getJSONObject(dc).getString(DEALCODE));
						}
						if(dealCodes.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							otherFee.put(DEALCODE, dealcode);
						else otherFee.put(DEALCODE+"_"+EXCLUSION, dealcode);
					}
				}
			}
			otherFeeArr.put(otherFee);
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
		setAirOtherFeesDestination(otherFeeArr,advanceDefinitionAir,commercialName);
		CommonFunctions.setOtherFeeTicketingPlusTravel(otherFeeArr,advanceDefinitionAir.getJSONObject(PROP_VALIDITY),commercialName);
		getOtherFeesFareBasis(otherFeeArr,advanceDefinitionAir,commercialName);
		//getOtherFeesFlightTiming(otherFeeArr,advanceDefinitionAir);
		//getOtherFeesFlightNumbers(otherFeeArr,advanceDefinitionAir);
	}

	
	public static void getTriggerPayoutConnectivity(JSONArray baseArr, JSONObject connectivity) {
		if(connectivity.has(PROP_SUPPTYPE) || connectivity.has(PROP_SUPPID)){
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(connectivity.getJSONArray(PROP_TRIGGERPAYOUT));
				JSONArray connectivityArr = new JSONArray();
				JSONObject connectivityObject = new JSONObject();
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					connectivityObject.put(CONN_SUPPTYPE,connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPID) && !connectivity.getString(PROP_SUPPID).equalsIgnoreCase("All")) // change as per schema supplier supplierId to supplierName
					connectivityObject.put(CONN_SUPPNAME,connectivity.getString(PROP_SUPPID));
				connectivityArr.put(triggerPayout);
				connectivityArr.put(connectivityObject);
				base.put(PROP_CONNECTIVITY, connectivityArr);
			}
		}
	}
}