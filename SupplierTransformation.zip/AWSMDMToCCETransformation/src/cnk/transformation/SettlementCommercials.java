package cnk.transformation;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class SettlementCommercials implements Constants {
	public static JSONObject main = new JSONObject();

	public static JSONObject settlementCommercials(String commercialName, JSONObject jsonObject, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName, String contractType, String commDefnID, JSONArray advanceDefinationData){
		JSONObject mainJson = new JSONObject();
		if(main.length()!=0 && !main.toString().equals("{}") && main.has(COMMDEFN_DT)){
			//indicates that values already inserted once in it
			mainJson=new JSONObject(new JSONTokener(main.toString()));
			JSONArray commercialHead = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
			JSONObject comm = new JSONObject();
			comm.put(PROP_COMMHEADNAME, commercialName);
			comm.put(PROP_CONTRACTTYPE, contractType);
			comm.put(PROP_ISAPPLICABLE, true);
			commercialHead.put(comm);
		}else{
			JSONObject commJson = new JSONObject();
			commJson.put(RULEID, commDefnID);
			commJson.put(TYPE, TYPE_DEFINITION);
			commJson.put(PROP_SUPPLIER, supplier);
			if(!supplierMarkets.equals("[]") && !supplierMarkets.isNull(0))
				commJson.put(SUPPLIERMARKET, supplierMarkets);
			appendProductCategoryAndSubType(commJson,productName,productCategory,productCategorySubType);
			JSONObject comm = new JSONObject();
			comm.put(PROP_COMMHEADNAME, commercialName);
			comm.put(PROP_CONTRACTTYPE, contractType);
			comm.put(PROP_ISAPPLICABLE, true);
			JSONArray commercialHeadArr = new JSONArray();
			commercialHeadArr.put(comm);
			commJson.put(COMMHEAD, commercialHeadArr);
			commJson.put(COMMERCIAL_ID, commDefnID);
			mainJson.put(COMMDEFN_DT, commJson);
		}

		JSONArray commercialHeadArr = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
		switch(commercialName){
		case MAINTENANCEFEES:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),MAINTENANCEFEES);
			mainJson.put(MAINTENANCEFEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,MAINTENANCEFEES));
			break;
		}
		case INTEGRATIONFEES:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),INTEGRATIONFEES);
			mainJson.put(INTEGRATIONEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,INTEGRATIONFEES));
			break;
		}
		case LICENCEFEES:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),LICENCEFEES);
			mainJson.put(LICENCEFEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,LICENCEFEES));
			break;
		}
		case WEBSERVICEFEES:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),WEBSERVICEFEES);
			mainJson.put(WEBSERVICEFEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,WEBSERVICEFEES));
			break;
		}
		case LOYALTYBONUS:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),LOYALTYBONUS);
			mainJson.put(LOYALTYBONUS_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,LOYALTYBONUS));
			break;
		}
		case TRAININGFEES:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),TRAININGFEES);
			mainJson.put(TRAININGFEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,TRAININGFEES));
			break;
		}
		case PREFERENCEBENEFIT:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),PREFERENCEBENEFIT);
			mainJson.put(PREFERENCEBENEFIT_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,PREFERENCEBENEFIT));
			break;
		}
		case RETAINERFEE:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),RETAINERFEE);
			mainJson.put(RETAINERFEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,RETAINERFEE));
			break;
		}
		case LISTINGFEE:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),LISTINGFEE);
			mainJson.put(LISTINGFEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,LISTINGFEE));
			break;
		}
		case CONTENTACCESSFEE:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),CONTENTACCESSFEE);
			mainJson.put(CONTENTACCESSFEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,CONTENTACCESSFEE));
			break;
		}
		case SIGNUPFEES:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),SIGNUPFEES);
			mainJson.put(SIGNUPFEE_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,SIGNUPFEES));
			break;
		}
		case SIGNUPBONUS:{
			JSONObject signUpBonusObj = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(PROP_SIGNUPBONUS);
			setCommercialType(commercialHeadArr,signUpBonusObj,SIGNUPBONUS);
			mainJson.put(SIGNUPBONUS_DT, getSignUpBonus(signUpBonusObj,commDefnID, productCategory));
			break;
		}
		case LOOKTOBOOK:{
			JSONObject ltb = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(PROP_LOOKTOBOOK);
			setCommercialType(commercialHeadArr,ltb,LOOKTOBOOK);
			setLookToBook(ltb,mainJson,jsonObject,commDefnID);
			break;	
		}
		case MSFFEES:{
			JSONObject msfMDM = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(PROP_MSFFEES);
			setCommercialType(commercialHeadArr,msfMDM,MSFFEES);
			mainJson.put(MSFFEE_DT, getMSFFee(msfMDM,jsonObject,commDefnID));
			break;
		}
		case IOTP:{
			JSONObject incentivesOnTopUpMDM = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(PROP_IOTP);
			setCommercialType(commercialHeadArr,incentivesOnTopUpMDM,IOTP);
			mainJson.put(IOTP_DT, getIncentiveOnTopUp(incentivesOnTopUpMDM,commDefnID));
			break;
		}
		case TERMINATIONFEES:{
			JSONObject terminationFeeMDM = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(PROP_TERMINATIONFEES);
			setCommercialType(commercialHeadArr,terminationFeeMDM,TERMINATIONFEES);
			mainJson.put(TERMINATIONFEE_DT,getTerminationFee(terminationFeeMDM,jsonObject,commDefnID));
			break;
		}
		case PENALTYFEE:{
			JSONObject penaltyFeeMDM = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(PROP_PENALTYFEE_KICKBACK);
			setCommercialType(commercialHeadArr,penaltyFeeMDM,PENALTYFEE);
			mainJson.put(PENALTYFEE_DT, getPenaltyFee(penaltyFeeMDM, commDefnID));
			break;
		}
		case FOC:{
			switch(productName){
			case PRODUCTNAME_ACCOMODATION:
				mainJson = setFOC(mainJson, jsonObject, commercialHeadArr, PROP_FOC_ACCO, PROP_PRODUCTS, commDefnID);
				break;
			case PRODUCTNAME_ACTIVITIES:
				mainJson = setFOC(mainJson, jsonObject, commercialHeadArr, PROP_FOC_ACTIVITIES,PROP_PRODUCTINFO, commDefnID);
				break;
			case PRODUCTNAME_AIR:
				mainJson = setFOC(mainJson, jsonObject, commercialHeadArr, PROP_FOC_FLIGHTS, PROP_PRODUCT, commDefnID);
				break;
			case PRODUCTNAME_HOLIDAYS:
				mainJson = setFOC(mainJson, jsonObject, commercialHeadArr, PROP_FOC_HOLIDAYS,PROP_PRODUCTINFO, commDefnID);
				break;
			}
			break;
		}
		case LOSTTICKET:{
			setCommercialType(commercialHeadArr,jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES),LOSTTICKET);
			mainJson.put(LOSTTICKET_DT, otherFees(jsonObject,commDefnID,productName,advanceDefinationData,LOSTTICKET));
			break;
		}
		case REMITTANCEFEES:{
			JSONObject remmitanceMDM = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(PROP_REMITTANCEFEES);
			setCommercialType(commercialHeadArr,remmitanceMDM,REMITTANCEFEES);
			getRemittanceFee(remmitanceMDM,mainJson,commDefnID);
			break;
		}
		}
		main=new JSONObject(new JSONTokener(mainJson.toString()));
		return main;
	}


	public static void setCommercialType(JSONArray commercialHeadArr, JSONObject jsonObject, String commercialName) {
		for(int k=0;k<commercialHeadArr.length();k++){
			JSONObject commercialHeadObj = commercialHeadArr.getJSONObject(k);
			if(commercialHeadObj.getString(PROP_COMMHEADNAME).equals(commercialName)){
				commercialHeadObj.put(PROP_COMMERCIALTYPE, jsonObject.getJSONObject(PROP_COMMERCIALINFO).getString(PROP_COMMERCIALTYPE));
			}
		}
	}


	public static void getRemittanceFee(JSONObject remmitanceMDM, JSONObject mainJson, String commDefnID) {
		JSONArray remittanceFeeArr = new JSONArray();
		if(remmitanceMDM.getBoolean(PROP_ISFIXED)){
			JSONObject remittanceFee = new JSONObject();
			remittanceFee.put(SELECTEDROW, commDefnID);
			remittanceFee.put(COMMERCIAL_ID, commDefnID);
			remittanceFee.put(TYPE, REMITTANCEFEES);
			JSONObject contractValidity = new JSONObject();
			if(remmitanceMDM.has(PROP_EFFECTIVE_TO)){
				contractValidity.put(OPERATOR, BETWEEN);
				contractValidity.put(FROM, remmitanceMDM.getString(PROP_EFFECTIVE_FROM).substring(0, 11)+"00:00:00");
				contractValidity.put(TO, remmitanceMDM.getString(PROP_EFFECTIVE_TO).substring(0, 11)+"23:59:59");
			}else{
				contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
				contractValidity.put(VALUE, remmitanceMDM.getString(PROP_EFFECTIVE_FROM).substring(0, 11)+"00:00:00");
			}
			remittanceFee.put(CONTRACTVALIDITY, contractValidity);
			remittanceFee.put(RULEID, commDefnID+"_"+REMITTANCEFEES);
			JSONObject fixed = remmitanceMDM.getJSONObject(PROP_FIXED);
			if(fixed.getBoolean(PROP_BOOLEAN_ISPERCENTAGE))
				remittanceFee.put(PERCENTAGE, fixed.get(PROP_PERCENT).toString());
			else{
				remittanceFee.put(COMMERCIALCURRENCY, fixed.getJSONObject(PROP_AMOUNT).getString(PROP_CURRENCY));
				remittanceFee.put(COMMERCIALAMOUNT, fixed.getJSONObject(PROP_AMOUNT).get(VALUE).toString());
			}
			mainJson.put(REMITTANCEFEE_DT, remittanceFee);
			System.out.println(REMITTANCEFEE_DT);
		}else{
			for(int i=0;i<remmitanceMDM.getJSONArray(PROP_SLABS).length();i++){
				JSONObject remittanceFee = new JSONObject();
				remittanceFee.put(SELECTEDROW, commDefnID);
				remittanceFee.put(COMMERCIAL_ID, commDefnID+"_"+i);
				remittanceFee.put(TYPE, REMITTANCEFEES);
				JSONObject contractValidity = new JSONObject();
				if(remmitanceMDM.has(PROP_CONTRACT_VAL_TO)){
					contractValidity.put(OPERATOR, BETWEEN);
					contractValidity.put(FROM, remmitanceMDM.getString(PROP_EFFECTIVE_FROM).substring(0, 11)+"00:00:00");
					contractValidity.put(TO, remmitanceMDM.getString(PROP_EFFECTIVE_TO).substring(0, 11)+"23:59:59");
				}else{
					contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
					contractValidity.put(VALUE, remmitanceMDM.getString(PROP_EFFECTIVE_FROM).substring(0, 11)+"00:00:00");
				}
				remittanceFee.put(CONTRACTVALIDITY, contractValidity);
				JSONObject slabs = remmitanceMDM.getJSONArray(PROP_SLABS).getJSONObject(i);
				remittanceFee.put(TOTALSETTLEMENT_CURRENCY, slabs.getString(PROP_CURRENCY));
				JSONObject totalSettlementAmount = new JSONObject();
				if(slabs.has(PROP_TRANSACTION_FROMVALUE) && slabs.has(PROP_TRANSACTION_TOVALUE)){
					totalSettlementAmount.put(OPERATOR, BETWEEN);
					totalSettlementAmount.put(FROM, slabs.get(PROP_TRANSACTION_FROMVALUE).toString());
					totalSettlementAmount.put(TO, slabs.get(PROP_TRANSACTION_TOVALUE).toString());
				}
				else if(slabs.has(PROP_TRANSACTION_FROMVALUE)){
					totalSettlementAmount.put(OPERATOR, GREATERTHANEQUALTO);
					totalSettlementAmount.put(VALUE, slabs.get(PROP_TRANSACTION_FROMVALUE).toString());
				}else{
					totalSettlementAmount.put(OPERATOR, LESSTHANEQUALTO);
					totalSettlementAmount.put(VALUE, slabs.get(PROP_TRANSACTION_TOVALUE).toString());
				}
				remittanceFee.put(TOTALSETTLEMENT_AMOUNT, totalSettlementAmount);
				if(slabs.getBoolean(PROP_BOOLEAN_ISPERCENTAGE))
					remittanceFee.put(PERCENTAGE,slabs.get(PERCENTAGE).toString());
				else{
					remittanceFee.put(COMMERCIALCURRENCY,slabs.getJSONObject(PROP_AMOUNT).getString(PROP_CURRENCY));
					remittanceFee.put(COMMERCIALAMOUNT,slabs.getJSONObject(PROP_AMOUNT).get(VALUE).toString());
				}
				remittanceFee.put(RULEID, commDefnID+"_"+REMITTANCEFEES+PROP_SLABS+i);
				remittanceFeeArr.put(remittanceFee);
			}
			mainJson.put(REMITTANCEFEE_DT, remittanceFeeArr);
		}
	}


	public static JSONArray getPenaltyFee(JSONObject penaltyFeeMDM, String commDefnID) {
		JSONArray penaltyFeeArr = new JSONArray();
		JSONArray penaltyCriteriaMDMarr = penaltyFeeMDM.getJSONArray(PROP_PENALTYCRITERIA);
		for(int i=0;i<penaltyCriteriaMDMarr.length();i++){
			JSONObject penaltyCRitObj = penaltyCriteriaMDMarr.getJSONObject(i);
			JSONObject penaltyFee = new JSONObject();
			JSONObject slabDetails = new JSONObject();
			JSONObject slabTypeVal = new JSONObject();
			penaltyFee.put(CONTRACTVALIDITY, getContractValidity(penaltyFeeMDM));
			penaltyFee.put(SELECTEDROW, commDefnID);
			penaltyFee.put(COMMERCIAL_ID, commDefnID+"_"+i);
			penaltyFee.put(TYPE, PENALTYFEE);
			penaltyFee.put(RULEID, commDefnID+"_"+PENALTYFEE+i);
			if(penaltyCRitObj.getJSONObject(PROP_CONDITION).has(PROP_MINIMUM_PERCENTTOACHIEVE) && penaltyCRitObj.getJSONObject(PROP_CONDITION).getJSONObject(PROP_MINIMUM_PERCENTTOACHIEVE)!=null ){
				String minToAchieve = penaltyCRitObj.getJSONObject(PROP_CONDITION).getJSONObject(PROP_MINIMUM_PERCENTTOACHIEVE).get(FROM).toString();
				String maxToAchieve = penaltyCRitObj.getJSONObject(PROP_CONDITION).getJSONObject(PROP_MINIMUM_PERCENTTOACHIEVE).get(TO).toString();
				slabDetails.put(PROP_SLABTYPE, penaltyCRitObj.getJSONObject(PROP_CONDITION).getString(PROP_SLABTYPE));
				slabTypeVal.put(MINIMUMTOACHIEVE,minToAchieve+"*"+penaltyCRitObj.getJSONObject(PROP_CONDITION).get(PROP_TARGET_TO));
				slabTypeVal.put(MAXIMUMTOACHIEVE,maxToAchieve+"*"+penaltyCRitObj.getJSONObject(PROP_CONDITION).get(PROP_TARGET_TO));
				slabDetails.put(PROP_SLABTYPEVALUE, slabTypeVal);
				penaltyFee.put(SLABDETAILS, slabDetails);
			}else{
				slabDetails.put(PROP_SLABTYPE, penaltyCRitObj.getJSONObject(PROP_CONDITION).getString(PROP_SLABTYPE));
				if(penaltyCRitObj.getJSONObject(PROP_CONDITION).has(PROP_TARGET_FROM) && penaltyCRitObj.getJSONObject(PROP_CONDITION).has(PROP_TARGET_TO)){
					slabTypeVal.put(OPERATOR, BETWEEN);
					slabTypeVal.put(FROM, penaltyCRitObj.getJSONObject(PROP_CONDITION).get(PROP_TARGET_FROM).toString());
					slabTypeVal.put(TO, penaltyCRitObj.getJSONObject(PROP_CONDITION).get(PROP_TARGET_TO).toString());
				}else if(penaltyCRitObj.getJSONObject(PROP_CONDITION).has(PROP_TARGET_FROM)){
					slabTypeVal.put(OPERATOR,GREATERTHANEQUALTO);
					slabTypeVal.put(VALUE, penaltyCRitObj.getJSONObject(PROP_CONDITION).get(PROP_TARGET_FROM).toString());
				}else{
					slabTypeVal.put(OPERATOR,LESSTHANEQUALTO);
					slabTypeVal.put(VALUE, penaltyCRitObj.getJSONObject(PROP_CONDITION).get(PROP_TARGET_TO).toString());
				}
				slabDetails.put(PROP_SLABTYPEVALUE, slabTypeVal);
				penaltyFee.put(SLABDETAILS, slabDetails);
			}
			if(penaltyCRitObj.getJSONObject(PROP_PENALTY).getBoolean(PROP_BOOLEAN_ISPERCENTAGE)){
				penaltyFee.put(MATCHING_SLABTYPE,penaltyCRitObj.getJSONObject(PROP_PENALTY).getJSONObject(PROP_PERCENT).getString(PROP_SLABTYPE));
				penaltyFee.put(PERCENTAGE, penaltyCRitObj.getJSONObject(PROP_PENALTY).getJSONObject(PROP_PERCENT).get(PROP_PERCENT).toString());
			}else{
				penaltyFee.put(COMMERCIALAMOUNT, penaltyCRitObj.getJSONObject(PROP_PENALTY).getJSONObject(PROP_AMOUNT).get(VALUE).toString());
				penaltyFee.put(COMMERCIALCURRENCY, penaltyCRitObj.getJSONObject(PROP_PENALTY).getJSONObject(PROP_AMOUNT).getString(PROP_CURRENCY));
			}
			penaltyFeeArr.put(penaltyFee);
		}
		return penaltyFeeArr;
	}


	public static JSONObject getTerminationFee(JSONObject terminationFeeMDM, JSONObject jsonObject, String commDefnID) {
		JSONObject terminationFee = new JSONObject();
		terminationFee.put(CONTRACTVALIDITY, getContractValidity(terminationFeeMDM));
		terminationFee.put(SELECTEDROW, commDefnID);
		terminationFee.put(RULEID, commDefnID+"_"+TERMINATIONFEES);
		terminationFee.put(COMMERCIAL_ID, commDefnID);
		terminationFee.put(TYPE, TERMINATIONFEES);
		if(terminationFeeMDM.getJSONObject(PROP_PAYABLE).getBoolean(PROP_FIXED)){
			terminationFee.put(COMMERCIALCURRENCY,terminationFeeMDM.getJSONObject(PROP_FIXED).getString(PROP_CURRENCY));
			terminationFee.put(COMMERCIALAMOUNT,terminationFeeMDM.getJSONObject(PROP_FIXED).get(VALUE).toString());
		}else{
			JSONArray returnableCommHeadArr =new JSONArray();
			for(int i=0;i<terminationFeeMDM.getJSONArray(PROP_RETURNOFPAYABLE).length();i++){
				JSONObject returnableCommHead =new JSONObject();
				returnableCommHead.put(COMMERCIALNAME, terminationFeeMDM.getJSONArray(PROP_RETURNOFPAYABLE).getJSONObject(i).getString(COMMHEAD));
				returnableCommHead.put(COMMERCIALPERCENTAGE, terminationFeeMDM.getJSONArray(PROP_RETURNOFPAYABLE).getJSONObject(i).get(PROP_INTERESTONAMOUNT).toString());
				returnableCommHeadArr.put(returnableCommHead);
			}
			terminationFee.put(RETURNABLECOMMHEAD,returnableCommHeadArr);
		}
		return terminationFee;
	}


	public static JSONArray getIncentiveOnTopUp(JSONObject incentivesOnTopUpMDM, String commDefnID) {
		JSONArray incentivesOnTopUpArr = new JSONArray();
		JSONArray supplierRateType = new JSONArray();
		JSONArray supplierRateCode = new JSONArray();
		JSONArray topUpAmountArrMDM = incentivesOnTopUpMDM.getJSONArray(PROP_TOPUP_AMOUNT);
		Set<String> supplierRateTypeSet = new HashSet<String>();
		Set<String> supplierRateCodeSet = new HashSet<String>();
		for(int i=0;i<topUpAmountArrMDM.length();i++){
			for(int l=0;l<incentivesOnTopUpMDM.getJSONArray(RATETYPE).length();l++){
				JSONObject iotpRateTypeObj = incentivesOnTopUpMDM.getJSONArray(RATETYPE).getJSONObject(l);
				if(iotpRateTypeObj.has(PROP_SUPPLIERRATETYPE) && !iotpRateTypeObj.getString(PROP_SUPPLIERRATETYPE).equalsIgnoreCase("All"))
					supplierRateTypeSet.add(iotpRateTypeObj.getString(PROP_SUPPLIERRATETYPE));
				if(iotpRateTypeObj.has(PROP_SUPPLIER_RATECODE) && !iotpRateTypeObj.getString(PROP_SUPPLIER_RATECODE).equalsIgnoreCase("All"))
					supplierRateCodeSet.add(iotpRateTypeObj.getString(PROP_SUPPLIER_RATECODE));
			}
			supplierRateType = new JSONArray(supplierRateTypeSet);
			supplierRateCode = new JSONArray(supplierRateCodeSet);
		}

		for(int i=0;i<topUpAmountArrMDM.length();i++){
			JSONObject incentivesOnTopUp = new JSONObject();
			JSONObject topUpAmount = topUpAmountArrMDM.getJSONObject(i);
			boolean insert=true;
			setIncentiveOnTopUp(incentivesOnTopUp,incentivesOnTopUpMDM,topUpAmount,commDefnID,supplierRateType,supplierRateCode,i);
			if(!incentivesOnTopUpMDM.getBoolean("isSingleTopUp")){
				insert=false;
				switch(incentivesOnTopUpMDM.getString(PROP_PERIODFORTOPUP)){
				case PROP_PERIODFORTOPUP_DAILY:{
					for(int j=0;j<incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONArray(PROP_PERIODFORTOPUP_DAILY).length();j++){
						JSONObject iotpDaily =incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONArray(PROP_PERIODFORTOPUP_DAILY).getJSONObject(j);
						JSONObject daily = new JSONObject();
						JSONObject periodForTopUp = new JSONObject();
						daily.put(PROP_HOUR, iotpDaily.get(PROP_HOUR).toString());
						daily.put(PROP_MINUTES, iotpDaily.get(PROP_MINUTES).toString());
						periodForTopUp.put(PROP_PERIODFORTOPUP_DAILY, daily);
						incentivesOnTopUp.put(PROP_PERIODFORTOPUP, periodForTopUp);
						incentivesOnTopUpArr.put(incentivesOnTopUp);
					}
					break;
				}
				case PROP_PERIODFORTOPUP_WEEKLY:{
					JSONObject weekly = new JSONObject();
					JSONObject periodForTopUp = new JSONObject();
					weekly.put(PROP_DAYOFWEEK, incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).get(PROP_PERIODFORTOPUP_WEEKLY));
					periodForTopUp.put(PROP_PERIODFORTOPUP_WEEKLY, weekly);
					incentivesOnTopUp.put(PROP_PERIODFORTOPUP, periodForTopUp);
					incentivesOnTopUpArr.put(incentivesOnTopUp);
					break;
				}
				case PROP_PERIODFORTOPUP_FORTNIGHTLY:{
					for(int j=0;j<incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONArray(PROP_PERIODFORTOPUP_FORTNIGHTLY).length();j++){
						JSONObject iotpFortnightly =incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONArray(PROP_PERIODFORTOPUP_FORTNIGHTLY).getJSONObject(j);
						JSONObject fortnighly = new JSONObject();
						JSONObject periodForTopUp = new JSONObject();
						JSONArray dayOfWeekInMonth = new JSONArray();
						JSONArray monthFortnightly = new JSONArray();
						dayOfWeekInMonth.put(iotpFortnightly.get(PROP_DAY_1).toString());
						dayOfWeekInMonth.put(iotpFortnightly.get(PROP_DAY_2).toString());
						fortnighly.put(DAY_OFWEEK_INMONTH, dayOfWeekInMonth);
						int f = iotpFortnightly.getInt(PROP_REPEATEVERY);
						for(int k=1;k<=12;k++){
							if(k%f==0){
								monthFortnightly.put(""+k);
							}
						}
						fortnighly.put(MONTH,monthFortnightly);
						periodForTopUp.put(FORTNIGHTLY, fortnighly);
						incentivesOnTopUp.put(PROP_PERIODFORTOPUP, periodForTopUp);
						incentivesOnTopUpArr.put(incentivesOnTopUp);
					}
					break;
				}
				case PROP_PERIODFORTOPUP_MONTHLY:{
					JSONObject monthly = new JSONObject();
					JSONObject periodForTopUp = new JSONObject();
					JSONArray monthMonthly = new JSONArray();
					if(incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONObject(PROP_PERIODFORTOPUP_MONTHLY).has(PROP_OPTION_1)){
						monthly.put(DAY_INMONTH, incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONObject(PROP_PERIODFORTOPUP_MONTHLY).getJSONObject(PROP_OPTION_1).get(PROP_DAY).toString());
						int t = incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONObject(PROP_PERIODFORTOPUP_MONTHLY).getJSONObject(PROP_OPTION_1).getInt(PROP_REPEATEVERY);
						for(int k=1;k<=12;k++){
							if(k%t==0){
								monthMonthly.put(""+k);
							}
						}
						monthly.put(MONTH, monthMonthly);
						periodForTopUp.put(PROP_PERIODFORTOPUP_MONTHLY, monthly);
						incentivesOnTopUp.put(PROP_PERIODFORTOPUP, periodForTopUp);
					}else{
						JSONArray weekOfMonthArr =new JSONArray();
						JSONArray dayOfWeekArr = new JSONArray();
						weekOfMonthArr.put(incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONObject(PROP_PERIODFORTOPUP_MONTHLY).getJSONObject(PROP_OPTION_2).get(PROP_WEEKOFMONTH).toString());		
						dayOfWeekArr.put(incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONObject(PROP_PERIODFORTOPUP_MONTHLY).getJSONObject(PROP_OPTION_2).get(PROP_DAYOFWEEK));
						monthly.put(DAY_OFWEEK_INMONTH, weekOfMonthArr);			
						monthly.put(PROP_DAYOFWEEK,dayOfWeekArr );
						int t = incentivesOnTopUpMDM.getJSONObject(PROP_PERIODICITY).getJSONObject(PROP_PERIODFORTOPUP_MONTHLY).getJSONObject(PROP_OPTION_2).getInt(PROP_REPEATEVERY);
						for(int k=1;k<=12;k++){
							if(k%t==0){
								monthMonthly.put(""+k);
							}
						}
						monthly.put(MONTH, monthMonthly);
						periodForTopUp.put(PROP_PERIODFORTOPUP_MONTHLY, monthly);
						incentivesOnTopUp.put(PROP_PERIODFORTOPUP, periodForTopUp);
					}
					incentivesOnTopUpArr.put(incentivesOnTopUp);
					break;
				}
				}
			}
			if(insert)
				incentivesOnTopUpArr.put(incentivesOnTopUp);
		}
		return incentivesOnTopUpArr;
	}


	private static void setIncentiveOnTopUp(JSONObject incentivesOnTopUp, JSONObject incentivesOnTopUpMDM, JSONObject topUpAmount, String commDefnID, JSONArray supplierRateType, JSONArray supplierRateCode, int objectNumber) {
		incentivesOnTopUp.put(CONTRACTVALIDITY, getContractValidity(incentivesOnTopUpMDM));
		incentivesOnTopUp.put(SELECTEDROW, commDefnID);
		incentivesOnTopUp.put(TYPE, IOTP);
		incentivesOnTopUp.put(COMMERCIAL_ID, commDefnID+"_"+objectNumber);
		incentivesOnTopUp.put(RULEID, commDefnID+"_"+IOTP+"_"+objectNumber);
		if(topUpAmount.has(MODEOFPAYMENT)&&!topUpAmount.getString(MODEOFPAYMENT).equalsIgnoreCase("All"))
			incentivesOnTopUp.put(MODEOFPAYMENT, topUpAmount.getString(MODEOFPAYMENT));
		if(topUpAmount.has(PROP_BANKNAME)&&!topUpAmount.getString(PROP_BANKNAME).equalsIgnoreCase("All"))
			incentivesOnTopUp.put(PROP_BANKNAME, topUpAmount.getString(PROP_BANKNAME));
		incentivesOnTopUp.put(INCENTIVECURRENCY, topUpAmount.getString(PROP_CURRENCY));
		incentivesOnTopUp.put(INCENTIVEAMOUNT, topUpAmount.get(PROP_AMOUNT).toString());
		incentivesOnTopUp.put(INCENTIVEPERCENTAGE, topUpAmount.get(PROP_INCENTIVESINPERCENTAGE).toString());
		if(!supplierRateType.equals("[]") && !supplierRateType.isNull(0))
			incentivesOnTopUp.put(INCENTIVE_RATETYPE, supplierRateType);
		if(!supplierRateCode.equals("[]") && !supplierRateCode.isNull(0))
			incentivesOnTopUp.put(INCENTIVE_RATECODE, supplierRateCode);
	}


	public static JSONObject getMSFFee(JSONObject msfMDM, JSONObject jsonObject, String commDefnID) {
		JSONObject msfFee = new JSONObject();
		msfFee.put(CONTRACTVALIDITY, getContractValidity(msfMDM));
		msfFee.put(SELECTEDROW, commDefnID);
		msfFee.put(RULEID, commDefnID+"_"+MSFFEES);
		msfFee.put(COMMERCIAL_ID, commDefnID);
		msfFee.put(TYPE, MSFFEES);
		JSONObject paymentRule = msfMDM.getJSONObject(PROP_PAYMENTRULE);
		if(paymentRule.has(PROP_TRANSACTIONTYPE))
			msfFee.put(PROP_TRANSACTIONTYPE, paymentRule.getString(PROP_TRANSACTIONTYPE));
		if(paymentRule.has(PROP_MSFCHARGESTYPE))
			msfFee.put(MSFCHARGETYPE, paymentRule.getString(PROP_MSFCHARGESTYPE));
		if(paymentRule.has(PROP_PAYMENTTYPE) && paymentRule.getJSONArray(PROP_PAYMENTTYPE).length()>0)
			msfFee.put(PROP_PAYMENTTYPE, paymentRule.get(PROP_PAYMENTTYPE));
		if(paymentRule.has(PROP_CARDTYPES) && paymentRule.getJSONArray(PROP_CARDTYPES).length()>0)
			msfFee.put(CARDTYPE, paymentRule.get(PROP_CARDTYPES));
		if(msfMDM.has(PROP_FIXED)){
			JSONObject fixed = msfMDM.getJSONObject(PROP_FIXED);
			msfFee.put(SERVICETAXAPPLICABLE, fixed.getBoolean(PROP_BOOLEAN_ISSERVICETAXAPPLIED));
			if(fixed.getBoolean(PROP_BOOLEAN_ISPERCENTAGE))
				msfFee.put(PERCENTAGE,fixed.getJSONObject(PERCENTAGE).get(VALUE).toString());
			if(fixed.getBoolean(PROP_BOOLEAN_ISAMOUNT)){
				msfFee.put(PROP_CURRENCY,fixed.getJSONObject(PROP_AMOUNT).getString(PROP_CURRENCY));
				msfFee.put(PROP_AMOUNT,fixed.getJSONObject(PROP_AMOUNT).get(VALUE).toString());
			}
		}
		return msfFee;
	}


	public static void setLookToBook(JSONObject ltb, JSONObject mainJson, JSONObject jsonObject, String commDefnID) {
		JSONArray ltbArr = new JSONArray();
		if(ltb.getBoolean(PROP_BOOLEAN_ISLTB_BYRATIO)){
			for(int i=0;i<ltb.getJSONArray(PROP_LTB_BYRATIO).length();i++){
				JSONObject lookRatio = ltb.getJSONArray(PROP_LTB_BYRATIO).getJSONObject(i);
				JSONObject lookToBook = new JSONObject();
				lookToBook.put(CONTRACTVALIDITY, getContractValidity(ltb));
				lookToBook.put(SELECTEDROW, commDefnID);
				lookToBook.put(COMMERCIAL_ID,commDefnID+"_"+i);
				lookToBook.put(TYPE, PROP_LOOKTOBOOK);
				lookToBook.put(RULEID, commDefnID+"_"+PROP_LOOKTOBOOK+i);
				JSONObject lookToBookObject = new JSONObject();
				lookToBookObject.put(FROM,lookRatio.getJSONObject(PROP_LOOKRATIO).get(FROM).toString());
				lookToBookObject.put(TO,lookRatio.getJSONObject(PROP_LOOKRATIO).get(TO).toString());
				lookToBookObject.put(PROP_BOOKRATIO, lookRatio.get(PROP_BOOKRATIO).toString());
				lookToBookObject.put(PROP_CURRENCY, lookRatio.optJSONObject(PROP_AMOUNTPEREXCESSLOOK).optString(PROP_CURRENCY));
				lookToBookObject.put(PROP_AMOUNTPEREXCESSLOOK, lookRatio.getJSONObject(PROP_AMOUNTPEREXCESSLOOK).get(PROP_AMOUNT).toString());
				lookToBook.put(PROP_LOOKTOBOOK, lookToBookObject);
				ltbArr.put(lookToBook);
			}
			mainJson.put(LOOKTOBOOK_DT, ltbArr);
			System.out.println(LOOKTOBOOK_DT+" [RATIO]");
		}else{
			JSONObject lookToBook = new JSONObject();
			lookToBook.put(CONTRACTVALIDITY, getContractValidity(ltb));
			lookToBook.put(SELECTEDROW, commDefnID);
			lookToBook.put(TYPE, PROP_LOOKTOBOOK);
			lookToBook.put(RULEID, commDefnID+"_"+PROP_LOOKTOBOOK);
			lookToBook.put(COMMERCIAL_ID,commDefnID);
			JSONObject LTBbyRate = ltb.getJSONObject(PROP_LTB_BYRATE);
			JSONObject lookToBookObject = new JSONObject();
			JSONObject lookRate = new JSONObject();
			JSONObject bookRate = new JSONObject();
			lookRate.put(PROP_AMOUNT, LTBbyRate.getJSONObject(PROP_RATEPERLOOK).get(PROP_AMOUNT).toString());
			lookRate.put(PROP_CURRENCY, LTBbyRate.getJSONObject(PROP_RATEPERLOOK).getString(PROP_CURRENCY));
			lookToBookObject.put(LOOKRATE, lookRate);
			bookRate.put(PROP_AMOUNT, LTBbyRate.getJSONObject(PROP_RATEPERBOOK).get(PROP_AMOUNT).toString());
			bookRate.put(PROP_CURRENCY, LTBbyRate.getJSONObject(PROP_RATEPERBOOK).getString(PROP_CURRENCY));
			lookToBookObject.put(BOOKRATE, bookRate);
			lookToBook.put(PROP_LOOKTOBOOK, lookToBookObject);
			mainJson.put(LOOKTOBOOK_DT, lookToBook);
			System.out.println(LOOKTOBOOK_DT+" [RATE]");
		}
	}


	public static JSONArray getSignUpBonus(JSONObject signUpBonusObj, String commDefnID, String productCategory) {
		JSONArray signUpBonusArr = new JSONArray();
		JSONObject signUpBonus = new JSONObject();
		signUpBonus.put(RULEID, commDefnID+"_"+SIGNUPBONUS+"_");
		signUpBonus.put(COMMERCIAL_ID, commDefnID);
		signUpBonus.put(SELECTEDROW, commDefnID);
		signUpBonus.put(TYPE, SIGNUPBONUS);
		signUpBonus.put(CONTRACTVALIDITY,getContractValidity(signUpBonusObj));
		if(signUpBonusObj.has(PROP_SIGNUPBONUS)){
			if(signUpBonusObj.getJSONObject(PROP_SIGNUPBONUS).has(PROP_CURRENCY))
				signUpBonus.put(COMMERCIALCURRENCY, signUpBonusObj.getJSONObject(PROP_SIGNUPBONUS).getString(PROP_CURRENCY));
			if(signUpBonusObj.getJSONObject(PROP_SIGNUPBONUS).has(VALUE))
				signUpBonus.put(COMMERCIALAMOUNT, signUpBonusObj.getJSONObject(PROP_SIGNUPBONUS).get(VALUE).toString());
		}
		boolean slab = true;
		for(int i=0;i<signUpBonusObj.getJSONArray(PROP_SIGNUPBONUS_CRITERIA).length();i++){
			slab = false;
			JSONObject signupBonusCriteria = signUpBonusObj.getJSONArray(PROP_SIGNUPBONUS_CRITERIA).getJSONObject(i);
			signUpBonus.put(PROP_SLABTYPE, signupBonusCriteria.getString(PROP_SLABTYPE));
			if(signupBonusCriteria.has(PROP_TARGET_FROM) && signupBonusCriteria.has(PROP_TARGET_TO)){
				signUpBonus.put(PROP_SLABTYPEVALUE, BETWEEN+";"+signupBonusCriteria.get(PROP_TARGET_FROM)+";"+signupBonusCriteria.get(PROP_TARGET_TO));
			}else if(signupBonusCriteria.has(PROP_TARGET_TO)){
				signUpBonus.put(PROP_SLABTYPEVALUE, LESSTHANEQUALTO+";"+signupBonusCriteria.get(PROP_TARGET_TO));
			}else{
				signUpBonus.put(PROP_SLABTYPEVALUE, GREATERTHANEQUALTO+";"+signupBonusCriteria.get(PROP_TARGET_FROM));
			}
			signUpBonusArr.put(signUpBonus);
		}
		
		if(slab)
			signUpBonusArr.put(signUpBonus);
		return signUpBonusArr;
	}


	public static JSONObject setFOC(JSONObject mainJson, JSONObject jsonObject, JSONArray commercialHeadArr, String focProd, String prodInfo, String commDefnID) {
		JSONArray focArr = new JSONArray();
		JSONObject tempMain = new JSONObject();
		JSONObject focUtilization = new JSONObject();
		String dtName= null;
		Set<String> utilizationProductCategorySet = new HashSet<String>();
		Set<String> utilizationproductCategorySubTypeSet = new HashSet<String>();
		Set<String> utilizationproductIdSet = new HashSet<String>();
		JSONObject focMDMObj = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(focProd);

		for(int k=0;k<commercialHeadArr.length();k++){
			JSONObject commercialHeadObj = commercialHeadArr.getJSONObject(k);
			if(commercialHeadObj.getString(PROP_COMMHEADNAME).equals(FOC)){
				commercialHeadObj.put(PROP_COMMERCIALTYPE, focMDMObj.getJSONObject(PROP_COMMERCIALINFO).getString(PROP_COMMERCIALTYPE));
				commercialHeadObj.put(PLB_APPLICABLE, focMDMObj.getJSONObject(PROP_COMMERCIALINFO).getBoolean(PROP_BOOLEAN_IS_PLB_APPLICABLE));
			}
		}

		if(focMDMObj.has(PROP_FOC_UTILIZATION) && focMDMObj.getJSONArray(PROP_FOC_UTILIZATION).length()>0){
			for(int i =0; i<focMDMObj.getJSONArray(PROP_FOC_UTILIZATION).length();i++){
				JSONObject focUtilizationObj = focMDMObj.getJSONArray(PROP_FOC_UTILIZATION).getJSONObject(i);
				if(focUtilizationObj.has(PROP_PRODUCTCATEGORY) && !focUtilizationObj.getString(PROP_PRODUCTCATEGORY).equalsIgnoreCase("All"))
					utilizationProductCategorySet.add(focUtilizationObj.getString(PROP_PRODUCTCATEGORY));
				if(focUtilizationObj.has(PROP_PRODUCTCATEGORYSUBTYPE) && !focUtilizationObj.getString(PROP_PRODUCTCATEGORYSUBTYPE).equalsIgnoreCase("All"))
					utilizationproductCategorySubTypeSet.add(focUtilizationObj.getString(PROP_PRODUCTCATEGORYSUBTYPE));
				if(focUtilizationObj.has(PROP_PRODUCTID) && !focUtilizationObj.getString(PROP_PRODUCTID).equalsIgnoreCase("All"))
					utilizationproductIdSet.add(focUtilizationObj.getString(PROP_PRODUCTID));
			}
			focUtilization.put(PROP_PRODUCTCATEGORY, utilizationProductCategorySet);
			focUtilization.put(PROP_PRODUCTCATEGORYSUBTYPE, utilizationproductCategorySubTypeSet);
			focUtilization.put(PROP_PRODUCTNAME, utilizationproductIdSet);
		}
		
		JSONArray slabRunning = new JSONArray();
		if(focMDMObj.has(PROP_SLAB_OR_RUNNING))
			slabRunning = focMDMObj.getJSONArray(PROP_SLAB_OR_RUNNING);
		else if(focMDMObj.has(PROP_SLABS_OR_RUNNING))
			slabRunning = focMDMObj.getJSONArray(PROP_SLABS_OR_RUNNING);
		
		for(int i = 0;i<slabRunning.length();i++){
			JSONObject focObj = new JSONObject();
			JSONArray slabArr = new JSONArray();
			JSONObject slabObj = new JSONObject();
			JSONObject freeOfCosts = new JSONObject();
			JSONObject slabOrRunning = slabRunning.getJSONObject(i);
			slabObj.put(CONTRACTVALIDITY, getContractValidity(focMDMObj));
			if(!focProd.equals(PROP_FOC_HOLIDAYS) && focUtilization!=null && focUtilization.length()!=0)
				freeOfCosts.put(FOCUTILISATION, focUtilization);	
			slabObj.putOpt(PROP_FREEOFCOSTS, freeOfCosts);
			slabObj.put(RULEID, commDefnID+"_"+FOC+i);
			slabObj.put(COMMERCIAL_ID, commDefnID);
			slabObj.put(SELECTEDROW, commDefnID);
			slabObj.put(TYPE, FOC);

			if(focProd.equals(PROP_FOC_FLIGHTS) && slabOrRunning.getJSONArray(PROP_PRODUCT).length()>0)
				slabObj.put(PROP_PRODUCTNAME, slabOrRunning.getJSONArray(PROP_PRODUCT));

			if(slabOrRunning.has(PROP_IATANOS) && slabOrRunning.getJSONArray(PROP_IATANOS).length()>0)
				slabObj.put(IATANO, slabOrRunning.getJSONArray(PROP_IATANOS));
				
			if(slabOrRunning.has(PROP_IATA_NOS) && slabOrRunning.getJSONArray(PROP_IATA_NOS).length()>0)
				slabObj.put(IATANO, slabOrRunning.getJSONArray(PROP_IATA_NOS));
			
			if(slabOrRunning.has(PROP_SLAB)){
				dtName = FOC_SLAB_DT;
				JSONObject slab = new JSONObject();
				JSONObject slabObject = slabOrRunning.getJSONObject(PROP_SLAB);
				slab.put(PROP_SLABTYPE, slabObject.getString(PROP_SLABTYPE));
				if(slabObject.has(PROP_FROMVALUE)){
					if(slabObject.has(PROP_TOVALUE))
						slab.put(PROP_SLABTYPEVALUE,BETWEEN+";"+slabObject.get(PROP_FROMVALUE).toString()+";"+slabObject.get(PROP_TOVALUE).toString());
					else slab.put(PROP_SLABTYPEVALUE,GREATERTHANEQUALTO+";"+slabObject.get(PROP_FROMVALUE).toString());
				}
				else if(slabObject.has(PROP_TOVALUE))
					slab.put(PROP_SLABTYPEVALUE,LESSTHANEQUALTO+";"+slabObject.get(PROP_TOVALUE).toString());

				if(slabObject.has(PROP_ROOMCATEGORY))
					slabObj.put(PROP_SLAB+"_"+PROP_ROOMCATEGORY, slabObject.getString(PROP_ROOMCATEGORY));

				if(slabObject.has(PROP_CABINCLASS))
					slabObj.put(PROP_SLAB+"_"+PROP_CABINCLASS, slabObject.getString(PROP_CABINCLASS));

				if(slabObj.has(PROP_FREEOFCOSTS))
					slabObj.getJSONObject(PROP_FREEOFCOSTS).put(PROP_SLAB, slab);
				else{
					JSONObject foc = new JSONObject();
					foc.put(SLABDETAILS, slab);
					slabObj.put(PROP_FREEOFCOSTS, foc);	
				}
			}
			
			if(slabOrRunning.has(PROP_RUNNING)){
				dtName = FOC_RUNNING_DT;
				JSONObject every = new JSONObject();
				JSONObject running = slabOrRunning.getJSONObject(PROP_RUNNING);
				if(running.has(PROP_EVERY))
					every.put(PROP_EVERY, running.getString(PROP_EVERY));
				if(running.has(PROP_TYPEIS))
					every.put(TYPE, running.getString(PROP_TYPEIS));
				if(running.has(PROP_ROOMCATEGORY))
					every.put(PROP_ROOMCATEGORY, running.getString(PROP_ROOMCATEGORY));
				if(running.has(PROP_CABINCLASS))
					every.put(PROP_CABINCLASS, running.getString(PROP_CABINCLASS));

				if(slabObj.has(PROP_FREEOFCOSTS))
					slabObj.getJSONObject(PROP_FREEOFCOSTS).put(PROP_EVERY, every);
				else{
					JSONObject foc = new JSONObject();
					foc.put(PROP_EVERY, every);
					slabObj.put(PROP_FREEOFCOSTS, foc);	
				}
			}

			if(slabOrRunning.has(PROP_FOC_ROOM)){
				JSONObject focRooms = new JSONObject();
				JSONObject freeOfCostRoom = slabOrRunning.getJSONObject(PROP_FOC_ROOM);
				if(freeOfCostRoom.has(PROP_ROOMCATEGORY))
					focRooms.put(ROOMS+"_"+PROP_ROOMCATEGORY, freeOfCostRoom.getString(PROP_ROOMCATEGORY));
				if(freeOfCostRoom.has(ROOMTYPE))
					focRooms.put(ROOMS+"_"+ROOMTYPE, freeOfCostRoom.getString(ROOMTYPE));
				if(freeOfCostRoom.has(PROP_NO_OF_ROOMS))
					focRooms.put(ROOMS+"_"+NOOFROOMS, freeOfCostRoom.get(PROP_NO_OF_ROOMS).toString());
				if(freeOfCostRoom.has(PROP_FOC_PERCENT))
					focRooms.put(ROOMS+"_"+PERCENTAGE, freeOfCostRoom.get(PROP_FOC_PERCENT).toString());
				if(freeOfCostRoom.has(PROP_PRICECOMPONENTS) && freeOfCostRoom.getJSONArray(PROP_PRICECOMPONENTS).length()>0)
					focRooms.put(ROOMS+"_"+PRICECOMPONENT, freeOfCostRoom.getJSONArray(PROP_PRICECOMPONENTS));

				if(focRooms!=null && focRooms.length()!=0)
					slabObj.getJSONObject(PROP_FREEOFCOSTS).put(FOCROOMS, focRooms);
			}

			if(slabOrRunning.has(PROP_FOC_UPGRADES)){
				JSONObject focUpgrades = new JSONObject();
				JSONObject freeOfCostUpgrades = slabOrRunning.getJSONObject(PROP_FOC_UPGRADES);
				if(freeOfCostUpgrades.has(PROP_UPGRADE_TO_ROOMCATEGORY))
					focUpgrades.put(UPGRADES+"_"+PROP_ROOMCATEGORY, freeOfCostUpgrades.getString(PROP_UPGRADE_TO_ROOMCATEGORY));
				if(freeOfCostUpgrades.has(PROP_UPGRADE_TO_CABINCLASS))
					focUpgrades.put(UPGRADES+"_"+PROP_CABINCLASS, freeOfCostUpgrades.getString(PROP_UPGRADE_TO_CABINCLASS));
				if(freeOfCostUpgrades.has(PROP_RBD))
					focUpgrades.put(UPGRADES+"_"+PROP_RBD, freeOfCostUpgrades.getString(PROP_RBD));
				if(freeOfCostUpgrades.has(PROP_NO_OF_UPGRADES))
					focUpgrades.put(UPGRADES+"_"+NO_OF_UPGRADES, freeOfCostUpgrades.get(PROP_NO_OF_UPGRADES).toString());
				if(freeOfCostUpgrades.has(PROP_FOC_PERCENT))
					focUpgrades.put(UPGRADES+"_"+PERCENTAGE, freeOfCostUpgrades.get(PROP_FOC_PERCENT).toString());
				if(freeOfCostUpgrades.has(PROP_PRICECOMPONENTS) && freeOfCostUpgrades.getJSONArray(PROP_PRICECOMPONENTS).length()>0)
					focUpgrades.put(UPGRADES+"_"+PRICECOMPONENT, freeOfCostUpgrades.getJSONArray(PROP_PRICECOMPONENTS));
				if(freeOfCostUpgrades.has(PROP_FARECOMPONENTS) && freeOfCostUpgrades.getJSONArray(PROP_FARECOMPONENTS).length()>0)
					focUpgrades.put(UPGRADES+"_"+PRICECOMPONENT, freeOfCostUpgrades.getJSONArray(PROP_FARECOMPONENTS));

				if(focUpgrades!=null && focUpgrades.length()!=0)
					slabObj.getJSONObject(PROP_FREEOFCOSTS).put(FOCUPGRADES, focUpgrades);
			}

			if(slabOrRunning.has(PROP_FOCTICKETS)){
				JSONObject focTickets = new JSONObject();
				JSONObject freeOfCostTickets = slabOrRunning.getJSONObject(PROP_FOCTICKETS);
				if(freeOfCostTickets.has(PROP_CABINCLASS))
					focTickets.put(TICKETS+"_"+PROP_CABINCLASS, freeOfCostTickets.getString(PROP_CABINCLASS));
				if(freeOfCostTickets.has(PROP_RBD))
					focTickets.put(TICKETS+"_"+PROP_RBD, freeOfCostTickets.getString(PROP_RBD));
				if(freeOfCostTickets.has(PROP_NO_OF_TICKETS))
					focTickets.put(TICKETS+"_"+PROP_NO_OF_TICKETS, freeOfCostTickets.get(PROP_NO_OF_TICKETS).toString());
				if(freeOfCostTickets.has(PROP_FOC_PERCENT))
					focTickets.put(TICKETS+"_"+PERCENTAGE, freeOfCostTickets.get(PROP_FOC_PERCENT).toString());
				if(freeOfCostTickets.has(PROP_FARECOMPONENTS) && freeOfCostTickets.getJSONArray(PROP_FARECOMPONENTS).length()>0)
					focTickets.put(TICKETS+"_"+PRICECOMPONENT, freeOfCostTickets.getJSONArray(PROP_FARECOMPONENTS));

				if(focTickets!=null && focTickets.length()!=0)
					slabObj.getJSONObject(PROP_FREEOFCOSTS).put(FOCTICKETS, focTickets);
			}

			if(slabOrRunning.has(PROP_SUPP_RATE)){	
				if(slabOrRunning.getJSONArray(PROP_SUPP_RATE).length()>0){
					HashSet<String> supplierRatetype = new HashSet<>();
					HashSet<String> supplierRateCode = new HashSet<>();
					for(int j=0;j<slabOrRunning.getJSONArray(PROP_SUPP_RATE).length();j++){
						if(slabOrRunning.getJSONArray(PROP_SUPP_RATE).getJSONObject(j).has(PROP_SUPPLIER_RATETYPE))
							supplierRatetype.add(slabOrRunning.getJSONArray(PROP_SUPP_RATE).getJSONObject(j).getString(PROP_SUPPLIER_RATETYPE));
						if(slabOrRunning.getJSONArray(PROP_SUPP_RATE).getJSONObject(j).has(PROP_SUPPLIER_RATECODE))
							supplierRateCode.add(slabOrRunning.getJSONArray(PROP_SUPP_RATE).getJSONObject(j).getString(PROP_SUPPLIER_RATECODE));
					}
					if(supplierRatetype.size()>0)
						slabObj.put(PROP_SUPPLIERRATETYPE, supplierRatetype);
					if(supplierRateCode.size()>0)
						slabObj.put(PROP_SUPPLIER_RATECODE, supplierRateCode);
				}
			}
			slabArr.put(slabObj);
			focObj.put(dtName, slabArr);

			if(slabOrRunning.getJSONArray(PROP_CLIENT).length()>0){
				JSONArray clientArr = new JSONArray();
				for(int j=0;j<slabOrRunning.getJSONArray(PROP_CLIENT).length();j++){
					JSONObject client = slabOrRunning.getJSONArray(PROP_CLIENT).getJSONObject(j);
					JSONObject clientObj = new JSONObject(new JSONTokener(focObj.getJSONArray(dtName).getJSONObject(0).toString()));
					if(client.has(PROP_CLIENTTYPE) && !client.getString(PROP_CLIENTTYPE).equalsIgnoreCase("All"))
						clientObj.put(PROP_CLIENTTYPE,client.getString(PROP_CLIENTTYPE));
					if(client.has(CLIENTGROUP) && !client.getString(CLIENTGROUP).equalsIgnoreCase("All"))
						clientObj.put(CLIENTGROUP,client.getString(CLIENTGROUP));
					if(client.has(PROP_CLIENTNAME) && !client.getString(PROP_CLIENTNAME).equalsIgnoreCase("All"))
						clientObj.put(PROP_CLIENTNAME,client.getString(PROP_CLIENTNAME));

					clientObj.put(RULEID, clientObj.getString(RULEID)+PROP_CLIENT+j);
					clientArr.put(clientObj);
				}
				focObj.put(dtName,clientArr);
			}

			if(slabOrRunning.optJSONArray(FREEOFCOST) != null && slabOrRunning.getJSONArray(FREEOFCOST).length()>0){
				JSONArray arr = new JSONArray();
				for(int j =0; j<focObj.getJSONArray(dtName).length(); j++){
					for(int k=0;k<slabOrRunning.getJSONArray(FREEOFCOST).length();k++){
						JSONObject fcObj = slabOrRunning.getJSONArray(FREEOFCOST).getJSONObject(k);
						JSONObject obj = new JSONObject(new JSONTokener(focObj.getJSONArray(dtName).getJSONObject(j).toString()));
						JSONObject foc = new JSONObject();
						if(fcObj.has(PROP_NO_OF_FREE))
							foc.put(NUMBEROFFREE,fcObj.get(PROP_NO_OF_FREE).toString());
						if(fcObj.has(PROP_FOC_PERCENT))
							foc.put(PERCENTAGE,fcObj.get(PROP_FOC_PERCENT).toString());
						if(fcObj.has(PROP_PRICECOMPONENTS))
							foc.put(PRICECOMPONENT,fcObj.getString(PROP_PRICECOMPONENTS));

						obj.getJSONObject(PROP_FREEOFCOSTS).put(FREEOFCOST, foc);
						obj.put(RULEID, obj.getString(RULEID)+FREEOFCOST+j+k);
						arr.put(obj);
					}
				}
				focObj.put(dtName,arr);
			}

			if(!focProd.equals(PROP_FOC_FLIGHTS)){
				if(slabOrRunning.getJSONArray(prodInfo).length()>0){
					JSONArray prodArr = new JSONArray();
					for(int j =0; j<focObj.getJSONArray(dtName).length(); j++){
						for(int k=0;k<slabOrRunning.getJSONArray(prodInfo).length();k++){
							JSONObject prod = slabOrRunning.getJSONArray(prodInfo).getJSONObject(k);
							JSONObject prodObj = new JSONObject(new JSONTokener(focObj.getJSONArray(dtName).getJSONObject(j).toString()));
							if(prod.has(PROP_CHAIN) && !prod.getString(PROP_CHAIN).equalsIgnoreCase("All"))
								prodObj.put(PRODUCTCHAIN,prod.getString(PROP_CHAIN));
							if(prod.has(PROP_BRAND) && !prod.getString(PROP_BRAND).equalsIgnoreCase("All"))
								prodObj.put(PRODUCTBRAND,prod.getString(PROP_BRAND));
							if(prod.has(PROP_PRODUCTID) && !prod.getString(PROP_PRODUCTID).equalsIgnoreCase("All"))
								prodObj.put(PROP_PRODUCTNAME,prod.getString(PROP_PRODUCTID));
							if(prod.has(PROP_PRODUCTCATEGORYSUBTYPE) && !prod.getString(PROP_PRODUCTCATEGORYSUBTYPE).equalsIgnoreCase("All"))
								prodObj.put(PROP_PRODUCTCATEGORYSUBTYPE,prod.getString(PROP_PRODUCTCATEGORYSUBTYPE));
							if(prod.has(PROP_PRODUCTTYPE) && !prod.getString(PROP_PRODUCTTYPE).equalsIgnoreCase("All"))
								prodObj.put(PROP_PRODUCTTYPE,prod.getString(PROP_PRODUCTTYPE));
							if(prod.has(PROP_PRODUCTNAMESUBTYPE) && !prod.getString(PROP_PRODUCTNAMESUBTYPE).equalsIgnoreCase("All"))
								prodObj.put(PROP_PRODUCTNAMESUBTYPE,prod.getString(PROP_PRODUCTNAMESUBTYPE));

							prodObj.put(RULEID, prodObj.getString(RULEID)+PROP_PRODUCT+j+k);
							prodArr.put(prodObj);
						}
					}
					focObj.put(dtName,prodArr);
				}
			}
			focArr.put(focObj);
		}	
		if(focArr.getJSONObject(0).getJSONArray(dtName).length()>1){
			for(int i =0;i<focArr.length();i++){
				for(int j=0; j<focArr.getJSONObject(i).getJSONArray(dtName).length();j++){
					tempMain.accumulate(dtName, focArr.getJSONObject(i).getJSONArray(dtName).getJSONObject(j));
				}
			}
			mainJson.put(dtName, tempMain.getJSONArray(dtName));
			return mainJson;
		}
		else{
			mainJson.put(dtName, focArr.getJSONObject(0).getJSONArray(dtName));
			return mainJson;
		}
	}


	public static JSONArray otherFees(JSONObject jsonObject, String commDefnID, String productName, JSONArray advanceDefinationData, String commercialName) {
		JSONObject otherFeeObjectMDM = jsonObject.getJSONObject(PROP_ADVCOMM).getJSONObject(OTHERFEES);
		JSONArray otherFeeArr = new JSONArray();
		JSONObject otherFee = new JSONObject();
		otherFee.put(RULEID, commDefnID+"_"+commercialName);
		otherFee.put(TYPE, TYPE_OTHERFEE);
		otherFee.put(SELECTEDROW, commDefnID);
		otherFee.put(COMMERCIAL_ID, commDefnID);
		otherFee.put(CONTRACTVALIDITY,getContractValidity(otherFeeObjectMDM));
		if(otherFeeObjectMDM.getBoolean(PROP_ISFIXED)){
			JSONObject fixed = otherFeeObjectMDM.getJSONObject(PROP_FIXED);
			otherFee.put(COMMERCIALCURRENCY, fixed.getString(PROP_CURRENCY));
			otherFee.put(COMMERCIALAMOUNT, fixed.get(VALUE).toString());
		}else appliedOnOtherFees(otherFeeObjectMDM, otherFee);
		applyOn(otherFeeObjectMDM, otherFee);
		otherFeeArr.put(otherFee);
		
		if(otherFeeObjectMDM.has(PROP_ADVDEFN_ID)){
			for(int i=0;i<advanceDefinationData.length();i++){
				JSONObject advanceDefinationDataObj = advanceDefinationData.getJSONObject(i);
				if(advanceDefinationDataObj.getString(PROP_ID).equals(otherFeeObjectMDM.getString(PROP_ADVDEFN_ID))){
					return setAdvancedDefintionOtherFees(advanceDefinationDataObj,productName,jsonObject,commDefnID,otherFeeArr,commercialName);
				}
			}
		}
		return otherFeeArr;
	}


	public static JSONArray setAdvancedDefintionOtherFees(JSONObject advanceDefinationDataObj, String productName, JSONObject jsonObject, String commDefnID, JSONArray otherFeeArr, String commercialName) {
		switch(productName){
		case PRODUCTNAME_ACCOMODATION:{
			JSONObject advanceDefinitionAccommodation = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_ACCO);
			Accomodation.setAccoOtherFeesAdvancedDefinition(advanceDefinitionAccommodation,otherFeeArr,commercialName);
			if(advanceDefinitionAccommodation.has(PROP_VALIDITY)){
				JSONObject validity = advanceDefinitionAccommodation.getJSONObject(PROP_VALIDITY);
				JSONArray salePlusTravel = validity.getJSONArray(PROP_SALEPLUSTRAVEL);
				CommonFunctions.setOtherFeesSalePlusTravel(salePlusTravel,otherFeeArr,commercialName);
			}
			break;
		}
		case PRODUCTNAME_HOLIDAYS:{
			JSONObject advanceDefinitionHolidays = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_HOLIDAYS);
			Holidays.setOtherFeesHolidaysAdvancedDefinition(advanceDefinitionHolidays, otherFeeArr,commercialName);
			break;
		}
		case PRODUCTNAME_ACTIVITIES:{
			JSONObject advanceDefinitionActivities = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_ACTIVITIES);
			Activities.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionActivities,jsonObject, commDefnID,commercialName);
			break;
		}
		case PRODUCTNAME_BUS:{
			JSONObject advanceDefinitionBus = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
			CommonFunctions.setTransportationOtherFeesAdvancedDefinition(advanceDefinitionBus, otherFeeArr,commercialName);
			break;
		}
		case PRODUCTNAME_CARRENTALS:{
			JSONObject advanceDefinitionCarRentals = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
			CommonFunctions.setTransportationOtherFeesAdvancedDefinition(advanceDefinitionCarRentals, otherFeeArr,commercialName);
			//car details
			break;
		}
		case PRODUCTNAME_CRUISE:{
			JSONObject advanceDefinitionCruise = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
			CommonFunctions.setTransportationOtherFeesAdvancedDefinition(advanceDefinitionCruise, otherFeeArr,commercialName);
			break;
		}
		case PRODUCTNAME_RAIL:{
			//JSONObject advanceDefinitionRail = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
			break;
		}
		case PRODUCTNAME_AIR:{
			JSONObject advanceDefinitionAir = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_AIR);
			Air.getOtherFeesAdvancedDefinition(otherFeeArr, advanceDefinitionAir,commercialName);
			break;
		}
		case PRODUCTNAME_RENTALS:{}
		case PRODUCTNAME_INSURANCE:{}
		case PRODUCTNAME_VISA:{}
		case PRODUCTNAME_TRANSFERS:{
			JSONObject advanceDefinitionTransfers = advanceDefinationDataObj.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
			CommonFunctions.setTransportationOtherFeesAdvancedDefinition(advanceDefinitionTransfers, otherFeeArr,commercialName);
			break;
		}
		}
		return otherFeeArr;
	}


	public static void appliedOnOtherFees(JSONObject mdmOtherFees, JSONObject otherFee) {
		if(mdmOtherFees.has(PERCENTAGE) && mdmOtherFees.getJSONArray(PERCENTAGE).length()>0){
			JSONArray percentArr = new JSONArray();
			for(int i=0;i<mdmOtherFees.getJSONArray(PERCENTAGE).length();i++){
				JSONObject percent = mdmOtherFees.getJSONArray(PERCENTAGE).getJSONObject(i);
				JSONObject percentObj = new JSONObject();
				percentObj.put(COMMERCIALNAME, percent.getString(PROP_APPLIEDON_COMMHEAD));
				percentObj.put(COMMERCIALPERCENTAGE, percent.get(PROP_PERCENT).toString());
				percentArr.put(percentObj);
			}
			otherFee.put(PERCENTAGE, percentArr);
		}
	}


	public static void applyOn(JSONObject mdmOtherFees, JSONObject otherFee) {
		if(mdmOtherFees.has(PROP_APPLYON) && mdmOtherFees.getJSONArray(PROP_APPLYON).length()>0){
			JSONArray productCategory = new JSONArray();
			JSONArray productCategorySubType = new JSONArray();
			for(int i=0;i<mdmOtherFees.getJSONArray(PROP_APPLYON).length();i++){
				JSONObject applyOn = mdmOtherFees.getJSONArray(PROP_APPLYON).getJSONObject(i);
				if(applyOn.getString(PROP_PRODUCTCATEGORY).length()!=0)
					productCategory.put(applyOn.getString(PROP_PRODUCTCATEGORY));
				if(applyOn.getString(PROP_PRODUCTCATEGORYSUBTYPE).length()!=0)
					productCategorySubType.put(applyOn.getString(PROP_PRODUCTCATEGORYSUBTYPE));
			}
			otherFee.put(APPLICABLE_PRODUCT_CATEGORY, productCategory);
			otherFee.put(APPLICABLE_PRODUCT_CATEGORY_SUBTYPE, productCategorySubType);
		}
	}


	public static JSONObject getContractValidity(JSONObject mdmOtherFees) {
		JSONObject contractValidity = new JSONObject();
		if(mdmOtherFees.has(PROP_CONTRACT_VAL_TO)){
			contractValidity.put(FROM, mdmOtherFees.getString(PROP_CONTRACT_VAL_FROM).substring(0, 11)+"00:00:00");
			contractValidity.put(TO, mdmOtherFees.getString(PROP_CONTRACT_VAL_TO).substring(0, 11)+"23:59:59");
			contractValidity.put(OPERATOR, BETWEEN);
		}else{
			contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
			contractValidity.put(VALUE, mdmOtherFees.getString(PROP_CONTRACT_VAL_FROM).substring(0, 11)+"00:00:00");
		}
		return contractValidity;
	}


	public static void appendProductCategoryAndSubType(JSONObject commJson, String productName, String productCategory, String productCategorySubType) {
		switch(productName){
		case PRODUCTNAME_ACCOMODATION:{
			commJson.put(PROP_PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		case PRODUCTNAME_HOLIDAYS:{
			commJson.put(PROP_PRODUCTCATEGORY, productCategory);
			commJson.put(PROP_PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		case PRODUCTNAME_CARRENTALS:{
			commJson.put(PROP_PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		
		}
	}
}
