package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Activities implements Constants{

	public static String setCommercials(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception {
		if(baseArr.length()>0){
			JSONObject standardCommercial = CommonFunctions.stdComm;
			if(standardCommercial.has(PROP_PRODUCT) && standardCommercial.getJSONObject(PROP_PRODUCT).has(PRODUCTNAME_ACTIVITIES)){
				JSONObject activities = standardCommercial.getJSONObject(PROP_PRODUCT).getJSONObject(PRODUCTNAME_ACTIVITIES);
				if(activities.has(PROP_IATANOS) && activities.getJSONArray(PROP_IATANOS).length()>0)
					calcArr.getJSONObject(0).put(PROP_IATANOS, activities.getJSONArray(PROP_IATANOS));
				if(activities.has(PROP_PRODUCTINFO) && activities.getJSONArray(PROP_PRODUCTINFO).length()>0)
					setProductInformation(baseArr,calcArr,activities.getJSONArray(PROP_PRODUCTINFO),STANDARD);
				if(activities.has(PROP_SUPP_RATE) && activities.getJSONArray(PROP_SUPP_RATE).length()>0)
					CommonFunctions.getSupplierRate(activities.getJSONArray(PROP_SUPP_RATE),calcArr);
			}

			if(standardCommercial.has(PROP_ADVDEFN_ID)){
				String advDefnID = standardCommercial.getString(PROP_ADVDEFN_ID);
				for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(i);
					if(advanceDefinationData.getString(PROP_ID).equals(advDefnID)){
						JSONObject advanceDefinitionActivities = advanceDefinationData.getJSONObject(PROP_ADVDEFN_ACTIVITIES);
						setActivitiesAdvancedDefinition(advanceDefinitionActivities,baseArr,calcArr,STANDARD);
					}
				}
			}

			JSONArray commercialHead = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
			CommonFunctions.setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,CommonFunctions.mdmRuleID,CommonFunctions.suppCommDataId);
			CommonFunctions.setCommercialId(mainJson, CommonFunctions.suppCommDataId);
		}
		//System.out.println("Activities Transactional: "+mainJson.toString());
		return mainJson.toString();		
	}


	private static void setProductInformation(JSONArray baseArr, JSONArray calcArr, JSONArray productInformation, String commercialName) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<productInformation.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject productInformationObject = productInformation.getJSONObject(j);
				if(productInformationObject.has(PROP_PRODUCTCATEGORYSUBTYPE))
					calculation.put(PROP_PRODUCTCATEGORYSUBTYPE, productInformationObject.getString(PROP_PRODUCTCATEGORYSUBTYPE));
				if(productInformationObject.has(PROP_PRODUCTTYPE))
					calculation.put(PROP_PRODUCTTYPE, productInformationObject.getString(PROP_PRODUCTTYPE));
				if(productInformationObject.has(PROP_PRODUCTNAME))
					calculation.put(PROP_PRODUCTNAME, productInformationObject.getString(PROP_PRODUCTNAME));
				if(productInformationObject.has(PROP_PRODUCTNAME_SUBTYPE))
					calculation.put(PROP_PRODUCTNAME_SUBTYPE, productInformationObject.getString(PROP_PRODUCTNAME_SUBTYPE));
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+"_"+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setActivitiesAdvancedDefinition(JSONObject advanceDefinitionActivities, JSONArray baseArr, JSONArray calcArr, String commercialName) {
		if(advanceDefinitionActivities.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionActivities.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				CommonFunctions.insertSalePlusTravel(baseArr, calcArr, validity.getJSONArray(PROP_SALEPLUSTRAVEL), true, true,commercialName);
			}
		}

		if(advanceDefinitionActivities.has(PROP_TRAVELDEST)){
			JSONObject travelDestination = advanceDefinitionActivities.getJSONObject(PROP_TRAVELDEST);
			if(travelDestination.has(PROP_DESTINATIONS) && travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
				JSONObject travelDestinations = travelDestination.getJSONArray(PROP_DESTINATIONS).getJSONObject(0);
				if(travelDestinations.has(PROP_TRIGGERPAYOUT) && travelDestinations.getJSONArray(PROP_TRIGGERPAYOUT).length()>0){
					CommonFunctions.getDestination(baseArr, calcArr, travelDestination.getJSONArray(PROP_DESTINATIONS), travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION), false,commercialName);
				}else CommonFunctions.getDestination(baseArr, calcArr, travelDestination.getJSONArray(PROP_DESTINATIONS), travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION), false,commercialName);
			}
		}

		if(advanceDefinitionActivities.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionActivities.getJSONObject(PROP_OTHERS);
			if(others.has(PROP_TRIGGERPAYOUT) && others.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				CommonFunctions.getBookingTypeTP(baseArr, others, true);//isInclusion : true
			else{
				if(others.has(PROP_BOOKINGTYPE)){
					for(int i=0;i<baseArr.length();i++){
						JSONObject base = baseArr.getJSONObject(i);
						base.put(PROP_BOOKINGTYPE, others.getString(PROP_BOOKINGTYPE));//inBase
					}
				}
			}
		}

		if(advanceDefinitionActivities.has(PROP_CREDENTIALS) && advanceDefinitionActivities.getJSONArray(PROP_CREDENTIALS).length()>0){
			JSONObject credentials = advanceDefinitionActivities.getJSONArray(PROP_CREDENTIALS).getJSONObject(0);
			if(credentials.has(PROP_TRIGGERPAYOUT) && credentials.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionActivities.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionActivities.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true);
		}

		if(advanceDefinitionActivities.has(PROP_NATIONALITY) && advanceDefinitionActivities.getJSONArray(PROP_NATIONALITY).length()>0){
			JSONObject nationality = advanceDefinitionActivities.getJSONArray(PROP_NATIONALITY).getJSONObject(0);
			if(nationality.has(PROP_TRIGGERPAYOUT) && nationality.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionActivities.getJSONArray(PROP_NATIONALITY), PROP_CLIENTNATIONALITY, true, true,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionActivities.getJSONArray(PROP_NATIONALITY), PROP_CLIENTNATIONALITY, true, true);
		}

		if(advanceDefinitionActivities.has(PROP_CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionActivities.getJSONObject(PROP_CONNECTIVITY);
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				if(connectivity.has(PROP_TRIGGERPAYOUT) && connectivity.getJSONArray(PROP_TRIGGERPAYOUT).length()>0){
					CommonFunctions.getConnectivityTP(baseArr, connectivity);
					break;
				}
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					base.put(CONN_SUPPTYPE,connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					base.put(CONN_SUPPNAME,connectivity.getString(PROP_SUPPLIERID));
			}
		}

		if(advanceDefinitionActivities.has(PROP_PASSENGERTYPES) && advanceDefinitionActivities.getJSONArray(PROP_PASSENGERTYPES).length()>0){
			JSONObject passengerType = advanceDefinitionActivities.getJSONArray(PROP_PASSENGERTYPES).getJSONObject(0);
			if(passengerType.has(PROP_TRIGGERPAYOUT) && passengerType.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionActivities.getJSONArray(PROP_PASSENGERTYPES), PROP_PASSENGERTYPES, true, false,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionActivities.getJSONArray(PROP_PASSENGERTYPES), PROP_PASSENGERTYPES, true, false);
		}
	}


	public static void getOtherFeesAdvancedDefinition(JSONArray otherFeeArr, JSONObject advanceDefinition, JSONObject jsonObject, String commDefnID, String commercialName){
		int length =otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
			if(advanceDefinition.has(PROP_CONNECTIVITY)){
				JSONObject connectivity = advanceDefinition.getJSONObject(PROP_CONNECTIVITY);
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					otherFee.put(CONN_SUPPTYPE, connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPID) && !connectivity.getString(PROP_SUPPID).equalsIgnoreCase("All"))
					otherFee.put(CONN_SUPPNAME, connectivity.getString(PROP_SUPPID));
			}
			
			if(advanceDefinition.has(PROP_CREDENTIALS) && advanceDefinition.getJSONArray(PROP_CREDENTIALS).length()>0){
				JSONArray credentials = new JSONArray() ;
				for(int j=0;j< advanceDefinition.getJSONArray(PROP_CREDENTIALS).length();j++){
					if( advanceDefinition.getJSONArray(PROP_CREDENTIALS).getJSONObject(j).has(PROP_CREDENTIALS));
					credentials.put(advanceDefinition.getJSONArray(PROP_CREDENTIALS).getJSONObject(j).getString(PROP_CREDENTIALS));
				}
				otherFee.put(CREDENTIALSNAME, credentials);
			}
			
			if(advanceDefinition.has(PROP_OTHERS)){
				if (advanceDefinition.getJSONObject(PROP_OTHERS).has(PROP_BOOKINGTYPE)) 
					otherFee.put(PROP_BOOKINGTYPE, advanceDefinition.getJSONObject(PROP_OTHERS).getString(PROP_BOOKINGTYPE));
			}

			/*if(advanceDefinition.has(PROP_PASSENGERTYPES) && advanceDefinition.getJSONArray(PROP_PASSENGERTYPES).length()>0){
				JSONArray passengerTypes  = advanceDefinition.getJSONArray(PROP_PASSENGERTYPES);
				JSONArray paxType = new JSONArray();
				for(int i=0;i<passengerTypes.length();i++){
					paxType.put(passengerTypes.getJSONObject(i).getString(PROP_PASSENGERTYPES));
				}
				otherFee.put("participantCategory", paxType);
			}*/
			
			otherFeeArr.put(otherFee);
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
		if(advanceDefinition.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinition.getJSONObject(PROP_VALIDITY);
			JSONArray salePlusTravel = validity.getJSONArray(PROP_SALEPLUSTRAVEL);
			CommonFunctions.setOtherFeesSalePlusTravel(salePlusTravel,otherFeeArr,commercialName);
		}
		if(advanceDefinition.has(PROP_TRAVELDEST)){
			JSONObject travelDestination = advanceDefinition.getJSONObject(PROP_TRAVELDEST);
			JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
			if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION))
				CommonFunctions.setOtherFeesDestination(otherFeeArr, destinations, true , commercialName);
			else CommonFunctions.setOtherFeesDestination(otherFeeArr, destinations, false , commercialName);

		}
	}
}
