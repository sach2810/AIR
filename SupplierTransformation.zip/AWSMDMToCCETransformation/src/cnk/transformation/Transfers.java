package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.transformation.CommonFunctions;

public class Transfers implements Constants {
	
	public static String setCommercials(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		if(baseArr.length()>0){
			JSONObject standardCommercial = CommonFunctions.stdComm;
			if(standardCommercial.has(PROP_PRODUCT)){
				if(standardCommercial.getJSONObject(PROP_PRODUCT).has(PROP_TRANSPORTATION)){
					JSONObject transportation = standardCommercial.getJSONObject(PROP_PRODUCT).getJSONObject(PROP_TRANSPORTATION);
					if(transportation.has(PROP_PRODUCT)){
						if(transportation.getJSONObject(PROP_PRODUCT).has(PROP_GENERICPRODUCT)){
							for(int i=0;i<baseArr.length();i++){
								JSONObject baseP = baseArr.getJSONObject(i);
								baseP.put(PROP_PRODUCTID, transportation.getJSONObject(PROP_PRODUCT).getJSONObject(PROP_GENERICPRODUCT).getJSONArray(PROP_PRODUCTID));
							}
						}
					}
				}
			}

			/*if(standardCommercial.getJSONArray(PROP_CLIENTS).length()>0)
				CommonFunctions.getClientDetails(baseArr,calcArr,standardCommercial.getJSONArray(PROP_CLIENTS));*/

			if(standardCommercial.has(PROP_ADVDEFN_ID)){
				String advDefnID = standardCommercial.getString(PROP_ADVDEFN_ID);
				for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(i);
					if(advanceDefinationData.getString(PROP_ID).equals(advDefnID)){
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true,STANDARD);
						appendVehicleDetails(baseArr,calcArr,advanceDefinitionTransportation,STANDARD);
						
					}
				}
			}
			
			JSONArray commercialHead = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
			CommonFunctions.setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,CommonFunctions.mdmRuleID,CommonFunctions.suppCommDataId);
			CommonFunctions.setCommercialId(mainJson, CommonFunctions.suppCommDataId);
		}
		//System.out.println("Transfers Transactional: "+mainJson.toString());
		return mainJson.toString();
	}
	
	
	public static void appendVehicleDetails(JSONArray advancedArr, JSONArray calcArr, JSONObject advanceDefinitionTransportation, String commercialName) {
		if(advanceDefinitionTransportation.has(PROP_VEHICLEDETAILS)){
			JSONObject vehicleDetails = advanceDefinitionTransportation.getJSONObject(PROP_VEHICLEDETAILS);
			if(vehicleDetails.has(PROP_VEHICLES) && vehicleDetails.getJSONArray(PROP_VEHICLES).length()>0){
				JSONArray vehicles = vehicleDetails.getJSONArray(PROP_VEHICLES);
				int length= advancedArr.length();
				for(int i=0;i<length;i++){
					for(int j=0;j<vehicles.length();j++){
						JSONObject base = new JSONObject(new JSONTokener(advancedArr.getJSONObject(i).toString()));
						JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
						JSONObject vehicle = vehicles.getJSONObject(j);
						if(vehicleDetails.getBoolean(PROP_BOOLEAN_ISINCLUSION)){
							/*if(vehicle.has(PROP_SIPP_ACRISSCODE))
								calculation.put(PROP_SIPP_ACRISSCODE, vehicle.getString(PROP_SIPP_ACRISSCODE));*/
							if(vehicle.has(PROP_VEHICLECATEGORY))
								calculation.put(PROP_VEHICLECATEGORY, vehicle.getString(PROP_VEHICLECATEGORY));
							if(vehicle.has(PROP_VEHICLENAME))
								calculation.put(PROP_VEHICLENAME, vehicle.getString(PROP_VEHICLENAME));
						}else{
							/*if(vehicle.has(PROP_SIPP_ACRISSCODE))
								calculation.put(PROP_SIPP_ACRISSCODE+"_"+EXCLUSION, vehicle.getString(PROP_SIPP_ACRISSCODE));*/
							if(vehicle.has(PROP_VEHICLECATEGORY))
								calculation.put(PROP_VEHICLECATEGORY+"_"+EXCLUSION, vehicle.getString(PROP_VEHICLECATEGORY));
							if(vehicle.has(PROP_VEHICLENAME))
								calculation.put(PROP_VEHICLENAME+"_"+EXCLUSION, vehicle.getString(PROP_VEHICLENAME));
						}
						CommonFunctions.setRuleID(advancedArr, calcArr, base, calculation, commercialName+PROP_VEHICLES+i+j);
					}
				}
				for(int i=0;i<length;i++){
					advancedArr.remove(0);
					calcArr.remove(0);
				}
			}
		}
		for(int j=0;j<calcArr.length();j++){
			JSONObject calculationClone = calcArr.getJSONObject(j);
			/*if(advanceDefinitionTransportation.has("rateTypeApplicableFor"))
				calculationClone.put("rateTypeApplicableFor", advanceDefinitionTransportation.getString("rateTypeApplicableFor"));
			if(advanceDefinitionTransportation.has("category"))
				calculationClone.put("rateTypeApplicableForCategory", advanceDefinitionTransportation.getString("category"));*/
			if(advanceDefinitionTransportation.has(PROP_BOOLEAN_ISPREPAID)){
				if(advanceDefinitionTransportation.getBoolean(PROP_BOOLEAN_ISPREPAID))
					calculationClone.put(MODEOFPAYMENT, PREPAID);
				else calculationClone.put(MODEOFPAYMENT, POSTPAID);
			}
		}
	}
}
