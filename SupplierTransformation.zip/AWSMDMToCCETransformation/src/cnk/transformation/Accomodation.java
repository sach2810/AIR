package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Accomodation implements Constants{
	
	public static String setCommercials(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		if(baseArr.length()>0){
			JSONObject standardCommercial = CommonFunctions.stdComm;
			JSONObject accommodation = standardCommercial.getJSONObject(PROP_PRODUCT).getJSONObject(PROP_ACCOMODATION);

			if(accommodation.getJSONArray(PROP_IATANOS).length()>0)
				baseArr.getJSONObject(0).put(IATANO, accommodation.getJSONArray(PROP_IATANOS));

			if(accommodation.getJSONArray(PROP_SUPP_RATE).length()>0)
				CommonFunctions.getSupplierRate(accommodation.getJSONArray(PROP_SUPP_RATE),calcArr);

			if(accommodation.getJSONArray(PROP_PRODUCTINFO).length()>0){
				JSONArray productInformationArr = accommodation.getJSONArray(PROP_PRODUCTINFO);
				CommonFunctions.getProductDetails(productInformationArr,baseArr,calcArr,STANDARD);
			}

			if(standardCommercial.getJSONArray(PROP_CLIENTS).length()>0)
				CommonFunctions.getClientDetails(baseArr,calcArr,standardCommercial.getJSONArray(PROP_CLIENTS),STANDARD);

			if(standardCommercial.has(PROP_ADVDEFN_ID)){
				String advDefnID = standardCommercial.getString(PROP_ADVDEFN_ID);
				for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(i);
					if(advanceDefinationData.getString(PROP_ID).equals(advDefnID)){
						JSONObject advanceDefinitionAccommodation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_ACCO);
						setAccomodationAdvancedDefinition(advanceDefinitionAccommodation,baseArr,calcArr,STANDARD);
						if(advanceDefinitionAccommodation.has(PROP_TRAVELDEST)){
							JSONObject travelDestination = advanceDefinitionAccommodation.getJSONObject(PROP_TRAVELDEST);
							JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
							CommonFunctions.getDestination(baseArr, calcArr, destinations, travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION), true, STANDARD);
						}
					}
				}
			}
			JSONArray commercialHead = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
			CommonFunctions.setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,CommonFunctions.mdmRuleID,CommonFunctions.suppCommDataId);
			CommonFunctions.setCommercialId(mainJson, CommonFunctions.suppCommDataId);
		}
		//System.out.println("Accomodation Transactional: "+mainJson.toString());
		return mainJson.toString();
	}


	public static void setPLBAdvancedDefinition(JSONObject advanceDefinitionAccommodationPLB, JSONArray baseArr, JSONArray calcArr, String commercialName) {
		if(advanceDefinitionAccommodationPLB.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionAccommodationPLB.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				JSONArray salePlusTravel = validity.getJSONArray(PROP_SALEPLUSTRAVEL);
				CommonFunctions.insertSalePlusTravel(salePlusTravel,baseArr,calcArr,true,true,commercialName);
			}
		}

		if(advanceDefinitionAccommodationPLB.has(PROP_NATIONALITY) && advanceDefinitionAccommodationPLB.getJSONArray(PROP_NATIONALITY).length()>0)
			CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray(PROP_NATIONALITY),PROP_CLIENTNATIONALITY,true,commercialName);

		if(advanceDefinitionAccommodationPLB.has(PROP_PASSENGERTYPES) && advanceDefinitionAccommodationPLB.getJSONArray(PROP_PASSENGERTYPES).length()>0)
			CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray(PROP_PASSENGERTYPES),PROP_PASSENGERTYPES,false,commercialName);

		if(advanceDefinitionAccommodationPLB.has(PROP_CREDENTIALS) && advanceDefinitionAccommodationPLB.getJSONArray(PROP_CREDENTIALS).length()>0)
			CommonFunctions.getTriggerPayoutArray(baseArr,calcArr,advanceDefinitionAccommodationPLB.getJSONArray(PROP_CREDENTIALS),PROP_CREDENTIALID,true,commercialName);

		if(advanceDefinitionAccommodationPLB.has(PROP_CONNECTIVITY))
			CommonFunctions.getConnectivityTP(baseArr,advanceDefinitionAccommodationPLB.getJSONObject(PROP_CONNECTIVITY));

		if(advanceDefinitionAccommodationPLB.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionAccommodationPLB.getJSONObject(PROP_OTHERS);
			if(others.has(PROP_BOOKINGTYPE)){
				if(others.has(PROP_BOOLEAN_ISINCLUSION)){
					if(others.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						CommonFunctions.getBookingTypeTP(baseArr,others.getJSONObject(PROP_BOOKINGTYPE),true);
					else CommonFunctions.getBookingTypeTP(baseArr,others.getJSONObject(PROP_BOOKINGTYPE),false);
				}
			}

			if(others.has(PROP_ROOMTYPES) && others.getJSONArray(PROP_ROOMTYPES).length()>0){
				if(others.has(PROP_BOOLEAN_ISINCLUSION)){
					if(others.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						CommonFunctions.getTriggerPayoutArrayIncExc(baseArr,calcArr,others.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES,true,false,commercialName);
					else CommonFunctions.getTriggerPayoutArrayIncExc(baseArr,calcArr,others.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES,false,false,commercialName);
				}
			}

			if(others.has(PROP_ROOMCATEGORIES) && others.getJSONArray(PROP_ROOMCATEGORIES).length()>0){
				if(others.has(PROP_BOOLEAN_ISINCLUSION)){
					if(others.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						CommonFunctions.getTriggerPayoutArrayIncExc(baseArr,calcArr,others.getJSONArray(PROP_ROOMCATEGORIES),PROP_ROOMCATEGORY,true,false,commercialName);
					else CommonFunctions.getTriggerPayoutArrayIncExc(baseArr,calcArr,others.getJSONArray(PROP_ROOMCATEGORIES),PROP_ROOMCATEGORY,false,false,commercialName);
				}
			}
		}

		if(advanceDefinitionAccommodationPLB.has(PROP_TRAVELDEST)){
			JSONObject travelDestination = advanceDefinitionAccommodationPLB.getJSONObject(PROP_TRAVELDEST);
			if(travelDestination.getJSONArray(PROP_DESTINATIONS).length()>0){
				if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
					if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						CommonFunctions.getDestination(baseArr,calcArr,travelDestination.getJSONArray(PROP_DESTINATIONS),true,true,commercialName);
					else CommonFunctions.getDestination(baseArr,calcArr,travelDestination.getJSONArray(PROP_DESTINATIONS),false,true,commercialName);
				}
			}
		}
	}


	public static void setAccomodationAdvancedDefinition(JSONObject advanceDefinitionAccommodation, JSONArray baseArr, JSONArray calcArr, String commercialName) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
			JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));

			if(advanceDefinitionAccommodation.has(PROP_NATIONALITY)){
				JSONObject nationality = advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY);
				if(nationality.getJSONArray(PROP_CLIENTNATIONALITY).length()>0 && !nationality.getJSONArray(PROP_CLIENTNATIONALITY).getString(0).equalsIgnoreCase("All")){
					if(nationality.getBoolean(PROP_BOOLEAN_ISINCLUSION))
						base.put(PROP_CLIENTNATIONALITY, nationality.get(PROP_CLIENTNATIONALITY));
					else base.put(PROP_CLIENTNATIONALITY+"_"+EXCLUSION, nationality.get(PROP_CLIENTNATIONALITY));
				}
			}
			if(advanceDefinitionAccommodation.has(PROP_PASSENGERTYPES) && advanceDefinitionAccommodation.getJSONArray(PROP_PASSENGERTYPES).length()>0){
				if(!advanceDefinitionAccommodation.getJSONArray(PROP_PASSENGERTYPES).getString(0).equalsIgnoreCase("All"))
					calculation.put(PASSENGERTYPE, advanceDefinitionAccommodation.getJSONArray(PROP_PASSENGERTYPES));
			}
			if(advanceDefinitionAccommodation.has(PROP_CREDENTIALS) && advanceDefinitionAccommodation.getJSONArray(PROP_CREDENTIALS).length()>0){
				JSONArray credentials = advanceDefinitionAccommodation.getJSONArray(PROP_CREDENTIALS);
				JSONArray credentialName = new JSONArray();
				for(int c=0;c<credentials.length();c++){
					credentialName.put(credentials.getJSONObject(c).getString(PROP_CREDENTIALSID));
				}
				if(credentialName.length()>0)
					base.put(CREDENTIALSNAME, credentialName);
			}
			if(advanceDefinitionAccommodation.has(PROP_CONNECTIVITY)){
				JSONObject connectivity = advanceDefinitionAccommodation.getJSONObject(PROP_CONNECTIVITY);
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					base.put(CONN_SUPPTYPE,connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPID) && !connectivity.getString(PROP_SUPPID).equalsIgnoreCase("All"))
					base.put(CONN_SUPPNAME,connectivity.getString(PROP_SUPPID));
			}
			if(advanceDefinitionAccommodation.has(PROP_OTHERS)){
				JSONObject others = advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS);
				if(others.has(PROP_BOOKINGTYPE) && !others.getString(PROP_BOOKINGTYPE).equalsIgnoreCase("All"))
					base.put(PROP_BOOKINGTYPE,others.getString(PROP_BOOKINGTYPE));
				if(others.has(PROP_ROOMTYPES)){
					JSONObject roomTypes = others.getJSONObject(PROP_ROOMTYPES);
					if(roomTypes.getJSONArray(PROP_ROOMTYPES).length()>0 && !roomTypes.getJSONArray(PROP_ROOMTYPES).getString(0).equalsIgnoreCase("All"))
						if(roomTypes.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							calculation.put(ROOMTYPE, roomTypes.getJSONArray(PROP_ROOMTYPES));
						else calculation.put(ROOMTYPE+"_"+EXCLUSION, roomTypes.getJSONArray(PROP_ROOMTYPES));
				}
				if(others.has(PROP_ROOMCATEGORIES)){
					JSONObject roomCategories = others.getJSONObject(PROP_ROOMCATEGORIES);
					if(roomCategories.getJSONArray(PROP_ROOMCATEGORIES).length()>0 && !roomCategories.getJSONArray(PROP_ROOMCATEGORIES).getString(0).equalsIgnoreCase("All"))
						if(roomCategories.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							calculation.put(PROP_ROOMCATEGORY, roomCategories.getJSONArray(PROP_ROOMCATEGORIES));
						else calculation.put(PROP_ROOMCATEGORY+"_"+EXCLUSION, roomCategories.getJSONArray(PROP_ROOMCATEGORIES));
				}
			}
			baseArr.put(base);
			calcArr.put(calculation);
		}
		for(int j=0;j<length;j++){
			baseArr.remove(0);
			calcArr.remove(0);
		}

		if(advanceDefinitionAccommodation.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionAccommodation.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				JSONArray salePlusTravel = validity.getJSONArray(PROP_SALEPLUSTRAVEL);
				CommonFunctions.insertSalePlusTravel(baseArr,calcArr,salePlusTravel,true,true,commercialName);
			}
		}
		if(advanceDefinitionAccommodation.has(PROP_TRAVELDEST)){
			JSONObject travelDestination = advanceDefinitionAccommodation.getJSONObject(PROP_TRAVELDEST);
			JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
			CommonFunctions.getDestination(baseArr, calcArr, destinations, travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION), true, commercialName);
		}
	}


	public static void setAccoOtherFeesAdvancedDefinition(JSONObject advanceDefinitionAccommodation, JSONArray otherFeeArr, String commercialName) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
			if(advanceDefinitionAccommodation.has(PROP_NATIONALITY)){
				if(advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).getJSONArray(PROP_CLIENTNATIONALITY).length()>0 && !advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).getJSONArray(PROP_CLIENTNATIONALITY).getString(0).equalsIgnoreCase("All")){
					if(advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).has(PROP_BOOLEAN_ISINCLUSION)){
						if(advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).getBoolean(PROP_BOOLEAN_ISINCLUSION))
							otherFee.put(PROP_CLIENTNATIONALITY, advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).getJSONArray(PROP_CLIENTNATIONALITY));
						else otherFee.put(PROP_CLIENTNATIONALITY+"_"+EXCLUSION, advanceDefinitionAccommodation.getJSONObject(PROP_NATIONALITY).getJSONArray(PROP_CLIENTNATIONALITY));
					}
				}
			}
			if(advanceDefinitionAccommodation.has(PROP_PASSENGERTYPES) && advanceDefinitionAccommodation.getJSONArray(PROP_PASSENGERTYPES).length()>0)
				otherFee.put(PASSENGERTYPE, advanceDefinitionAccommodation.getJSONArray(PROP_PASSENGERTYPES));

			if(advanceDefinitionAccommodation.has(PROP_CREDENTIALS) && advanceDefinitionAccommodation.getJSONArray(PROP_CREDENTIALS).length()>0){
				JSONArray credentials = advanceDefinitionAccommodation.getJSONArray(PROP_CREDENTIALS);
				JSONArray credentialName = new JSONArray();
				for(int c=0;c<credentials.length();c++){
					credentialName.put(credentials.getJSONObject(c).getString(PROP_CREDENTIALSID));
				}
				if(credentialName.length()>0)
					otherFee.put(CREDENTIALSNAME, credentialName);
			}
			if(advanceDefinitionAccommodation.has(PROP_CONNECTIVITY)){
				if(advanceDefinitionAccommodation.getJSONObject(PROP_CONNECTIVITY).has(PROP_SUPPTYPE))
					otherFee.put(CONN_SUPPTYPE,advanceDefinitionAccommodation.getJSONObject(PROP_CONNECTIVITY).getString(PROP_SUPPTYPE));
				if(advanceDefinitionAccommodation.getJSONObject(PROP_CONNECTIVITY).has(PROP_SUPPID))
					otherFee.put(CONN_SUPPNAME,advanceDefinitionAccommodation.getJSONObject(PROP_CONNECTIVITY).getString(PROP_SUPPID));
			}
			if(advanceDefinitionAccommodation.has(PROP_OTHERS)){
				JSONObject others = advanceDefinitionAccommodation.getJSONObject(PROP_OTHERS);
				if(others.has(PROP_BOOKINGTYPE))
					otherFee.put(PROP_BOOKINGTYPE,others.getString(PROP_BOOKINGTYPE));
				if(others.has(PROP_ROOMTYPES)){
					if(others.getJSONObject(PROP_ROOMTYPES).has(PROP_BOOLEAN_ISINCLUSION)){
						if(others.getJSONObject(PROP_ROOMTYPES).getBoolean(PROP_BOOLEAN_ISINCLUSION))
							otherFee.put(ROOMTYPE, others.getJSONObject(PROP_ROOMTYPES).getJSONArray(PROP_ROOMTYPES));
						else otherFee.put(ROOMTYPE+"_"+EXCLUSION, others.getJSONObject(PROP_ROOMTYPES).getJSONArray(PROP_ROOMTYPES));
					}
				}
				if(others.has(PROP_ROOMCATEGORIES)){
					if(others.getJSONObject(PROP_ROOMCATEGORIES).has(PROP_BOOLEAN_ISINCLUSION)){
						if(others.getJSONObject(PROP_ROOMCATEGORIES).getBoolean(PROP_BOOLEAN_ISINCLUSION))
							otherFee.put(PROP_ROOMCATEGORY, others.getJSONObject(PROP_ROOMCATEGORIES).getJSONArray(PROP_ROOMCATEGORIES));
						else otherFee.put(PROP_ROOMCATEGORY+"_"+EXCLUSION, others.getJSONObject(PROP_ROOMCATEGORIES).getJSONArray(PROP_ROOMCATEGORIES));
					}
				}
			}
			otherFeeArr.put(otherFee);
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
		if(advanceDefinitionAccommodation.has(PROP_TRAVELDEST)){
			JSONObject travelDestination = advanceDefinitionAccommodation.getJSONObject(PROP_TRAVELDEST);
			JSONArray destinationArray = travelDestination.getJSONArray(PROP_DESTINATIONS);
			CommonFunctions.setOtherFeesDestination(otherFeeArr, destinationArray, travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION), commercialName);
		}
	}
}
