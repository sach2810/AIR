package cnk.transformation;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import cnk.kafkaConsumer.ReceiveMDMRequest;

public class CommonFunctions implements Constants{
	public static String commDefnID,suppCommDataId,mdmRuleID,overCT,plbCT,destCT,segCT,serCT,issCT,mngtCT,commCT;
	public static JSONObject stdComm;
	public static boolean overSet,plbSet,destSet,segSet,serSet,issSet,mngtSet,commSet;
	private static HashMap<String,String> commercialMappingId = new HashMap<String,String>();
	public static HashMap<String,JSONObject> commDefnMap = new HashMap<String,JSONObject>();

	public static JSONObject getCommercialDefiniton(JSONObject mdmDefn, String productCategory,String productCategorySubType, String supplier, JSONArray supplierMarkets, String commercialName, String companyId) {
		JSONObject commDefn = new JSONObject();
		if(supplier!=null)
			commDefn.put(PROP_SUPPLIER, supplier);
		commDefnID=productCategorySubType+"_"+supplier+"_"+mdmDefn.getJSONObject(PROP_SUPP_COMM_DATA).getString(PROP_ID);
		commDefn.put(RULEID, commDefnID);
		commDefn.put(TYPE, TYPE_DEFINITION);
		commDefn.put(PROP_COMPANY_ID, companyId);
		if(supplierMarkets.length()>0)
			commDefn.put(SUPPLIERMARKET,supplierMarkets);
		JSONObject commHead = new JSONObject();
		JSONObject standardCommercial = mdmDefn.getJSONObject(PROP_SUPP_COMM_DATA).getJSONObject(PROP_STD_COMM);
		commHead.put(PROP_COMMHEADNAME, commercialName);
		commHead.put(PROP_SETTLEMENTTRANSACTIONWISE, standardCommercial.getBoolean(PROP_BOOLEAN_ISSETTTRANSWISE));
		commHead.put(PROP_COMMERCIALTYPE, standardCommercial.getJSONObject(PROP_COMMERCIALINFO).getString(PROP_COMMERCIALTYPE));
		if(standardCommercial.getJSONObject(PROP_COMMERCIALINFO).has(PROP_BOOLEAN_ISPROVISIONAL))
			commHead.put(PROP_CONTRACTTYPE, PROVISIONAL);
		else commHead.put(PROP_CONTRACTTYPE, FINAL);
		commHead.put(PROP_COMMISSIONABLE, standardCommercial.getBoolean(PROP_BOOLEAN_ISCOMMISIONABLE));
		JSONObject calculation = standardCommercial.getJSONObject(CALCULATION);
		if(calculation.has(PROP_MARKDOWN)){
			JSONObject markDown = calculation.getJSONObject(PROP_MARKDOWN);
			if(markDown.has(PROP_APPLICABLE))
				commHead.put(PROP_MARKDOWNAPPLICABLE, markDown.getBoolean(PROP_APPLICABLE));
			if(markDown.has(PROP_CLIENTTYPE))
				commHead.put(MARKDOWNCLIENTAPPLICABLE, markDown.getString(PROP_CLIENTTYPE));
		}
		JSONObject markUp = calculation.getJSONObject(PROP_MARKUP);
		if(markUp.has(PROP_MINIMUMPERCENT))
			commHead.put(PROP_MIN_MARKUP_PERCENTAGE, markUp.get(PROP_MINIMUMPERCENT));
		if(markUp.has(PROP_MAXIMUMPERCENT))
			commHead.put(PROP_MAX_MARKUP_PERCENTAGE, markUp.get(PROP_MAXIMUMPERCENT));
		if(markUp.has(PROP_CLIENTTYPE))
			commHead.put(MARKUPCLIENTTYPE, markUp.getString(PROP_CLIENTTYPE));
		JSONArray commHeadArr = new JSONArray();
		commHeadArr.put(commHead);
		commDefn.put(COMMHEAD, commHeadArr);
		
		if(!commDefn.has(PROP_SUPPLIER))
			commDefn.put(PRIORITY, "-1");
		return commDefn;
	}


	public static void setCommercialHead(JSONObject mainJson, String baseDT, String calculationDT, JSONArray baseArr, JSONArray calcArr, String commercialName, JSONArray commHead, String netOffCommercialHead, String commercialType, String contractType, boolean settlementTransactionWise) {
		boolean insert=true;
		for(int i=0;i<commHead.length();i++){
			JSONObject commHeadObj = commHead.getJSONObject(i);
			if(commHeadObj.getString(PROP_COMMHEADNAME).equals(commercialName)){
				if(commHeadObj.has(PROP_NETTOFFCOMMHEADNAME)){
					if(commHeadObj.getString(PROP_NETTOFFCOMMHEADNAME).equals(netOffCommercialHead))
						insert=false;
				}else{
					if(netOffCommercialHead==null)
						insert=false;
				}
			}
		}
		
		if(insert){
			JSONObject commercialData = new JSONObject();
			commercialData.put(PROP_COMMHEADNAME, commercialName);
			commercialData.put(PROP_COMMERCIALTYPE, commercialType);
			commercialData.put(PROP_SETTLEMENTTRANSACTIONWISE, settlementTransactionWise);
			commercialData.put(PROP_CONTRACTTYPE, contractType);
			commercialData.put(PROP_COMMISSIONABLE, false);
			commercialData.put(PROP_MARKDOWNAPPLICABLE, false);
			commercialData.put(PROP_MIN_MARKUP_PERCENTAGE, 0);
			commercialData.put(PROP_MAX_MARKUP_PERCENTAGE, 0);
			if(netOffCommercialHead!=null)
				commercialData.put(PROP_NETTOFFCOMMHEADNAME, netOffCommercialHead);

			commHead.put(commercialData);
		}
	}


	public static String getFareComponentString(JSONArray fareComponentsArr) {
		String fareComponent=null;int flag=0;
		for(int i=0;i<fareComponentsArr.length();i++){
			if(fareComponentsArr.get(i).equals(BASIC)){
				flag=1;
			}
		}
		if(flag==1){
			fareComponent=BASIC;
			for(int i=0;i<fareComponentsArr.length();i++){
				if(!fareComponentsArr.get(i).equals(BASIC)){
					fareComponent+=","+fareComponentsArr.getString(i);
				}
			}
		}else{
			for(int i=0;i<fareComponentsArr.length();i++){
				if(i==0)
					fareComponent=fareComponentsArr.getString(i);
				else fareComponent+=","+fareComponentsArr.getString(i);
			}
		}
		return fareComponent;
	}


	public static String getCommercialName(String displayName) {
		switch(displayName){
		case MDM_STANDARD: return STANDARD;
		case MDM_OVERRIDING: return OVERRIDING;
		case MDM_PLB: return PLB;
		case MDM_SECTORINCENTIVES: return SECTORWISEINCENTIVE;
		case MDM_SEGMENTFEES: return SEGMENTFEE;
		case MDM_MANAGEMENTFEE: return MANAGEMENTFEE;
		case MDM_SERVICECHARGES: return SERVICECHARGE;
		//case "Discount": return "Discount";
		//case "MarkUp": return "MarkUp";
		case MDM_DESTINATIONINCENTIVES: return DESTINATIONINCENTIVE;
		case MDM_ISSUANCEFEES: return ISSUANCEFEE;
		case MDM_COMMISSION: return MDM_COMMISSION;
		case MDM_MAINTENANCEFEES: return MAINTENANCEFEES;
		case MDM_INTEGRATIONFEES: return INTEGRATIONFEES;
		case MDM_LICENCEFEES: return LICENCEFEES;
		case MDM_WEBSERVICEFEES: return WEBSERVICEFEES;
		case MDM_LOYALTYBONUS: return LOYALTYBONUS;
		case MDM_PREFERENCEBENEFIT: return PREFERENCEBENEFIT;
		case MDM_RETAINERFEE: return RETAINERFEE;
		case MDM_LISTINGFEE: return LISTINGFEE;
		case MDM_CONTENTACCESSFEE: return CONTENTACCESSFEE;
		case MDM_SIGNUPFEES: return SIGNUPFEES;
		case MDM_SIGNUPBONUS: return SIGNUPBONUS;
		case MDM_LOOKTOBOOK: return LOOKTOBOOK;
		case MDM_MSFFEES: return MSFFEES;
		case MDM_IOTP: return IOTP;
		case MDM_TERMINATIONFEES: return TERMINATIONFEES;
		case MDM_PENALTYFEE: return PENALTYFEE;
		case MDM_FOC: return FOC;
		case MDM_LOSTTICKET: return LOSTTICKET;
		case MDM_REMITTANCEFEES: return REMITTANCEFEES;
		case MDM_TRAININGFEES: return TRAININGFEES;
		default:System.out.println("deafult of getCommercialName due to: "+displayName);
		}
		return null;
	}


	public static String getProductName(JSONObject commercialDefinition) {
		switch(commercialDefinition.getString(PROP_PRODUCTCATEGORY)){
		case MDM_PRODUCTNAME_ACCOMODATION:return PRODUCTNAME_ACCOMODATION;
		case MDM_PRODUCTNAME_ACTIVITIES: return PRODUCTNAME_ACTIVITIES;
		case MDM_PRODUCTNAME_COMBINATION: return PRODUCTNAME_COMBINATION;
		case MDM_PRODUCTNAME_HOLIDAYS: return PRODUCTNAME_HOLIDAYS;
		case MDM_PRODUCTNAME_OTHER_PRODUCTS: {
			switch(commercialDefinition.getString(PROP_PRODUCTCATEGORYSUBTYPE)){
			case MDM_PRODUCTNAME_INSURANCE: return PRODUCTNAME_INSURANCE;
			case MDM_PRODUCTNAME_VISA: return PRODUCTNAME_VISA;
			}
		}
		case MDM_PRODUCTNAME_TRANSPORTATION:{
			switch(commercialDefinition.getString(PROP_PRODUCTCATEGORYSUBTYPE)){
			case MDM_PRODUCTNAME_BUS: return PRODUCTNAME_BUS;
			case MDM_PRODUCTNAME_CAR: return PRODUCTNAME_CARRENTALS;
			case MDM_PRODUCTNAME_CRUISE: return PRODUCTNAME_CRUISE;
			case MDM_PRODUCTNAME_EUROPEAN_RAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_FLIGHT: return PRODUCTNAME_AIR;
			case MDM_PRODUCTNAME_INDIAN_RAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_RAIL: return PRODUCTNAME_RAIL;
			case MDM_PRODUCTNAME_RENTAL: return PRODUCTNAME_RENTALS;
			case MDM_PRODUCTNAME_TRANSFER: return PRODUCTNAME_TRANSFERS;
			}
		}
		}
		return null;
	}


	public static void getProductDetails(JSONArray productInformationArr, JSONArray baseArr, JSONArray calcArr, String commercialName) {
		if(productInformationArr.length()>0){
			int length = baseArr.length();
			for(int j=0;j<length;j++){
				for(int i=0;i<productInformationArr.length();i++){
					JSONObject productInformation = productInformationArr.getJSONObject(i);
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(j).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(j).toString()));
					if(productInformation.has(PROP_PRODUCTID) && !productInformation.getString(PROP_PRODUCTID).equalsIgnoreCase("All"))
						calculation.put(PROP_PRODUCTID, productInformation.getString(PROP_PRODUCTID));
					if(productInformation.has(PROP_BRAND) && !productInformation.getString(PROP_BRAND).equalsIgnoreCase("All"))
						calculation.put(PRODUCTBRAND, productInformation.getString(PROP_BRAND));
					if(productInformation.has(PROP_CHAIN) && !productInformation.getString(PROP_CHAIN).equalsIgnoreCase("All"))
						calculation.put(PRODUCTCHAIN, productInformation.getString(PROP_CHAIN));

					setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_PRODUCTID+i+j);
				}
			}
			for(int j=0;j<length;j++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void getClientDetails(JSONArray baseArr, JSONArray calcArr, JSONArray clientArr, String commercialName) {
		if(clientArr.length()>0){
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<clientArr.length();j++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject client = clientArr.getJSONObject(j);
					if(client.has(PROP_CLIENTNAME) && !client.getString(PROP_CLIENTNAME).equalsIgnoreCase("All"))
						base.put(PROP_CLIENTNAME, client.getString(PROP_CLIENTNAME));
					if(client.has(PROP_CLIENTTYPE) && !client.getString(PROP_CLIENTTYPE).equalsIgnoreCase("All")){
						if(client.getString(PROP_CLIENTTYPE).equalsIgnoreCase(PROP_BOTH))
							base.put(PROP_CLIENTTYPE,new String[]{CLIENTGROUP_B2B,CLIENTGROUP_B2C});
						else base.put(PROP_CLIENTTYPE, client.getString(PROP_CLIENTTYPE));
					}
					if(client.has(PROP_CLIENTGROUP) && !client.getString(PROP_CLIENTGROUP).equalsIgnoreCase("All"))
						base.put(CLIENTGROUP, client.getString(PROP_CLIENTGROUP));
					setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_CLIENTTYPE+i+j);
				}
			}
			for(int j=0;j<length;j++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void getSlabDetails(String advancedCommID, JSONArray baseArr, JSONArray calcArr, JSONArray slabArr, String mdmruleID, String commercialName) {
		if(slabArr.length()>0){
			int length = baseArr.length();
			String tempRuleID = mdmruleID+="slab|";
			for(int i=0;i<length;i++){
				for(int j=0;j<slabArr.length();j++){
					JSONObject slab = slabArr.getJSONObject(j);
					JSONArray currencyDetails = slab.getJSONArray(PROP_CURRENCYDETAILS);
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					if(slab.has(PROP_SLABTYPE))
						calculation.put(PROP_SLABTYPE, slab.getString(PROP_SLABTYPE));
					String slabtypeValue=BETWEEN;
					for(int k=0;k<currencyDetails.length();k++){
						JSONObject currencyDetailsObject = currencyDetails.getJSONObject(k);
						slabtypeValue+=";"+currencyDetailsObject.get(PROP_FROMVALUE).toString()+";"+currencyDetailsObject.get(PROP_TOVALUE).toString();
						calculation.put(PROP_SLABTYPEVALUE,slabtypeValue);
					}
					getFixedDetails(calculation, slab);

					String baseRuleID = base.getString(RULEID)+commercialName+PROP_SLAB+j+advancedCommID;
					String calculationRuleID = calculation.getString(RULEID)+commercialName+PROP_SLAB+j+advancedCommID;
					base.put(RULEID, baseRuleID);
					calculation.put(RULEID, calculationRuleID);
					calculation.put(SELECTEDROW, baseRuleID);

					mdmruleID+=j+"|"+calculation.getString(SELECTEDROW);
					calculation.put(MDMRULEID, mdmruleID);

					baseArr.put(base);
					calcArr.put(calculation);

					mdmruleID= tempRuleID;
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void getConnectivityTP(JSONArray baseArr, JSONObject connectivity) {
		if(connectivity.getJSONArray(PROP_TRIGGERPAYOUT).length()>0 && (connectivity.has(PROP_SUPPTYPE) || connectivity.has(PROP_SUPPLIERID))){
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				JSONObject triggerPayout = getTriggerPayoutObject(connectivity.getJSONArray(PROP_TRIGGERPAYOUT));
				JSONArray connectivityArr = new JSONArray();
				JSONObject connectivityObject = new JSONObject();
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					connectivityObject.put(CONN_SUPPTYPE,connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					connectivityObject.put(CONN_SUPPNAME,connectivity.getString(PROP_SUPPLIERID));
				connectivityArr.put(triggerPayout);
				connectivityArr.put(connectivityObject);
				base.put(PROP_CONNECTIVITY, connectivityArr);
			}
		}
	}


	public static JSONObject getTriggerPayoutObject(JSONArray triggerOrPayout) {
		JSONObject triggerPayout = new JSONObject();
		boolean trigger=false,payout=false;
		for(int i=0;i<triggerOrPayout.length();i++){
			String value = triggerOrPayout.getString(i);
			if(value.toLowerCase().equalsIgnoreCase(TRIGGER))
				trigger=true;

			if(value.toLowerCase().equalsIgnoreCase(PAYOUT))
				payout=true;
		}
		triggerPayout.put(TRIGGER, trigger);
		triggerPayout.put(PAYOUT, payout);

		return triggerPayout;
	}


	public static void getTriggerPayoutArray(JSONArray baseArr, JSONArray calcArr, JSONArray array, String name, boolean inBase, String commercialName){
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<array.length();j++){
				JSONObject object = array.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(object.getJSONArray(PROP_TRIGGERPAYOUT));
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONArray requestArr = new JSONArray();
				JSONObject requestObject = new JSONObject();
				requestObject.put(name, object.getString(name));
				requestArr.put(triggerPayout);
				requestArr.put(requestObject);
				if(inBase)
					base.put(name, requestArr);
				else calculation.put(name, requestArr);
				setRuleID(baseArr,calcArr,base,calculation,commercialName+name+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getTriggerPayoutArrayIncExc(JSONArray baseArr, JSONArray calcArr, JSONArray roomTypes, String name, boolean isInclusion, boolean inBase, String commercialName) {
		if(roomTypes.length()>0){
			int length= baseArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<roomTypes.length();j++){
					JSONObject roomTypesObject = roomTypes.getJSONObject(j);
					JSONObject triggerPayout = getTriggerPayoutObject(roomTypesObject.getJSONArray(PROP_TRIGGERPAYOUT));
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONArray roomTypesArr = new JSONArray();
					JSONObject roomTypesInnerObject = new JSONObject();
					if(isInclusion)
						roomTypesInnerObject.put(name, roomTypesObject.getString(name));
					else roomTypesInnerObject.put(name+"_"+EXCLUSION, roomTypesObject.getString(name));
					roomTypesArr.put(triggerPayout);
					roomTypesArr.put(roomTypesInnerObject);
					if(inBase)
						base.put(name, roomTypesArr);
					else calculation.put(name, roomTypesArr);
					setRuleID(baseArr,calcArr,base,calculation,commercialName+name+i+j);
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void getBookingTypeTP(JSONArray baseArr, JSONObject bookingType, boolean isInclusion) {
		for(int i=0;i<baseArr.length();i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(bookingType.getJSONArray(PROP_TRIGGERPAYOUT));
			JSONArray bookingTypeArr = new JSONArray();
			JSONObject bookingTypeObject = new JSONObject();
			if(isInclusion)
				bookingTypeObject.put(PROP_BOOKINGTYPE,bookingType.getString(PROP_BOOKINGTYPE));
			else bookingTypeObject.put(PROP_BOOKINGTYPE+"_"+EXCLUSION,bookingType.getString(PROP_BOOKINGTYPE));
			bookingTypeArr.put(triggerPayout);
			bookingTypeArr.put(bookingTypeObject);
			base.put(PROP_BOOKINGTYPE, bookingTypeArr);
		}
	}


	public static void setRuleID(JSONArray baseArr, JSONArray calcArr, JSONObject base, JSONObject calculation, String ID) {
		String baseRuleID = base.getString(RULEID)+ID;
		String calculationRuleID = calculation.getString(RULEID)+ID;
		base.put(RULEID, baseRuleID);
		calculation.put(RULEID, calculationRuleID);
		calculation.put(SELECTEDROW, baseRuleID);

		baseArr.put(base);
		calcArr.put(calculation);
	}


	public static void getTriggerPayoutEnumValues(JSONArray baseArr, JSONArray triggerOrPayout, JSONArray jsonArray, String name, boolean isInclusion) {
		int length =baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject triggerPayout = getTriggerPayoutObject(triggerOrPayout);
			JSONArray array = new JSONArray();
			array.put(triggerPayout);
			JSONObject object = new JSONObject();
			if(isInclusion)
				object.put(name, jsonArray);
			else object.put(name+"_"+EXCLUSION, jsonArray);
			array.put(object);
			base.put(name, array);
		}
	}


	public static void getFixedDetails(JSONObject calculation, JSONObject fixed) {
		if(fixed.has(PROP_BOOLEAN_ISPERCENTAGE) && fixed.getBoolean(PROP_BOOLEAN_ISPERCENTAGE)){
			JSONArray percentageDetails = fixed.getJSONArray(PROP_PERCENTAGEDETAILS);
			JSONArray fareComponentsArr = new JSONArray();
			for(int k=0;k<percentageDetails.length();k++){
				String percentage = percentageDetails.getJSONObject(k).get(PROP_VALUEPERCENTAGE).toString();
				if(percentageDetails.getJSONObject(k).has(PROP_FAREPRICECOMPONENTS)){
					String fareComp = percentageDetails.getJSONObject(k).getString(PROP_FAREPRICECOMPONENTS);
					String[] fareCompo = fareComp.split("\\+");
					for(int i=0;i<fareCompo.length;i++){
						switch(fareCompo[i]){
						case BASIC:{}
						case TOTAL:{
							fareComponentsArr.put(fareCompo[i]);
							calculation.put(PERCENTAGE, percentage);
							break;
						}
						default:{
							fareComponentsArr.put(fareCompo[i]+";"+percentage);
						}
						}
					}
				}else{
					fareComponentsArr.put(TOTAL);
					calculation.put(PERCENTAGE, percentage);
				}
			}
			calculation.put(FARECOMPONENT, CommonFunctions.getFareComponentString(fareComponentsArr));
			if(fixed.has(PROP_BOOLEAN_ISAMOUNT) && fixed.getBoolean(PROP_BOOLEAN_ISAMOUNT)){
				calculation.put(PROP_CURRENCY, fixed.getString(PROP_CURRENCY));
				calculation.put(AMOUNTVALUE, fixed.get(PROP_VALUEAMOUNT).toString());
			}
		}else if(fixed.has(PROP_BOOLEAN_ISAMOUNT) && fixed.getBoolean(PROP_BOOLEAN_ISAMOUNT)){
			if(!fixed.getBoolean(PROP_BOOLEAN_ISPERCENTAGE))
				calculation.put(FARECOMPONENT, TOTAL);
			calculation.put(PROP_CURRENCY, fixed.getString(PROP_CURRENCY));
			calculation.put(AMOUNTVALUE, fixed.get(PROP_VALUEAMOUNT).toString());
		}
	}


	public static void getSupplierRate(JSONArray supplierRateArr, JSONArray calculationArr) {
		Set<String> rateType = new HashSet<String>();
		Set<String> rateCode = new HashSet<String>();
		for(int i=0;i<supplierRateArr.length();i++){
			JSONObject supplierRate = supplierRateArr.getJSONObject(i);
			if(supplierRate.has(PROP_SUPPLIER_RATETYPE) && !supplierRate.getString(PROP_SUPPLIER_RATETYPE).equalsIgnoreCase("All"))
				rateType.add(supplierRate.getString(PROP_SUPPLIER_RATETYPE));
			if(supplierRate.has(PROP_SUPPLIER_RATECODE) && !supplierRate.getString(PROP_SUPPLIER_RATECODE).equalsIgnoreCase("All"))
				rateCode.add(supplierRate.getString(PROP_SUPPLIER_RATECODE));
		}
		for(int i=0;i<calculationArr.length();i++){
			JSONObject calculation = calculationArr.getJSONObject(i);
			if(!rateType.isEmpty())
				calculation.put(RATETYPE, rateType);
			if(!rateCode.isEmpty())
				calculation.put(RATECODE, rateCode);
		}
	}


	public static void setOtherFeesRuleID(JSONArray otherFeeArr, JSONObject otherFee, String ID) {
		String otherFeeRuleID = otherFee.getString(RULEID)+ID;
		otherFee.put(RULEID, otherFeeRuleID);
		otherFeeArr.put(otherFee);
	}


	public static void getArrayNonTP(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, boolean isInclusion, boolean inBase) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=baseArr.length();
		for(int i=0;i<length;i++){
			JSONObject base = baseArr.getJSONObject(i);
			JSONObject calculation = calcArr.getJSONObject(i);
			if(isInclusion){
				if(inBase)
					base.put(name, array);
				else calculation.put(name, array);
			}else{
				if(inBase)
					base.put(name+"_"+EXCLUSION, array);
				else calculation.put(name+"_"+EXCLUSION, array);
			}
		}
	}


	public static void getArray(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, boolean isInclusion,boolean inBase, String commercialName) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<jsonArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject jsonObject = jsonArray.getJSONObject(j);
				JSONObject triggerPayout = getTriggerPayoutObject(jsonObject.getJSONArray(PROP_TRIGGERPAYOUT));
				JSONArray array = new JSONArray();
				JSONObject object = new JSONObject();
				array.put(triggerPayout);
				object.put(name, jsonObject.getString(name));
				array.put(object);

				if(isInclusion){
					if(inBase)
						base.put(name, array);
					else calculation.put(name, array);
				}else{
					if(inBase)
						base.put(name+""+"_"+EXCLUSION, array);
					else calculation.put(name+""+"_"+EXCLUSION, array);
				}

				setRuleID(baseArr, calcArr, base, calculation, commercialName+name+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void setTransportationAdvancedDefinition(JSONObject advanceDefinitionTransportation, JSONArray baseArr, JSONArray calcArr, boolean isTravelInBase, String commercialName) {
		if(advanceDefinitionTransportation.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionTransportation.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_VALIDITYTYPE)){
				JSONArray salePlusTravel = validity.getJSONArray(PROP_SALEPLUSTRAVEL);
				CommonFunctions.insertSalePlusTravel(baseArr,calcArr,salePlusTravel,true,isTravelInBase,commercialName);
			}
		}

		if(advanceDefinitionTransportation.has(PROP_TRAVELDEST)){
			JSONObject travelDestination = advanceDefinitionTransportation.getJSONObject(PROP_TRAVELDEST);
			JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
			if(destinations.length()>0){
				JSONObject destObject = destinations.getJSONObject(0);
				if(destObject.has(PROP_TRIGGERPAYOUT) && destObject.getJSONArray(PROP_TRIGGERPAYOUT).length()>0){
					if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
						if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							getTriggerPayoutDestination(baseArr,calcArr,destinations,true,false , commercialName);//isBase : false
						else getTriggerPayoutDestination(baseArr,calcArr,destinations,false,false , commercialName);//isBase : false
					}
				}else{
					if(travelDestination.has(PROP_BOOLEAN_ISINCLUSION)){
						if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION))
							getDestination(baseArr,calcArr,destinations,true,false , commercialName);//isBase : false
						else getDestination(baseArr,calcArr,destinations,false,false , commercialName);//isBase : false
					}
				}
			}
		}

		if(advanceDefinitionTransportation.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionTransportation.getJSONObject(PROP_OTHERS);
			if(others.has(PROP_TRIGGERPAYOUT) && others.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				getBookingTypeTP(baseArr, others, true);//isInclusion : true
			else{
				if(others.has(PROP_BOOKINGTYPE)){
					for(int i=0;i<baseArr.length();i++){
						JSONObject base = baseArr.getJSONObject(i);
						base.put(PROP_BOOKINGTYPE, others.getString(PROP_BOOKINGTYPE));//inBase
					}
				}
			}
		}

		if(advanceDefinitionTransportation.has(PROP_CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionTransportation.getJSONObject(PROP_CONNECTIVITY);
			if(connectivity.has(PROP_TRIGGERPAYOUT) && connectivity.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				getConnectivityTP(baseArr,connectivity);
			else{
				for(int i=0;i<baseArr.length();i++){
					JSONObject base = baseArr.getJSONObject(i);
					if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
						base.put(CONN_SUPPTYPE,connectivity.getString(PROP_SUPPTYPE));
					if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
						base.put(CONN_SUPPNAME,connectivity.getString(PROP_SUPPLIERID));
				}
			}
		}

		if(advanceDefinitionTransportation.has(PROP_CREDENTIALS) && advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS).length()>0){
			JSONObject credentials = advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS).getJSONObject(0);
			if(credentials.has(PROP_TRIGGERPAYOUT) && credentials.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true , commercialName);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true);
		}

		if(advanceDefinitionTransportation.has(PROP_NATIONALITY) && advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY).length()>0){
			JSONObject nationality = advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY).getJSONObject(0);
			if(nationality.has(PROP_TRIGGERPAYOUT) && nationality.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY), PROP_CLIENTNATIONALITY, true, true , commercialName);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY), PROP_CLIENTNATIONALITY, true, true);
		}

		if(advanceDefinitionTransportation.has(PROP_PASSENGERTYPES) && advanceDefinitionTransportation.getJSONArray(PROP_PASSENGERTYPES).length()>0){
			JSONObject passengerTypes = advanceDefinitionTransportation.getJSONArray(PROP_PASSENGERTYPES).getJSONObject(0);
			if(passengerTypes.has(PROP_TRIGGERPAYOUT) && passengerTypes.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				getArray(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_PASSENGERTYPES), PROP_PASSENGERTYPES, true, false , commercialName);
			else getArrayNonTP(baseArr, calcArr, advanceDefinitionTransportation.getJSONArray(PROP_PASSENGERTYPES), PROP_PASSENGERTYPES, true, false);
		}
	}


	public static void setTransportationOtherFeesAdvancedDefinition(JSONObject advanceDefinitionTransportation, JSONArray otherFeeArr, String commercialName) {
		if(advanceDefinitionTransportation.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionTransportation.getJSONObject(PROP_VALIDITY);
			JSONArray salePlusTravel = validity.getJSONArray(PROP_SALEPLUSTRAVEL);
			CommonFunctions.setOtherFeesSalePlusTravel(salePlusTravel,otherFeeArr,commercialName);
		}
		if(advanceDefinitionTransportation.has(PROP_TRAVELDEST)){
			JSONObject travelDestination = advanceDefinitionTransportation.getJSONObject(PROP_TRAVELDEST);
			JSONArray destinations = travelDestination.getJSONArray(PROP_DESTINATIONS);
			if(travelDestination.getBoolean(PROP_BOOLEAN_ISINCLUSION))
				setOtherFeesDestination(otherFeeArr, destinations, true , commercialName);
			else setOtherFeesDestination(otherFeeArr, destinations, false , commercialName);

		}
		if(advanceDefinitionTransportation.has(PROP_OTHERS)){
			JSONObject others = advanceDefinitionTransportation.getJSONObject(PROP_OTHERS);
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				otherFee.put(PROP_BOOKINGTYPE, others.getString(PROP_BOOKINGTYPE));
			}
		}

		if(advanceDefinitionTransportation.has(PROP_CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionTransportation.getJSONObject(PROP_CONNECTIVITY);
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					otherFee.put(CONN_SUPPTYPE,connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					otherFee.put(CONN_SUPPNAME,connectivity.getString(PROP_SUPPLIERID));
			}
		}
		if(advanceDefinitionTransportation.has(PROP_CREDENTIALS) && advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS);

		if(advanceDefinitionTransportation.has(PROP_NATIONALITY) && advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray(PROP_NATIONALITY), PROP_CLIENTNATIONALITY);

		if(advanceDefinitionTransportation.has(PROP_PASSENGERTYPES) && advanceDefinitionTransportation.getJSONArray(PROP_PASSENGERTYPES).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionTransportation.getJSONArray(PROP_PASSENGERTYPES), PROP_PASSENGERTYPES);
	}


	public static void getOtherFeesArrayNonTP(JSONArray otherFeeArr, JSONArray jsonArray, String name) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			JSONObject otherFee = otherFeeArr.getJSONObject(i);
			otherFee.put(name, array);
		}
	}


	public static JSONObject setAmmendRequest(JSONObject mdmDefn) {
		String bookingId = mdmDefn.getString(BOOKINGID);
		JSONArray opsAmendments = mdmDefn.getJSONArray(PROP_OPS_AMMENDMENTS);
		JSONObject mainJson = new JSONObject();
		for(int i=0;i<opsAmendments.length();i++){
			JSONObject opsObject = opsAmendments.getJSONObject(i);
			JSONArray data = mdmDefn.getJSONArray(PROP_DATA);
			for(int j=0;j<data.length();j++){
				JSONObject dataObject = data.getJSONObject(j);
				if(opsObject.getString(COMMERCIALNAME).equals(dataObject.getString(COMMERCIALNAME))){
					String mdmRuleID = opsObject.getString(MDMRULEID);
					String[] values = mdmRuleID.split("\\|");
					JSONObject calculation = new JSONObject();
					calculation.put(RULEID, mdmRuleID);
					calculation.put(COMMERCIAL_ID, values[1]+"_"+values[3]);
					calculation.put(MDMRULEID, mdmRuleID);
					calculation.put(TYPE, CALCULATION);
					calculation.put(SELECTEDROW, values[6]);
					calculation.put(BOOKINGID, bookingId);
					calculation.put(PRIORITY, "1");
					if(dataObject.has(PROP_FIXED))						
						CommonFunctions.getFixedDetails(calculation,dataObject.getJSONObject(PROP_FIXED));
					else CommonFunctions.getFixedDetails(calculation,dataObject.getJSONObject(PROP_SLAB));
					mainJson.put(getDecisionTableName(dataObject.getString(COMMERCIALNAME)), calculation);
				}
			}
		}
		return mainJson;
	}


	private static String getDecisionTableName(String commercialName) {
		switch(commercialName){
		case STANDARD: return STANDARD_CALCULATION_DT;
		case OVERRIDING: return OVERRIDING_CALCULATION_DT;
		case PLB: return PLB_CALCULATION_DT;
		case SECTORWISEINCENTIVE: return SECTORWISE_CALCULATION_DT;
		case SEGMENTFEE: return SEGMENTFEE_CALCULATION_DT;
		case MANAGEMENTFEE: return MNGT_CALCULATION_DT;
		case SERVICECHARGE: return SERVICE_CALCULATION_DT;
		//case "Discount": return "DiscountClientCommercialCalculationDT";
		case DESTINATIONINCENTIVE: return DESTINATION_CALCULATION_DT;
		case ISSUANCEFEE: return ISSUANCEFEE_CALCULATION_DT;
		case MDM_COMMISSION: return COMMISSION_CALCULATION_DT;
		case MAINTENANCEFEES: return MAINTENANCEFEE_DT;
		case INTEGRATIONFEES: return INTEGRATIONEE_DT;
		case LICENCEFEES: return LICENCEFEE_DT;
		case WEBSERVICEFEES: return WEBSERVICEFEE_DT;
		case LOYALTYBONUS: return LOYALTYBONUS_DT;
		case PREFERENCEBENEFIT: return PREFERENCEBENEFIT_DT;
		case RETAINERFEE: return RETAINERFEE_DT;
		case LISTINGFEE: return LISTINGFEE_DT;
		case CONTENTACCESSFEE: return CONTENTACCESSFEE_DT;
		case SIGNUPFEES: return SIGNUPFEE_DT;
		case SIGNUPBONUS: return SIGNUPBONUS_DT;
		case LOOKTOBOOK: return LOOKTOBOOK_DT;
		case MDM_MSFFEES: return MSFFEE_DT;
		case IOTP: return IOTP_DT;
		case TERMINATIONFEES: return TERMINATIONFEE_DT;
		case PENALTYFEE: return PENALTYFEE_DT;
		case LOSTTICKET: return LOSTTICKET_DT;
		case MDM_REMITTANCEFEES: return REMITTANCEFEE_DT;
		case TRAININGFEES: return TRAININGFEE_DT;
		default:System.out.println("default of getDecisionTableName due to: "+commercialName);
		}
		return null;
	}


	public static JSONObject getContractValidity(JSONObject jsonObject) {
		JSONObject contractValidity = new JSONObject();
		if(jsonObject.has(PROP_CONTRACT_VAL_TO)){
			contractValidity.put(OPERATOR, BETWEEN);
			contractValidity.put(FROM, jsonObject.getString(PROP_CONTRACT_VAL_FROM).substring(0, 11)+"00:00:00");
			contractValidity.put(TO, jsonObject.getString(PROP_CONTRACT_VAL_TO).substring(0, 11)+"23:59:59");
		}else{
			contractValidity.put(OPERATOR, GREATERTHANEQUALTO);
			contractValidity.put(VALUE, jsonObject.getString(PROP_CONTRACT_VAL_FROM).substring(0, 11)+"00:00:00");
		}
		return contractValidity;
	}
	
	
	public static void setOtherFeesSalePlusTravel(JSONArray salePlusTravel, JSONArray otherFeeArr, String commercialName) {
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<salePlusTravel.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject salePlusTravelObj = salePlusTravel.getJSONObject(j);
				JSONObject trigPayout = new JSONObject();
				if(salePlusTravelObj.has(PROP_TRIGGERPAYOUT) && salePlusTravelObj.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
					trigPayout = getTriggerPayoutObject(salePlusTravelObj.getJSONArray(PROP_TRIGGERPAYOUT));
				JSONArray saleArr = new JSONArray();
				JSONArray salesinclusionArr = new JSONArray();
				JSONArray salesexclusionArr = new JSONArray();
				JSONObject salesinclusionObject = new JSONObject();
				JSONObject salesexclusionObject = new JSONObject();
				JSONObject inclusionObject = new JSONObject();
				JSONObject exclusionObject = new JSONObject();
				JSONArray travelArr = new JSONArray();
				JSONArray travelinclusionArr = new JSONArray();
				JSONArray travelexclusionArr = new JSONArray();
				JSONObject saleObj = salePlusTravelObj.getJSONObject(PROP_SALES);
				JSONObject travelObj = salePlusTravelObj.getJSONObject(PROP_TRAVEL);
				
				switch(salePlusTravelObj.getString(PROP_VALIDITYTYPE).toLowerCase()){
				case PROP_SALES:{
					CommonFunctions.getDates(saleObj, salesinclusionArr, PROP_SALEFROM, PROP_SALETO,trigPayout,saleArr);
					CommonFunctions.getBlockOutDates(saleObj, salesexclusionArr,trigPayout,saleArr);
					break;
				}
				case PROP_SALE:{
					CommonFunctions.getDates(saleObj, salesinclusionArr, PROP_SALEFROM, PROP_SALETO,trigPayout,saleArr);
					CommonFunctions.getBlockOutDates(saleObj, salesexclusionArr,trigPayout,saleArr);
					break;
				}
				case PROP_TRAVEL:{
					CommonFunctions.getDates(travelObj, travelinclusionArr, PROP_TRAVELFROM, PROP_TRAVELTO,trigPayout,travelArr);
					CommonFunctions.getBlockOutDates(travelObj, travelinclusionArr,trigPayout,travelArr);
					break;
				}
				default:{
					CommonFunctions.getDates(saleObj, salesinclusionArr, PROP_SALEFROM, PROP_SALETO,trigPayout,saleArr);
					CommonFunctions.getBlockOutDates(saleObj, salesexclusionArr,trigPayout,saleArr);
					CommonFunctions.getDates(travelObj, travelinclusionArr, PROP_TRAVELFROM, PROP_TRAVELTO,trigPayout,travelArr);
					CommonFunctions.getBlockOutDates(travelObj, travelinclusionArr,trigPayout,travelArr);
				}
				}
				
				if(salesinclusionArr.length()>0){
					salesinclusionObject.put(INCLUSION,salesinclusionArr);
					saleArr.put(salesinclusionObject);
				}
				if(salesexclusionArr.length()>0){
					salesexclusionObject.put(EXCLUSION,salesexclusionArr);
					saleArr.put(salesexclusionObject);
				}

				if(travelinclusionArr.length()>0){
					inclusionObject.put(INCLUSION,travelinclusionArr);
					travelArr.put(inclusionObject);
				}
				if(travelexclusionArr.length()>0){
					exclusionObject.put(EXCLUSION,travelexclusionArr);
					travelArr.put(exclusionObject);
				}
				
				if(saleArr.length()>0)
					otherFee.put(PROP_SALE, saleArr);
				if(travelArr.length()>0)
					otherFee.put(PROP_TRAVEL, travelArr);

				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+PROP_SALES+PROP_TRAVEL+i+j);
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}


	public static void insertSalePlusTravel(JSONArray baseArr, JSONArray calcArr, JSONArray salePlusTravel, boolean isSalesInBase, boolean isTravelInBase, String commercialName) {
		if(salePlusTravel.length()>0){
			int length=baseArr.length();
			for(int j=0;j<length;j++){
				for(int i=0;i<salePlusTravel.length();i++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(j).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(j).toString()));
					JSONArray saleArray = new JSONArray();
					JSONObject trigPayout = new JSONObject();
					JSONArray travelArray = new JSONArray();
					JSONObject saleinclusion = new JSONObject();
					JSONObject saleexclusion = new JSONObject();
					JSONObject travelinclusion = new JSONObject();
					JSONObject travelexclusion = new JSONObject();
					JSONArray salesDateInclusionArr = new JSONArray();
					JSONArray travelDateInclusionArr = new JSONArray();
					JSONArray salesDateExclusionArr = new JSONArray();
					JSONArray travelDateExclusionArr = new JSONArray();

					JSONObject salePlusTravelObject = salePlusTravel.getJSONObject(i);
					if(salePlusTravelObject.has(PROP_TRIGGERPAYOUT) && salePlusTravelObject.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
						trigPayout = getTriggerPayoutObject(salePlusTravelObject.getJSONArray(PROP_TRIGGERPAYOUT));
					JSONObject sale = salePlusTravelObject.getJSONObject(PROP_SALES);
					JSONObject travel = salePlusTravelObject.getJSONObject(PROP_TRAVEL);

					switch(salePlusTravelObject.getString(PROP_VALIDITYTYPE).toLowerCase()){
					case PROP_SALES:{
						getDates(sale,salesDateInclusionArr,PROP_SALEFROM,PROP_SALETO,trigPayout,saleArray);
						getBlockOutDates(sale, salesDateExclusionArr,trigPayout,saleArray);
						break;
					}
					case PROP_SALE:{
						getDates(sale,salesDateInclusionArr,PROP_SALEFROM,PROP_SALETO,trigPayout,saleArray);
						getBlockOutDates(sale, salesDateExclusionArr,trigPayout,saleArray);
						break;
					}
					case PROP_TRAVEL:{
						getDates(travel,travelDateInclusionArr,PROP_TRAVELFROM,PROP_TRAVELTO,trigPayout,travelArray);
						getBlockOutDates(travel, travelDateExclusionArr,trigPayout,travelArray);
						break;
					}
					default:{
						getDates(sale,salesDateInclusionArr,PROP_SALEFROM,PROP_SALETO,trigPayout,saleArray);
						getBlockOutDates(sale, salesDateExclusionArr,trigPayout,saleArray);
						getDates(travel,travelDateInclusionArr,PROP_TRAVELFROM,PROP_TRAVELTO,trigPayout,travelArray);
						getBlockOutDates(travel, travelDateExclusionArr,trigPayout,travelArray);
					}
					}

					if(!salesDateInclusionArr.isNull(0)){
						saleinclusion.put(INCLUSION, salesDateInclusionArr);
						saleArray.put(saleinclusion);
					}
					if(!travelDateInclusionArr.isNull(0)){
						travelinclusion.put(INCLUSION, travelDateInclusionArr);
						travelArray.put(travelinclusion);
					}
					if(!salesDateExclusionArr.isNull(0)){
						saleexclusion.put(EXCLUSION, salesDateExclusionArr);
						saleArray.put(saleexclusion);
					}
					if(!travelDateExclusionArr.isNull(0)){
						travelexclusion.put(EXCLUSION, travelDateExclusionArr);
						travelArray.put(travelexclusion);
					}

					if(saleArray.length()>0){
						if(isSalesInBase)
							base.put(PROP_SALE, saleArray);
						else calculation.put(PROP_SALE, saleArray);
					}

					if(travelArray.length()>0){
						if(isTravelInBase)
							base.put(PROP_TRAVEL, travelArray);
						else calculation.put(PROP_TRAVEL, travelArray);
					}

					CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_SALES+PROP_TRAVEL+i+j);
				}
			}
			for(int j=0;j<length;j++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void setOtherFeeTicketingPlusTravel(JSONArray otherFeeArr, JSONObject validity, String commercialName){
		if(validity.has(PROP_VALIDITYTYPE)){
			int length = otherFeeArr.length();
			JSONArray ticketingPlusTravel = validity.getJSONArray(PROP_TICKETINGPLUSTRAVEL);
			for(int i=0;i<length;i++){
				for(int j=0;j<ticketingPlusTravel.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(j);
					JSONArray tickincArr =new JSONArray();
					JSONArray tickexcArr =new JSONArray();
					JSONArray travelincArr =new JSONArray();
					JSONArray travelexcArr =new JSONArray();
					JSONArray ticketingDate = new JSONArray();
					JSONArray travelDate = new JSONArray();
					JSONObject inclusionTkt = new JSONObject();
					JSONObject exclusionTkt = new JSONObject();
					JSONObject inclusionTra = new JSONObject();
					JSONObject exclusionTra = new JSONObject();
					JSONObject trigPayout = new JSONObject();
					if(ticketPlusTravelObj.has(PROP_TRIGGERPAYOUT) && ticketPlusTravelObj.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
						trigPayout = getTriggerPayoutObject(ticketPlusTravelObj.getJSONArray(PROP_TRIGGERPAYOUT));
					
					JSONObject ticketingObject = ticketPlusTravelObj.getJSONObject(PROP_TICKET);
					JSONObject travelObject = ticketPlusTravelObj.getJSONObject(PROP_TRAVEL);
					
					switch(ticketPlusTravelObj.getString(PROP_VALIDITYTYPE).toLowerCase()){
					case PROP_TICKETING:{
						getDates(ticketingObject, tickincArr, PROP_TICKETINGFROM, PROP_TICKETINGTO,trigPayout,ticketingDate);
						getBlockOutDates(ticketingObject, tickexcArr,trigPayout,ticketingDate);
						break;
					}
					case PROP_TRAVEL:{
						getDates(travelObject, travelincArr, PROP_TRAVELFROM, PROP_TRAVELTO,trigPayout,ticketingDate);
						getBlockOutDates(travelObject, travelexcArr,trigPayout,ticketingDate);
						break;
					}
					default:{
						getDates(ticketingObject, tickincArr, PROP_TICKETINGFROM, PROP_TICKETINGTO,trigPayout,ticketingDate);
						getBlockOutDates(ticketingObject, tickexcArr,trigPayout,ticketingDate);
						getDates(travelObject, travelincArr, PROP_TRAVELFROM, PROP_TRAVELTO,trigPayout,ticketingDate);
						getBlockOutDates(travelObject, travelexcArr,trigPayout,ticketingDate);
					}
					}

					if(!tickincArr.isNull(0)){
						inclusionTkt.put(INCLUSION,tickincArr);
						ticketingDate.put(inclusionTkt);
					}
					if(!tickexcArr.isNull(0)){
						exclusionTkt.put(EXCLUSION,tickexcArr);
						ticketingDate.put(exclusionTkt);
					}
					if(!travelincArr.isNull(0)){
						inclusionTra.put(INCLUSION,travelincArr);
						travelDate.put(inclusionTra);
					}
					if(!travelexcArr.isNull(0)){
						exclusionTra.put(EXCLUSION,travelexcArr);
						travelDate.put(exclusionTra);
					}
					if(ticketingDate.length()>0)
						otherFee.put(PROP_TICKETING, ticketingDate);
					if(travelDate.length()>0)
						otherFee.put(PROP_TRAVEL, travelDate);

					setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+PROP_TICKETING+PROP_TRAVEL+i+j);
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}


	public static void setTicketingPlusTravel(JSONArray baseArr, JSONArray calcArr, JSONObject validity, boolean isTicketingInBase, boolean isTravelInBase, String commercialName) {
		int length = baseArr.length();
		JSONArray ticketingPlusTravel = validity.getJSONArray(PROP_TICKETINGPLUSTRAVEL);
		if(ticketingPlusTravel.length()>0){
			for(int i=0;i<length;i++){
				for(int j=0;j<ticketingPlusTravel.length();j++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject ticketPlusTravelObj = ticketingPlusTravel.getJSONObject(j);
					JSONObject trigPayout = new JSONObject();
					if(ticketPlusTravelObj.has(PROP_TRIGGERPAYOUT) && ticketPlusTravelObj.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
						trigPayout = getTriggerPayoutObject(ticketPlusTravelObj.getJSONArray(PROP_TRIGGERPAYOUT));
					JSONArray tickincArr =new JSONArray();
					JSONArray tickexcArr =new JSONArray();
					JSONArray travelincArr =new JSONArray();
					JSONArray travelexcArr =new JSONArray();
					JSONArray ticketingDate = new JSONArray();
					JSONArray travelDate = new JSONArray();
					JSONObject inclusionTkt = new JSONObject();
					JSONObject exclusionTkt = new JSONObject();
					JSONObject inclusionTra = new JSONObject();
					JSONObject exclusionTra = new JSONObject();

					JSONObject ticketingObject = ticketPlusTravelObj.getJSONObject(PROP_TICKET);
					JSONObject travelObject = ticketPlusTravelObj.getJSONObject(PROP_TRAVEL);

					switch(ticketPlusTravelObj.getString(PROP_VALIDITYTYPE).toLowerCase()){
					case PROP_TICKETING:{
						getDates(ticketingObject,tickincArr,PROP_TICKETINGFROM,PROP_TICKETINGTO,trigPayout,ticketingDate);
						getBlockOutDates(ticketingObject, tickexcArr,trigPayout,ticketingDate);
						break;
					}
					case PROP_TRAVEL:{
						getDates(travelObject,travelincArr,PROP_TRAVELFROM,PROP_TRAVELTO,trigPayout,travelDate);
						getBlockOutDates(travelObject, travelexcArr,trigPayout,travelDate);
						break;
					}
					default:{
						getDates(ticketingObject,tickincArr,PROP_TICKETINGFROM,PROP_TICKETINGTO,trigPayout,ticketingDate);
						getBlockOutDates(ticketingObject, tickexcArr,trigPayout,ticketingDate);
						getDates(travelObject,travelincArr,PROP_TRAVELFROM,PROP_TRAVELTO,trigPayout,travelDate);
						getBlockOutDates(travelObject, travelexcArr,trigPayout,travelDate);
					}
					}

					if(!tickincArr.isNull(0)){
						inclusionTkt.put(INCLUSION,tickincArr);
						ticketingDate.put(inclusionTkt);
					}
					if(!tickexcArr.isNull(0)){
						exclusionTkt.put(EXCLUSION,tickexcArr);
						ticketingDate.put(exclusionTkt);
					}
					if(!travelincArr.isNull(0)){
						inclusionTra.put(INCLUSION,travelincArr);
						travelDate.put(inclusionTra);
					}
					if(!travelexcArr.isNull(0)){
						exclusionTra.put(EXCLUSION,travelexcArr);
						travelDate.put(exclusionTra);
					}

					if(ticketingDate.length()>0){
						if(isTicketingInBase)
							base.put(PROP_TICKETING, ticketingDate);
						else calculation.put(PROP_TICKETING, ticketingDate);
					}

					if(travelDate.length()>0){
						if(isTravelInBase)
							base.put(PROP_TRAVEL, travelDate);
						else calculation.put(PROP_TRAVEL, travelDate);
					}

					setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_TICKETING+PROP_TRAVEL+i+j);
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void getDates(JSONObject dateObject, JSONArray inclusionArray, String from, String to, JSONObject trigPayout, JSONArray mainDateArray) {
		JSONObject indiObj = new JSONObject();
		if(dateObject.has(from)){
			if(dateObject.has(to)){
				indiObj.put(OPERATOR,BETWEEN);
				indiObj.put(FROM, dateObject.getString(from).substring(0, 11)+"00:00:00");
				indiObj.put(TO, dateObject.getString(to).substring(0, 11)+"23:59:59");
			}else{
				indiObj.put(OPERATOR,GREATERTHANEQUALTO);
				indiObj.put(VALUE, dateObject.getString(from).substring(0, 11)+"00:00:00");
			}
		}else if(dateObject.has(to)){
			indiObj.put(OPERATOR,LESSTHANEQUALTO);
			indiObj.put(VALUE, dateObject.getString(to).substring(0, 11)+"23:59:59");
		}
		if(trigPayout.length()!=0 && trigPayout!=null && !trigPayout.toString().equals("{}"))
			mainDateArray.put(trigPayout);
		inclusionArray.put(indiObj);
	}


	public static void getBlockOutDates(JSONObject dateObject, JSONArray exclusionArray, JSONObject trigPayout, JSONArray mainDateArray) {
		if(dateObject.has(PROP_BLOCKOUT_FROM) && dateObject.getJSONArray(PROP_BLOCKOUT_FROM).length()>0){
			if(dateObject.has(PROP_BLOCKOUT_TO) && dateObject.getJSONArray(PROP_BLOCKOUT_TO).length()>0){
				JSONArray blockOutFrom = dateObject.getJSONArray(PROP_BLOCKOUT_FROM);
				JSONArray blockOutTo = dateObject.getJSONArray(PROP_BLOCKOUT_TO);
				if(trigPayout.length()!=0 && trigPayout!=null && !trigPayout.toString().equals("{}"))
					mainDateArray.put(trigPayout);
				for(int a=0;a<blockOutFrom.length();a++){
					JSONObject indiBlockObj = new JSONObject();
					indiBlockObj.put(OPERATOR, BETWEEN);
					indiBlockObj.put(FROM, blockOutFrom.getString(a).substring(0, 11)+"00:00:00");
					indiBlockObj.put(TO, blockOutTo.getString(a).substring(0, 11)+"23:59:59");
					exclusionArray.put(indiBlockObj);
				}
			}
		}
	}


	public static void getDestination(JSONArray baseArr, JSONArray calcArr, JSONArray destinations, boolean isInclusion, boolean inBase, String commercialName) {
		if(destinations.length()>0){
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<destinations.length();j++){
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONObject destination = destinations.getJSONObject(j);
					if(inBase){
						if(isInclusion){
							if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
								base.put(PROP_CONTINENT, destination.getString(PROP_CONTINENT));
							if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
								base.put(PROP_COUNTRY, destination.getString(PROP_COUNTRY));
							if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
								base.put(PROP_STATE, destination.getString(PROP_STATE));
							if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
								base.put(PROP_CITY, destination.getString(PROP_CITY));
						}else{
							if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
								base.put(PROP_CONTINENT+"_"+EXCLUSION, destination.getString(PROP_CONTINENT));
							if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
								base.put(PROP_COUNTRY+"_"+EXCLUSION, destination.getString(PROP_COUNTRY));
							if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
								base.put(PROP_STATE+"_"+EXCLUSION, destination.getString(PROP_STATE));
							if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
								base.put(PROP_CITY+"_"+EXCLUSION, destination.getString(PROP_CITY));
						}
					}else{
						if(isInclusion){
							if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
								calculation.put(PROP_CONTINENT, destination.getString(PROP_CONTINENT));
							if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
								calculation.put(PROP_COUNTRY, destination.getString(PROP_COUNTRY));
							if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
								calculation.put(PROP_STATE, destination.getString(PROP_STATE));
							if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
								calculation.put(PROP_CITY, destination.getString(PROP_CITY));
						}else{
							if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
								calculation.put(PROP_CONTINENT+"_"+EXCLUSION, destination.getString(PROP_CONTINENT));
							if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
								calculation.put(PROP_COUNTRY+"_"+EXCLUSION, destination.getString(PROP_COUNTRY));
							if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
								calculation.put(PROP_STATE+"_"+EXCLUSION, destination.getString(PROP_STATE));
							if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
								calculation.put(PROP_CITY+"_"+EXCLUSION, destination.getString(PROP_CITY));
						}
					}
					setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_DESTINATIONS+i+j);
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}
	
	
	public static void getTriggerPayoutDestination(JSONArray baseArr, JSONArray calcArr, JSONArray travel, boolean isInclusion, boolean inBase, String commercialName) {
		if(travel.length()>0){
			int length= baseArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<travel.length();j++){
					JSONObject object = travel.getJSONObject(j);
					JSONObject triggerPayout = getTriggerPayoutObject(object.getJSONArray(PROP_TRIGGERPAYOUT));
					JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
					JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
					JSONArray requestArr = new JSONArray();
					JSONObject requestObject = new JSONObject();
					requestArr.put(triggerPayout);
					if(isInclusion){
						if(object.has(PROP_CONTINENT) && !object.getString(PROP_CONTINENT).equalsIgnoreCase("All") && object.getString(PROP_CONTINENT).length()!=0)
							requestObject.put(PROP_CONTINENT, object.getString(PROP_CONTINENT));
						if(object.has(PROP_COUNTRY) && !object.getString(PROP_COUNTRY).equalsIgnoreCase("All") && object.getString(PROP_COUNTRY).length()!=0)
							requestObject.put(PROP_COUNTRY, object.getString(PROP_COUNTRY));
						if(object.has(PROP_STATE) && !object.getString(PROP_STATE).equalsIgnoreCase("All") && object.getString(PROP_STATE).length()!=0)
							requestObject.put(PROP_STATE, object.getString(PROP_STATE));
						if(object.has(PROP_CITY) && !object.getString(PROP_CITY).equalsIgnoreCase("All") && object.getString(PROP_CITY).length()!=0)
							requestObject.put(PROP_CITY, object.getString(PROP_CITY));
					}else{
						if(object.has(PROP_CONTINENT) && !object.getString(PROP_CONTINENT).equalsIgnoreCase("All") && object.getString(PROP_CONTINENT).length()!=0)
							requestObject.put(PROP_CONTINENT+"_"+EXCLUSION, object.getString(PROP_CONTINENT));
						if(object.has(PROP_COUNTRY) && !object.getString(PROP_COUNTRY).equalsIgnoreCase("All") && object.getString(PROP_COUNTRY).length()!=0)
							requestObject.put(PROP_COUNTRY+"_"+EXCLUSION, object.getString(PROP_COUNTRY));
						if(object.has(PROP_STATE) && !object.getString(PROP_STATE).equalsIgnoreCase("All") && object.getString(PROP_STATE).length()!=0)
							requestObject.put(PROP_STATE+"_"+EXCLUSION, object.getString(PROP_STATE));
						if(object.has(PROP_CITY) && !object.getString(PROP_CITY).equalsIgnoreCase("All") && object.getString(PROP_CITY).length()!=0)
							requestObject.put(PROP_CITY+"_"+EXCLUSION, object.getString(PROP_CITY));
					}
					requestArr.put(requestObject);
					if(inBase)
						base.put(PROP_TRAVELDEST, requestArr);
					else calculation.put(PROP_TRAVELDEST, requestArr);
					setRuleID(baseArr,calcArr,base,calculation,commercialName+PROP_TRAVELDEST+i+j);
				}
			}
			for(int i=0;i<length;i++){
				baseArr.remove(0);
				calcArr.remove(0);
			}
		}
	}


	public static void setOtherFeesDestination(JSONArray otherFeeArr, JSONArray destinations, boolean isInclusion, String commercialName) {
		if(destinations.length()>0){
			int length = otherFeeArr.length();
			for(int i=0;i<length;i++){
				for(int j=0;j<destinations.length();j++){
					JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
					JSONObject destination = destinations.getJSONObject(j);
					if(isInclusion){
						if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
							otherFee.put(PROP_CONTINENT, destination.getString(PROP_CONTINENT));
						if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
							otherFee.put(PROP_COUNTRY, destination.getString(PROP_COUNTRY));
						if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
							otherFee.put(PROP_STATE, destination.getString(PROP_STATE));
						if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
							otherFee.put(PROP_CITY, destination.getString(PROP_CITY));
					}else{
						if(destination.has(PROP_CONTINENT) && !destination.getString(PROP_CONTINENT).equalsIgnoreCase("All") && destination.getString(PROP_CONTINENT).length()!=0)
							otherFee.put(PROP_CONTINENT+"_"+EXCLUSION, destination.getString(PROP_CONTINENT));
						if(destination.has(PROP_COUNTRY) && !destination.getString(PROP_COUNTRY).equalsIgnoreCase("All") && destination.getString(PROP_COUNTRY).length()!=0)
							otherFee.put(PROP_COUNTRY+"_"+EXCLUSION, destination.getString(PROP_COUNTRY));
						if(destination.has(PROP_STATE) && !destination.getString(PROP_STATE).equalsIgnoreCase("All") && destination.getString(PROP_STATE).length()!=0)
							otherFee.put(PROP_STATE+"_"+EXCLUSION, destination.getString(PROP_STATE));
						if(destination.has(PROP_CITY) && !destination.getString(PROP_CITY).equalsIgnoreCase("All") && destination.getString(PROP_CITY).length()!=0)
							otherFee.put(PROP_CITY+"_"+EXCLUSION, destination.getString(PROP_CITY));
					}

					setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+PROP_DESTINATIONS+i+j);
				}
			}
			for(int i=0;i<length;i++){
				otherFeeArr.remove(0);
			}
		}
	}


	public static void setInitialRequirements(JSONArray baseArr, JSONArray calcArr, JSONObject jsonObject, String mainScreenId, String commercialName) {
		JSONObject base = new JSONObject();
		JSONObject calculation = new JSONObject();
		base.put(CONTRACTVALIDITY, CommonFunctions.getContractValidity(jsonObject));
		base.put(TYPE, BASE);
		calculation.put(TYPE, CALCULATION);
		base.put(SELECTEDROW, commDefnID);
		base.put(RULEID, BASE+"_"+mainScreenId+"_"+commercialName+"_");
		calculation.put(RULEID, CALCULATION+"_"+mainScreenId+"_"+commercialName+"_");
		base.put(COMMERCIAL_ID, BASE+"_"+mainScreenId+"_"+commercialName+"_");
		calculation.put(COMMERCIAL_ID, CALCULATION+"_"+mainScreenId+"_"+commercialName+"_");
		calculation.put(SELECTEDROW, BASE+"_"+mainScreenId+"_"+commercialName+"_");
		//base.put("isTransactional", jsonObject.getBoolean("isTransactional"));
		baseArr.put(base);
		calcArr.put(calculation);
	}
	

	public static void setCommercialId(JSONObject mainJson, String _id){
		Iterator<?> keys =mainJson.keys();
		while(keys.hasNext()){
			String key= (String) keys.next();
			if(mainJson.get(key) instanceof JSONArray){
				JSONArray keyData = mainJson.getJSONArray(key);
				for(int k=0;k<keyData.length();k++){
					JSONObject jsonObject = keyData.getJSONObject(k);
					if(jsonObject.getString(TYPE).equals(BASE))
						jsonObject.put(COMMERCIAL_ID, jsonObject.getString(COMMERCIAL_ID)+k);
					else jsonObject.put(COMMERCIAL_ID, jsonObject.getString(COMMERCIAL_ID)+k);
					jsonObject.put("key", _id);
				}
			}else{
				JSONObject jsonObject  =mainJson.getJSONObject(key);
				jsonObject.put(COMMERCIAL_ID, _id);
				jsonObject.put("key", _id);
			}
		}
	}


	public static void setAdvancedCommercials(String advancedCommID, String baseDT, String calculationDT, JSONObject advanceCommercial, JSONArray baseArr, JSONArray calcArr, JSONArray commercialHead, JSONObject mainJson, String commercialName, String contractType, boolean settlementTransactionWise, String advanceCommercialDataID, String _id) {
		String netOffCommercialHead=null;
		String commercialType = advanceCommercial.getJSONObject(PROP_COMMERCIALINFO).getString(PROP_COMMERCIALTYPE);
		if(advanceCommercial.has(CALCULATION)){
			if(advanceCommercial.getJSONObject(CALCULATION).has(PROP_NETTOFFCOMMHEAD))
				netOffCommercialHead = getCommercialName(advanceCommercial.getJSONObject(CALCULATION).getString(PROP_NETTOFFCOMMHEAD));
		}
		setInitialRequirements(baseArr,calcArr,advanceCommercial,_id,commercialName);
		setCommercialHead(mainJson,baseDT,calculationDT,baseArr,calcArr,commercialName,commercialHead,netOffCommercialHead,commercialType,contractType,settlementTransactionWise);

		if(advanceCommercial.getJSONArray(PROP_IATANOS).length()>0){
			for(int i=0;i<baseArr.length();i++){
				baseArr.getJSONObject(i).put(IATANO, advanceCommercial.getJSONArray(PROP_IATANOS));
			}
		}
		
		if(advanceCommercial.has(PROP_SUPP_RATE) && advanceCommercial.getJSONArray(PROP_SUPP_RATE).length()>0)
			getSupplierRate(advanceCommercial.getJSONArray(PROP_SUPP_RATE),calcArr);

		if(advanceCommercial.getJSONArray(PROP_CLIENT).length()>0)
			getClientDetails(baseArr,calcArr,advanceCommercial.getJSONArray(PROP_CLIENT),commercialName);
		
		/*if(advanceCommercial.has(PROP_PRODUCT) && advanceCommercial.getJSONArray(PROP_PRODUCT).length()>0){
			JSONArray product = advanceCommercial.getJSONArray(PROP_PRODUCT);
			CommonFunctions.getProductDetails(product,baseArr,calcArr,commercialName);
		}*/
		
		if(advanceCommercial.has(PROP_PRODUCT) && advanceCommercial.getJSONArray(PROP_PRODUCT).length()>0){
			JSONArray product = advanceCommercial.getJSONArray(PROP_PRODUCT);
			HashSet<String> productId = new HashSet<String>();
			for(int i=0;i<product.length();i++){
				if(!product.getJSONObject(i).getString(PROP_PRODUCTID).equalsIgnoreCase("All"))
				productId.add(product.getJSONObject(i).getString(PROP_PRODUCTID));
			}
			if(productId.size()>0){
				for(int i=0;i<baseArr.length();i++){
					baseArr.getJSONObject(i).put(PROP_PRODUCTID, productId);
				}
			}
		}
		
		if(advanceCommercial.has(PROP_CALCULATIONTYPE)){
			if(advanceCommercial.getString(PROP_CALCULATIONTYPE).equals(PROP_FIXED)){
				for(int i=0;i<calcArr.length();i++){
					getFixedDetails(calcArr.getJSONObject(i),advanceCommercial.getJSONObject(PROP_FIXED));
				}
			}
		}else if(advanceCommercial.has(PROP_FIXED)){
			for(int i=0;i<calcArr.length();i++){
				getFixedDetails(calcArr.getJSONObject(i),advanceCommercial.getJSONObject(PROP_FIXED));
			}
		}

		boolean slab=false;
		if((advanceCommercial.has(PROP_CALCULATIONTYPE) && advanceCommercial.getString(PROP_CALCULATIONTYPE).equals(PROP_SLAB)) || (!advanceCommercial.has(PROP_CALCULATIONTYPE) && advanceCommercial.has(PROP_SLAB))){
			slab=true;
			advanceCommercialDataID+="|";
			getSlabDetails(advancedCommID,baseArr,calcArr,advanceCommercial.getJSONArray(PROP_SLAB),advanceCommercialDataID,commercialName);
		}

		if(!slab){
			int length=calcArr.length();
			advanceCommercialDataID+="|fixed|null";
			String temp = advanceCommercialDataID;
			for(int i=0;i<length;i++){
				calcArr.getJSONObject(i).put(MDMRULEID, advanceCommercialDataID+"|"+calcArr.getJSONObject(i).getString(SELECTEDROW));
				getFixedDetails(calcArr.getJSONObject(i), advanceCommercial.getJSONObject(PROP_FIXED));
				advanceCommercialDataID = temp;
			}
		}

		if(mainJson.has(baseDT)){
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				mainJson.getJSONArray(baseDT).put(baseArr.getJSONObject(i));
				mainJson.getJSONArray(calculationDT).put(calcArr.getJSONObject(i));
			}
		}else{
			mainJson.put(baseDT, baseArr);
			mainJson.put(calculationDT, calcArr);
		}
	}


	public static void setInitialRquirement(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) {
		JSONObject supplierCommercialData = mdmDefn.getJSONObject(PROP_SUPP_COMM_DATA);
		if(supplierCommercialData.has(PROP_STD_COMM)){
			String _id = supplierCommercialData.getString(PROP_ID);
			suppCommDataId=_id;
			String supplierCommercialDataID = null, companyId = null;
			if(supplierCommercialData.has(PROP__V))
				supplierCommercialDataID = supplierCommercialData.get(PROP__V)+"|"+_id;
			else supplierCommercialDataID = "0|"+_id;
			mdmRuleID=supplierCommercialDataID;
			if(supplierCommercialData.has(PROP_COMPANY_ID))
				companyId = supplierCommercialData.getString(PROP_COMPANY_ID);
			JSONObject standardCommercial = supplierCommercialData.getJSONObject(PROP_STD_COMM);
			stdComm=standardCommercial;
			if(toInsert(supplierCommercialData.getString("commercialMappingId"),mdmDefn,productCategorySubType,supplier)){
				JSONObject commDefn = getCommercialDefiniton(mdmDefn,productCategory,productCategorySubType,supplier,supplierMarkets,STANDARD,companyId);
				setProductCategorySubType(productName,commDefn,productCategory,productCategorySubType);
				mainJson.put(COMMDEFN_DT, commDefn);
				commDefnMap.put(commDefnID, commDefn);
			}
			setInitialRequirements(baseArr,calcArr,standardCommercial,_id,STANDARD);
			mainJson.put(STANDARD_BASE_DT, baseArr);
			mainJson.put(STANDARD_CALCULATION_DT, calcArr);
			
			String stdmdmRuleID = supplierCommercialDataID+"|standardCommercial|null|";
			String fixed = stdmdmRuleID+="fixed|null";
			String temp = fixed;
			int length = baseArr.length();
			for(int i=0;i<length;i++){
				calcArr.getJSONObject(i).put(MDMRULEID, fixed+"|"+calcArr.getJSONObject(i).getString(SELECTEDROW));
				if(standardCommercial.getBoolean(PROP_ISFIXED))
					getFixedDetails(calcArr.getJSONObject(i),standardCommercial.getJSONObject(PROP_FIXED));
				else getSlabDetails(_id,baseArr,calcArr,standardCommercial.getJSONArray(PROP_SLAB),stdmdmRuleID,STANDARD);
				fixed=temp;
			}
		}
	}


	private static boolean toInsert(String commMappingId, JSONObject mdmDefn, String productCategorySubType, String supplier) {
		String _id = mdmDefn.getJSONObject(PROP_SUPP_COMM_DATA).getString(PROP_ID);
		if(commercialMappingId == null || commercialMappingId.size() == 0){
			commercialMappingId.put(commMappingId, productCategorySubType+"_"+supplier+"_"+_id);
			return true;
		}else{
			if(commercialMappingId.containsKey(commMappingId)){
				commDefnID = commercialMappingId.get(commMappingId);
				return false;
			}else{
				commercialMappingId.put(commMappingId, productCategorySubType+"_"+supplier+"_"+_id);
				return true;
			}
		}
	}


	private static void setProductCategorySubType(String productName, JSONObject commDefn, String productCategory, String productCategorySubType) {
		switch(productName){
		case PRODUCTNAME_ACCOMODATION:{
			commDefn.put(PROP_PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		case PRODUCTNAME_ACTIVITIES:{
			commDefn.put(PROP_PRODUCTCATEGORY, productCategory);
			commDefn.put(PROP_PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		case PRODUCTNAME_HOLIDAYS:{
			commDefn.put(PROP_PRODUCTCATEGORY, productCategory);
			commDefn.put(PROP_PRODUCTCATEGORYSUBTYPE, productCategorySubType);
			break;
		}
		}
	}


	public static void setAdvancedCommercials(JSONObject mdmDefn, JSONArray commercialHead, JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject standardCommercial, String supplier, JSONArray supplierMarkets, String productCategory , String productCategorySubType, String productName, String supplierCommercialDataID, String _id) throws Exception {
		Boolean settlement=false;
		JSONObject settlementObject = new JSONObject();
		String advanceCommercialDataID = supplierCommercialDataID+"|advanceCommercialData|";
		String tempAdvCommID = advanceCommercialDataID;
		for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVCOMMDATA).length();i++){
			JSONObject advanceCommercialData = mdmDefn.getJSONArray(PROP_ADVCOMMDATA).getJSONObject(i);
			JSONObject advanceCommercial = advanceCommercialData.getJSONObject(PROP_ADVCOMM);
			String advancedCommID = advanceCommercialData.getString(PROP_ID);
			advanceCommercialDataID+=advancedCommID;
			String displayName = advanceCommercial.getJSONObject(PROP_COMMHEADINFO).getString(PROP_DISPLAYNAME);
			switch(displayName){
			case MDM_OVERRIDING:{
				JSONObject overRidingCommission = advanceCommercial.getJSONObject(PROP_OVERCOMM);
				setContractType(MDM_OVERRIDING,overRidingCommission);
				advanceCommercialDataID+="_"+PROP_OVERCOMM;
				setAdvancedCommercial(advancedCommID,mainJson,OVERRIDING_BASE_DT,OVERRIDING_CALCULATION_DT,OVERRIDING,overRidingCommission,mdmDefn,commercialHead,overCT,overSet,advanceCommercialDataID,_id,productName);
				break;
			}
			case MDM_PLB:{
				JSONObject plb = advanceCommercial.getJSONObject(PROP_PLB);
				setContractType(MDM_PLB,plb);
				advanceCommercialDataID+="_"+PROP_PLB;
				setAdvancedCommercial(advancedCommID,mainJson,PLB_BASE_DT,PLB_CALCULATION_DT,PLB,plb,mdmDefn,commercialHead,plbCT,plbSet,advanceCommercialDataID,_id,productName);
				break;
			}
			case MDM_DESTINATIONINCENTIVES:{
				JSONObject destinationIncentives = advanceCommercial.getJSONObject(PROP_DESTINATIONINCENTIVES);
				setContractType(MDM_DESTINATIONINCENTIVES,destinationIncentives);
				advanceCommercialDataID+="_"+PROP_DESTINATIONINCENTIVES;
				setAdvancedCommercial(advancedCommID,mainJson,DESTINATION_BASE_DT,DESTINATION_CALCULATION_DT,DESTINATIONINCENTIVE,destinationIncentives,mdmDefn,commercialHead,destCT,destSet,advanceCommercialDataID,_id,productName);
				break;
			}
			case MDM_SECTORINCENTIVES:{
				JSONObject sectorWiseIncentives = advanceCommercial.getJSONObject(PROP_SECTORWISEINCENTIVES);
				setContractType(MDM_SECTORINCENTIVES,sectorWiseIncentives);
				advanceCommercialDataID+="_"+PROP_SECTORWISEINCENTIVES;
				setAdvancedCommercial(advancedCommID,mainJson,SECTORWISE_BASE_DT,SECTORWISE_CALCULATION_DT,SECTORWISEINCENTIVE,sectorWiseIncentives,mdmDefn,commercialHead,destCT,destSet,advanceCommercialDataID,_id,productName);
				break;
			}
			case MDM_SEGMENTFEES:{
				JSONObject segmentFees = advanceCommercial.getJSONObject(PROP_SEGMENTFEES);
				setContractType(MDM_SEGMENTFEES,segmentFees);
				advanceCommercialDataID+="_"+PROP_SEGMENTFEES;
				setAdvancedCommercial(advancedCommID,mainJson,SEGMENTFEE_BASE_DT,SEGMENTFEE_CALCULATION_DT,SEGMENTFEE,segmentFees,mdmDefn,commercialHead,segCT,segSet,advanceCommercialDataID,_id,productName);
				break;
			}
			case MDM_SERVICECHARGES:{
				JSONObject serviceCharge = advanceCommercial.getJSONObject(PROP_SERVICECHARGE);
				setContractType(MDM_SERVICECHARGES,serviceCharge);
				advanceCommercialDataID+="_"+PROP_SERVICECHARGE;
				setAdvancedCommercial(advancedCommID,mainJson,SERVICE_BASE_DT,SERVICE_CALCULATION_DT,SERVICECHARGE,serviceCharge,mdmDefn,commercialHead,serCT,serSet,advanceCommercialDataID,_id,productName);
				break;
			}
			case MDM_ISSUANCEFEES:{
				JSONObject issuanceFees = advanceCommercial.getJSONObject(PROP_ISSUANCEFEES);
				setContractType(MDM_ISSUANCEFEES,issuanceFees);
				advanceCommercialDataID+="_"+PROP_ISSUANCEFEES;
				setAdvancedCommercial(advancedCommID,mainJson,ISSUANCEFEE_BASE_DT,ISSUANCEFEE_CALCULATION_DT,ISSUANCEFEE,issuanceFees,mdmDefn,commercialHead,issCT,issSet,advanceCommercialDataID,_id,productName);
				break;
			}
			case MDM_MANAGEMENTFEE:{
				JSONObject managementFee = advanceCommercial.getJSONObject(PROP_MANAGEMENTFEE);
				setContractType(MDM_MANAGEMENTFEE,managementFee);
				advanceCommercialDataID+="_"+PROP_MANAGEMENTFEE;
				setAdvancedCommercial(advancedCommID,mainJson,MNGT_BASE_DT,MNGT_CALCULATION_DT,MANAGEMENTFEE,managementFee,mdmDefn,commercialHead,mngtCT,mngtSet,advanceCommercialDataID,_id,productName);
				break;
			}
			case MDM_COMMISSION:{
				JSONObject commissionFlights = advanceCommercial.getJSONObject(PROP_COMMISSIONFLIGHTS);
				setContractType(MDM_COMMISSION,commissionFlights);
				advanceCommercialDataID+="_"+PROP_COMMISSIONFLIGHTS;
				setAdvancedCommercial(advancedCommID,mainJson,COMMMISSION_BASE_DT,COMMISSION_CALCULATION_DT,MDM_COMMISSION,commissionFlights,mdmDefn,commercialHead,commCT,commSet,advanceCommercialDataID,_id,productName);
				break;
			}
			default:{
				settlement=true;
				String commercialName = CommonFunctions.getCommercialName(displayName);
				String commDefnID = mdmDefn.getJSONObject(PROP_SUPP_COMM_DATA).getString(PROP_ID);
				String contractType = null;
				if(standardCommercial.getJSONObject(PROP_COMMERCIALINFO).has(PROP_BOOLEAN_ISPROVISIONAL)){
					if(standardCommercial.getJSONObject(PROP_COMMERCIALINFO).getBoolean(PROP_BOOLEAN_ISPROVISIONAL))
						contractType=PROVISIONAL;
					else contractType=FINAL;
				}
				settlementObject = SettlementCommercials.settlementCommercials(commercialName,mdmDefn.getJSONArray(PROP_ADVCOMMDATA).getJSONObject(i),supplier,supplierMarkets,productCategory,productCategorySubType,productName,contractType,commDefnID,mdmDefn.getJSONArray(PROP_ADVDEFN_DATA));
			}
			}
			advanceCommercialDataID = tempAdvCommID;
		}
		if(settlement){
			CommonFunctions.setCommercialId(settlementObject, _id);
			ReceiveMDMRequest.LOGGER.info(productName+" Settlement: "+settlementObject.toString());
			ReceiveMDMRequest.invokeSettlementRuleConfigurator(settlementObject.toString(),productName,ReceiveMDMRequest.method);
			SettlementCommercials.main.keySet().clear();
		}
	}


	public static void setAdvancedCommercial(String advancedCommID, JSONObject mainJson, String baseDT, String calculationDT, String commercialName, JSONObject advanceCommercialNameObject, JSONObject mdmDefn, JSONArray commercialHead, String contractType, boolean settlementTransactionWise, String advanceCommercialDataID, String _id, String productName) {
		JSONArray baseArr = new JSONArray();
		JSONArray calcArr = new JSONArray();
		CommonFunctions.setAdvancedCommercials(advancedCommID,baseDT,calculationDT,advanceCommercialNameObject,baseArr,calcArr,commercialHead,mainJson,commercialName,contractType,settlementTransactionWise,advanceCommercialDataID,_id);

		if(advanceCommercialNameObject.has(PROP_ADVDEFN_ID)){
			String advDefnID = advanceCommercialNameObject.getString(PROP_ADVDEFN_ID);
			for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).length();i++){
				JSONObject advanceDefinationData = mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(i);
				if(advanceDefinationData.getString(PROP_ID).equals(advDefnID)){
					switch(productName){
					case PRODUCTNAME_ACCOMODATION:{
						if(commercialName.equals(PLB)){
							JSONObject advanceDefinitionAccommodationPLB = advanceDefinationData.getJSONObject(PROP_ADVDEFN_ACCO_PLB);
							Accomodation.setPLBAdvancedDefinition(advanceDefinitionAccommodationPLB,baseArr,calcArr,commercialName);
						}else{
							JSONObject advanceDefinitionAccommodation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_ACCO);
							Accomodation.setAccomodationAdvancedDefinition(advanceDefinitionAccommodation,baseArr,calcArr,commercialName);
						}break;
					}
					case PRODUCTNAME_ACTIVITIES:{
						JSONObject advanceDefinitionActivities = advanceDefinationData.getJSONObject(PROP_ADVDEFN_ACTIVITIES);
						Activities.setActivitiesAdvancedDefinition(advanceDefinitionActivities, baseArr, calcArr,commercialName);
						break;
					}
					case PRODUCTNAME_AIR:{
						JSONObject advanceDefinitionAir = advanceDefinationData.getJSONObject(PROP_ADVDEFN_AIR);
						if(commercialName.equals(PLB))
							Air.setPLBAdvancedDefinition(baseArr,calcArr,advanceDefinitionAir,commercialName,_id);
						else Air.setAirAdvancedDefinition(baseArr,calcArr,advanceDefinitionAir,commercialName);
						break;
					}
					case PRODUCTNAME_HOLIDAYS:{
						JSONObject advanceDefinitionHolidays = advanceDefinationData.getJSONObject(PROP_ADVDEFN_HOLIDAYS);
						Holidays.setHolidaysAdvancedDefinition(advanceDefinitionHolidays, baseArr, calcArr,commercialName);
						break;
					}
					case PRODUCTNAME_CARRENTALS:{
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true,commercialName);
						CarRentals.appendVehicleDetails(baseArr,calcArr,advanceDefinitionTransportation,commercialName);
						break;
					}
					case PRODUCTNAME_CRUISE:{
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,false,commercialName);
						break;
					}
					case PRODUCTNAME_RAIL:{
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true,commercialName);
						break;
					}
					case PRODUCTNAME_BUS:{
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true,commercialName);
						break;
					}
					case PRODUCTNAME_TRANSFERS:{
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true,commercialName);
						Transfers.appendVehicleDetails(baseArr,calcArr,advanceDefinitionTransportation,commercialName);
						break;
					}
					case PRODUCTNAME_INSURANCE:{}
					case PRODUCTNAME_VISA:{}
					}
				}
			}
		}
	}


	private static void setContractType(String displayName, JSONObject jsonObject) {
		String contractType=FINAL;boolean settlementTransactionWise=false;
		if(jsonObject.getJSONObject(PROP_COMMERCIALINFO).has(PROP_BOOLEAN_ISPROVISIONAL) && jsonObject.getJSONObject(PROP_COMMERCIALINFO).getBoolean(PROP_BOOLEAN_ISPROVISIONAL))
			contractType=PROVISIONAL;
		if(jsonObject.has(PROP_BOOLEAN_ISSETTTRANSWISE))
			settlementTransactionWise= jsonObject.getBoolean(PROP_BOOLEAN_ISSETTTRANSWISE);

		switch(displayName){
		case MDM_OVERRIDING:{overCT=contractType;overSet=settlementTransactionWise;break;}
		case MDM_PLB:{plbCT=contractType;plbSet=settlementTransactionWise;break;}
		case MDM_DESTINATIONINCENTIVES:{destCT=contractType;destSet=settlementTransactionWise;break;}
		case MDM_SEGMENTFEES:{segCT=contractType;segSet=settlementTransactionWise;break;}
		case MDM_SERVICECHARGES:{serCT=contractType;serSet=settlementTransactionWise;break;}
		case MDM_ISSUANCEFEES:{issCT=contractType;issSet=settlementTransactionWise;break;}
		case MDM_MANAGEMENTFEE:{mngtCT=contractType;mngtSet=settlementTransactionWise;break;}
		default:System.out.println("default of CommonFunctions.setContractType due to MDM commercialName: "+displayName);
		}
	}
}
