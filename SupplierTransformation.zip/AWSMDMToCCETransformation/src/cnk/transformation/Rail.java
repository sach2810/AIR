package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;

public class Rail implements Constants {
	
	public static String setCommercials(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		if(baseArr.length()>0){
			JSONObject standardCommercial = CommonFunctions.stdComm;
			baseArr.getJSONObject(0).put(PROP_PRODUCTCATEGORY, productCategory);
			baseArr.getJSONObject(0).put(PROP_PRODUCTCATEGORYSUBTYPE, productCategorySubType);

			if(standardCommercial.has(PROP_PRODUCT) && standardCommercial.getJSONObject(PROP_PRODUCT).has(PROP_TRANSPORTATION)){
				JSONObject transportation = standardCommercial.getJSONObject(PROP_PRODUCT).getJSONObject(PROP_TRANSPORTATION);
				if(transportation.has(PROP_PRODUCT)){
					JSONObject product = transportation.getJSONObject(PROP_PRODUCT);
					if(product.has(PRODUCTNAME_RAIL) && product.getJSONArray(PRODUCTNAME_RAIL).length()>0){
						JSONArray rail = product.getJSONArray(PRODUCTNAME_RAIL);
						setRailDetails(rail,baseArr,calcArr);
					}
				}
			}

			if(standardCommercial.has(PROP_ADVDEFN_ID)){
				String advDefnID = standardCommercial.getString(PROP_ADVDEFN_ID);
				for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(i);
					if(advanceDefinationData.getString(PROP_ID).equals(advDefnID)){
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						if(advanceDefinitionTransportation.has(PROP_VALIDITY)){
							JSONObject validity = advanceDefinitionTransportation.getJSONObject(PROP_VALIDITY);
							if(validity.has(PROP_VALIDITYTYPE)){
								CommonFunctions.insertSalePlusTravel(baseArr,calcArr, validity.getJSONArray(PROP_SALEPLUSTRAVEL), true, false,STANDARD);
							}
						}
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true,STANDARD);
					}
				}
			}
			JSONArray commercialHead = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
			CommonFunctions.setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,CommonFunctions.mdmRuleID,CommonFunctions.suppCommDataId);
			CommonFunctions.setCommercialId(mainJson, CommonFunctions.suppCommDataId);
		}
		//System.out.println("Rail Transactional: "+mainJson.toString());
		return mainJson.toString();
	}
	
	
	private static void setRailDetails(JSONArray rail, JSONArray baseArr, JSONArray calcArr) {
		
		
	}
}
