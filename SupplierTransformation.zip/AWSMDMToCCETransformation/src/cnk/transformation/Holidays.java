package cnk.transformation;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Holidays implements Constants {
	
	public static String setCommercials(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		if(baseArr.length()>0){
			JSONObject standardCommercial = CommonFunctions.stdComm;
			JSONObject holidays = standardCommercial.getJSONObject(PROP_PRODUCT).getJSONObject(PRODUCTNAME_HOLIDAYS);
			if(holidays.getJSONArray(PROP_SUPP_RATE).length()>0)
				CommonFunctions.getSupplierRate(holidays.getJSONArray(PROP_SUPP_RATE),calcArr);

			if(holidays.getJSONArray("products").length()>0){
				JSONArray products = holidays.getJSONArray("products");
				getHolidaysProductDetails(products,baseArr,calcArr,STANDARD);
			}

			if(standardCommercial.getJSONArray(PROP_CLIENTS).length()>0)
				CommonFunctions.getClientDetails(baseArr,calcArr,standardCommercial.getJSONArray(PROP_CLIENTS),STANDARD);

			if(standardCommercial.has(PROP_ADVDEFN_ID)){
				String advDefnID = standardCommercial.getString(PROP_ADVDEFN_ID);
				for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(i);
					if(advanceDefinationData.getString(PROP_ID).equals(advDefnID)){
						JSONObject advanceDefinitionHolidays = advanceDefinationData.getJSONObject(PROP_ADVDEFN_HOLIDAYS);
						setHolidaysAdvancedDefinition(advanceDefinitionHolidays,baseArr,calcArr,STANDARD);
					}
				}
			}
			JSONArray commercialHead = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
			CommonFunctions.setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,CommonFunctions.mdmRuleID,CommonFunctions.suppCommDataId);
			CommonFunctions.setCommercialId(mainJson, CommonFunctions.suppCommDataId);
		}
		//System.out.println("Holidays Transactional: "+mainJson.toString());
		return mainJson.toString();
	}


	public static void setHolidaysAdvancedDefinition(JSONObject advanceDefinitionHolidays, JSONArray baseArr, JSONArray calcArr, String commercialName) {
		if(advanceDefinitionHolidays.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionHolidays.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_SALEORTRAVEL)){
				switch(validity.getString(PROP_SALEORTRAVEL)){
				case PROP_SALES:{
					JSONObject sales = validity.getJSONArray(PROP_SALES).getJSONObject(0);
					if(sales.has(PROP_TRIGGERPAYOUT) && sales.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
						getPLBDates(baseArr, calcArr, validity.getJSONArray(PROP_SALES), PROP_SALES, false, PLB);
					else setDate(baseArr, calcArr, validity.getJSONArray(PROP_SALES), PROP_SALE, false);
					break;
				}
				case PROP_TRAVEL:{
					JSONObject travel = validity.getJSONArray(PROP_TRAVEL).getJSONObject(0);
					if(travel.has(PROP_TRIGGERPAYOUT) && travel.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
						getPLBDates(baseArr, calcArr, validity.getJSONArray(PROP_TRAVEL), PROP_TRAVEL, false, PLB);
					else setDate(baseArr, calcArr, validity.getJSONArray(PROP_TRAVEL), PROP_TRAVEL, false);
					break;
				}
				default:System.out.println("default of Holidays.setHolidaysAdvancedDefinition");
				}
			}
		}

		if(advanceDefinitionHolidays.has(PROP_TRAVELDESTS) && advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTS).length()>0){
			JSONObject travelDestinations = advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTS).getJSONObject(0);
			if(travelDestinations.has(PROP_TRIGGERPAYOUT) && travelDestinations.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				setPLBHolidaysDestinations(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTS));
			else setHolidaysDestinations(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTS));
		}
		
		if(advanceDefinitionHolidays.has(PROP_CREDENTIALS) && advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS).length()>0){
			JSONObject credentials = advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS).getJSONObject(0);
			if(credentials.has(PROP_TRIGGERPAYOUT) && credentials.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS, true, true);
		}
		
		if(advanceDefinitionHolidays.has(PROP_NATIONALITY) && advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY).length()>0){
			JSONObject nationality = advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY).getJSONObject(0);
			if(nationality.has(PROP_TRIGGERPAYOUT) && nationality.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY), PROP_CLIENTNATIONALITY, true, true,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY), PROP_CLIENTNATIONALITY, true, true);
		}
		
		if(advanceDefinitionHolidays.has(PROP_TOURTYPES) && advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES).length()>0){
			JSONObject tourTypes = advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES).getJSONObject(0);
			if(tourTypes.has(PROP_TRIGGERPAYOUT) && tourTypes.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES), PROP_TOURTYPES, true, false,commercialName);
			else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES), PROP_TOURTYPES, true, false);
		}
		
		if(advanceDefinitionHolidays.has(PROP_CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionHolidays.getJSONObject(PROP_CONNECTIVITY);
			for(int i=0;i<baseArr.length();i++){
				JSONObject base = baseArr.getJSONObject(i);
				if(connectivity.has(PROP_TRIGGERPAYOUT) && connectivity.getJSONArray(PROP_TRIGGERPAYOUT).length()>0){
					CommonFunctions.getConnectivityTP(baseArr, connectivity);
					break;
				}
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					base.put(CONN_SUPPTYPE,connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					base.put(CONN_SUPPNAME,connectivity.getString(PROP_SUPPLIERID));
			}
		}
		
		if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
			if(roomLevel.has(PROP_BOOKINGTYPE)){
				JSONObject bookingType = roomLevel.getJSONObject(PROP_BOOKINGTYPE);
				if(bookingType.has(PROP_TRIGGERPAYOUT) && bookingType.getJSONArray(PROP_TRIGGERPAYOUT).length()>0){
					CommonFunctions.getBookingTypeTP(calcArr, bookingType, true);
				}else{
					if(bookingType.has(PROP_BOOKINGTYPE)){
						int length=calcArr.length();
						for(int i=0;i<length;i++){
							JSONObject calculation = calcArr.getJSONObject(i);
							calculation.put(PROP_BOOKINGTYPE, bookingType.getString(PROP_BOOKINGTYPE));
						}
					}
				}
			}	
		}
		
		if(advanceDefinitionHolidays.has(APPLICABLEON) && advanceDefinitionHolidays.getJSONArray(APPLICABLEON).length()>0){
			setHolidaysApplicableOn(baseArr, calcArr,advanceDefinitionHolidays.getJSONArray(APPLICABLEON),advanceDefinitionHolidays,commercialName);
		}else{
			if(advanceDefinitionHolidays.has(PASSENGERTYPE) && advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE).length()>0){
				JSONObject passengerType = advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE).getJSONObject(0);
				if(passengerType.has(PROP_TRIGGERPAYOUT) && passengerType.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
					CommonFunctions.getArray(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE), PASSENGERTYPE, true, false,commercialName);
				else CommonFunctions.getArrayNonTP(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE), PASSENGERTYPE, true, false);
			}
			
			if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
				JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
				if(roomLevel.has(PROP_ROOMCATEGORIES) && roomLevel.getJSONArray(PROP_ROOMCATEGORIES).length()>0){
					JSONObject roomCategories = roomLevel.getJSONArray(PROP_ROOMCATEGORIES).getJSONObject(0);
					if(roomCategories.has(PROP_TRIGGERPAYOUT) && roomCategories.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
						CommonFunctions.getArray(baseArr, calcArr, roomLevel.getJSONArray(PROP_ROOMCATEGORIES), PROP_ROOMCATEGORIES, true, false,commercialName);
					else CommonFunctions.getArrayNonTP(baseArr, calcArr,roomLevel.getJSONArray(PROP_ROOMCATEGORIES),PROP_ROOMCATEGORIES,true,false);
				}
				
				if(roomLevel.has(PROP_ROOMTYPES) && roomLevel.getJSONArray(PROP_ROOMTYPES).length()>0){
					JSONObject roomTypes = roomLevel.getJSONArray(PROP_ROOMTYPES).getJSONObject(0);
					if(roomTypes.has(PROP_TRIGGERPAYOUT) && roomTypes.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
						CommonFunctions.getArray(baseArr, calcArr, roomLevel.getJSONArray(PROP_ROOMTYPES), PROP_ROOMTYPES, true, false,commercialName);
					else CommonFunctions.getArrayNonTP(baseArr, calcArr,roomLevel.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES,true,false);
				}
			}
			
			for(int i=0;i<calcArr.length();i++){
				JSONObject calculation = calcArr.getJSONObject(i);
				calculation.put(POSTPROCESSING_BOOLEAN, true);	//only for holidays
			}
		}
	}
	
	
	private static void setPLBHolidaysDestinations(JSONArray baseArr, JSONArray calcArr, JSONArray travelDestinationsArr) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(travelDestinations.getJSONArray(PROP_TRIGGERPAYOUT));
				JSONArray destinatn = new JSONArray();
				JSONObject desti = new JSONObject();
				destinatn.put(triggerPayout);
				
				if(travelDestinations.has(DESTINATION) && !travelDestinations.getString(DESTINATION).equalsIgnoreCase("All"))
					desti.put(TO_CONTINENT, travelDestinations.getString(DESTINATION));
				if(travelDestinations.has(PROP_COUNTRY) && !travelDestinations.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
					desti.put(TO_COUNTRY, travelDestinations.getString(PROP_COUNTRY));
				if(travelDestinations.has(PROP_CITY) && !travelDestinations.getString(PROP_CITY).equalsIgnoreCase("All"))
					desti.put(TO_CITY, travelDestinations.getString(PROP_CITY));
				if(travelDestinations.has(PROP_STATE) && !travelDestinations.getString(PROP_STATE).equalsIgnoreCase("All"))
					desti.put(TO_STATE, travelDestinations.getString(PROP_STATE));

				destinatn.put(desti);
				calculation.put(PROP_TRAVELDESTS, destinatn);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, travelDestinations.getString(PROP_ID));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void setHolidaysApplicableOn(JSONArray baseArr, JSONArray calcArr, JSONArray applicableOnArr, JSONObject advanceDefinitionHolidays, String commercialName) {
		if(advanceDefinitionHolidays.has(PASSENGERTYPE) && advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE).length()>0){
			JSONObject passengerType = advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE).getJSONObject(0);
			if(passengerType.has(PROP_TRIGGERPAYOUT) && passengerType.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
				getArrayApplicableOn(baseArr, calcArr, advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE), PASSENGERTYPE,commercialName);
			else getArrayNonTPApplicableOn(calcArr, advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE), PASSENGERTYPE);
		}
		
		if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
			if(roomLevel.has(PROP_ROOMCATEGORIES) && roomLevel.getJSONArray(PROP_ROOMCATEGORIES).length()>0){
				JSONObject roomCategories = roomLevel.getJSONArray(PROP_ROOMCATEGORIES).getJSONObject(0);
				if(roomCategories.has(PROP_TRIGGERPAYOUT) && roomCategories.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
					getArrayApplicableOn(baseArr, calcArr, roomLevel.getJSONArray(PROP_ROOMCATEGORIES), PROP_ROOMCATEGORIES,commercialName);
				else getArrayNonTPApplicableOn(calcArr,roomLevel.getJSONArray(PROP_ROOMCATEGORIES),PROP_ROOMCATEGORIES);
			}
			
			if(roomLevel.has(PROP_ROOMTYPES) && roomLevel.getJSONArray(PROP_ROOMTYPES).length()>0){
				JSONObject roomTypes = roomLevel.getJSONArray(PROP_ROOMTYPES).getJSONObject(0);
				if(roomTypes.has(PROP_TRIGGERPAYOUT) && roomTypes.getJSONArray(PROP_TRIGGERPAYOUT).length()>0)
					getArrayApplicableOn(baseArr, calcArr, roomLevel.getJSONArray(PROP_ROOMTYPES), PROP_ROOMTYPES,commercialName);
				else getArrayNonTPApplicableOn(calcArr,roomLevel.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES);
			}
		}
		
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<applicableOnArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				calculation.put(PROP_PRODUCTNAME+"_"+APPLICABLEON, applicableOnArr.getString(j));
				calculation.put(APPLICABLEON_BOOLEAN, true);
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, applicableOnArr.getString(j));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void getArrayApplicableOn(JSONArray baseArr, JSONArray calcArr, JSONArray jsonArray, String name, String commercialName) {
		int length=calcArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<jsonArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject jsonObject = jsonArray.getJSONObject(j);
				JSONObject triggerPayout = CommonFunctions.getTriggerPayoutObject(jsonObject.getJSONArray(PROP_TRIGGERPAYOUT));
				JSONArray array = new JSONArray();
				array.put(triggerPayout);
				JSONObject object = new JSONObject();
				object.put(name+"_"+APPLICABLEON, jsonObject.getString(name));
				array.put(object);
				calculation.put(name, array);
				
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+name+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	private static void getArrayNonTPApplicableOn(JSONArray calcArr, JSONArray jsonArray, String name) {
		Set<String> array = new HashSet<String>();
		for(int j=0;j<jsonArray.length();j++){
			JSONObject jsonObject = jsonArray.getJSONObject(j);
			array.add(jsonObject.getString(name));
		}

		int length=calcArr.length();
		for(int i=0;i<length;i++){
			JSONObject calculation = calcArr.getJSONObject(i);
			calculation.put(name+"_"+APPLICABLEON, array);
		}
	}


	public static void setHolidaysDestinations(JSONArray baseArr, JSONArray calcArr, JSONArray travelDestinationsArr) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				if(travelDestinations.has(DESTINATION) && !travelDestinations.getString(DESTINATION).equalsIgnoreCase("All"))
					calculation.put(TO_CONTINENT, travelDestinations.getString(DESTINATION));
				if(travelDestinations.has(PROP_COUNTRY) && !travelDestinations.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
					calculation.put(TO_COUNTRY, travelDestinations.getString(PROP_COUNTRY));
				if(travelDestinations.has(PROP_CITY) && !travelDestinations.getString(PROP_CITY).equalsIgnoreCase("All"))
					calculation.put(TO_CITY, travelDestinations.getString(PROP_CITY));
				if(travelDestinations.has(PROP_STATE) && !travelDestinations.getString(PROP_STATE).equalsIgnoreCase("All"))
					calculation.put(TO_STATE, travelDestinations.getString(PROP_STATE));

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, travelDestinations.getString(PROP_ID));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getHolidaysProductDetails(JSONArray products, JSONArray baseArr, JSONArray calcArr, String commercialName) {
		int length=baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<products.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject productObject = products.getJSONObject(j);
				if(productObject.has(PROP_PRODUCTNAME) && !productObject.getString(PROP_PRODUCTNAME).equalsIgnoreCase("All"))
					calculation.put(PROP_PRODUCTNAME, productObject.getString(PROP_PRODUCTNAME));
				if(productObject.has(PROP_PRODUCTFLAVOURNAME) && !productObject.getString(PROP_PRODUCTFLAVOURNAME).equalsIgnoreCase("All"))
					calculation.put(PROP_PRODUCTFLAVOURNAME, productObject.getString(PROP_PRODUCTFLAVOURNAME));
				if(productObject.has(PROP_PRODUCTTYPE) && !productObject.getString(PROP_PRODUCTTYPE).equalsIgnoreCase("All"))
					calculation.put(PROP_PRODUCTTYPE, productObject.getString(PROP_PRODUCTTYPE));
				if(productObject.has(PROP_FLAVOURTYPE) && !productObject.getString(PROP_FLAVOURTYPE).equalsIgnoreCase("All"))
					calculation.put(PROP_FLAVOURTYPE, productObject.getString(PROP_FLAVOURTYPE));
				if(productObject.has(PROP_BRANDNAME) && !productObject.getString(PROP_BRANDNAME).equalsIgnoreCase("All"))
					calculation.put(PROP_BRANDNAME, productObject.getString(PROP_BRANDNAME));

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_PRODUCTS+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
	
	
	public static void setOtherFeesHolidaysAdvancedDefinition(JSONObject advanceDefinitionHolidays, JSONArray otherFeeArr, String commercialName){
		if(advanceDefinitionHolidays.has(PROP_VALIDITY)){
			JSONObject validity = advanceDefinitionHolidays.getJSONObject(PROP_VALIDITY);
			if(validity.has(PROP_SALEORTRAVEL)){
				switch(validity.getString(PROP_SALEORTRAVEL)){
				case PROP_SALES:{
					setOtherFeesDate(otherFeeArr,validity.getJSONArray(PROP_SALES),PROP_SALES);
					break;
				}
				case PROP_TRAVEL:{
					setOtherFeesDate(otherFeeArr,validity.getJSONArray(PROP_TRAVEL),PROP_TRAVEL);
					break;
				}
				default:System.out.println("default of Holidays.setHolidaysAdvancedDefinition");
				}
			}
		}

		if(advanceDefinitionHolidays.has(PROP_TRAVELDESTS) && advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTS).length()>0)
			setOtherFeeHolidaysDestinations(otherFeeArr,advanceDefinitionHolidays.getJSONArray(PROP_TRAVELDESTS),commercialName);

		if(advanceDefinitionHolidays.has(PROP_CREDENTIALS) && advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr, advanceDefinitionHolidays.getJSONArray(PROP_CREDENTIALS), PROP_CREDENTIALS);

		if(advanceDefinitionHolidays.has(PROP_NATIONALITY) && advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray(PROP_NATIONALITY), PROP_CLIENTNATIONALITY);

		if(advanceDefinitionHolidays.has(PROP_TOURTYPES) && advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray(PROP_TOURTYPES), PROP_TOURTYPES);

		if(advanceDefinitionHolidays.has(PROP_CONNECTIVITY)){
			JSONObject connectivity = advanceDefinitionHolidays.getJSONObject(PROP_CONNECTIVITY);
			for(int i=0;i<otherFeeArr.length();i++){
				JSONObject otherFee = otherFeeArr.getJSONObject(i);
				if(connectivity.has(PROP_SUPPTYPE) && !connectivity.getString(PROP_SUPPTYPE).equalsIgnoreCase("All"))
					otherFee.put(CONN_SUPPTYPE,connectivity.getString(PROP_SUPPTYPE));
				if(connectivity.has(PROP_SUPPLIERID) && !connectivity.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
					otherFee.put(CONN_SUPPNAME,connectivity.getString(PROP_SUPPLIERID));
			}
		}

		if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
			if(roomLevel.has(PROP_BOOKINGTYPE)){
				JSONObject bookingType = roomLevel.getJSONObject(PROP_BOOKINGTYPE);
				int length=otherFeeArr.length();
				for(int i=0;i<length;i++){
					JSONObject otherFee = otherFeeArr.getJSONObject(i);
					otherFee.put(PROP_BOOKINGTYPE, bookingType.getString(PROP_BOOKINGTYPE));
				}
			}	
		}

		if(advanceDefinitionHolidays.has(PASSENGERTYPE) && advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE).length()>0)
			CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,advanceDefinitionHolidays.getJSONArray(PASSENGERTYPE), PASSENGERTYPE);

		if(advanceDefinitionHolidays.has(PROP_ROOMLEVEL)){
			JSONObject roomLevel = advanceDefinitionHolidays.getJSONObject(PROP_ROOMLEVEL);
			if(roomLevel.has(PROP_ROOMCATEGORIES) && roomLevel.getJSONArray(PROP_ROOMCATEGORIES).length()>0)
				CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,roomLevel.getJSONArray(PROP_ROOMCATEGORIES),PROP_ROOMCATEGORIES);
			if(roomLevel.has(PROP_ROOMTYPES) && roomLevel.getJSONArray(PROP_ROOMTYPES).length()>0)
				CommonFunctions.getOtherFeesArrayNonTP(otherFeeArr,roomLevel.getJSONArray(PROP_ROOMTYPES),PROP_ROOMTYPES);
		}
	}
	
	
	public static void setOtherFeeHolidaysDestinations(JSONArray otherFeeArr, JSONArray travelDestinationsArr, String commercialName) {
		int length=otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<travelDestinationsArr.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject travelDestinations = travelDestinationsArr.getJSONObject(j);
				if(travelDestinations.has(DESTINATION) && !travelDestinations.getString(DESTINATION).equalsIgnoreCase("All"))
					otherFee.put(TO_CONTINENT, travelDestinations.getString(DESTINATION));
				if(travelDestinations.has(PROP_COUNTRY) && !travelDestinations.getString(PROP_COUNTRY).equalsIgnoreCase("All"))
					otherFee.put(TO_COUNTRY, travelDestinations.getString(PROP_COUNTRY));
				if(travelDestinations.has(PROP_CITY) && !travelDestinations.getString(PROP_CITY).equalsIgnoreCase("All"))
					otherFee.put(TO_CITY, travelDestinations.getString(PROP_CITY));
				if(travelDestinations.has(PROP_STATE) && !travelDestinations.getString(PROP_STATE).equalsIgnoreCase("All"))
					otherFee.put(TO_STATE, travelDestinations.getString(PROP_STATE));

				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, commercialName+DESTINATION+i+j);
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}


	public static void setOtherFeesDate(JSONArray otherFeeArr, JSONArray dateArray, String date) {
		String from = date+FROM_CAPITAL;
		String to = date+TO_CAPITAL;
		int length = otherFeeArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArray.length();j++){
				JSONObject otherFee = new JSONObject(new JSONTokener(otherFeeArr.getJSONObject(i).toString()));
				JSONObject dateObject =dateArray.getJSONObject(j);
				JSONArray incArr =new JSONArray();
				JSONArray excArr =new JSONArray();
				JSONArray Date = new JSONArray();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();
				
				CommonFunctions.getDates(dateObject, incArr, from, to,new JSONObject(),Date);
				CommonFunctions.getBlockOutDates(dateObject, excArr,new JSONObject(),Date);

				if(!incArr.isNull(0)){
					inclusion.put(INCLUSION,incArr);
					Date.put(inclusion);
				}
				if(!excArr.isNull(0)){
					exclusion.put(EXCLUSION,excArr);
					Date.put(exclusion);
				}
				otherFee.put(date, Date);
				CommonFunctions.setOtherFeesRuleID(otherFeeArr, otherFee, dateObject.getString(PROP_ID));			
			}
		}
		for(int i=0;i<length;i++){
			otherFeeArr.remove(0);
		}
	}
	
	
	public static void setDate(JSONArray baseArr, JSONArray calcArr, JSONArray dateArray, String date, boolean inBase) {
		String from = date+FROM_CAPITAL;
		String to = date+TO_CAPITAL;
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArray.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject dateObject =dateArray.getJSONObject(j);
				JSONArray incArr =new JSONArray();
				JSONArray excArr =new JSONArray();
				JSONArray Date = new JSONArray();
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();

				CommonFunctions.getDates(dateObject,incArr,from,to,new JSONObject(),Date);
				CommonFunctions.getBlockOutDates(dateObject,excArr,new JSONObject(),Date);

				if(!incArr.isNull(0)){
					inclusion.put(INCLUSION,incArr);
					Date.put(inclusion);
				}
				if(!excArr.isNull(0)){
					exclusion.put(EXCLUSION,excArr);
					Date.put(exclusion);
				}

				if(inBase)
					base.put(date, Date);
				else calculation.put(date, Date);

				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, dateObject.getString(PROP_ID));
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}


	public static void getPLBDates(JSONArray baseArr, JSONArray calcArr, JSONArray dateArr, String date, boolean inBase, String commercialName) {
		String from = date+FROM_CAPITAL;
		String to = date+TO_CAPITAL;
		int length= baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<dateArr.length();j++){
				JSONObject dateObject = dateArr.getJSONObject(j);
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject inclusion = new JSONObject();
				JSONObject exclusion = new JSONObject();
				JSONArray DateInclusionArr = new JSONArray();
				JSONArray DateExclusionArr = new JSONArray();
				JSONArray mainDateArray = new JSONArray();
				
				JSONObject trigPayout = CommonFunctions.getTriggerPayoutObject(dateObject.getJSONArray(PROP_TRIGGERPAYOUT));
				mainDateArray.put(trigPayout);
				
				CommonFunctions.getDates(dateObject, DateInclusionArr, from, to,trigPayout,mainDateArray);
				CommonFunctions.getBlockOutDates(dateObject, DateExclusionArr,trigPayout,mainDateArray);

				if(!DateInclusionArr.isNull(0)){
					inclusion.put(INCLUSION, DateInclusionArr);
					mainDateArray.put(inclusion);
				}
				if(!DateExclusionArr.isNull(0)){
					exclusion.put(EXCLUSION, DateExclusionArr);
					mainDateArray.put(exclusion);
				}

				if(inBase)
					base.put(date, mainDateArray);
				else calculation.put(date, mainDateArray);
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+date+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
}
