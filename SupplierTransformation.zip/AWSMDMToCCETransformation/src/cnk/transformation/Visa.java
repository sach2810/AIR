package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;

public class Visa {

public static String setCommercials(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		
		return null;
	}
}
