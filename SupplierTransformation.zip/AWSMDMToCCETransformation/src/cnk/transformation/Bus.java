package cnk.transformation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Bus implements Constants {

	public static String setCommercials(JSONObject mainJson, JSONArray baseArr, JSONArray calcArr, JSONObject mdmDefn, String supplier, JSONArray supplierMarkets, String productCategory, String productCategorySubType, String productName) throws Exception{
		if(baseArr.length()>0){
			JSONObject standardCommercial = CommonFunctions.stdComm;
			setBusDetails(standardCommercial,baseArr,calcArr);

			if(standardCommercial.has(PROP_ADVDEFN_ID)){
				String advDefnID = standardCommercial.getString(PROP_ADVDEFN_ID);
				for(int i=0;i<mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).length();i++){
					JSONObject advanceDefinationData = mdmDefn.getJSONArray(PROP_ADVDEFN_DATA).getJSONObject(i);
					if(advanceDefinationData.getString(PROP_ID).equals(advDefnID)){
						JSONObject advanceDefinitionTransportation = advanceDefinationData.getJSONObject(PROP_ADVDEFN_TRANSPORTATION);
						CommonFunctions.setTransportationAdvancedDefinition(advanceDefinitionTransportation,baseArr,calcArr,true,STANDARD);
					}
				}
			}
			JSONArray commercialHead = mainJson.getJSONObject(COMMDEFN_DT).getJSONArray(COMMHEAD);
			CommonFunctions.setAdvancedCommercials(mdmDefn,commercialHead,mainJson,baseArr,calcArr,standardCommercial,supplier,supplierMarkets,productCategory,productCategorySubType,productName,CommonFunctions.mdmRuleID,CommonFunctions.suppCommDataId);
			CommonFunctions.setCommercialId(mainJson, CommonFunctions.suppCommDataId);
		}
		//System.out.println("Bus Transactional: "+mainJson.toString());
		return mainJson.toString();
	}


	private static void setBusDetails(JSONObject standardCommercial, JSONArray baseArr, JSONArray calcArr) {
		if(standardCommercial.has(PROP_PRODUCT)){
			if(standardCommercial.getJSONObject(PROP_PRODUCT).has(PROP_TRANSPORTATION)){
				JSONObject transportation = standardCommercial.getJSONObject(PROP_PRODUCT).getJSONObject(PROP_TRANSPORTATION);
				if(transportation.has(PROP_PRODUCT)){
					if(transportation.getJSONObject(PROP_PRODUCT).has(PRODUCTNAME_BUS)){
						JSONObject bus = transportation.getJSONObject(PROP_PRODUCT).getJSONObject(PRODUCTNAME_BUS);
						if(bus.has(PROP_OPERATORS) && bus.getJSONArray(PROP_OPERATORS).length()>0){
							for(int i=0;i<calcArr.length();i++){
								JSONObject cal = calcArr.getJSONObject(i);
								cal.put(OPERATORNAME, bus.getJSONArray(PROP_OPERATORS));
							}
						}

						if(bus.has(PROP_ROUTES) && bus.getJSONArray(PROP_ROUTES).length()>0){
							JSONArray routes = bus.getJSONArray(PROP_ROUTES);
							setRouteDetails(baseArr,calcArr,routes,STANDARD);
						}
					}

					if(transportation.getJSONObject(PROP_PRODUCT).has(PROP_GENERICPRODUCT)){
						for(int i=0;i<baseArr.length();i++){
							JSONObject baseP = baseArr.getJSONObject(i);
							baseP.put(PROP_PRODUCTID, transportation.getJSONObject(PROP_PRODUCT).getJSONObject(PROP_GENERICPRODUCT).getJSONArray(PROP_PRODUCTID));
						}
					}
				}
			}
		}
	}


	private static void setRouteDetails(JSONArray baseArr, JSONArray calcArr, JSONArray routes, String commercialName) {
		int length = baseArr.length();
		for(int i=0;i<length;i++){
			for(int j=0;j<routes.length();j++){
				JSONObject base = new JSONObject(new JSONTokener(baseArr.getJSONObject(i).toString()));
				JSONObject calculation = new JSONObject(new JSONTokener(calcArr.getJSONObject(i).toString()));
				JSONObject route = routes.getJSONObject(j);
				if(route.has(PROP_OPERATORCOUNTRY) && !route.getString(PROP_OPERATORCOUNTRY).equalsIgnoreCase("All"))
					calculation.put(PROP_OPERATORCOUNTRY, route.getString(PROP_OPERATORCOUNTRY));
				if(route.has(PROP_FROMCITY) && !route.getString(PROP_FROMCITY).equalsIgnoreCase("All"))
					calculation.put(ROUTE_FROMCITY, route.getString(PROP_FROMCITY));
				if(route.has(PROP_TOCITY) && !route.getString(PROP_TOCITY).equalsIgnoreCase("All"))
					calculation.put(ROUTE_TOCITY, route.getString(PROP_TOCITY));
				CommonFunctions.setRuleID(baseArr, calcArr, base, calculation, commercialName+PROP_ROUTES+i+j);
			}
		}
		for(int i=0;i<length;i++){
			baseArr.remove(0);
			calcArr.remove(0);
		}
	}
}
