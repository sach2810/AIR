package cnk.kafkaConsumer;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.log4j.PropertyConfigurator;
import java.util.Properties;
import java.util.Enumeration;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.apache.log4j.Logger;
import cnk.transformation.Accomodation;
import cnk.transformation.Activities;
import cnk.transformation.Air;
import cnk.transformation.Bus;
import cnk.transformation.CarRentals;
import cnk.transformation.CommonFunctions;
import cnk.transformation.Constants;
import cnk.transformation.Cruise;
import cnk.transformation.Holidays;
import cnk.transformation.Insurance;
import cnk.transformation.Rail;
import cnk.transformation.Transfers;
import cnk.transformation.Visa;
import java.io.File;
import org.apache.commons.io.FileUtils;

public class ReceiveMDMRequest implements Constants{
	public static String method;
	private static String mUserID;
	private transient static String mPassword;
	private transient static String mHttpBasicAuth;
	public final static Logger LOGGER = Logger.getLogger(ReceiveMDMRequest.class);
	
	
	public static void main(String args[]) throws Exception {
		//PropertyConfigurator.configure("src/resources/log4j.properties");
		/*do{
			Properties loggingProperties = new Properties();
			addLoggingProperties(loggingProperties);*/

			String content = FileUtils.readFileToString(new File("D:\\AVAMAR BACKUP\\Milan Tank\\Desktop\\Test.json"), "utf-8");
			JSONObject mdmCommDefn = new JSONObject(content);
			method=mdmCommDefn.getString("method");
			readJSON(mdmCommDefn.getJSONObject("data"));
			
			/*PropertyConfigurator.configure(loggingProperties);
			KafkaConsumer<String, String> consumer = null;
			Properties properties = new Properties();
			addProperties(properties);
			String str = "";
			String topic = TOPIC_NAME;


			try{
				Enumeration<Object> enuKeys = properties.keys();
				while (enuKeys.hasMoreElements()) {
					String key = (String) enuKeys.nextElement();
					String value = properties.getProperty(key);
					properties.put(key, value);
				}

				consumer = new KafkaConsumer<String, String>(properties);
				consumer.subscribe(Arrays.asList(topic));
				System.out.println("Subscribed to topic " + topic);

				while (true) {
					ConsumerRecords<String, String> records = consumer.poll(100);
					for (ConsumerRecord<String, String> record : records) {
						System.out.printf("offset = %d, message = %s\n", record.offset(), record.value());
						str = record.value();
						LOGGER.info("offset = "+record.offset()+" , message = "+str);
						JSONObject mdmData = new JSONObject(str);
						method = mdmData.getString("method");
						try{
							readJSON(mdmData.getJSONObject("data"));
							consumer.commitSync();
						}
						catch(Exception ex){
							LOGGER.error(ex);
							//insert error messages in a different queue : kafkaProducer (Retry mechanism)
							ex.printStackTrace();
							consumer.commitSync();
							continue;
						}
					}
				}
			}catch(Exception e){
				LOGGER.error(e);
				e.printStackTrace();
				consumer.commitSync();
			}
		}while(true);*/
	}
	

	public static void readJSON(JSONObject mdmDefn) throws Exception {
		if(mdmDefn.has(PROP_SUPP_COMM_DATA) && mdmDefn.getJSONObject(PROP_SUPP_COMM_DATA).has(PROP_COMM_DEFN)){
			String transform = null;
			String supplier= null,productCategorySubType=null;
			JSONArray supplierMarkets = new JSONArray();
			JSONObject commercialDefinition = mdmDefn.getJSONObject(PROP_SUPP_COMM_DATA).getJSONObject(PROP_COMM_DEFN);
			String productName=CommonFunctions.getProductName(commercialDefinition);
			if(!commercialDefinition.getString(PROP_SUPPLIERID).equalsIgnoreCase("All"))
				supplier = commercialDefinition.getString(PROP_SUPPLIERID);
			if(!commercialDefinition.getJSONArray(PROP_SUPPLIER_MARKETS).getString(0).equalsIgnoreCase("All"))
				supplierMarkets = commercialDefinition.getJSONArray(PROP_SUPPLIER_MARKETS);
			String productCategory = commercialDefinition.getString(PROP_PRODUCTCATEGORY);
			if(commercialDefinition.has(PROP_PRODUCTCATEGORYSUBTYPE))
				productCategorySubType = commercialDefinition.getString(PROP_PRODUCTCATEGORYSUBTYPE);
			
			JSONObject mainJson = new JSONObject();
			JSONArray baseArr = new JSONArray();
			JSONArray calcArr = new JSONArray();
			CommonFunctions.setInitialRquirement(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
			
			switch(productName){
			case PRODUCTNAME_ACCOMODATION:{
				transform=Accomodation.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_AIR:{
				transform=Air.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_ACTIVITIES:{
				transform=Activities.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_HOLIDAYS:{
				transform=Holidays.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_BUS:{
				transform=Bus.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_CARRENTALS:{
				transform=CarRentals.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_CRUISE:{
				transform=Cruise.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_RAIL:{
				transform=Rail.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_TRANSFERS:{
				transform=Transfers.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_INSURANCE:{
				transform=Insurance.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			case PRODUCTNAME_VISA:{
				transform=Visa.setCommercials(mainJson,baseArr,calcArr,mdmDefn,supplier,supplierMarkets,productCategory,productCategorySubType,productName);
				break;
			}
			default:System.out.println("default of readJSON due to productName: "+productName);
			}
			//LOGGER.info(productName.toUpperCase()+" Transactional: "+transform);
			System.out.println(productName.toUpperCase()+" Transactional: "+transform);
			if(transform!=null)
				invokeRuleConfigurator(transform,productName,method);
		}else{
			String productName = CommonFunctions.getProductName(mdmDefn.getJSONObject(PROP_COMM_DEFN));
			String transform = CommonFunctions.setAmmendRequest(mdmDefn).toString();
			LOGGER.info(productName.toUpperCase()+" transactional (bookingId): "+transform);
			invokeRuleConfigurator(transform,productName,method);
		}
	}


	public static void invokeRuleConfigurator(String request, String productName, String kafkaMethod) throws Exception{
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = MUSER_ID;
		mPassword = MPASSWORD;
		mHttpBasicAuth = HTTP_AUTH_BASIC_PREFIX.concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(kafkaMethod){
		case URL_MTD_POST:{
			URL = PROP_URL+productName+URL_TRANS_CREATE;
			break;
		}
		case URL_MTD_PUT:{
			URL = PROP_URL+productName+URL_TRANS_UPDATE;
			break;
		}
		case URL_MTD_DELETE:{
			URL = PROP_URL+productName+URL_TRANS_DELETE;
			break;
		}
		default:System.out.println("default of hitJSONservice");
		}
		if(URL!=null){
			URL productURL = new URL(URL);
			String outputString = null;
			JSONObject outputS = consumeJSONService(PORT,productURL,mHttpHeaders,request);
			if(outputS!=null)
				outputString=outputS.toString();
			else outputString="null";
			LOGGER.info(outputString);
			System.out.println(outputString);
		}else System.out.println("Method name is other than POST,PUT or DELETE");
	}
	
	
	public static void invokeSettlementRuleConfigurator(String request, String productName, String kafkaMethod) throws Exception{
		String URL = null;
		Map<String, String> mHttpHeaders = new HashMap<String, String>();
		mUserID = MUSER_ID;      
		mPassword = MPASSWORD;
		mHttpBasicAuth = HTTP_AUTH_BASIC_PREFIX.concat(Base64.getEncoder().encodeToString(mUserID.concat(":").concat(mPassword).getBytes()));
		mHttpHeaders.put("Content-Type", "application/json");
		mHttpHeaders.put("Authorization", mHttpBasicAuth);
		switch(kafkaMethod){
		case URL_MTD_POST:{
			URL = PROP_URL+productName+URL_SETT_CREATE;
			break;
		}
		case URL_MTD_PUT:{
			URL = PROP_URL+productName+URL_SETT_UPDATE;
			break;
		}
		case URL_MTD_DELETE:{
			URL = PROP_URL+productName+URL_SETT_DELETE;
			break;
		}
		default:System.out.println("default of hitJSONservice");
		}
		if(URL!=null){
			URL productURL = new URL(URL);
			String outputString = null;
			JSONObject outputS = consumeJSONService(PORT,productURL,mHttpHeaders,request);
			if(outputS!=null)
				outputString=outputS.toString();
			else outputString="null";
			LOGGER.info(outputString);
			System.out.println(outputString);
		}else System.out.println("Method name is other than POST,PUT or DELETE");
	}
	

	private static JSONObject consumeJSONService(String tgtSysId, URL tgtSysURL, Map<String, String> httpHdrs, String reqJsonStr) throws Exception {
		HttpURLConnection svcConn = null;
		try{
			svcConn = (HttpURLConnection) tgtSysURL.openConnection();
			/*if (logger.isTraceEnabled()) {
				logger.trace(String.format("%s JSON Request = %s", tgtSysId, reqJsonStr));
			}*/
			InputStream httpResStream = consumeService(tgtSysId, svcConn, httpHdrs, reqJsonStr.getBytes());
			if(httpResStream != null)
				return new JSONObject(new JSONTokener(httpResStream));
		}
		catch(Exception x){
			//logger.warn(String.format("%s JSON Service <%s> Consume Error", tgtSysId, tgtSysURL), x);
		}
		finally{
			if(svcConn != null)
				svcConn.disconnect();
		}
		return null;
	}


	private static InputStream consumeService(String tgtSysId, HttpURLConnection svcConn, Map<String, String> httpHdrs, byte[] payload) throws Exception {
		svcConn.setDoOutput(true);
		svcConn.setRequestMethod("POST");

		Set<Entry<String,String>> httpHeaders = httpHdrs.entrySet();
		if (httpHeaders != null && httpHeaders.size() > 0) {
			Iterator<Entry<String,String>> httpHeadersIter = httpHeaders.iterator();
			while (httpHeadersIter.hasNext()) {
				Entry<String,String> httpHeader = httpHeadersIter.next();
				svcConn.setRequestProperty(httpHeader.getKey(), httpHeader.getValue());
			}
		}
		//logger.trace(String.format("Sending request to %s",tgtSysId));
		OutputStream httpOut = svcConn.getOutputStream();
		httpOut.write(payload);
		httpOut.flush();
		httpOut.close();

		int resCode = svcConn.getResponseCode();
		//logger.debug(String.format("Receiving response from %s with HTTP response status: %s", tgtSysId, resCode));
		if (resCode == HttpURLConnection.HTTP_OK) {
			return svcConn.getInputStream();
		}
		return null;
	}
	

	private static void addProperties(Properties properties) {
		properties.put(BOOTSTRAP_SERVERS, BOOTSTRAP_SERVERS_VALUE);
		properties.put(GROUP_ID, GROUP_ID_VALUE);
		properties.put(ENABLE_AUTO_COMMIT, ENABLE_AUTO_COMMIT_VALUE);
		properties.put(HEARTBEAT_INTERVAL, HEARTBEAT_INTERVAL_VALUE);
		properties.put(AUTO_COMMIT, AUTO_COMMIT_VALUE);
		properties.put(AUTO_OFFSET_RESET, AUTO_OFFSET_RESET_VALUE);
		properties.put(SESSION_TIMEOUT, SESSION_TIMEOUT_VALUE);
		properties.put(REQUEST_TIMEOUT, REQUEST_TIMEOUT_VALUE);
		properties.put(KEY_DESERIALIZER, KEY_DESERIALIZER_VALUE);
		properties.put(VALUE_DESRIALIZER, VALUE_DESRIALIZER_VALUE);
	}


	private static void addLoggingProperties(Properties loggingProperties) {
		loggingProperties.put("log4j.rootLogger", "DEBUG, FILE");
		loggingProperties.put("log4j.appender.FILE", "org.apache.log4j.RollingFileAppender");
		//loggingProperties.put("log4j.appender.FILE.File", "/home/tlgxadmin/TLGX/BRMS_logs/SupplierTransformation.log");
		loggingProperties.put("log4j.appender.FILE.File", "/home/server-admin/BRE_Java/BRMS_logs/SupplierTransformation.log");
		loggingProperties.put("log4j.appender.FILE.MaxFileSize", "25MB");
		loggingProperties.put("log4j.appender.FILE.MaxBackupIndex", "50");
		//loggingProperties.put("log4j.appender.FILE.RollingPolicy.FileNamePattern", "/home/tlgxadmin/TLGX/BRMS_logs/SupplierTransformation-%d{yyyyMMddHH}-%i.log");
		loggingProperties.put("log4j.appender.FILE.RollingPolicy.FileNamePattern", "/home/server-admin/BRE_Java/BRMS_logs/SupplierTransformation-%d{yyyyMMddHH}-%i.log");
		loggingProperties.put("log4j.appender.FILE.Append", "true");
		loggingProperties.put("log4j.appender.FILE.threshold", "DEBUG");
		loggingProperties.put("log4j.appender.FILE.layout", "org.apache.log4j.PatternLayout");
		loggingProperties.put("log4j.appender.FILE.layout.ConversionPattern", "%d{yyyy-MM-dd HH:mm:ss} %-5p:%L - %m%n");
	}
}
