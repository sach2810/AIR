package cnk.cce.rest;

import java.io.File;
import java.io.InputStream;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONObject;
import org.json.JSONTokener;
import cnk.cce.configuration.Constants;
import cnk.cce.configuration.Rule;
import cnk.cce.configuration.products.RuleGenerator;
import cnk.cce.maven.MavenInvoker;

@Path("/cce")
public class RuleConfigurator implements Constants{

	@Path("{product}/{entity}/{type}/create")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response createRule(InputStream ip,@PathParam(PRODUCT) String productName, @PathParam(ENTITY) String entityType, @PathParam(TYPE) String commercialType){
		JSONTokener jt = new JSONTokener(ip);
		JSONObject data = new JSONObject(jt);
		Rule product=new RuleGenerator();
		String location = null;boolean maven = false;
		try {
			location = MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName+"_"+entityType+"_"+commercialType);
			product.createRule(data,location,productName,commercialType,entityType);
			maven=true;
			MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
			return Response.status(200).entity("{ \"Status\": \"Success\" }").build();
		}
		catch(Exception e){
			if(maven){
				try{
					e.printStackTrace();
					product.deleteRule(data,location,productName,commercialType,entityType);
					product.createRule(data,location,productName,commercialType,entityType);
					MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
					return Response.status(200).entity("{ \"Status\": \"Success\" }").build();
				}catch (Exception e1) {
					try {
						product.deleteRule(data,location,productName,commercialType,entityType);
						MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
						return Response.status(200).entity("{ \"Status\": \"Build Failure after Deleting Duplicate Rule\" }").build();
					} catch (Exception e2) {
						e2.printStackTrace();
					}
					e1.printStackTrace();
				}
			}else{
				e.printStackTrace();
			}
		}
		return Response.status(500).entity("{ \"Status\": \"Failure\" }").build();
	}
	
	@Path("{product}/{entity}/{type}/update")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateRule(InputStream ip,@PathParam(PRODUCT) String productName, @PathParam(ENTITY) String entityType, @PathParam(TYPE) String commercialType){
		JSONTokener jt = new JSONTokener(ip);
		JSONObject data = new JSONObject(jt);
		Rule product=new RuleGenerator();
		String location = null;boolean maven = false;
		try {
			location = MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName+"_"+entityType+"_"+commercialType);
			product.updateRule(data,location,productName,commercialType,entityType);
			maven=true;
			MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
			return Response.status(200).entity("{ \"Status\": \"Success\" }").build();
		}
		catch (Exception e) {
			if(maven){
				try{
					e.printStackTrace();
					product.deleteRule(data,location,productName,commercialType,entityType);
					product.createRule(data,location,productName,commercialType,entityType);
					MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
					return Response.status(200).entity("{ \"Status\": \"Success\" }").build();
				}catch (Exception e1) {
					try {
						product.deleteRule(data,location,productName,commercialType,entityType);
						MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
						return Response.status(200).entity("{ \"Status\": \"Build Failure after Deleting Duplicate Rule\" }").build();
					} catch (Exception e2) {
						e2.printStackTrace();
					}
					e1.printStackTrace();
				}
			}else{
				e.printStackTrace();
			}
		}
		return Response.status(500).entity("{ \"Status\": \"Failure\" }").build();
	}
	
	@Path("{product}/{entity}/{type}/delete")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public String deleteRule(InputStream ip,@PathParam(PRODUCT) String productName, @PathParam(ENTITY) String entityType, @PathParam(TYPE) String commercialType){
		JSONTokener jt = new JSONTokener(ip);
		JSONObject data = new JSONObject(jt);
		Rule product=new RuleGenerator();
		String location = null;boolean maven = false;
		try {
			location = MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName+"_"+entityType+"_"+commercialType);
			product.deleteRule(data,location,productName,commercialType,entityType);
			maven=true;
			MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
			return "{ \"Status\": \"Success\" }";
		}
		catch (Exception e) {
			if(maven){
				try{
					e.printStackTrace();
					product.deleteRule(data,location,productName,commercialType,entityType);
					MavenInvoker.getInstance().invoke(new File(MavenInvoker.getInstance().getProperties().getProperty(BASE_DIR)+"/"+MavenInvoker.getInstance().getProperties().getProperty(productName),"pom.xml"));
					return "{ \"Status\": \"Success\" }";
				}catch (Exception e1) {
					e1.printStackTrace();
				}
			}else{
				e.printStackTrace();
			}
		}
		return "{ \"Status\": \"Failure\" }";
	}
}
