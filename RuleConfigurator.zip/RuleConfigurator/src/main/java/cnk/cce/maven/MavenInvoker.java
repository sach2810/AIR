package cnk.cce.maven;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.apache.maven.shared.invoker.DefaultInvocationRequest;
import org.apache.maven.shared.invoker.DefaultInvoker;
import org.apache.maven.shared.invoker.InvocationRequest;
import org.apache.maven.shared.invoker.InvocationResult;
import org.apache.maven.shared.invoker.Invoker;
import org.apache.maven.shared.invoker.MavenInvocationException;

import cnk.cce.configuration.Constants;

public class MavenInvoker implements Constants{

	private static final List<String> PUBLISH_GOALS = Arrays.asList("clean", "install");
	private final Invoker invoker;
	private final Properties properties;
	private static MavenInvoker instance;
	private final Properties carProperties;
	private final Properties airProperties;
	private final Properties activitiesProperties;
	private final Properties accomodationProperties;
	private final Properties busProperties;
	private final Properties railProperties;
	private final Properties cruiseProperties;
	private final Properties insuranceProperties;
	private final Properties holidaysProperties;
	private final Properties visaProperties;
	private final Properties transfersProperties;
	
	private MavenInvoker() throws IOException {
		this.properties = new Properties();
		this.carProperties=new Properties();
		this.airProperties=new Properties();
		this.activitiesProperties=new Properties();
		this.accomodationProperties=new Properties();
		this.busProperties=new Properties();
		this.railProperties=new Properties();
		this.cruiseProperties=new Properties();
		this.insuranceProperties=new Properties();
		this.holidaysProperties=new Properties();
		this.visaProperties=new Properties();
		this.transfersProperties=new Properties();
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		try(InputStream in = classLoader.getResourceAsStream("configuration.properties")){
			properties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("carrentals.properties")){
			carProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("air.properties")){
			airProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("activities.properties")){
			activitiesProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("accomodation.properties")){
			accomodationProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("bus.properties")){
			busProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("rail.properties")){
			railProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("cruise.properties")){
			cruiseProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("insurance.properties")){
			insuranceProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("holidays.properties")){
			holidaysProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("visa.properties")){
			visaProperties.load(in);
		}
		try(InputStream in = classLoader.getResourceAsStream("transfers.properties")){
			transfersProperties.load(in);
		}
		Invoker newInvoker = new DefaultInvoker();
		newInvoker.setLocalRepositoryDirectory(new File(properties.getProperty("LOCAL_M2")));
		/* ignore when using env variable m2_home */
		newInvoker.setMavenHome(new File(properties.getProperty("M2_HOME")));
		this.invoker = newInvoker;
	}
	

	public static MavenInvoker getInstance() throws IOException {
		if (instance == null) {
			synchronized (MavenInvoker.class) {
				if (instance == null) {
					instance = new MavenInvoker();
				}
			}
		}
		return instance;
	}

	
	public void invoke(File projectDir) throws MavenInvocationException {
		InvocationRequest request = new DefaultInvocationRequest();
		request.setPomFile(projectDir);
		request.setGoals(PUBLISH_GOALS);
		InvocationResult result;
		result = invoker.execute(request);
		if (result.getExitCode() != 0) {
			if (result.getExecutionException() != null) {
				throw new MavenInvocationException("Failed to publish site.", result.getExecutionException());
			} else {
				throw new MavenInvocationException("Failed to publish site. Exit code: " + result.getExitCode());
			}
		}
	}
	

	public Properties getProperties() {
		return properties;
	}
	
	
	public Properties getProductProperties(String productName) {
		switch(productName){
		case PRODUCTNAME_AIR: return airProperties;
		case PRODUCTNAME_ACTIVITIES: return activitiesProperties;
		case PRODUCTNAME_ACCOMODATION: return accomodationProperties;
		case PRODUCTNAME_BUS: return busProperties;
		case PRODUCTNAME_RAIL: return railProperties;
		case PRODUCTNAME_CRUISE: return cruiseProperties;
		case PRODUCTNAME_INSURANCE: return insuranceProperties;
		case PRODUCTNAME_CARRENTALS: return carProperties;
		case PRODUCTNAME_HOLIDAYS: return holidaysProperties;
		case PRODUCTNAME_VISA: return visaProperties;
		case PRODUCTNAME_TRANSFERS: return transfersProperties;
		}
		return null;
	}
}