package cnk.cce.configuration;

import java.util.HashMap;
import java.util.Map;

public class MappingConfiguration {
	
	public static Map<String,String> _id = new HashMap<String,String>();
	
	public static Map<String,Integer> carLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [CAR_SUPPLIER]
	public static Map<String,Integer> carClientLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [CAR_CLIENT]
	public static Map<String,Integer> carLTBCumSeq = new HashMap<String,Integer>();													//this map will keep record of supplier:cumulativeSequence [CAR_SUPPLIER]
	public static Map<String,Integer> carClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [CAR_CLIENT]
	public static Map<String,String> carSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [CAR_SUPPLIER]
	public static Map<String,String> carClientRefRuleID = new HashMap<String,String>();												//this map will keep record of supplier_market:referenceCounterRuleRowNumber [CAR_CLIENT]
	
	public static Map<String,Integer> airLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [AIR_SUPPLIER]
	public static Map<String,Integer> airClientLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [AIR_CLIENT]
	public static Map<String,Integer> airLTBCumSeq = new HashMap<String,Integer>();													//this map will keep record of supplier:cumulativeSequence [AIR_SUPPLIER]
	public static Map<String,Integer> airClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [AIR_CLIENT]
	public static Map<String,String> airSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [AIR_SUPPLIER]
	public static Map<String,String> airClientRefRuleID = new HashMap<String,String>();												//this map will keep record of supplier_market:referenceCounterRuleRowNumber [AIR_CLIENT]
	
	public static Map<String,Integer> activitiesLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [ACTIVITIES_SUPPLIER]
	public static Map<String,Integer> activitiesClientLTB = new HashMap<String,Integer>();											//this map will keep record of supplier:lowerLimit [ACTIVITIES_CLIENT]
	public static Map<String,Integer> activitiesLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [ACTIVITIES_SUPPLIER]
	public static Map<String,Integer> activitiesClientLTBCumSeq = new HashMap<String,Integer>();									//this map will keep record of supplier:cumulativeSequence [ACTIVITIES_CLIENT]
	public static Map<String,String> activitiesSupplierRefRuleID = new HashMap<String,String>();									//this map will keep record of supplier_market:referenceCounterRuleRowNumber [ACTIVITIES_SUPPLIER]
	public static Map<String,String> activitiesClientRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [ACTIVITIES_CLIENT]
	
	public static Map<String,Integer> accomodationLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [ACCOMODATION_SUPPLIER]
	public static Map<String,Integer> accomodationClientLTB = new HashMap<String,Integer>();										//this map will keep record of supplier:lowerLimit [ACCOMODATION_CLIENT]
	public static Map<String,Integer> accomodationLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [ACCOMODATION_SUPPLIER]
	public static Map<String,Integer> accomodationClientLTBCumSeq = new HashMap<String,Integer>();									//this map will keep record of supplier:cumulativeSequence [ACCOMODATION_CLIENT]
	public static Map<String,String> accomodationSupplierRefRuleID = new HashMap<String,String>();									//this map will keep record of supplier_market:referenceCounterRuleRowNumber [ACCOMODATION_SUPPLIER]
	public static Map<String,String> accomodationClientRefRuleID = new HashMap<String,String>();									//this map will keep record of supplier_market:referenceCounterRuleRowNumber [ACCOMODATION_CLIENT]
	
	public static Map<String,Integer> busLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [BUS_SUPPLIER]
	public static Map<String,Integer> busClientLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [BUS_CLIENT]
	public static Map<String,Integer> busLTBCumSeq = new HashMap<String,Integer>();													//this map will keep record of supplier:cumulativeSequence [BUS_SUPPLIER]
	public static Map<String,Integer> busClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [BUS_CLIENT]
	public static Map<String,String> busSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [BUS_SUPPLIER]
	public static Map<String,String> busClientRefRuleID = new HashMap<String,String>();												//this map will keep record of supplier_market:referenceCounterRuleRowNumber [BUS_CLIENT]
	
	public static Map<String,Integer> railLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [RAIL_SUPPLIER]
	public static Map<String,Integer> railClientLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [RAIL_CLIENT]
	public static Map<String,Integer> railLTBCumSeq = new HashMap<String,Integer>();												//this map will keep record of supplier:cumulativeSequence [RAIL_SUPPLIER]
	public static Map<String,Integer> railClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [RAIL_CLIENT]
	public static Map<String,String> railSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [RAIL_SUPPLIER]
	public static Map<String,String> railClientRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [RAIL_CLIENT]
	
	public static Map<String,Integer> cruiseLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [CRUISE_SUPPLIER]
	public static Map<String,Integer> cruiseClientLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [CRUISE_CLIENT]
	public static Map<String,Integer> cruiseLTBCumSeq = new HashMap<String,Integer>();												//this map will keep record of supplier:cumulativeSequence [CRUISE_SUPPLIER]
	public static Map<String,Integer> cruiseClientLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [CRUISE_CLIENT]
	public static Map<String,String> cruiseSupplierRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [CRUISE_SUPPLIER]
	public static Map<String,String> cruiseClientRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [CRUISE_CLIENT]
	
	public static Map<String,Integer> insuranceLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [INSURANCE_SUPPLIER]
	public static Map<String,Integer> insuranceClientLTB = new HashMap<String,Integer>();											//this map will keep record of supplier:lowerLimit [INSURANCE_CLIENT]
	public static Map<String,Integer> insuranceLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [INSURANCE_SUPPLIER]
	public static Map<String,Integer> insuranceClientLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [INSURANCE_CLIENT]
	public static Map<String,String> insuranceSupplierRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [INSURANCE_SUPPLIER]
	public static Map<String,String> insuranceClientRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [INSURANCE_CLIENT]
	
	public static Map<String,Integer> holidaysLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [HOLIDAYS_SUPPLIER]
	public static Map<String,Integer> holidaysClientLTB = new HashMap<String,Integer>();											//this map will keep record of supplier:lowerLimit [HOLIDAYS_CLIENT]
	public static Map<String,Integer> holidaysLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [HOLIDAYS_SUPPLIER]
	public static Map<String,Integer> holidaysClientLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [HOLIDAYS_CLIENT]
	public static Map<String,String> holidaysSupplierRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [HOLIDAYS_SUPPLIER]
	public static Map<String,String> holidaysClientRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [HOLIDAYS_CLIENT]
	
	public static Map<String,Integer> visaLTB = new HashMap<String,Integer>();														//this map will keep record of supplier:lowerLimit [VISA_SUPPLIER]
	public static Map<String,Integer> visaClientLTB = new HashMap<String,Integer>();												//this map will keep record of supplier:lowerLimit [VISA_CLIENT]
	public static Map<String,Integer> visaLTBCumSeq = new HashMap<String,Integer>();												//this map will keep record of supplier:cumulativeSequence [VISA_SUPPLIER]
	public static Map<String,Integer> visaClientLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [VISA_CLIENT]
	public static Map<String,String> visaSupplierRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [VISA_SUPPLIER]
	public static Map<String,String> visaClientRefRuleID = new HashMap<String,String>();											//this map will keep record of supplier_market:referenceCounterRuleRowNumber [VISA_CLIENT]
	
	public static Map<String,Integer> transfersLTB = new HashMap<String,Integer>();													//this map will keep record of supplier:lowerLimit [TRANSFERS_SUPPLIER]
	public static Map<String,Integer> transfersClientLTB = new HashMap<String,Integer>();											//this map will keep record of supplier:lowerLimit [TRANSFERS_CLIENT]
	public static Map<String,Integer> transfersLTBCumSeq = new HashMap<String,Integer>();											//this map will keep record of supplier:cumulativeSequence [TRANSFERS_SUPPLIER]
	public static Map<String,Integer> transfersClientLTBCumSeq = new HashMap<String,Integer>();										//this map will keep record of supplier:cumulativeSequence [TRANSFERS_CLIENT]
	public static Map<String,String> transfersSupplierRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [TRANSFERS_SUPPLIER]
	public static Map<String,String> transfersClientRefRuleID = new HashMap<String,String>();										//this map will keep record of supplier_market:referenceCounterRuleRowNumber [TRANSFERS_CLIENT]
}
