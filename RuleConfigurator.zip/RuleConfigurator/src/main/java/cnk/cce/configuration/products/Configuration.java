package cnk.cce.configuration.products;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import cnk.cce.configuration.Constants;
import cnk.cce.configuration.MappingConfiguration;
import cnk.cce.maven.MavenInvoker;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

public class Configuration implements Constants{
	public static int carchangeRefCount=0,carrefreshCounterRule=0,carclientRefreshCounterRule=0,carclientChangeRefCount=0,airchangeRefCount=0,airrefreshCounterRule=0,airclientRefreshCounterRule=0,airclientChangeRefCount=0,error=0,visaclientRefreshCounterRule=0,visaclientChangeRefCount=0,transfersclientRefreshCounterRule=0;
	public static int activitieschangeRefCount=0,activitiesrefreshCounterRule=0,activitiesclientRefreshCounterRule=0,activitiesclientChangeRefCount=0,accomodationchangeRefCount=0,accomodationrefreshCounterRule=0,accomodationclientRefreshCounterRule=0,accomodationclientChangeRefCount=0,cruiseclientChangeRefCount=0,transfersclientChangeRefCount=0;
	public static int buschangeRefCount=0,busrefreshCounterRule=0,busclientRefreshCounterRule=0,busclientChangeRefCount=0,railchangeRefCount=0,railrefreshCounterRule=0,railclientRefreshCounterRule=0,railclientChangeRefCount=0,cruisechangeRefCount=0,cruiserefreshCounterRule=0,cruiseclientRefreshCounterRule=0,transferschangeRefCount=0;
	public static int insurancechangeRefCount=0,insurancerefreshCounterRule=0,insuranceclientRefreshCounterRule=0,insuranceclientChangeRefCount=0,holidayschangeRefCount=0,holidaysrefreshCounterRule=0,holidaysclientRefreshCounterRule=0,holidaysclientChangeRefCount=0,visachangeRefCount=0,visarefreshCounterRule=0,transfersrefreshCounterRule=0;


	private static void setValue(int columnIndex, Row row, String value) {
		Cell cell=null;
		try{
			cell= row.createCell(columnIndex);
		}catch(Exception e){
			row.removeCell(row.getCell(columnIndex));
			cell= row.createCell(columnIndex);
		}
		cell.setCellValue(value);
	}


	public static void insertIntoSheet(String name, String value, String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException{
		//System.out.println(entityType+"_"+commercialType+"_"+DTname+name);
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+name));
		Cell cell=null;
		try{
			cell= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell= row1.createCell(columnIndex);
		}
		try{
			double value1=Double.parseDouble(value);
			cell.setCellValue(value1);
		}catch(Exception e){
			cell.setCellValue('"'+value+'"');
		}
	}
	
	
	public static void getSupplierTransactionalCommercialHead(JSONObject object, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, JSONException, IOException {
		String commHead=""; int nettOff=0;
		if(!object.has(NETTOFF_COMMHEAD)){
			if(!object.has(MARKUP_CLIENTTYPE)){
				if(!object.has(MARKDOWN_CLIENTAPPLICABLE))
					commHead= '"'+object.getString(COMMHEADNAME)+'"'+",null,"+'"'+object.getString(COMMTYPE)+'"'+","+object.getBoolean(SETTLEMENTTRANSACTIONWISE)+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(COMMISSIONABLE)+","+object.getBoolean(MARKDOWNAPPLICABLE)+",null,"+object.getDouble(MIN_MARKUP_PERCENTAGE)+","+object.getDouble(MAX_MARKUP_PERCENTAGE)+",null,null";
				else
					commHead= '"'+object.getString(COMMHEADNAME)+'"'+",null,"+'"'+object.getString(COMMTYPE)+'"'+","+object.getBoolean(SETTLEMENTTRANSACTIONWISE)+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(COMMISSIONABLE)+","+object.getBoolean(MARKDOWNAPPLICABLE)+","+'"'+object.getString(MARKDOWN_CLIENTAPPLICABLE)+'"'+","+object.getDouble(MIN_MARKUP_PERCENTAGE)+","+object.getDouble(MAX_MARKUP_PERCENTAGE)+",null,null";
			}else{
				if(!object.has(MARKDOWN_CLIENTAPPLICABLE))
					commHead=	'"'+object.getString(COMMHEADNAME)+'"'+",null,"+'"'+object.getString(COMMTYPE)+'"'+","+object.getBoolean(SETTLEMENTTRANSACTIONWISE)+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(COMMISSIONABLE)+","+object.getBoolean(MARKDOWNAPPLICABLE)+",null,"+object.getDouble(MIN_MARKUP_PERCENTAGE)+","+object.getDouble(MAX_MARKUP_PERCENTAGE)+","+'"'+object.getString(MARKUP_CLIENTTYPE)+'"'+",null";
				else
					commHead= '"'+object.getString(COMMHEADNAME)+'"'+",null,"+'"'+object.getString(COMMTYPE)+'"'+","+object.getBoolean(SETTLEMENTTRANSACTIONWISE)+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(COMMISSIONABLE)+","+object.getBoolean(MARKDOWNAPPLICABLE)+","+'"'+object.getString(MARKDOWN_CLIENTAPPLICABLE)+'"'+","+object.getDouble(MIN_MARKUP_PERCENTAGE)+","+object.getDouble(MAX_MARKUP_PERCENTAGE)+","+'"'+object.getString(MARKUP_CLIENTTYPE)+'"'+",null";
			}
		}
		else{
			nettOff=1;
			if(!object.has(MARKUP_CLIENTTYPE)){
				if(!object.has(MARKDOWN_CLIENTAPPLICABLE))
					commHead= '"'+object.getString(COMMHEADNAME)+'"'+","+'"'+object.getString(NETTOFF_COMMHEAD)+'"'+","+'"'+object.getString(COMMTYPE)+'"'+","+object.getBoolean(SETTLEMENTTRANSACTIONWISE)+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(COMMISSIONABLE)+","+object.getBoolean(MARKDOWNAPPLICABLE)+",null,"+object.getDouble(MIN_MARKUP_PERCENTAGE)+","+object.getDouble(MAX_MARKUP_PERCENTAGE)+",null,null";
				else
					commHead= '"'+object.getString(COMMHEADNAME)+'"'+","+'"'+object.getString(NETTOFF_COMMHEAD)+'"'+","+'"'+object.getString(COMMTYPE)+'"'+","+object.getBoolean(SETTLEMENTTRANSACTIONWISE)+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(COMMISSIONABLE)+","+object.getBoolean(MARKDOWNAPPLICABLE)+","+'"'+object.getString(MARKDOWN_CLIENTAPPLICABLE)+'"'+","+object.getDouble(MIN_MARKUP_PERCENTAGE)+","+object.getDouble(MAX_MARKUP_PERCENTAGE)+",null,null";
			}else{
				if(!object.has(MARKDOWN_CLIENTAPPLICABLE))
					commHead= '"'+object.getString(COMMHEADNAME)+'"'+","+'"'+object.getString(NETTOFF_COMMHEAD)+'"'+","+'"'+object.getString(COMMTYPE)+'"'+","+object.getBoolean(SETTLEMENTTRANSACTIONWISE)+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(COMMISSIONABLE)+","+object.getBoolean(MARKDOWNAPPLICABLE)+",null,"+object.getDouble(MIN_MARKUP_PERCENTAGE)+","+object.getDouble(MAX_MARKUP_PERCENTAGE)+","+'"'+object.getString(MARKUP_CLIENTTYPE)+'"'+",null";
				else
					commHead= '"'+object.getString(COMMHEADNAME)+'"'+","+'"'+object.getString(NETTOFF_COMMHEAD)+'"'+","+'"'+object.getString(COMMTYPE)+'"'+","+object.getBoolean(SETTLEMENTTRANSACTIONWISE)+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(COMMISSIONABLE)+","+object.getBoolean(MARKDOWNAPPLICABLE)+","+'"'+object.getString(MARKDOWN_CLIENTAPPLICABLE)+'"'+","+object.getDouble(MIN_MARKUP_PERCENTAGE)+","+object.getDouble(MAX_MARKUP_PERCENTAGE)+","+'"'+object.getString(MARKUP_CLIENTTYPE)+'"'+",null";
			}
		}
		try{
			int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+object.getString(COMMHEADNAME)));
			setValue(columnIndex,row1,commHead);
			if(nettOff==1){
				insertIntoSheet("_"+object.getString(COMMHEADNAME)+"_"+NETTOFF, object.getString(NETTOFF_COMMHEAD), productName, entityType, commercialType, DTname, row1);
			}
		}catch(Exception e){
			System.out.println("commercialHeadName "+COMMHEADNAME+" not specified for the product "+productName);
		}
	}


	public static void getSupplierSettlementCommercialHead(JSONObject object, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, JSONException, IOException {
		String commHead="";
		object.keySet().size();
		if(!object.has(REFUNDABLE))
			commHead='"'+object.getString(COMMTYPE)+'"'+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(ISAPPLICABLE);
		else if(!object.has(PLBAPPLICABLE))
			commHead='"'+object.getString(COMMTYPE)+'"'+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(ISAPPLICABLE)+","+object.getBoolean(REFUNDABLE)+","+object.getBoolean(RECURRING);
		else commHead='"'+object.getString(COMMTYPE)+'"'+","+'"'+object.getString(CONTRACTTYPE)+'"'+","+object.getBoolean(ISAPPLICABLE)+","+object.getBoolean(PLBAPPLICABLE);
		try{
			int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+object.getString(COMMHEADNAME)));
			setValue(columnIndex,row1,commHead);
		}catch(Exception e){
			System.out.println("commercialHeadName "+COMMHEADNAME+" not specified for the product "+productName);
		}
	}

	
	public static void setInclusionExclusion(String IncExc, JSONArray incJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType, String name) throws NumberFormatException, IOException {
		String value="";int multipleFlag=0;
		for (int i=0; i < incJsonArr.length(); i++){
			if(multipleFlag==0){
				JSONObject IndiJsonObject = (JSONObject)incJsonArr.get(i);
				if(IndiJsonObject.has(OPERATOR) || IndiJsonObject.has(TO)){										//if the object contains OPERATOR, indicates dates or travel destination 
					if(IndiJsonObject.has(VALUE)){
						value=getOperatorString(IndiJsonObject,i,value);
						if(IncExc.equals(INCLUSION))
							insertIntoSheet("_"+name,value,productName,entityType,commercialType,DTname,row1);
						else insertIntoSheet("_"+name+"_"+EXCLUSION,value,productName,entityType,commercialType,DTname,row1);
					}
					else{
						if(IndiJsonObject.has(OPERATOR)){
							if(IndiJsonObject.get(TO) instanceof String){											//its a string! The inputs are Date Values
								value=getOperatorString(IndiJsonObject,i,value);
								if(IncExc.equals(INCLUSION))
									insertIntoSheet("_"+name,value,productName,entityType,commercialType,DTname,row1);
								else  insertIntoSheet("_"+name+"_"+EXCLUSION,value,productName,entityType,commercialType,DTname,row1);
							}
						}else{
							insertRepeatingValues(IndiJsonObject.getJSONArray(TO),productName,entityType,commercialType,DTname,row1,IncExc);
							if(IndiJsonObject.has(FROM))
								insertRepeatingValues(IndiJsonObject.getJSONArray(FROM),productName,entityType,commercialType,DTname,row1,IncExc);
							if(IndiJsonObject.has(VIA))
								insertRepeatingValues(IndiJsonObject.getJSONArray(VIA),productName,entityType,commercialType,DTname,row1,IncExc);
						}
					}
				}
				else{																							//without TO, indicates other advanced defn values with inc/exc
					Iterator<String> keys =IndiJsonObject.keys();
					while(keys.hasNext()){
						String key=keys.next();
						if(!(IndiJsonObject.get(key) instanceof List)){
							if(incJsonArr.length()>1){
								multipleFlag=1;
								insertRepeatingValues(incJsonArr,productName,entityType,commercialType,DTname,row1,IncExc);
								break;
							}else{
								if(IncExc.equals(INCLUSION))
									insertIntoSheet("_"+key,IndiJsonObject.getString(key),productName,entityType,commercialType,DTname,row1);
								else insertIntoSheet("_"+key+"_"+EXCLUSION,IndiJsonObject.getString(key),productName,entityType,commercialType,DTname,row1);
							}
						}
						else{																					//Input LIST hai!
							if(IndiJsonObject.has(FROM) || IndiJsonObject.has(VIA)){
								if(IndiJsonObject.has(FROM))
									insertRepeatingValues(IndiJsonObject.getJSONArray(FROM),productName,entityType,commercialType,DTname,row1,IncExc);
								if(IndiJsonObject.has(VIA))
									insertRepeatingValues(IndiJsonObject.getJSONArray(VIA),productName,entityType,commercialType,DTname,row1,IncExc);
							}else insertArrayListValues(IncExc, key, (JSONArray) IndiJsonObject.get(key), productName, row1, DTname, commercialType, entityType);
						}
					}
				}
			}
		}multipleFlag=0;
	}

	
	private static void insertRepeatingValues(JSONArray incJsonArr, String productName, String entityType, String commercialType, String DTname, Row row1, String IncExc) throws NumberFormatException, JSONException, IOException {
		JSONObject details = new JSONObject();
		for(int i=0;i<incJsonArr.length();i++){
			JSONObject IndiJsonObject = incJsonArr.getJSONObject(i);
			Iterator<String> keys =IndiJsonObject.keys();
			while(keys.hasNext()){
				String key=keys.next();
				if(i==0){
					if(IndiJsonObject.getString(key).length()!=0){
						JSONArray value = new JSONArray();
						value.put(IndiJsonObject.getString(key));
						details.put(key, value);
					}else{
						JSONArray value = new JSONArray();
						details.put(key, value);
					}
				}else{
					if(!(IndiJsonObject.getString(key).isEmpty()) || !(IndiJsonObject.getString(key)==null)){
						if(details.getJSONArray(key).length()>0){
							for(int j=0;j<details.getJSONArray(key).length();j++){
								if(!(IndiJsonObject.getString(key).equals(details.getJSONArray(key).get(j)))){
									details.getJSONArray(key).put(IndiJsonObject.getString(key));
								}
							}
						}else{
							details.getJSONArray(key).put(IndiJsonObject.getString(key));
						}
					}
				}
			}
		}
		Iterator<String> keys =details.keys();
		while(keys.hasNext()){
			String key=keys.next();
			insertArrayListValues(IncExc,key,details.getJSONArray(key),productName,row1,DTname,commercialType,entityType);
		}
	}
	
	
	public static void setFareComponent(JSONObject map, Cell cell, String productName, Row row1, String DTname, String commercialType, String entityType, String name) throws NumberFormatException, IOException {
		if(!(map.get(name).equals(TOTAL))){
			if(map.get(name).equals(BASIC)){
				cell.setCellValue((String)map.get(name));
			}else{
				List<String> fareComponentList = Arrays.asList(((String) map.get(name)).split(","));
				if(fareComponentList.get(0).equals(BASIC)){
					if(fareComponentList.size()>1){
						String fareComponent="",taxComponent="";
						for (int i = 0; i < fareComponentList.size(); i++){
							if(i==0)
								fareComponent=fareComponentList.get(i);
							else if(i==1) taxComponent=fareComponentList.get(i);
							if(i>1){
								taxComponent=taxComponent+"|"+fareComponentList.get(i);
							}
						}
						cell.setCellValue((String)fareComponent);
						int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+TAXCOMPONENT));
						setValue(columnIndex,row1,taxComponent);
					}
				}else{
					List<String> taxComponentList = Arrays.asList(map.get(name).toString().split(","));
					String taxComponent=taxComponentList.get(0);
					if(taxComponentList.size()>1){
						for (int i = 1; i < taxComponentList.size(); i++){
							taxComponent=taxComponent+"|"+taxComponentList.get(i);
						}
					}
					int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+TAXCOMPONENT));
					setValue(columnIndex,row1,taxComponent);
				}
			}
		}else cell.setCellValue((String)map.get(name));
	}
	
	
	public static void setContractValidity(String name, JSONObject jsonObj, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
		Cell cell=null;
		try{
			cell= row1.createCell(columnIndex);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndex));
			cell= row1.createCell(columnIndex);
		}
		cell.setCellValue('"'+getOperatorString(jsonObj,0,"")+'"');
	}
	
	
	public static String getOperatorString(JSONObject jsonObj, int indicator,String value){
		if(jsonObj.getString(OPERATOR).equals(BETWEEN)){
			if(value=="" && indicator==0)
				value=jsonObj.getString(OPERATOR)+";"+jsonObj.getString(FROM)+";"+jsonObj.getString(TO);
			else value= value+";"+jsonObj.getString(FROM)+";"+jsonObj.getString(TO);
		}
		if(jsonObj.getString(OPERATOR).equals(IN)){
			if(value=="" && indicator==0)
				value=jsonObj.getString(OPERATOR)+"/"+jsonObj.getString(VALUE);
			else value= value+"/"+jsonObj.getString(VALUE);
		}
		if(!(jsonObj.getString(OPERATOR).equals(BETWEEN) || jsonObj.getString(OPERATOR).equals(IN)) && indicator==0){
			value=jsonObj.getString(OPERATOR)+";"+jsonObj.getString(VALUE);
		}
		return value;
	}
	
	
	public static void insertArrayListValues(String incExc, String name, JSONArray entireJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		String value=""; int columnIndex;
		if(!(name.equals(SUPPLIERMARKET) && entireJsonArr.getString(0).equals(ALL_MARKETS))){
			for (int j=0; j < entireJsonArr.length(); j++){
				if(j==0){
					if(incExc.equals(INCLUSION_IOTP))
						value=entireJsonArr.getString(j);
					else value='"'+entireJsonArr.getString(j)+'"';
				}
				else{
					if(incExc.equals(INCLUSION_IOTP))
						value+=";"+entireJsonArr.getString(j);
					else value+=","+'"'+entireJsonArr.getString(j)+'"';
				}
			}
			if(incExc.equals(INCLUSION) || incExc.equals(INCLUSION_IOTP))
				columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
			else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name+"_"+EXCLUSION));
			Cell cell=null;
			try{
				cell= row1.createCell(columnIndex);
			}catch(Exception e){
				row1.removeCell(row1.getCell(columnIndex));
				cell= row1.createCell(columnIndex);
			}
			if(incExc.equals(INCLUSION_IOTP)){
				if(name.equals(DAYOFWEEK) && entireJsonArr.getString(0).equals("All")){
					String dayOfWeekAll=DAYSOFWEEK_SUN_TO_SAT;
					cell.setCellValue('"'+dayOfWeekAll+'"');
				}
				else cell.setCellValue('"'+value+'"');
			}else cell.setCellValue(value);
		}
	}
	

	public static void insertOtherFeesPercentage(JSONArray EntireJsonArr, String productName, Row row1, String DTname, String entityType, String commercialType) throws NumberFormatException, IOException {
		String commercialName="",percentage="";
		for (int j=0; j < EntireJsonArr.length(); j++){
			JSONObject PartJsonObject = EntireJsonArr.getJSONObject(j);
			if(j==0){
				commercialName=PartJsonObject.getString(COMMNAME);
				percentage=PartJsonObject.getString(COMMPERCENTAGE);
			}else{
				commercialName+=";"+PartJsonObject.getString(COMMNAME);
				percentage+=";"+PartJsonObject.getString(COMMPERCENTAGE);
			}
		}
		insertIntoSheet("_"+APPLICABLE_COMMNAME, commercialName, productName, entityType, commercialType, DTname, row1);
		
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+APPLICABLE_COMMPERCENTAGE));
		setValue(columnIndex,row1,'"'+percentage+'"');
	}
	
	
	public static void msfFeeInsertion(String value, String productName, Row row1, String DTname, String commercialType, String entityType) throws IOException {
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+CURRENCY+","+AMOUNT));
		setValue(columnIndex,row1,value);
	}
	
	
	public static void insertSlabDetails(JSONObject SlabJSONObject, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		String slabTypeValue=""; JSONObject JSONObj = new JSONObject();
		insertIntoSheet("_"+SLABTYPE, SlabJSONObject.getString(SLABTYPE), productName, entityType, commercialType, DTname, row1);
		if(!(SlabJSONObject.get(SLABTYPEVALUE) instanceof String)){
			JSONObj = SlabJSONObject.getJSONObject(SLABTYPEVALUE);
			if(JSONObj.has(OPERATOR)){
				slabTypeValue=getOperatorString(JSONObj,0,slabTypeValue);
				insertIntoSheet("_"+SLABTYPEVALUE,slabTypeValue,productName,entityType,commercialType,DTname,row1);
			}else{
				int columnIndexMTA = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+MINTOACHIEVE));
				setValue(columnIndexMTA,row1,JSONObj.getString(MINTOACHIEVE));
				int columnIndexMaxTA = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+MAXTOACHIEVE));
				setValue(columnIndexMaxTA,row1,JSONObj.getString(MAXTOACHIEVE));
				if(JSONObj.has(MATCHING_SLABTYPE)){
					insertIntoSheet("_"+MATCHING_SLABTYPE, JSONObj.getString(MATCHING_SLABTYPE), productName, entityType, commercialType, DTname, row1);
				}
			}
		} 
		else insertIntoSheet("_"+SLABTYPEVALUE,SlabJSONObject.getString(SLABTYPEVALUE),productName,entityType,commercialType,DTname,row1);	//slabTypeValue given directly
	}
	
	
	public static void insertIncentiveOnTopUp(JSONObject JsonObj, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, JSONException, IOException {
		Iterator<String> keys =JsonObj.keys();
		while(keys.hasNext()){
			String key=keys.next();
			/*if(key.equals("daily")){														//direct String value
				JSONObject json = new JSONObject(JsonObj.get("daily").toString());
				insertIntoSheet("_hours", json.getString("hours"), productName, entityType, commercialType, DTname, row1);
				insertIntoSheet("_minutes", json.getString("minutes"), productName, entityType, commercialType, DTname, row1);
			}
			else{*/
				JSONObject json = new JSONObject(JsonObj.get(key).toString());
				Iterator<String> jsonkeys =json.keys();
				while(jsonkeys.hasNext()){
					String jsonkey=jsonkeys.next();
					insertArrayListValues(INCLUSION_IOTP, jsonkey, json.getJSONArray(jsonkey), productName, row1, DTname, commercialType, entityType);
				}
			//}
		}
	}
	
	
	public static void setRefreshCounterRule(String DTname, JSONObject map, String selectedRow, String productName, String packageDir, String commercialType, String entityType, Sheet sheet) throws NumberFormatException, IOException {
		Row row = sheet.createRow(sheet.getLastRowNum()+1);
		for (String name : map.keySet()){
			if(name.equals(CONTRACTVALIDITY))
				setContractValidity(CONTRACTVALIDITY,map.getJSONObject(name),productName,row,DTname,commercialType,entityType);
			else if(!name.equals(LOOKTOBOOK))
				insertIntoSheet("_"+name, map.getString(name), productName, entityType, commercialType, DTname, row);
		}
		
		setRefreshCounterValue(productName,entityType,selectedRow,row,commercialType,DTname);
		setFOCBooleanValues("_"+REFRESHCOUNTER_VALUE,productName,entityType,commercialType,DTname,row);
		insertIntoSheet("_"+PRIORITY, "-1", productName, entityType, commercialType, DTname, row);

		int booleanCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_COUNT));
		for(int count=1;count<=booleanCount;count++){
			setFOCBooleanValues("_"+BOOLEAN_VALUE+"_"+count,productName,entityType,commercialType,DTname,row);
		}
		
		int columnIndexSR = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+SELECTEDROW));
		setValue(columnIndexSR,row,selectedRow);
		supplierRefRuleID(productName,entityType,row,selectedRow);
	}
	
	
	public static void setRefreshCounterValue(String productName, String entityType, String selectedRow, Row row, String commercialType, String DTname) throws NumberFormatException, IOException{
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+REFRESHCOUNTER));
		Cell cell=null;
		try{
			cell= row.createCell(columnIndex);
		}catch(Exception e){
			row.removeCell(row.getCell(columnIndex));
			cell= row.createCell(columnIndex);
		}
		switch(productName){
		case PRODUCTNAME_AIR: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.airLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.airClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_ACTIVITIES: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.activitiesLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.activitiesClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_ACCOMODATION: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.accomodationLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.accomodationClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_BUS: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.busLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.busClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_RAIL: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.railLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.railClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_CRUISE: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.cruiseLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.cruiseClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_INSURANCE: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.insuranceLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.insuranceClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_CARRENTALS: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.carLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.carClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_HOLIDAYS: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.holidaysLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.holidaysClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_VISA: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.visaLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.visaClientLTB.get(selectedRow));
			break;
		}
		case PRODUCTNAME_TRANSFERS: {
			if(entityType.equals(SUPPLIER))
				cell.setCellValue(MappingConfiguration.transfersLTB.get(selectedRow));
			else cell.setCellValue(MappingConfiguration.transfersClientLTB.get(selectedRow));
			break;
		}
		}
	}
		

	public static void insertLTB(JSONObject ltbjson, String suppSelectedRow, String clientSelectedRow, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		int refcount=0;
		Iterator<String> keys =ltbjson.keys();
		while(keys.hasNext()){
			String key=keys.next();
			if(key.equals(LOOKRATIO)){
				JSONObject jsonLR = new JSONObject(ltbjson.get(key).toString());
				refcount = Integer.parseInt(jsonLR.get(FROM).toString());
				setContractValidity(key,jsonLR,productName,row1,DTname,commercialType,entityType);
			}
			else insertIntoSheet("_"+key,ltbjson.get(key).toString(),productName,entityType,commercialType,DTname,row1);
		}
		if(DTname.equals(DTNAME_LOOKTOBOOK))
			refreshCounter(suppSelectedRow,clientSelectedRow,refcount,entityType,productName);
		else cumulativeSequence(productName, suppSelectedRow, clientSelectedRow, entityType, commercialType, DTname, row1);
	}
	

	public static void setLookToBookRate(JSONObject ltbjson, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		String rate="";
		JSONObject lookjson = ltbjson.getJSONObject(LOOKRATE);
		rate=lookjson.get(AMOUNT).toString();
		JSONObject bookjson = ltbjson.getJSONObject(BOOKRATE);
		rate=rate+","+bookjson.get(AMOUNT).toString();
		int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+RATE));
		setValue(columnIndex,row1,rate);
		insertIntoSheet("_"+CURRENCY,lookjson.get(CURRENCY).toString(), productName, entityType, commercialType, DTname, row1);
	}
	
	
	public static void getClientTransactionalCommercialHead(JSONObject object, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, JSONException, IOException {
		String commHead="";
		commHead='"'+object.getString(COMMHEADNAME)+'"'+","+'"'+object.getString(COMMTYPE)+'"'+","+'"'+object.getString(COMMPROPERTY)+'"'+","+object.getBoolean(ISCOMMISSIONABLE);
		try{
			int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+object.getString(COMMHEADNAME)));
			setValue(columnIndex,row1,commHead);
		}catch(Exception e){
			System.out.println("commercialHeadName "+COMMHEADNAME+" not specified for the product "+productName);
		}
	}
	
	
	public static void insertFOC(JSONObject focJSONObject, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		if(focJSONObject.has(EVERY)){//FOC Every
			JSONObject jsonEvery = focJSONObject.getJSONObject(EVERY);
			if(jsonEvery.getString(TYPE).equalsIgnoreCase(PAXS)||jsonEvery.getString(TYPE).equalsIgnoreCase(PAX)||jsonEvery.getString(TYPE).equalsIgnoreCase(TKTS)||jsonEvery.getString(TYPE).equalsIgnoreCase(ROOMS)||jsonEvery.getString(TYPE).equalsIgnoreCase(TKT)||jsonEvery.getString(TYPE).equalsIgnoreCase(ROOM))
				insertIntoSheet("_"+EVERY+jsonEvery.getString(TYPE), jsonEvery.getString(EVERY), productName, entityType, commercialType, DTname, row1);
		}else insertSlabDetails(focJSONObject.getJSONObject(SLAB), productName, row1, DTname, commercialType, entityType);
		
		if(focJSONObject.has(FOC_UPGRADES)){
			setFOCBooleanValues("_"+BOOLEAN_UPGRADES,productName,entityType,commercialType,DTname,row1);
			insertFOCSheets(focJSONObject.getJSONObject(FOC_UPGRADES),"_"+FOC_UPGRADES+"_",productName,entityType,commercialType,DTname,row1);
		}else if(focJSONObject.has(FOC_ROOMS)){
			setFOCBooleanValues("_"+BOOLEAN_ROOMS,productName,entityType,commercialType,DTname,row1);
			insertFOCSheets(focJSONObject.getJSONObject(FOC_ROOMS),"_"+FOC_ROOMS+"_",productName,entityType,commercialType,DTname,row1);
		}else if(focJSONObject.has(FOC_TICKETS)){
			setFOCBooleanValues("_"+BOOLEAN_TICKETS,productName,entityType,commercialType,DTname,row1);
			insertFOCSheets(focJSONObject.getJSONObject(FOC_TICKETS),"_"+FOC_TICKETS+"_",productName,entityType,commercialType,DTname,row1);
		}
		
		if(focJSONObject.has(FREEOFCOST)){//ACTIVITIES
			Iterator<String> keys =focJSONObject.getJSONObject(FREEOFCOST).keys();
			while(keys.hasNext()){
				String key=keys.next();
				insertIntoSheet("_"+key, focJSONObject.getJSONObject(FREEOFCOST).getString(key), productName, entityType, commercialType, DTname, row1);
			}
		}
		
		if(focJSONObject.has(FOC_UTILISATION)){
			JSONObject jsonUtilise = focJSONObject.getJSONObject(FOC_UTILISATION);
			Iterator<String> keys =jsonUtilise.keys();
			while(keys.hasNext()){
				String key=keys.next();
				insertArrayListValues(INCLUSION, FOC_UTILISATION+"_"+key, jsonUtilise.getJSONArray(key), productName, row1, DTname, commercialType, entityType);
			}
		}
		
		setFOCFalseValues(productName,entityType,commercialType,DTname,row1);
		setBooleanValuesTrue(productName,entityType,commercialType,DTname,row1);
	}
	
	
	private static void setBooleanValuesTrue(String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException {
		int booleanCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_COUNT));
		for(int count=1;count<=booleanCount;count++){
			int columnIndex=Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_VALUE+"_"+count));
			Cell cell = row1.createCell(columnIndex);
			cell.setCellValue(true);
		}
	}


	private static void setFOCFalseValues(String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException {
		if(Boolean.parseBoolean(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+ARE_FALSECOUNT))){
			int booleanCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+FALSECOUNT));
			for(int count=0;count<=booleanCount;count++){
				int columnIndex=Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+FALSECOUNT_VALUE+"_"+count));
				Cell cell=null;
				try{
					cell= row1.createCell(columnIndex);
				}catch(Exception e){
					row1.removeCell(row1.getCell(columnIndex));
					cell= row1.createCell(columnIndex);
				}
				cell.setCellValue(false);
			}
		}
	}


	private static void setFOCBooleanValues(String value, String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException {
		int columnIndexB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+value));
		Cell cellB=null;
		try{
			cellB= row1.createCell(columnIndexB);
		}catch(Exception e){
			row1.removeCell(row1.getCell(columnIndexB));
			cellB= row1.createCell(columnIndexB);
		}
		cellB.setCellValue(true);
	}


	private static void insertFOCSheets(JSONObject jsonObject, String name, String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, JSONException, IOException {
		Iterator<String> keys =jsonObject.keys();
		while(keys.hasNext()){
			String key=keys.next();
			insertIntoSheet(name+key, jsonObject.getString(key), productName, entityType, commercialType, DTname, row1);
		}
	}
	
	
	public static void cumulativeSequence(String productName, String suppSelectedRow, String clientSelectedRow, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException{
		switch(productName){
		case PRODUCTNAME_AIR: {checkCumulativeSequence(MappingConfiguration.airLTBCumSeq,MappingConfiguration.airClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_ACTIVITIES: {checkCumulativeSequence(MappingConfiguration.activitiesLTBCumSeq,MappingConfiguration.activitiesClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_ACCOMODATION: {checkCumulativeSequence(MappingConfiguration.accomodationLTBCumSeq,MappingConfiguration.accomodationClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_BUS: {checkCumulativeSequence(MappingConfiguration.busLTBCumSeq,MappingConfiguration.busClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_RAIL: {checkCumulativeSequence(MappingConfiguration.railLTBCumSeq,MappingConfiguration.railClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_CRUISE: {checkCumulativeSequence(MappingConfiguration.cruiseLTBCumSeq,MappingConfiguration.cruiseClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_INSURANCE: {checkCumulativeSequence(MappingConfiguration.insuranceLTBCumSeq,MappingConfiguration.insuranceClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_CARRENTALS: {checkCumulativeSequence(MappingConfiguration.carLTBCumSeq,MappingConfiguration.carClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_HOLIDAYS: {checkCumulativeSequence(MappingConfiguration.holidaysLTBCumSeq,MappingConfiguration.holidaysClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_VISA: {checkCumulativeSequence(MappingConfiguration.visaLTBCumSeq,MappingConfiguration.visaClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		case PRODUCTNAME_TRANSFERS: {checkCumulativeSequence(MappingConfiguration.transfersLTBCumSeq,MappingConfiguration.transfersClientLTBCumSeq,suppSelectedRow,clientSelectedRow,productName,entityType,commercialType,DTname,row1); break;}
		}
	}
	
	
	public static void checkCumulativeSequence(Map<String,Integer> ltbCumSeq, Map<String,Integer> clientLtbCumSeq, String suppSelectedRow, String clientSelectedRow, String productName, String entityType, String commercialType, String DTname, Row row1) throws NumberFormatException, IOException{
		if(entityType.equals(SUPPLIER)){				//for SUPPLIER
			if(ltbCumSeq.isEmpty() || ltbCumSeq == null){
				ltbCumSeq.put(suppSelectedRow,0);	
			}else{
				if(ltbCumSeq.containsKey(suppSelectedRow)){
					ltbCumSeq.put(suppSelectedRow,ltbCumSeq.get(suppSelectedRow)+1);
				}
				else{
					ltbCumSeq.put(suppSelectedRow,0);
				}	
			}
			insertIntoSheet("_"+CUMULATIVESEQUENCE,ltbCumSeq.get(suppSelectedRow).toString(), productName, entityType, commercialType, DTname, row1);
		}else{											//for CLIENT
			if(clientLtbCumSeq.isEmpty() || clientLtbCumSeq == null){
				clientLtbCumSeq.put(clientSelectedRow,0);	
			}else{
				if(clientLtbCumSeq.containsKey(clientSelectedRow))
					clientLtbCumSeq.put(clientSelectedRow,clientLtbCumSeq.get(clientSelectedRow)+1);
				else clientLtbCumSeq.put(clientSelectedRow,0);
			}
			insertIntoSheet("_"+CUMULATIVESEQUENCE, clientLtbCumSeq.get(clientSelectedRow).toString(), productName, entityType, commercialType, DTname, row1);
		}
	}
	
	
	public static void supplierRefRuleID(String productName, String entityType, Row row, String selectedRow){
		switch(productName){
		case PRODUCTNAME_AIR: {setSupplierRefRuleID(MappingConfiguration.airSupplierRefRuleID, MappingConfiguration.airClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_ACTIVITIES: {setSupplierRefRuleID(MappingConfiguration.activitiesSupplierRefRuleID, MappingConfiguration.activitiesClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_ACCOMODATION: {setSupplierRefRuleID(MappingConfiguration.accomodationSupplierRefRuleID, MappingConfiguration.accomodationClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_BUS: {setSupplierRefRuleID(MappingConfiguration.busSupplierRefRuleID, MappingConfiguration.busClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_RAIL: {setSupplierRefRuleID(MappingConfiguration.railSupplierRefRuleID, MappingConfiguration.railClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_CRUISE: {setSupplierRefRuleID(MappingConfiguration.cruiseSupplierRefRuleID, MappingConfiguration.cruiseClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_INSURANCE: {setSupplierRefRuleID(MappingConfiguration.insuranceSupplierRefRuleID, MappingConfiguration.insuranceClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_CARRENTALS: {setSupplierRefRuleID(MappingConfiguration.carSupplierRefRuleID, MappingConfiguration.carClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_HOLIDAYS: {setSupplierRefRuleID(MappingConfiguration.holidaysSupplierRefRuleID, MappingConfiguration.holidaysClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_VISA: {setSupplierRefRuleID(MappingConfiguration.visaSupplierRefRuleID, MappingConfiguration.visaClientRefRuleID,selectedRow,entityType,row); break;}
		case PRODUCTNAME_TRANSFERS: {setSupplierRefRuleID(MappingConfiguration.transfersSupplierRefRuleID, MappingConfiguration.transfersClientRefRuleID,selectedRow,entityType,row); break;}
		}
	}
	
	
	public static void setSupplierRefRuleID(Map<String,String> suppMap, Map<String,String> clMap, String selectedRow, String entityType, Row row){
		if(entityType.equals(SUPPLIER))
			suppMap.put(selectedRow, selectedRow+"_"+row.getRowNum());
		else clMap.put(selectedRow, selectedRow+"_"+row.getRowNum());
	}
	
	
	public static void refreshCounter(String suppSelectedRow, String clientSelectedRow, int refcount, String entityType, String productName){
		switch(productName){
		case PRODUCTNAME_AIR: {refreshCounter(MappingConfiguration.airLTB,MappingConfiguration.airClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_ACTIVITIES: {refreshCounter(MappingConfiguration.activitiesLTB,MappingConfiguration.activitiesClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_ACCOMODATION: {refreshCounter(MappingConfiguration.accomodationLTB,MappingConfiguration.accomodationClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_BUS: {refreshCounter(MappingConfiguration.busLTB,MappingConfiguration.busClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_RAIL: {refreshCounter(MappingConfiguration.railLTB,MappingConfiguration.railClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_CRUISE: {refreshCounter(MappingConfiguration.cruiseLTB,MappingConfiguration.cruiseClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_INSURANCE: {refreshCounter(MappingConfiguration.insuranceLTB,MappingConfiguration.insuranceClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_CARRENTALS: {refreshCounter(MappingConfiguration.carLTB,MappingConfiguration.carClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_HOLIDAYS: {refreshCounter(MappingConfiguration.holidaysLTB,MappingConfiguration.holidaysClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_VISA: {refreshCounter(MappingConfiguration.visaLTB,MappingConfiguration.visaClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		case PRODUCTNAME_TRANSFERS: {refreshCounter(MappingConfiguration.transfersLTB,MappingConfiguration.transfersClientLTB,suppSelectedRow,clientSelectedRow,entityType,refcount,productName); break;}
		}
	}
	
	
	public static void refreshCounter(Map<String,Integer> mapSupp, Map<String,Integer> mapClient, String suppSelectedRow, String clientSelectedRow, String entityType, int refcount, String productName){
		if(entityType.equals(SUPPLIER)){																											//for SUPPLIER
			if(mapSupp == null || mapSupp.isEmpty()){
				mapSupp.put(suppSelectedRow,refcount);
				setSupplierRefreshCounter(productName);																								//insert refresh counter RULE
			}else if(mapSupp.containsKey(suppSelectedRow)){
				if(refcount<mapSupp.get(suppSelectedRow)){
					setSupplierChangeRefreshCounter(productName);																					//call UPDATE Function
					mapSupp.put(suppSelectedRow,refcount);
				}
			}else {
				setSupplierRefreshCounter(productName);
				mapSupp.put(suppSelectedRow,refcount);
			}
		}else{																																		//for CLIENT
			if(mapClient == null || mapClient.isEmpty()){
				mapClient.put(clientSelectedRow,refcount);
				setClientRefreshCounter(productName);																								//insert refresh counter RULE
			}else if(mapClient.containsKey(clientSelectedRow)){
				if(refcount<mapClient.get(clientSelectedRow)){
					setClientChangeRefreshCounter(productName);																						//call UPDATE Function
					mapClient.put(clientSelectedRow,refcount);
				}
			} else {
				setClientRefreshCounter(productName);
				mapClient.put(clientSelectedRow,refcount);
			}
		}
	}
	
	
	public static void setSupplierRefreshCounter(String productName){
		switch(productName){
		case PRODUCTNAME_AIR: {airrefreshCounterRule=1; break;}
		case PRODUCTNAME_ACTIVITIES: {activitiesrefreshCounterRule=1; break;}
		case PRODUCTNAME_ACCOMODATION: {accomodationrefreshCounterRule=1; break;}
		case PRODUCTNAME_BUS: {busrefreshCounterRule=1; break;}
		case PRODUCTNAME_RAIL: {railrefreshCounterRule=1; break;}
		case PRODUCTNAME_CRUISE: {cruiserefreshCounterRule=1; break;}
		case PRODUCTNAME_INSURANCE: {insurancerefreshCounterRule=1; break;}
		case PRODUCTNAME_CARRENTALS: {carrefreshCounterRule=1; break;}
		case PRODUCTNAME_HOLIDAYS: {holidaysrefreshCounterRule=1; break;}
		case PRODUCTNAME_VISA: {visarefreshCounterRule=1; break;}
		case PRODUCTNAME_TRANSFERS: {transfersrefreshCounterRule=1; break;}
		}
	}
	
	
	public static void setClientRefreshCounter(String productName){
		switch(productName){
		case PRODUCTNAME_AIR: {airclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_ACTIVITIES: {activitiesclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_ACCOMODATION: {accomodationclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_BUS: {busclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_RAIL: {railclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_CRUISE: {cruiseclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_INSURANCE: {insuranceclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_CARRENTALS: {carclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_HOLIDAYS: {holidaysclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_VISA: {visaclientRefreshCounterRule=1; break;}
		case PRODUCTNAME_TRANSFERS: {transfersclientRefreshCounterRule=1; break;}
		}
	}
	
	
	public static void setSupplierChangeRefreshCounter(String productName){
		switch(productName){
		case PRODUCTNAME_AIR: {airchangeRefCount=1; break;}
		case PRODUCTNAME_ACTIVITIES: {activitieschangeRefCount=1; break;}
		case PRODUCTNAME_ACCOMODATION: {accomodationchangeRefCount=1; break;}
		case PRODUCTNAME_BUS: {buschangeRefCount=1; break;}
		case PRODUCTNAME_RAIL: {railchangeRefCount=1; break;}
		case PRODUCTNAME_CRUISE: {cruisechangeRefCount=1; break;}
		case PRODUCTNAME_INSURANCE: {insurancechangeRefCount=1; break;}
		case PRODUCTNAME_CARRENTALS: {carchangeRefCount=1; break;}
		case PRODUCTNAME_HOLIDAYS: {holidayschangeRefCount=1; break;}
		case PRODUCTNAME_VISA: {visachangeRefCount=1; break;}
		case PRODUCTNAME_TRANSFERS: {transferschangeRefCount=1; break;}
		}
	}
	
	
	public static void setClientChangeRefreshCounter(String productName){
		switch(productName){
		case PRODUCTNAME_AIR: {airclientChangeRefCount=1; break;}
		case PRODUCTNAME_ACTIVITIES: {activitiesclientChangeRefCount=1; break;}
		case PRODUCTNAME_ACCOMODATION: {accomodationclientChangeRefCount=1; break;}
		case PRODUCTNAME_BUS: {busclientChangeRefCount=1; break;}
		case PRODUCTNAME_RAIL: {railclientChangeRefCount=1; break;}
		case PRODUCTNAME_CRUISE: {cruiseclientChangeRefCount=1; break;}
		case PRODUCTNAME_INSURANCE: {insuranceclientChangeRefCount=1; break;}
		case PRODUCTNAME_CARRENTALS: {carclientChangeRefCount=1; break;}
		case PRODUCTNAME_HOLIDAYS: {holidaysclientChangeRefCount=1; break;}
		case PRODUCTNAME_VISA: {visaclientChangeRefCount=1; break;}
		case PRODUCTNAME_TRANSFERS: {transfersclientChangeRefCount=1; break;}
		}
	}
	
	
	public static void setTriggerPayout(JSONArray trigPayJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType, String name) throws NumberFormatException, IOException {
		Boolean triggerB = null,payoutB = null;
		String trigger = null,payout=null;
		for(int i=0;i<trigPayJsonArr.length();i++){
			JSONObject json = new JSONObject(trigPayJsonArr.get(i).toString());
			if(i==0){
				triggerB = json.getBoolean(TRIGGER);
				trigger = triggerB.toString();
				payoutB = json.getBoolean(PAYOUT);
				payout = payoutB.toString();
			}else{
				if(json.has(INCLUSION)){
					JSONArray IncJsonArr = json.getJSONArray(INCLUSION);
					Configuration.setTriggerPayoutInclusionExclusion(INCLUSION,IncJsonArr,productName,row1,DTname,commercialType,entityType,name,trigger,payout);
				}else if(json.has(EXCLUSION)){
					JSONArray IncJsonArr = json.getJSONArray(EXCLUSION);
					Configuration.setTriggerPayoutInclusionExclusion(EXCLUSION,IncJsonArr,productName,row1,DTname,commercialType,entityType,name,trigger,payout);
				}else{																																				//other advDef values
					Iterator<String> keys =json.keys();
					while(keys.hasNext()){
						String key=keys.next();
						if(json.get(key) instanceof String){
							int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key));
							setValue(columnIndex,row1,'"'+json.get(key).toString()+'"'+","+'"'+trigger+'"'+","+'"'+payout+'"');
						}else{																																		//IndiJsonObject.get(key) LIST hai!
							if(productName.equals(PRODUCTNAME_ACCOMODATION) && commercialType.equals(TRANSACTIONAL) && (name.equals(PAXTYPE) || name.equals(RATETYPE) || name.equals(RATECODE)))			//for ACCOMODATION only
								insertTriggerPayoutArrayListValues(INCLUSION_IOTP,json.getJSONArray(key),productName,row1,DTname,commercialType,entityType,key,trigger,payout);
							else if(json.get(key) instanceof Boolean){
								if(key.equals(CODESHAREFLIGHTINCLUDED) || key.equals(CODESHAREDFLIGHTINCLUDED)){
									int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key));
									String value = json.getBoolean(key)+","+trigger+","+payout;
									setValue(columnIndex,row1,value);
								}else{
									int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key));
									String value = json.getBoolean(key)+","+'"'+trigger+'"'+","+'"'+payout+'"';
									setValue(columnIndex,row1,value);
								}
							}else{
								insertTriggerPayoutArrayListValues(INCLUSION, json.getJSONArray(key), productName, row1, DTname, commercialType, entityType,key,trigger,payout);
							}
						}
					}
				}
			}
		}
	}
	

	private static void insertTriggerPayoutArrayListValues(String incExc,JSONArray entireJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType, String name, String trigger, String payout) throws NumberFormatException, IOException {
		String value=""; int columnIndex;
		for (int j=0; j < entireJsonArr.length(); j++){
			if(j==0)
				value=entireJsonArr.getString(j);
			else value+=";"+entireJsonArr.getString(j);
		}
		if(incExc.equals(INCLUSION))
			columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
		else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name+"_"+EXCLUSION));
		setValue(columnIndex,row1,'"'+value+'"'+","+'"'+trigger+'"'+","+'"'+payout+'"');
	}
	

	private static void setTriggerPayoutInclusionExclusion(String IncExc, JSONArray incJsonArr, String productName, Row row1, String DTname, String commercialType, String entityType, String name, String trigger, String payout) throws NumberFormatException, IOException {
		String value="";int columnIndex;
		for (int i=0; i < incJsonArr.length(); i++){
			JSONObject IndiJsonObject = (JSONObject)incJsonArr.get(i);
			if(IndiJsonObject.has(OPERATOR) || IndiJsonObject.has(TO)){																							//if the object contains OPERATOR, indicates dates or travel destination 
				if(IndiJsonObject.has(VALUE)){
					value=getOperatorString(IndiJsonObject,i,value);
					if(IncExc.equals(INCLUSION))
						columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
					else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name+"_"+EXCLUSION));
					setValue(columnIndex,row1,'"'+value+'"'+","+'"'+trigger+'"'+","+'"'+payout+'"');
				}
				else{
					if(!(IndiJsonObject.get(TO) instanceof JSONObject)){																							//if it's not a JSONObject, then its a List! The inputs are Date Values
						value=getOperatorString(IndiJsonObject,i,value);
						if(IncExc.equals(INCLUSION))
							columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
						else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name+"_"+EXCLUSION));
						setValue(columnIndex,row1,'"'+value+'"'+","+'"'+trigger+'"'+","+'"'+payout+'"');
					}
					else{																																			//It's a normal JSONObject
						Iterator<String> keys =IndiJsonObject.keys();
						while(keys.hasNext()){
							String key=keys.next();
							if(key.equals(TO)||key.equals(VIA)||key.equals(FROM)){																			//values insertion for to,via,from
								JSONObject ToJsonObject = IndiJsonObject.getJSONObject(key);
								insertTriggerPayoutFTVValues(IncExc,key,ToJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
							}
							else{																																		//values insertion other than to,via,from in same JSONObject
								if(IncExc.equals(INCLUSION))
									columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key));
								else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key+"_"+EXCLUSION));
								setValue(columnIndex,row1,'"'+IndiJsonObject.get(key).toString()+'"'+","+'"'+trigger+'"'+","+'"'+payout+'"');
							}
						}
					}
				}
			}
			else{
				if(IndiJsonObject.has(FAREBASIS)){																												//for AIR specifically
					String fareBasisStringValue='"'+IndiJsonObject.getString(FAREBASIS)+'"'+","+'"'+IndiJsonObject.getString(FAREBASISVALUE)+'"';
					if(IncExc.equals(INCLUSION))
						columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+FAREBASIS));
					else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+FAREBASIS+"_"+EXCLUSION));
					setValue(columnIndex,row1,fareBasisStringValue+","+'"'+trigger+'"'+","+'"'+payout+'"');
				}else{																																				//without TO, indicates other advanced defn values with inc/exc
					Iterator<String> keys =IndiJsonObject.keys();
					while(keys.hasNext()){
						String key=keys.next();
						if(IndiJsonObject.get(key) instanceof String){
							if(IncExc.equals(INCLUSION))
								columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key));
							else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key+"_"+EXCLUSION));
							setValue(columnIndex,row1,'"'+(String)IndiJsonObject.get(key)+'"'+","+'"'+trigger+'"'+","+'"'+payout+'"');
						}
						else{																																		//IndiJsonObject.get(key) LIST hai!
							if(productName.equals(PRODUCTNAME_ACCOMODATION) && commercialType.equals(TRANSACTIONAL) && (name.equals(PAXTYPE) || name.equals(RATETYPE) || name.equals(RATECODE)))			//for ACCOMODATION only
								insertTriggerPayoutArrayListValues(INCLUSION_IOTP,IndiJsonObject.getJSONArray(key),productName,row1,DTname,commercialType,entityType,key,trigger,payout);
							else insertTriggerPayoutArrayListValues(IncExc, IndiJsonObject.getJSONArray(key), productName, row1, DTname, commercialType, entityType,key,trigger,payout);
						}
					}
				}
			}
		}
	}
	
	
	private static void insertTriggerPayoutFTVValues(String IncExc, String key, JSONObject toJsonObject, Row row1, String DTname, String commercialType, String entityType, String productName, String trigger, String payout) throws NumberFormatException, IOException {
		if(toJsonObject.has(CONTINENT))
			TriggerPayoutftvInsertion(CONTINENT,IncExc,key,toJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
		if(toJsonObject.has(COUNTRY))
			TriggerPayoutftvInsertion(COUNTRY,IncExc,key,toJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
		if(toJsonObject.has(STATE))
			TriggerPayoutftvInsertion(STATE,IncExc,key,toJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
		if(toJsonObject.has(CITY))
			TriggerPayoutftvInsertion(CITY,IncExc,key,toJsonObject,row1,DTname,commercialType,entityType,productName,trigger,payout);
	}
	
	
	private static void TriggerPayoutftvInsertion(String value, String IncExc, String key, JSONObject toJsonObject, Row row1, String DTname, String commercialType, String entityType, String productName, String trigger, String payout) throws NumberFormatException, IOException {
		int columnIndex;
		if(IncExc.equals(INCLUSION))
			columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key+value));
		else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+key+value+"_"+EXCLUSION));
		setValue(columnIndex,row1,'"'+(String)toJsonObject.get(value)+'"'+","+'"'+trigger+'"'+","+'"'+payout+'"');
	}


	public static void insertAirBookingClass(JSONObject airCabinClass, String productName, Row row1, String DTname, String commercialType, String entityType) throws NumberFormatException, IOException {
		String value=null;boolean inclusion=false;
		if(airCabinClass.has("cabinClass")){
			inclusion=true;
			value='"'+airCabinClass.getString("cabinClass")+'"';
		}if(airCabinClass.has("cabinClass_exclusion"))
			value='"'+airCabinClass.getString("cabinClass_exclusion")+'"';
		if(airCabinClass.has("rbd"))
			value+=","+'"'+airCabinClass.getString("rbd")+'"';
		if(airCabinClass.has("rbd_exclusion"))
			value+=","+'"'+airCabinClass.getString("rbd_exclusion")+'"';
		if(airCabinClass.has("trigger")){
			value+=","+'"'+airCabinClass.getString("trigger")+'"'+","+'"'+airCabinClass.getString("payout")+'"';
		}
		int columnIndex;
		if(inclusion)
			columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+"CabinClass_RBD"));
		else columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+"CabinClass_RBD"+"_"+EXCLUSION));
		setValue(columnIndex,row1,value);
	}
	
	
	public static boolean checkValid(String RuleID) {
		if(MappingConfiguration._id.isEmpty()||MappingConfiguration._id == null){
			MappingConfiguration._id.put(RuleID, RuleID);
			return true;
		}else{
			if(MappingConfiguration._id.containsKey(RuleID))
				return false;
			else{
				MappingConfiguration._id.put(RuleID, RuleID);
				return true;
			}
		}
	}


	public static void writeIntoDrl(JSONObject map, String DTname, String packageDir, String operationName) throws IOException {
		if(DTname.equals(DTNAME_STD_ADVANCED) || DTname.equals(DTNAME_MARKUP_ADVANCED)){
			String agendaGroup = map.getString(AGENDAGROUP);
			String selectedRow = map.getString(SELECTEDROW);
			String ruleCheck= AGENDA_GROUP+selectedRow+"\"";
			String text = null;File file = null;

			switch(DTname){
			case DTNAME_STD_ADVANCED:{
				if(operationName.equals(DELETE)){
					file=null;
					deleteFromDRL(STANDARD,packageDir+"/"+DRL_STD,agendaGroup,selectedRow);
				}else{
					file = new File(packageDir+"/"+DRL_STD);
					if(!checkIfRuleExists(file,ruleCheck))
						text = DRL_PART1+agendaGroup+DRL_PART2+selectedRow+DRL_PART3_STD+selectedRow+DRL_PART4;
					else file=null;
				}
				break;
			}
			case DTNAME_MARKUP_ADVANCED:{
				if(operationName.equals(DELETE)){
					file=null;
					deleteFromDRL(MARKUP,packageDir+"/"+DRL_MARKUP,agendaGroup,selectedRow);
				}else{
					file = new File(packageDir+"/"+DRL_MARKUP);
					if(!checkIfRuleExists(file,ruleCheck))
						text = DRL_PART1+agendaGroup+DRL_PART2+selectedRow+DRL_PART3_MARKUP+selectedRow+DRL_PART4;
					else file=null;
				}
				break;
			}
			}
			if(file!=null)
				writeContent(file,text);
		}
	}


	private static boolean checkIfRuleExists(File file, String ruleCheck) throws FileNotFoundException {
		Scanner scanner=new Scanner(file);
		while(scanner.hasNextLine()){
			if(ruleCheck.equals(scanner.nextLine().trim())){
				scanner.close();
				return true;
			}
		}scanner.close();
		return false;
	}


	private static void writeContent(File file, String text) throws IOException {
		BufferedWriter output = null;
		FileReader fr = new FileReader(file);
		BufferedReader br  = new BufferedReader(fr);
		while(true){
			if(br.readLine()==null){
				output = new BufferedWriter(new FileWriter(file,true));
				output.write(text);
				break;
			}
		}
		br.close();
		if(output!=null)
			output.close();
	}


	public static void writeDrlContent(String drlName, JSONObject jsonObject, String packageDir) throws IOException{
		String RuleID = jsonObject.getString(RULEID);
		String content = null;File file = null;
		String ruleCheck = RULEFLOWGROUP+RuleID+"\"";
		switch(drlName){
		case STARTCOMMDEFN:{
			file = new File(packageDir+"/"+DRL_STARTCOMMDEFN);
			if(!checkIfRuleExists(file,ruleCheck)){
				content = DRL_PART1+RuleID+STARTCOMMDEFN_DRL_PART2+RuleID+STARTCOMMDEFN_DRL_PART3+RuleID+STARTCOMMDEFN_DRL_PART4;
			}break;
		}
		case START_BYPRODUCT:{
			file = new File(packageDir+"/"+DRL_STARTBYPRODUCT);
			if(!checkIfRuleExists(file,ruleCheck)){
				content = DRL_PART1+RuleID+START_BYPRODUCT_DRL_PART2+RuleID+STARTCOMMDEFN_DRL_PART3+RuleID+START_BYPRODUCT_DRL_PART3;
			}break;
		}
		case NOMARKUP_BYSUPP:{
			file = new File(packageDir+"/"+DRL_NOMARKUP_BYSUPP);
			if(!checkIfRuleExists(file,ruleCheck)){
				content = DRL_PART1+RuleID+NOMARKUP_BYSUPP_DRL_PART2+RuleID+NOMARKUP_BYSUPP_DRL_PART3+RuleID+NOMARKUP_BYSUPP_DRL_PART4+RuleID+NOMARKUP_BYSUPP_DRL_PART5;
			}break;
		}
		case NOSTANDARD_BYSUPP:{
			file = new File(packageDir+"/"+DRL_NOSTANDARD_BYSUPP);
			if(!checkIfRuleExists(file,ruleCheck)){
				content = DRL_PART1+RuleID+NOSTANDARD_BYSUPP_DRL_PART2+RuleID+NOSTANDARD_BYSUPP_DRL_PART3+RuleID+NOSTANDARD_BYSUPP_DRL_PART4+RuleID+NOMARKUP_BYSUPP_DRL_PART5;
			}break;
		}
		case AFTERMARKUP_BYPRODUCT:{
			file = new File(packageDir+"/"+DRL_AFTERMARKUP_BYPRODUCT);
			if(!checkIfRuleExists(file,ruleCheck)){
				content = DRL_PART1+RuleID+AFTERMARKUP_BYPRODUCT_DRL_PART2+RuleID+AFTERMARKUP_BYPRODUCT_DRL_PART3+RuleID+AFTERMARKUP_BYPRODUCT_DRL_PART4+RuleID+NOMARKUP_BYSUPP_DRL_PART5;
			}break;
		}
		case AFTERSTANDARD_BYPRODUCT:{
			file = new File(packageDir+"/"+DRL_AFTERSTANDARD_BYPRODUCT);
			if(!checkIfRuleExists(file,ruleCheck)){
				content = DRL_PART1+RuleID+AFTERSTANDARD_BYPRODUCT_DRL_PART2+RuleID+AFTERSTANDARD_BYPRODUCT_DRL_PART3+RuleID+AFTERMARKUP_BYPRODUCT_DRL_PART4+RuleID+NOMARKUP_BYSUPP_DRL_PART5;
			}break;
		}
		}
		
		if(content!=null)
			writeContent(file,content);
	}


	private static void deleteFromDRL(String commercialName, String drlName, String agendaGroup, String selectedRow) throws IOException {
		String[] configData = new String[11];
		configData[0]="rule \""+agendaGroup+"\"";
		configData[1]=AGENDA_GROUP+selectedRow+"\"";
		if(commercialName.equals(MARKUP)){
			configData[2]=SALIENCE_1000;
			configData[7]=MARKUP_1+selectedRow+MARKUP_STD_2;
		}else{
			configData[2]=SALIENCE_500;
			configData[7]=STD_1+selectedRow+MARKUP_STD_2;
		}
		configData[3]=WHEN;
		configData[4]=ROOT;
		configData[5]=BUSINESS_RULE_INTAKE;
		configData[6]=ENTITY_DETAILS;
		configData[8]=THEN;
		configData[9]=SET_FOCUS;
		configData[10]=END;

		File inputFile = new File(drlName);
		if (!inputFile.isFile()) {
			System.out.println("Parameter is not an existing file");
			return;
		}

		File tempFile = new File(inputFile.getAbsolutePath() + ".tmp");
		BufferedReader br = new BufferedReader(new FileReader(drlName));
		PrintWriter pw = new PrintWriter(new FileWriter(tempFile));
		String line = null;
		int i=0;

		while ((line = br.readLine()) != null) {
			if(i<11){
				if (!line.trim().equals(configData[i])) {
					pw.println(line);
					pw.flush();
				}else i++;
			}else{
				pw.println(line);
				pw.flush();
			}
		}
		pw.close();
		br.close();

		if (!inputFile.delete()) {
			System.out.println("Could not delete file");
			return;
		}

		if (!tempFile.renameTo(inputFile))
			System.out.println("Could not rename file");
	}
	

	public static boolean isBoolean(String name) {
		switch(name){
		case CODESHAREFLIGHTINCLUDED:return true;
		case CODESHAREDFLIGHTINCLUDED:return true;
		case BOOLEAN_APPLICABLEON:return true;
		case BOOLEAN_POSTPROCESSING:return true;
		case BOOLEAN_BYPRODUCT:return true;
		case BOOLEAN_MARKUP_BYPRODUCT:return true;
		case BOOLEAN_STANDARD_BYPRODUCT:return true;
		case BOOLEAN_STANDARD_BYSUPP:return true;
		case SERVICETAX_APPLICABLE:return true;
		case "isTransactional":return true;
		case "overridingByProduct":return true;
		case "plbByProduct":return true;
		case "sectorWiseIncentiveByProduct":return true;
		case "segmentFeeByProduct":return true;
		case "managementFeeByProduct":return true;
		case "serviceChargeByProduct":return true;
		case "discountByProduct":return true;
		case CODESHAREFLIGHTINCLUDED+"_exclusion":return true;
		case CODESHAREDFLIGHTINCLUDED+"_exclusion":return true;
		}
		return false;
	}
}