package cnk.cce.configuration.products;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.json.JSONArray;
import org.json.JSONObject;
import cnk.cce.configuration.Constants;
import cnk.cce.configuration.MappingConfiguration;
import cnk.cce.maven.MavenInvoker;

public class RuleFunctions implements Constants{

	public static void insertFunction(String DTname, JSONObject map, String productName, String entityType, String commercialType, String packageDir) throws NumberFormatException, IOException {
		try{
			HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(packageDir+"/"+DTname+".xls")));
			Sheet sheet = wb.getSheetAt(0);
			Row row1 = sheet.createRow(getLastRow(sheet)+1);

			int booleanCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_COUNT));
			for(int count=1;count<=booleanCount;count++){
				//System.out.println(entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_VALUE+"_"+count);
				int columnIndex=Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_VALUE+"_"+count));
				Cell cell = row1.createCell(columnIndex);
				if(commercialType.equals(SETTLEMENT) && (entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_VALUE+"_"+count).equals((entityType+"_"+SETT_DTNAME_SIGNUPBONUS+"_"+BOOLEAN_VALUE+"_1")) || (entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_VALUE+"_"+count).equals(entityType+"_"+SETT_DTNAME_PENALTYFEE+"_"+BOOLEAN_VALUE+"_1"))
					cell.setCellValue(false);
				else cell.setCellValue(true);
			}

			if(Boolean.parseBoolean(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+BOOLEAN_HARDCODE))){
				int hardCodeCount = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+HARDCODE_COUNT));
				for(int count=1;count<=hardCodeCount;count++){
					Cell cell = row1.createCell(Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+HARDCODE_INDEX+"_"+count)));
					try{
						int value = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+HARDCODE_VALUE+"_"+count));
						cell.setCellValue(value);
					}catch(Exception e){
						cell.setCellValue(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+HARDCODE_VALUE+"_"+count));
					}
				}
			}
			
			for (String name : map.keySet()){
				int indicator=0;
				if(!name.equals(TYPE) && !name.equals(COMMERCIAL_ID) && !name.equals(KEY) && !name.equals(PREPROCESS_BYPRODUCT) && !(DTname.equals(DTNAME_COMMDEFN_PREPROCESS) && name.equals(RULEID))){
					if(DTname.equals(DTNAME_MSFFEE) && (name.equals(CURRENCY) || name.equals(AMOUNT))){
						indicator=1;
						if(map.has(AMOUNT)){
							String value = "\""+map.getString(CURRENCY)+"\","+map.get(AMOUNT);
							Configuration.msfFeeInsertion(value, productName, row1, DTname, commercialType, entityType);
						}
					}
					if(map.get(name) instanceof JSONArray){
						JSONArray EntireJsonArr = map.getJSONArray(name);
						for (int j=0; j < EntireJsonArr.length(); j++){
							if(EntireJsonArr.length()>0){
								if(EntireJsonArr.get(j) instanceof String){																									//value is ArrayList
									indicator=1;
									if(productName.equals(PRODUCTNAME_ACCOMODATION) && commercialType.equals(TRANSACTIONAL) && (name.equals(PAXTYPE) || name.equals(RATETYPE) || name.equals(RATECODE)))			//for ACCOMODATION only
										Configuration.insertArrayListValues(INCLUSION_IOTP,name,EntireJsonArr,productName,row1,DTname,commercialType,entityType);
									else Configuration.insertArrayListValues(INCLUSION,name,EntireJsonArr,productName,row1,DTname,commercialType,entityType);
									break;
								}else{
									JSONObject PartJsonObject = EntireJsonArr.getJSONObject(j);																				//value is JSONObject
									if(name.equals(COMMHEAD) || PartJsonObject.has(INCLUSION) || PartJsonObject.has(EXCLUSION) || PartJsonObject.has(TRIGGER)){
										if(name.equals(COMMHEAD)){
											indicator = 1;
											if(entityType.equals(SUPPLIER)){																								//entityType: SUPPLIER
												if(commercialType.equals(TRANSACTIONAL))
													Configuration.getSupplierTransactionalCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);
												else Configuration.getSupplierSettlementCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);
											}else{																															//entityType: CLIENT
												if(commercialType.equals(TRANSACTIONAL))
													Configuration.getClientTransactionalCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);
												else Configuration.getSupplierSettlementCommercialHead(PartJsonObject,productName,row1,DTname,commercialType,entityType);	//functionality is same for both client & supplier
											}
										}
										if(PartJsonObject.has(TRIGGER)){
											indicator=1;
											Configuration.setTriggerPayout(EntireJsonArr,productName,row1,DTname,commercialType,entityType,name);
											break;
										}
										if(PartJsonObject.has(INCLUSION)){
											indicator=1;
											JSONArray IncJsonArr = PartJsonObject.getJSONArray(INCLUSION);
											Configuration.setInclusionExclusion(INCLUSION,IncJsonArr,productName,row1,DTname,commercialType,entityType,name);
										}
										if(PartJsonObject.has(EXCLUSION)){
											indicator=1;
											JSONArray IncJsonArr = PartJsonObject.getJSONArray(EXCLUSION);
											Configuration.setInclusionExclusion(EXCLUSION,IncJsonArr,productName,row1,DTname,commercialType,entityType,name);
										}
									}else if(commercialType.equals(SETTLEMENT)){
										if(name.equals(PERCENTAGE) || name.equals(RETURNABLE_COMMHEAD)){
											indicator=1;
											Configuration.insertOtherFeesPercentage(EntireJsonArr,productName,row1,DTname,entityType,commercialType);					//OtherFees : commercialPercentage
											break;
										}
									}
								}
							}
						}
					}
					switch(name){
					case "airCabinClass": {
						indicator=1;
						Configuration.insertAirBookingClass(map.getJSONObject(name),productName,row1,DTname,commercialType,entityType);break;
					}
					case SLABDETAILS: {
						indicator=1;
						Configuration.insertSlabDetails(map.getJSONObject(name),productName,row1,DTname,commercialType,entityType); break;
					}
					case CONTRACTVALIDITY: {
						indicator=1;
						Configuration.setContractValidity(name,map.getJSONObject(name),productName,row1,DTname,commercialType,entityType); break;
					}
					case TOTALSETTLEMENTAMOUNT: {
						indicator=1;
						Configuration.setContractValidity(name,map.getJSONObject(name),productName,row1,DTname,commercialType,entityType); break;
					}
					case PERIODFORTOPUP: {
						indicator=1;
						Configuration.insertIncentiveOnTopUp(map.getJSONObject(name),productName,row1,DTname,commercialType,entityType); break;
					}
					case FREEOFCOSTS: {
						indicator=1;
						Configuration.insertFOC(map.getJSONObject(name),productName,row1,DTname,commercialType,entityType); break;
					}
					case LOOKTOBOOK: {
						indicator=1;
						if(!map.getJSONObject(name).has(LOOKRATE))																						//Look to Book by Ratio
							Configuration.insertLTB(map.getJSONObject(name),map.getString(SELECTEDROW),map.getString(SELECTEDROW),productName,row1,DTname,commercialType,entityType);
						else Configuration.setLookToBookRate(map.getJSONObject(name),productName,row1,DTname,commercialType,entityType);					//Look to Book by Rate
					}
					}

					if(indicator==0){
						//System.out.println(entityType+"_"+commercialType+"_"+DTname+"_"+name);
						int columnIndex = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+name));
						Cell cell = row1.createCell(columnIndex);
						if(Configuration.isBoolean(name)){
							cell.setCellValue(Boolean.parseBoolean(map.get(name).toString()));
						}else{
							try{
								if(name.equals("mid"))
									throw new Exception();
								double value=Double.parseDouble(map.getString(name));
								if(checkIfString(map.getString(name)))
									throw new Exception();
								
								cell.setCellValue(value);
							}catch(Exception e){
								if((map.get(TYPE).equals(CALCULATION) && (name.equals(FARECOMPONENT)||name.equals(CURRENCY))) || name.equals(MDMRULEID) || name.equals(AGENDAGROUP)){
									if(name.equals(FARECOMPONENT))
										Configuration.setFareComponent(map,cell,productName,row1,DTname,commercialType,entityType,name);
									else cell.setCellValue(map.getString(name));
								}
								else cell.setCellValue('"'+map.getString(name)+'"');
							}
						}
					}
				}
			}

			FileOutputStream fos = new FileOutputStream(packageDir+"/"+DTname+".xls");
			wb.write(fos);

			if(commercialType.equals(SETTLEMENT) && (DTname.equals(DTNAME_LOOKTOBOOK) || DTname.equals(DTNAME_LOOKTOBOOKCUMULATIVE)))
				checkLookToBook(DTname,map,map.getString(SELECTEDROW),map.getString(SELECTEDROW),packageDir,productName,commercialType,entityType,sheet,wb);

			FileOutputStream fos1 = new FileOutputStream(packageDir+"/"+DTname+".xls");
			wb.write(fos1);
			fos1.close();
			fos.close();
			wb.close();
		}catch(FileNotFoundException e){
			System.out.println("File "+DTname+" not found");
		}
	}


	private static boolean checkIfString(String value) {
		int counter = 0;
		if(value.equals("0"))
			return false;
		for (int i=0; i < value.length(); i++) {
			if (value.charAt(i) == '0') {
				counter++;
		    }else break;
		}
		
		if(counter>1)
			return true;
		else if(counter==1 && value.charAt(counter)!='.')
			return true;
		
		return false;
	}


	public static void checkLookToBook(String DTname, JSONObject map, String suppSelectedRow, String clientSelectedRow, String packageDir, String productName, String commercialType, String entityType, Sheet sheet, HSSFWorkbook wb) throws NumberFormatException, IOException{
		switch(productName){
		case PRODUCTNAME_AIR: {
			lookToBook(Configuration.airclientRefreshCounterRule,Configuration.airrefreshCounterRule,Configuration.airclientChangeRefCount,Configuration.airchangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.airClientRefRuleID,MappingConfiguration.airClientLTB,MappingConfiguration.airSupplierRefRuleID,MappingConfiguration.airLTB,map,packageDir,sheet);
			Configuration.airclientRefreshCounterRule=0;Configuration.airrefreshCounterRule=0;Configuration.airclientChangeRefCount=0;Configuration.airchangeRefCount=0; break;
		}
		case PRODUCTNAME_ACTIVITIES: {
			lookToBook(Configuration.activitiesclientRefreshCounterRule,Configuration.activitiesrefreshCounterRule,Configuration.activitiesclientChangeRefCount,Configuration.activitieschangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.activitiesClientRefRuleID,MappingConfiguration.activitiesClientLTB,MappingConfiguration.activitiesSupplierRefRuleID,MappingConfiguration.activitiesLTB,map,packageDir,sheet);
			Configuration.activitiesclientRefreshCounterRule=0;Configuration.activitiesrefreshCounterRule=0;Configuration.activitiesclientChangeRefCount=0;Configuration.activitieschangeRefCount=0; break;
		}
		case PRODUCTNAME_ACCOMODATION: {
			lookToBook(Configuration.accomodationclientRefreshCounterRule,Configuration.accomodationrefreshCounterRule,Configuration.accomodationclientChangeRefCount,Configuration.accomodationchangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.accomodationClientRefRuleID,MappingConfiguration.accomodationClientLTB,MappingConfiguration.accomodationSupplierRefRuleID,MappingConfiguration.accomodationLTB,map,packageDir,sheet);
			Configuration.accomodationclientRefreshCounterRule=0;Configuration.accomodationrefreshCounterRule=0;Configuration.accomodationclientChangeRefCount=0;Configuration.accomodationchangeRefCount=0; break;
		}
		case PRODUCTNAME_BUS: {
			lookToBook(Configuration.busclientRefreshCounterRule,Configuration.busrefreshCounterRule,Configuration.busclientChangeRefCount,Configuration.buschangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.busClientRefRuleID,MappingConfiguration.busClientLTB,MappingConfiguration.busSupplierRefRuleID,MappingConfiguration.busLTB,map,packageDir,sheet);
			Configuration.busclientRefreshCounterRule=0;Configuration.busrefreshCounterRule=0;Configuration.busclientChangeRefCount=0;Configuration.buschangeRefCount=0; break;
		}
		case PRODUCTNAME_RAIL: {
			lookToBook(Configuration.railclientRefreshCounterRule,Configuration.railrefreshCounterRule,Configuration.railclientChangeRefCount,Configuration.railchangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.railClientRefRuleID,MappingConfiguration.railClientLTB,MappingConfiguration.railSupplierRefRuleID,MappingConfiguration.railLTB,map,packageDir,sheet);
			Configuration.railclientRefreshCounterRule=0;Configuration.railrefreshCounterRule=0;Configuration.railclientChangeRefCount=0;Configuration.railchangeRefCount=0; break;
		}
		case PRODUCTNAME_CRUISE: {
			lookToBook(Configuration.cruiseclientRefreshCounterRule,Configuration.cruiserefreshCounterRule,Configuration.cruiseclientChangeRefCount,Configuration.cruisechangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.cruiseClientRefRuleID,MappingConfiguration.cruiseClientLTB,MappingConfiguration.cruiseSupplierRefRuleID,MappingConfiguration.cruiseLTB,map,packageDir,sheet);
			Configuration.cruiseclientRefreshCounterRule=0;Configuration.cruiserefreshCounterRule=0;Configuration.cruiseclientChangeRefCount=0;Configuration.cruisechangeRefCount=0; break;
		}
		case PRODUCTNAME_INSURANCE: {
			lookToBook(Configuration.insuranceclientRefreshCounterRule,Configuration.insurancerefreshCounterRule,Configuration.insuranceclientChangeRefCount,Configuration.insurancechangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.insuranceClientRefRuleID,MappingConfiguration.insuranceClientLTB,MappingConfiguration.insuranceSupplierRefRuleID,MappingConfiguration.insuranceLTB,map,packageDir,sheet);
			Configuration.insuranceclientRefreshCounterRule=0;Configuration.insurancerefreshCounterRule=0;Configuration.insuranceclientChangeRefCount=0;Configuration.insurancechangeRefCount=0; break;
		}
		case PRODUCTNAME_CARRENTALS: {
			lookToBook(Configuration.carclientRefreshCounterRule,Configuration.carrefreshCounterRule,Configuration.carclientChangeRefCount,Configuration.carchangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.carClientRefRuleID,MappingConfiguration.carClientLTB,MappingConfiguration.carSupplierRefRuleID,MappingConfiguration.carLTB,map,packageDir,sheet);
			Configuration.carclientRefreshCounterRule=0;Configuration.carrefreshCounterRule=0;Configuration.carclientChangeRefCount=0;Configuration.carchangeRefCount=0; break;
		}
		case PRODUCTNAME_HOLIDAYS: {
			lookToBook(Configuration.holidaysclientRefreshCounterRule,Configuration.holidaysrefreshCounterRule,Configuration.holidaysclientChangeRefCount,Configuration.holidayschangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.holidaysClientRefRuleID,MappingConfiguration.holidaysClientLTB,MappingConfiguration.holidaysSupplierRefRuleID,MappingConfiguration.holidaysLTB,map,packageDir,sheet);
			Configuration.holidaysclientRefreshCounterRule=0;Configuration.holidaysrefreshCounterRule=0;Configuration.holidaysclientChangeRefCount=0;Configuration.holidayschangeRefCount=0; break;
		}
		case PRODUCTNAME_VISA: {
			lookToBook(Configuration.visaclientRefreshCounterRule,Configuration.visarefreshCounterRule,Configuration.visaclientChangeRefCount,Configuration.visachangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.visaClientRefRuleID,MappingConfiguration.visaClientLTB,MappingConfiguration.visaSupplierRefRuleID,MappingConfiguration.visaLTB,map,packageDir,sheet);
			Configuration.visaclientRefreshCounterRule=0;Configuration.visarefreshCounterRule=0;Configuration.visaclientChangeRefCount=0;Configuration.visachangeRefCount=0; break;
		}
		case PRODUCTNAME_TRANSFERS: {
			lookToBook(Configuration.transfersclientRefreshCounterRule,Configuration.transfersrefreshCounterRule,Configuration.transfersclientChangeRefCount,Configuration.transferschangeRefCount,suppSelectedRow,clientSelectedRow,entityType,commercialType,DTname,productName,MappingConfiguration.transfersClientRefRuleID,MappingConfiguration.transfersClientLTB,MappingConfiguration.transfersSupplierRefRuleID,MappingConfiguration.transfersLTB,map,packageDir,sheet);
			Configuration.transfersclientRefreshCounterRule=0;Configuration.transfersrefreshCounterRule=0;Configuration.transfersclientChangeRefCount=0;Configuration.transferschangeRefCount=0; break;
		}
		}

		FileOutputStream fos1 = new FileOutputStream(packageDir+"/"+DTname+".xls");
		wb.write(fos1);
		fos1.close();
	}


	public static void lookToBook(int clientRefreshCounterRule, int refreshCounterRule, int clientChangeRefCount, int changeRefCount, String suppSelectedRow, String clientSelectedRow, String entityType, String commercialType, String DTname, String productName, Map<String,String> clientRefRuleID, Map<String,Integer> clientLTB, Map<String,String> supplierRefRuleID, Map<String,Integer> ltb, JSONObject map, String packageDir, Sheet sheet) throws NumberFormatException, IOException{
		if(clientRefreshCounterRule==1)
			Configuration.setRefreshCounterRule(DTname,map,clientSelectedRow,productName,packageDir,commercialType,entityType,sheet);

		if(refreshCounterRule==1)
			Configuration.setRefreshCounterRule(DTname,map,suppSelectedRow,productName,packageDir,commercialType,entityType,sheet);

		if(clientChangeRefCount==1){	//update refreshCounter Rule [CLIENT]
			List<String> rowNumber = Arrays.asList(clientRefRuleID.get(clientSelectedRow).split("_"));
			Row row=sheet.getRow(Integer.parseInt(rowNumber.get(4)));
			int columnIndexLTB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+REFRESHCOUNTER));
			Cell cellLTB = row.getCell(columnIndexLTB);
			if(cellLTB == null)
				cellLTB = row.createCell(columnIndexLTB);
			cellLTB.setCellValue(clientLTB.get(clientSelectedRow));
		}

		if(changeRefCount==1){			//update refreshCounter Rule [SUPPLIER]
			List<String> rowNumber = Arrays.asList(supplierRefRuleID.get(suppSelectedRow).split("_"));
			Row row=sheet.getRow(Integer.parseInt(rowNumber.get(1)));
			int columnIndexLTB = Integer.parseInt(MavenInvoker.getInstance().getProductProperties(productName).getProperty(entityType+"_"+commercialType+"_"+DTname+"_"+REFRESHCOUNTER));
			Cell cellLTB = row.getCell(columnIndexLTB);
			if(cellLTB == null)
				cellLTB = row.createCell(columnIndexLTB);
			cellLTB.setCellValue(ltb.get(suppSelectedRow));
			Configuration.setContractValidity(CONTRACTVALIDITY,map.getJSONObject(CONTRACTVALIDITY),productName,row,DTname,commercialType,entityType);
		}
	}


	public static String deleteRule(int removeFromMappingConfig, String DTname, JSONObject map, String packageDir, String productName, String commercialType, String entityType) throws IOException{
		InputStream inp = new FileInputStream(packageDir+"/"+DTname+".xls");
		HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(inp));
		Sheet sheet = wb.getSheetAt(0);
		String RuleID=null;
		if(map.has(BOOKING_ID))
			RuleID=map.get(RULEID).toString();
		else RuleID=map.get(KEY).toString();
		List<Integer> toRemove = addRowsToList(sheet,RuleID);

		if(!toRemove.isEmpty()){
			deleteRows(toRemove,sheet);
			if(removeFromMappingConfig==1)
				System.out.println(DTname+": Deleted");
		}

		FileOutputStream fos = new FileOutputStream(packageDir+"/"+DTname+".xls");
		wb.write(fos); fos.close(); wb.close(); inp.close();

		return "SuccessFul";
	}
	

	public static List<Integer> addRowsToList(Sheet sheet, String RuleID) {
		List<Integer> toRemove = new ArrayList<Integer>();
		for (Row row: sheet){
			int count=0;
			for (Cell cell: row){
				if(count<1){
					switch(cell.getCellTypeEnum()){
					case NUMERIC:{break;}
					case BOOLEAN:{break;}
					default:{
						if(cell.getStringCellValue().contains(RuleID)){
							toRemove.add(row.getRowNum());
							break;
						}break;
					}
					}
					count++;
				}
			}
		}
		return toRemove;
	}
	
	
	public static void deleteRows(List<Integer> toRemove, Sheet sheet) {
		for(int i=toRemove.size()-1;i>=0;i--){
			int num = toRemove.get(i);
			deleteFunction(sheet, num);
		}
	}

	
	private static void deleteFunction(Sheet sheet, int num) {
		Row row1 = sheet.getRow(num);
		sheet.removeRow(row1);
		if(num-1==getLastRow(sheet))
			sheet.shiftRows(getLastRow(sheet),num,0);
		else sheet.shiftRows(num+1,getLastRow(sheet),-1);
	}
	
	
	public static int getLastRow(final Sheet sheet){
		int lastRowNum = sheet.getLastRowNum();
		int rowNum = lastRowNum;
		for (rowNum = lastRowNum; rowNum > 8; rowNum--) {
			Row r = sheet.getRow(rowNum);
			if (checkIfRowIsEmpty(r))
				continue;
			else break;
		}
		return rowNum;
	}

	
	private static boolean checkIfRowIsEmpty(Row row) {
		if (row == null) 
			return true;

		if (row.getLastCellNum() <= 0) 
			return true;

		for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
			Cell cell = row.getCell(cellNum);
			if (cell != null && cell.getCellTypeEnum() != CellType.BLANK && StringUtils.isNotBlank(cell.toString())) 
				return false;
		}
		return true;
	}

	/*public static void removeRows(final Sheet sheet, int rowNum){
		Row row=sheet.getRow(rowNum);
		sheet.removeRow(row);
		if(rowNum-1==getLastRow(sheet))
			sheet.shiftRows(getLastRow(sheet),rowNum,0);
		else sheet.shiftRows(rowNum+1,getLastRow(sheet),-1);
	}*/
}
