package cnk.cce.configuration;

import org.json.JSONObject;

public interface Rule {

	void createRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception;
	void updateRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception;
	void deleteRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception;
}