package cnk.cce.configuration.products;

import java.io.IOException;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import cnk.cce.configuration.Constants;
import cnk.cce.configuration.MappingConfiguration;
import cnk.cce.configuration.Rule;

public class RuleGenerator implements Rule,Constants{

	@Override
	public void createRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception{
		Iterator<String> keys =data.keys();
		while(keys.hasNext()){
			String key=keys.next();								//key is the DTname
			if(data.get(key) instanceof JSONArray){
				JSONArray keyData = data.getJSONArray(key);
				for(int i=0;i<keyData.length();i++){
					if(Configuration.checkValid(keyData.getJSONObject(i).getString(COMMERCIAL_ID))){
						RuleFunctions.insertFunction(key,keyData.getJSONObject(i),productName,entityType,commercialType,packageDir);
					}else{
						RuleFunctions.deleteRule(0,key, keyData.getJSONObject(0), packageDir, productName, commercialType, entityType);
						RuleFunctions.insertFunction(key,keyData.getJSONObject(i),productName,entityType,commercialType,packageDir);
					}
				}
			}else{
				if(Configuration.checkValid(data.getJSONObject(key).getString(COMMERCIAL_ID)))
					RuleFunctions.insertFunction(key,data.getJSONObject(key),productName,entityType,commercialType,packageDir);
				else{
					RuleFunctions.deleteRule(0,key, data.getJSONObject(key), packageDir, productName, commercialType, entityType);
					RuleFunctions.insertFunction(key,data.getJSONObject(key),productName,entityType,commercialType,packageDir);
				}
			}
			if(entityType.equals(CLIENT) && commercialType.equals(TRANSACTIONAL))
				writeDrl(data, packageDir, commercialType, entityType, key, INSERT);
		}
	}

	@Override
	public void updateRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception {
		Iterator<String> keys =data.keys();
		while(keys.hasNext()){
			String key=keys.next();
			if(data.get(key) instanceof JSONArray){
				JSONArray keyData = data.getJSONArray(key);
				if(keyData.length()>0)
					RuleFunctions.deleteRule(0,key, keyData.getJSONObject(0), packageDir, productName, commercialType, entityType);
				for(int i=0;i<keyData.length();i++){
					RuleFunctions.insertFunction(key,keyData.getJSONObject(i),productName,entityType,commercialType,packageDir);
				}
			}else{
				RuleFunctions.deleteRule(0,key, data.getJSONObject(key), packageDir, productName, commercialType, entityType);
				RuleFunctions.insertFunction(key,data.getJSONObject(key),productName,entityType,commercialType,packageDir);
			}
			if(entityType.equals(CLIENT) && commercialType.equals(TRANSACTIONAL))
				writeDrl(data, packageDir, commercialType, entityType, key, INSERT);
		}
	}

	@Override
	public void deleteRule(JSONObject data, String packageDir, String productName, String commercialType, String entityType) throws Exception {
		Iterator<String> keys =data.keys();
		while(keys.hasNext()){
			String key=keys.next();
			if(data.get(key) instanceof JSONArray){
				JSONArray keyData = data.getJSONArray(key);
				if(keyData.length()>0)
					RuleFunctions.deleteRule(1,key, keyData.getJSONObject(0), packageDir, productName, commercialType, entityType);
				for(int i=0;i<keyData.length();i++){
					MappingConfiguration._id.remove(keyData.getJSONObject(i).getString(COMMERCIAL_ID));
				}
			}else{
				RuleFunctions.deleteRule(1,key, data.getJSONObject(key), packageDir, productName, commercialType, entityType);
				MappingConfiguration._id.remove(data.getJSONObject(key).getString(COMMERCIAL_ID));
			}
			if(entityType.equals(CLIENT) && commercialType.equals(TRANSACTIONAL))
				writeDrl(data, packageDir, commercialType, entityType, key, DELETE);
		}
	}

	private void writeDrl(JSONObject data, String packageDir, String commercialType, String entityType, String key, String operationName) throws JSONException, IOException {
		if(data.get(key) instanceof JSONObject){
			if(data.getJSONObject(key).getString(TYPE).equals(ADVANCED))
				Configuration.writeIntoDrl(data.getJSONObject(key),key,packageDir,operationName);
		}else{
			JSONArray keyData = data.getJSONArray(key);
			if(keyData.getJSONObject(0).getString(TYPE).equals(ADVANCED))
				Configuration.writeIntoDrl(keyData.getJSONObject(0),key,packageDir,operationName);
		}
		
		//TODO delete logic
		if(key.equals(DTNAME_COMMDEFN)){
			JSONObject commDefn = data.getJSONObject(key);
			if(commDefn.getBoolean(BOOLEAN_BYPRODUCT)){
				Configuration.writeDrlContent(STARTCOMMDEFN,data.getJSONObject(key),packageDir);
			}else{
				Configuration.writeDrlContent(START_BYPRODUCT,data.getJSONObject(key),packageDir);
				Configuration.writeDrlContent(NOMARKUP_BYSUPP,data.getJSONObject(key),packageDir);
				Configuration.writeDrlContent(NOSTANDARD_BYSUPP,data.getJSONObject(key),packageDir);
			}
		}
		
		if(key.equals(DTNAME_COMMDEFN_PREPROCESS)){
			JSONObject commDefnPreProcess = data.getJSONObject(key);
			if(commDefnPreProcess.getBoolean(PREPROCESS_BYPRODUCT)){
				if(commDefnPreProcess.has(BOOLEAN_MARKUP_BYPRODUCT)){
					Configuration.writeDrlContent(AFTERMARKUP_BYPRODUCT,data.getJSONObject(key),packageDir);
				}
				if(commDefnPreProcess.has(BOOLEAN_STANDARD_BYPRODUCT)){
					Configuration.writeDrlContent(AFTERSTANDARD_BYPRODUCT,data.getJSONObject(key),packageDir);
				}
			}
		}
		
	}
}
